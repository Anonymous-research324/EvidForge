"""Reporting only; all means/SD and costs come from immutable scored outputs and real responses."""
from pathlib import Path
import statistics,time,collections
from common import ROOT,load,save,sha
def summary(v):
 n=sum(x is not None for x in v)
 return {"mean":statistics.mean(v) if n==3 else None,"sd":statistics.stdev(v) if n==3 else None,"n":n,"seed_values":v}
def build(rows):
 groups=[]
 for dataset in load(ROOT/"configs/protocol.json")["datasets"]:
  for n in [5,10,20]:
   rs=sorted([x for x in rows if x["dataset"]==dataset and x["learning_groups"]==n],key=lambda x:x["seed"]);assert [x["seed"] for x in rs]==[1013,1014,1015]
   g={"dataset":dataset,"learning_groups":n,"validation_groups":n,"qualified_seeds":sum(x["qualified"] for x in rs)}
   for metric in ["P","R","F1","normal_damage"]:g[metric]=summary([x["repair"][metric] for x in rs])
   g["actual_calls"]=summary([x["cost"]["actual_calls"] for x in rs])
   g["learning_seconds"]=summary([x["learning_seconds"] for x in rs])
   g["labeled_target_cells_learning"]=summary([x["zones"]["learning"]["confirmed_target_cells"] for x in rs])
   g["labeled_target_cells_validation"]=summary([x["zones"]["validation"]["confirmed_target_cells"] for x in rs])
   groups.append(g)
 save(ROOT/"reports/aggregate.json",groups)
 paired=[]
 for dataset in load(ROOT/"configs/protocol.json")["datasets"]:
  for a,b in [(5,10),(10,20),(5,20)]:
   before={x["seed"]:x for x in rows if x["dataset"]==dataset and x["learning_groups"]==a}
   after={x["seed"]:x for x in rows if x["dataset"]==dataset and x["learning_groups"]==b}
   paired.append({"dataset":dataset,"from":a,"to":b,**{k:summary([after[s]["repair"][k]-before[s]["repair"][k] if after[s]["repair"][k] is not None and before[s]["repair"][k] is not None else None for s in [1013,1014,1015]]) for k in ["F1","normal_damage"]}})
 save(ROOT/"reports/paired_differences.json",paired)
 # Real model costs include every response, including any failed call (failure blocks final report).
 costs=[]
 for gpu in [0,1]:
  for p in sorted((ROOT/"services"/("gpu"+str(gpu))/"requests").glob("*")):
   if not (p/"request.json").exists():continue
   body=load(p/"request.json");response=load(p/"response.json");timing=load(p/"timing.json")
   costs.append({"tag":p.name,"gpu":gpu,"seed":body["seed"],"model":body["model"],"temperature":body["temperature"],"usage":response.get("usage"),"seconds":timing["seconds"],"request_sha":sha(p/"request.json"),"response_sha":sha(p/"response.json")})
 save(ROOT/"reports/actual_model_costs.json",costs)
 lines=["# 教学与校验联合预算：完整结果","",
 "已知UCI来源，预先随机100个完整实体组：20学习池/20独立校验池/60固定正式测试。三档5+5、10+10、20+20嵌套；该实验同时改变学习与校验预算，不单独归因学习样例。数量准入小样本适配透明，原候选/支持数/门槛/算法不变。三seed均值±样本SD，不称显著。","",
 "|数据集|5+5：F1 / 正常误改%|10+10：F1 / 正常误改%|20+20：F1 / 正常误改%|","|---|---:|---:|---:|"]
 def fmt(g,k):
  x=g[k]
  if x["n"]<3:return "N/A("+str(x["n"])+"/3)"
  scale=100 if k=="normal_damage" else 1
  return format(x["mean"]*scale,".3f")+" ± "+format(x["sd"]*scale,".3f")
 for d in load(ROOT/"configs/protocol.json")["datasets"]:
  gs=[next(g for g in groups if g["dataset"]==d and g["learning_groups"]==n) for n in [5,10,20]]
  lines.append("|"+d+"|"+"|".join(fmt(g,"F1")+" / "+fmt(g,"normal_damage") for g in gs)+"|")
 lines+=["","外校合格seed数按5+5/10+10/20+20："]
 for d in load(ROOT/"configs/protocol.json")["datasets"]:
  lines.append("- "+d+": "+"/".join(str(next(g for g in groups if g["dataset"]==d and g["learning_groups"]==n)["qualified_seeds"])+"/3" for n in [5,10,20]))
 lines+=["","未通过外校的预定研究prior不得视为合格部署；零修改P=None、F1=0有效，不把失败填0。完整逐seed、实际标注组/行/格数、学习/调用成本保留JSON。精简三线表图片须独立呈现与实际看图QA后交付。"]
 (ROOT/"reports/示例预算_六表精简结果.md").write_text("\n".join(lines)+"\n")
 print("\n".join(lines),flush=True)
