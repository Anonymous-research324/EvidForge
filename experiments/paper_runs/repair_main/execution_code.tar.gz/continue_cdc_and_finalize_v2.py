"""Continue untouched CDC cases; record reviewed native failures as N/A, then once-only score.
No repair algorithms, RNGs, splits, thresholds or completed outputs are changed.
"""
from pathlib import Path
import sys,os,time,json,hashlib,traceback,csv,subprocess,fcntl
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_multiseed as locked
BASE=ROOT.parent/"DataForge_V23_Benchmark_seed1013"
PY=locked.PY
def save(p,j):locked.save(p,j)
def load(p):return locked.load(p)
def h(p):return locked.digest(p)
def reviewed_native_failure(seed,name):
 r=locked.case(seed);out=r/"outputs"/name/"cdc"
 state=out/"column_status.json"
 if not state.exists():return False
 states=load(state)
 if not states or states[-1].get("status")!="failed":return False
 failure=states[-1]
 # A mathematically unsupported source-only classification split is not repaired
 # by changing seed, adding hidden labels or inventing a constant cleaner.
 if failure.get("exception")!="AssertionError" or "y does not contain exactly 2 unique values:" not in failure.get("message",""):return False
 path=r/"status/closed_unavailable"/f"{name}_cdc.json"
 if path.exists():return True
 save(path,{"status":"unavailable","method":"cdc","dataset":name,"seed":seed,
  "reason":"Native AutoGluon binary classifier cannot fit the fixed source split with only one class",
  "source_column_failure":failure,"all_failed_artifacts_retained":True,"partial_repairs_not_scored":True,
  "algorithm_parameters_changed":False,"source_split_changed":False,"formal_reference_read":False,
  "reviewed_at":time.time(),"aggregate_policy":"N/A with n<3, never zero or two-seed mean±SD labelled as three"})
 save(ROOT/"audit"/f"reviewed_native_cdc_failure_{seed}_{name}.json",{
  "review":"Source-only native algorithm applicability failure, not a score; permit original scorer's pre-existing --close-incomplete N/A path.",
  "column_status_sha256":h(state),"original_entry_sha256":h(r/"code/run_cdc.py"),
  "log_sha256":h(r/"logs"/f"{name}_cdc_{name}.log"),"closure":str(path),"test_truth_read":False})
 return True
def check_all(seed):
 r=locked.case(seed);locked.verify(seed)
 for name in locked.NAMES:
  with (r/"datasets"/name/"public/repair_dirty.csv").open() as f:
   rd=csv.DictReader(f);cols=rd.fieldnames;ids=[x["entity_id"] for x in rd]
  for method in ["primary_llm","tool_llm","raha_holoclean","garf","cdc"]:
   out=r/"outputs"/name/method
   close=r/"status/closed_unavailable"/f"{name}_{method}.json"
   if close.exists():
    assert method=="cdc" and reviewed_native_failure(seed,name)
    continue
   for rel,expected in load(out/"output_freeze.json")["files"].items():assert h(out/rel)==expected
   for filename in (["pure_output.csv","v23_output.csv"] if method=="primary_llm" else ["repair_output.csv"]):
    with (out/filename).open() as f:
     rd=csv.DictReader(f);assert rd.fieldnames==cols;assert [x["entity_id"] for x in rd]==ids
 save(r/"audit/all_outputs_integrity_with_disclosed_na.json",{
  "seed":seed,"all_available_output_sha_fields_ids_pass":True,
  "unavailable":[str(p) for p in (r/"status/closed_unavailable").glob("*.json")],
  "formal_reference_read":False,"timestamp":time.time()})
def main():
 with (ROOT/"status/cdc_recovery.lock").open("a") as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  save(ROOT/"status/cdc_recovery_owner.json",{"pid":os.getpid(),"started":time.time(),"entry":str(Path(__file__))})
  errors=[]
  for name in locked.NAMES:
   for seed in locked.SEEDS:
    r=locked.case(seed)
    if (r/"outputs"/name/"cdc/output_freeze.json").exists():continue
    if reviewed_native_failure(seed,name):continue
    folder=r/"outputs"/name/"cdc"
    if folder.exists():raise RuntimeError("Unreviewed incomplete case; do not overwrite "+str(folder))
    try:locked.invoke(seed,"cdc_"+name,"run_cdc.py",dataset=name,environment="cdc")
    except Exception:
     if reviewed_native_failure(seed,name):continue
     raise
  save(ROOT/"status/cdc_recovery_complete.json",{"time":time.time(),"closed_available_and_disclosed_na":True})
  parent=load(ROOT/"status/owner.json")["pid"]
  while locked.live_command(parent):
   save(ROOT/"status/cdc_recovery_wait.json",{"phase":"waiting_for_original_non_cdc_branches","pid":os.getpid(),"original_controller":parent,"time":time.time()})
   time.sleep(25)
  # The original controller retained its cdc error and did not score. Other errors require independent review.
  failures=load(ROOT/"status/failures.json") if (ROOT/"status/failures.json").exists() else {}
  if set(failures)!={"cdc"}:raise RuntimeError("Additional original branch failure requires review: "+str(failures.keys()))
  assert h(BASE/"reports/final_seed1013/scores.json")==load(ROOT/"protocol.json")["original_1013_scores_sha256"]
  for seed in locked.SEEDS:
   r=locked.case(seed);check_all(seed)
   for name in locked.NAMES:
    receipt=load(r/"datasets"/name/"input_freeze.json")
    for zone in ["public","private"]:
     for rel,v in receipt[zone].items():assert h(r/"datasets"/name/zone/rel)==v
   marker=r/"audit/scoring_started.json"
   assert not marker.exists(),"Once-only scoring marker exists; inspect, do not delete"
   save(marker,{"time":time.time(),"available_outputs_frozen":True,"reviewed_native_failure_NA":True,"unchanged_original_metrics":True})
   locked.invoke(seed,"final_scoring","score_all.py",args=["--close-incomplete"])
   locked.invoke(seed,"postgres_stop","start_owned_postgres.py",args=["stop"],timeout=90)
  p=subprocess.run([PY,"-B",str(ROOT/"aggregate_three_seeds.py")],cwd=ROOT)
  assert p.returncode==0,"Aggregation error: preserve scores"
  save(ROOT/"status/complete.json",{"time":time.time(),"seeds":[1013,1014,1015],
    "standard_deviation":"sample ddof=1 for complete n3 cells only","native_failure_cells_disclosed_NA":True})
if __name__=="__main__":
 try:main()
 except Exception as e:
  save(ROOT/"status/cdc_recovery_error.json",{"time":time.time(),"error":repr(e),"traceback":traceback.format_exc()})
  raise
