"""仅恢复缺失分组元数据的读接口；numeric_context仍保持{}，候选/拟合/评分不变。"""
from pathlib import Path
import ast,sys,hashlib,importlib.machinery
import runtime as base
from common import ROOT,ENGINE
TARGETS={"learning/prepare.py","learning/downstream_view.py","source_runtime/skill_runtime/learning.py"}
def loader(self,data,path,*,_optimize=-1):
    p=Path(path).resolve();b=data.encode() if isinstance(data,str) else data
    if hashlib.sha256(b).hexdigest() in base.KNOWN and any(str(p).endswith("/"+n) for n in TARGETS):
        t=ast.parse(b,filename=str(path))
        class Adapter(ast.NodeTransformer):
            def visit_Constant(self,n):
                return ast.copy_location(ast.Constant(base.SEED),n) if type(n.value)is int and n.value==20260927 else n
            def visit_Subscript(self,n):
                n=self.generic_visit(n)
                if ast.unparse(n)=="model['numeric_context']['training_groups']":
                    return ast.copy_location(ast.Call(func=ast.Name(id="_ef_fit_groups",ctx=ast.Load()),args=[ast.Name(id="model",ctx=ast.Load())],keywords=[]),n)
                return n
        t=Adapter().visit(t)
        pos=1 if t.body and isinstance(t.body[0],ast.Expr) and isinstance(t.body[0].value,ast.Constant) and isinstance(t.body[0].value.value,str) else 0
        t.body.insert(pos,ast.ImportFrom(module="advisor_metadata_v4",names=[ast.alias(name="fit_groups",asname="_ef_fit_groups")],level=0))
        ast.fix_missing_locations(t)
        return compile(t,str(path),"exec",dont_inherit=True)
    return base.loader(self,data,path,_optimize=_optimize)
def install():
    base.install()
    importlib.machinery.SourceFileLoader.source_to_code=loader
def main():
    a=sys.argv[1:]
    while a and a[0] in ["-B","-u"]:a.pop(0)
    f=Path(a.pop(0)).resolve();b=f.read_bytes()
    if hashlib.sha256(b).hexdigest() not in base.KNOWN:raise ValueError("Only frozen engine entry")
    sys.argv=[str(f),*a];install()
    exec(loader(None,b,str(f)),{"__name__":"__main__","__file__":str(f),"__package__":None})
if __name__=="__main__":main()
