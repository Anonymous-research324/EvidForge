"""只确认预先逐case审查过、实际触发原始重复保护的source不可用；不改变分区/保护。"""
from pathlib import Path
from common import ROOT,load,save,sha
def review(case):
    records=load(ROOT/"audit/source_guard_review_v5.json")["cases_with_observation_signature_conflict"]
    item=next((x for x in records if x["case"]==case.name),None)
    if item is None:return False
    failure=case/"status/recovery_failure_v4.json";log=case/"logs/full/prepare.log"
    if not failure.exists() or not log.exists():return False
    text=log.read_text()
    if "ValueError: 学习和校验存在重复记录" not in text or "normalize_bundle" not in text:return False
    if "logs/full/prepare.log" not in load(failure)["error"]:return False
    if not item["stages"] or any(s["overlap"]["row_keys"] or s["overlap"]["entities"] or s["confirmed_target_truth_overlap"] or not s["overlap"]["dirty_signatures"] for s in item["stages"]):return False
    assert not (case/"work/full/onboarding").exists()
    assert not list((case/"outputs").glob("*/output_freeze.json"))
    prefix="Advisor"+case.name.replace("_","").replace("-","")
    calls=list((ROOT/"services").glob("gpu*/requests/"+prefix+"*"))
    if calls:raise ValueError("Source failure with existing actual model calls requires new review")
    for role in ["public","private"]:
        for f,h in load(case/"input_freeze.json")[role].items():
            if sha(case/role/f)!=h:raise ValueError("Frozen input changed")
    receipt={"status":"N/A","arms":["full","no_llm","reuse"],"reason":"Original unchanged learning/validation duplicate-observation guard rejects post-corruption identical feature vectors across distinct entities; no resplit, dropped rows or guard relaxation","source_review":item,"failure_sha":sha(failure),"log_sha":sha(log),"actual_model_calls":0,"guard_unchanged":True,"formal_reference_read":False}
    target=case/"status/source_closed_unavailable.json"
    if target.exists():
        if load(target)!=receipt:raise ValueError("Reviewed receipt differs")
    else:save(target,receipt)
    return True
if __name__=="__main__":
    for n in load(ROOT/"configs/cases.json"):
        if review(ROOT/"cases"/n):print(n)
