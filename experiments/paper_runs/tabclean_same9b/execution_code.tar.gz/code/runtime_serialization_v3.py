"""Serialization-only integrity compatibility: verify original pre-JSON integer-key fingerprint; never change model or expected digest."""
from pathlib import Path
import copy,sys
import runtime_v4 as base
from common import ENGINE
def install():
 base.install()
 import unseen_table.save_skill as package
 original=package.validate
 def validated(skill,_original=original):
  try:return _original(skill)
  except ValueError as exc:
   if str(exc)!='技能文件发生变化':raise
   restored=copy.deepcopy(skill);changed=0
   for field,profile in restored.get('profiles',{}).items():
    for key in ['precision','canonical_precision']:
     values=profile.get(key)
     if isinstance(values,dict) and values and all(isinstance(k,str) and k.isdigit() for k in values):
      profile[key]={int(k):v for k,v in values.items()};changed+=1
   if not changed:raise
   # Exact stored artifact hash must match; never substitute or recompute expected hash.
   _original(restored)
   # Preserve the original loaded representation and every downstream numerical value.
   return skill
 package.validate=validated
def main():
 import hashlib
 a=sys.argv[1:]
 while a and a[0] in ['-B','-u']:a.pop(0)
 f=Path(a.pop(0)).resolve();b=f.read_bytes()
 if hashlib.sha256(b).hexdigest() not in base.base.KNOWN:raise ValueError('Only original frozen engine entry')
 sys.argv=[str(f),*a];install()
 exec(base.loader(None,b,str(f)),{'__name__':'__main__','__file__':str(f),'__package__':None})
if __name__=='__main__':main()
