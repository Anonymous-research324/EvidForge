"""只在新进程中绑定种子和预定消融；124原文件不改，参考答案禁止访问。"""
from pathlib import Path
import ast,sys,os,importlib.machinery,hashlib,json
from common import ROOT,ENGINE,load,save
SEED=int(os.environ.get("EF_SEED","1013"))
KNOWN=set(load(ROOT/"audit/core124.json")["files"].values())
ORIGINAL=importlib.machinery.SourceFileLoader.source_to_code
def transform(data,path):
 b=data.encode() if isinstance(data,str) else data
 if hashlib.sha256(b).hexdigest() not in KNOWN or ROOT not in Path(path).resolve().parents:return None
 t=ast.parse(b,filename=str(path))
 class Switch(ast.NodeTransformer):
  def visit_Constant(self,n):
   return ast.copy_location(ast.Constant(SEED),n) if type(n.value)is int and n.value==20260927 else n
  def visit_Call(self,n):
   n=self.generic_visit(n)
   if os.environ.get("EF_ARM")=="no_generated_execution" and str(path).endswith(("learning/execute.py","supplementary/execute.py")) and isinstance(n.func,ast.Attribute) and n.func.attr=="exists" and isinstance(n.func.value,ast.Name) and n.func.value.id=="candidate":return ast.copy_location(ast.Constant(False),n)
   return n
 t=Switch().visit(t);ast.fix_missing_locations(t);return compile(t,str(path),"exec",dont_inherit=True)
def loader(self,data,path,*,_optimize=-1):
 c=transform(data,path);return c if c is not None else ORIGINAL(self,data,path,_optimize=_optimize)
def guard():
 if getattr(sys,"_ef_advisor_guard",False):return
 sys._ef_advisor_guard=True
 def hook(event,args):
  if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
   p=Path(os.fsdecode(args[0])).resolve()
   if any(x in p.parts for x in ["private","local_private","downstream_training"]) or ("TabClean_author" in p.parts and "datasets" in p.parts) or p.name in ["clean.csv","holdout_reference.csv","repair_reference.csv"]:
    raise PermissionError("Repair role cannot read formal/original/label material: "+str(p))
 sys.addaudithook(hook)
def replace(old,new):
 for m in list(sys.modules.values()):
  if m:
   for k,v in list(vars(m).items()):
    if v is old:setattr(m,k,new)
def install():
 guard();sys.dont_write_bytecode=True
 sys.path[:0]=[str(ENGINE),str(ENGINE/"source_runtime"),str(ENGINE/"application")]
 importlib.machinery.SourceFileLoader.source_to_code=loader
 import random,numpy as np
 random.seed(SEED);np.random.seed(SEED)
 arm=os.environ.get("EF_ARM","full")
 if arm=="no_transforms":
  import unseen_table.candidate_pool as m,unseen_table.rank_candidates
  old=m.candidates
  def candidates(row,col,fitted,context=None,source=None):
   f={**fitted,"rules":[r for r in fitted["rules"] if r["kind"] not in {"affix","scale","shift","mapping","strip","casefold","edit"}]}
   return old(row,col,f,context,source)
  replace(old,candidates)
  import skill_runtime.codec as codec
  for name in ["fit","decode"]:
   original=getattr(codec,name)
   def wrapped(*a,_f=original,**k):
    result=_f(*a,**k);return {**result,"rules":[r for r in result["rules"] if r["kind"] not in {"affix","scale","shift","mapping","strip","casefold","edit"}]}
   replace(original,wrapped)
 if arm=="no_predictive_context":
  import unseen_table.numeric_context as m,unseen_table.row_state as s,supplementary.context as c
  from unseen_table.trusted_context import bootstrap
  def evidence(row,fitted,trusted=None,exclude_group=None):return {"trusted":trusted or bootstrap(row,fitted),"columns":{}}
  replace(m.evidence,evidence);ov=s.vector
  def vector(row,target,fitted,trusted=None):
   x=ov(row,target,fitted,trusted);n=len(fitted["declaration"]["targets"]);return x[:n]+[0.]*(len(x)-n)
  replace(ov,vector);om=c.matrix
  def matrix(*a,**k):return np.zeros_like(om(*a,**k))
  replace(om,matrix)
 if arm=="no_final_gate":
  import unseen_table.validate_skill as b,learning.candidate_verifier as g
  def pb(c,policy):
   if "confidence_threshold" in policy:return c["top"]["kind"]!="keep" and not c.get("tied",False)
   p=policy.get("by_region",{}).get(b.region(c),policy if "score_threshold" in policy else {})
   return c["top"]["kind"]!="keep" and not c.get("tied",False) and bool(p)
  def pg(q,policy):return bool(q["accept"] and q["differs_from_baseline"] and policy.get(q["channel"]))
  replace(b.permitted,pb);replace(g.permitted,pg)
 delta=float(os.environ.get("EF_CONF_OFFSET","0"))
 if delta:
  import unseen_table.validate_skill as b
  old=b.permitted
  def shifted(c,policy):
   import copy
   p=copy.deepcopy(policy)
   def adjust(x):
    if isinstance(x,dict):
     for k,v in x.items():
      if k in ["confidence_threshold","score_threshold"] and isinstance(v,(int,float)):x[k]=max(0.,min(1.,v+delta))
      elif isinstance(v,dict):adjust(v)
   adjust(p);return old(c,p)
  replace(old,shifted)
 if os.environ.get("EVIDFORGE_NATIVE_VARIANT")=="no_feedback":
  from ablation_protocol import install as nf
  nf()
def main():
 a=sys.argv[1:]
 while a and a[0] in ["-B","-u"]:a.pop(0)
 f=Path(a.pop(0)).resolve();b=f.read_bytes();c=transform(b,f)
 if c is None:raise ValueError("Only original hash-verified engine entry accepted")
 sys.argv=[str(f),*a];install();exec(c,{"__name__":"__main__","__file__":str(f),"__package__":None})
if __name__=="__main__":main()
