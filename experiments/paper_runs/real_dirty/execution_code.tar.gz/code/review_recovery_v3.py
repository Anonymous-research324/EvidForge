"""Independent arithmetic/public-output reviewer; never parses any formal reference."""
from pathlib import Path
import json,time,statistics,math,copy
from common import ROOT as R,load,save,sha,read_csv
from score_recovery_v3 import O,METHODS,RETAINED,NEW,equal,align,verify,output_dir

def close(a,b):
 if a is None or b is None:assert a is None and b is None;return
 assert math.isclose(a,b,abs_tol=1e-12,rel_tol=1e-12),(a,b)

def check_metric(m,detected=None):
 E,M,C,N,D=m['errors'],m['changes'],m['exact'],m['clean'],m['normal_damage']
 assert all(isinstance(v,int) and v>=0 for v in [E,M,C,N,D,m['known_cells'],m['unknown_cells'],m['unknown_edits']])
 assert C<=min(E,M) and D<=N and C+D<=M and E+N==m['known_cells']
 close(m['P'],C/M if M else 0.);close(m['R'],C/E if E else 0.);close(m['F1'],2*C/(E+M) if E+M else 0.);close(m['normal_damage_rate'],D/N if N else None)
 assert m['net_correct_cells']==C-D
 if detected is not None:
  assert C<=detected<=min(E,M)
  close(m['edit01_AUC'],(1+detected/E-D/N)/2 if E and N else None)
 elif m['edit01_AUC'] is not None:assert -.0000001<=m['edit01_AUC']<=1.0000001

def public_edit_check(case,out,zone,m,maskpath):
 _,dirty=read_csv(case/'public'/f'{zone}_dirty.csv');_,rows=read_csv(out/f'{zone}_output.csv');rows=align(dirty,rows)
 known=load(maskpath);assert known['truth_values_included'] is False
 mask=dict(zip(known['row_keys'],known['known_fields']));assert set(mask)=={x['__rowkey__'] for x in dirty}
 cols=load(case/'case.json')['targets'];K=M=U=UE=0
 for a,b in zip(dirty,rows):
  fields=set(mask[a['__rowkey__']]);assert fields<=set(cols)
  for f in cols:
   change=not equal(a[f],b[f])
   if f in fields:K+=1;M+=change
   else:U+=1;UE+=change
 assert (K,M,U,UE)==(m['known_cells'],m['changes'],m['unknown_cells'],m['unknown_edits'])

def main():
 assert (R/'status/scoring_complete.json').exists()
 names,pilots,imports,available,costs,resources=verify()
 rows=load(R/'reports/all_scores.json');pr=load(R/'reports/pilot_scores.json');assert len(rows)==120 and len(pr)==5
 assert len({(x['dataset'],x['seed'],x['method']) for x in rows})==120
 old=load(O/'reports/all_scores.json');old_index={(x['dataset'],x['seed'],x['method']):x for x in old};oldsha=sha(O/'reports/all_scores.json');reused=0
 for x in rows+pr:
  assert x['status']=='scored' and x['repair'] is not None
  expected_complete=not (x['experiment_partition']=='pilot' and x['dataset'] in ['beers','jobposting_small'] and x['method']=='full')
  assert x['protocol_log_complete']==expected_complete
  if not expected_complete:assert x['seed']==9013 and x.get('protocol_log_limitation')
  case=R/'cases'/x['case'];out=output_dir(x['case'],x['method'],imports)
  if x['result_origin']=='imported_original_frozen_score':
   orig=old_index[x['dataset'],x['seed'],x['method']]
   for key,value in orig.items():assert x[key]==value,('imported original record changed',key)
   assert x['original_score_sha256']==oldsha;reused+=1
  ca=x.get('count_audit',{})
  check_metric(x['repair'],ca.get('repair_detected_error_edits'));check_metric(x['validation'],ca.get('validation_detected_error_edits'))
  public_edit_check(case,out,'repair',x['repair'],case/'audit/scoring_known_cells_expansion.json')
  public_edit_check(case,out,'validation',x['validation'],case/'audit/scoring_known_validation_cells_expansion.json')
  q=x['validation'];expected=q['changes']>=5 and q['clean']>=10 and q['P']>=.98 and q['normal_damage_rate'] is not None and q['normal_damage_rate']<=.005
  assert x['qualified']==expected
 assert reused==25
 order=load(R/'configs/protocol.json')['datasets']
 saved=load(R/'reports/aggregate.json');assert len(saved)==40
 pairs=load(R/'reports/paired_differences.json');assert len(pairs)==32
 def mean_sd(values):
  assert len(values)==3
  average=sum(values)/3
  return average,(sum((v-average)**2 for v in values)/2)**.5
 def count_f1(x):
  q=x['repair'];return 2*q['exact']/(q['errors']+q['changes']) if q['errors']+q['changes'] else 0.
 for ds in order:
  for method in METHODS:
   group=[x for x in rows if x['dataset']==ds and x['method']==method];assert len(group)==3
   mu,sd=mean_sd([count_f1(x) for x in group]);actual=next(x for x in saved if x['dataset']==ds and x['method']==method)
   assert actual['n']==actual['expected_n']==3 and actual['complete'];close(actual['mean'],mu);close(actual['sample_sd'],sd)
   damage=[x['repair']['normal_damage']/x['repair']['clean'] for x in group if x['repair']['clean']]
   close(actual['normal_damage_mean'],sum(damage)/3 if len(damage)==3 else None)
   assert actual['qualified_n']==sum(bool(x['qualified']) for x in group)
  for method in METHODS[1:]:
   p=next(x for x in pairs if x['dataset']==ds and x['baseline']==method);assert p['n']==3
   values=[]
   for seed in [1013,1014,1015]:
    full=next(x for x in rows if x['dataset']==ds and x['seed']==seed and x['method']=='full');base=next(x for x in rows if x['dataset']==ds and x['seed']==seed and x['method']==method)
    value=count_f1(full)-count_f1(base);item=next(x for x in p['differences'] if x['seed']==seed);close(item['F1_full_minus_baseline'],value);values.append(value)
   mu,sd=mean_sd(values);close(p['mean'],mu);close(p['sample_sd'],sd)
 cost=load(R/'reports/actual_model_costs.json');new=[x for x in cost if x['attempt_origin']=='new_compat_expansion'];assert len(new)==len(costs) and sum(x['usage']['total_tokens'] for x in new)==sum(x['usage']['total_tokens'] for x in costs)
 for name in names+pilots:
  marker=load(R/'cases'/name/'scoring_started_recovery_v3.json');assert marker['old_score_sha256']==oldsha
  assert marker['entry_sha256']==sha(R/'code/score_recovery_v3.py') and marker['formal_reference_read_once_for_new_outputs_only']
 save(R/'audit/final_independent_fixedscore_review.json',{'passed':True,'at':time.time(),'formal_records':120,'pilot_records':5,'reused_old_scores_unchanged':25,'new_main_scored':95,'no_failed_outputs_or_zero_fallback':True,'metric_arithmetic_P_R_F1_damage':True,'new_AUC_saved_detection_counts_verified':True,'public_known_and_unknown_edit_counts_verified':True,'mean_sampleSD_paired_recomputed':True,'old_score_SHA_core124_and_frozen_inputs_verified':True,'formal30_and_new_pilot2_Hooks_strict_v4_verified':True,'old_pilot6_full_Hooks_verified':True,'exploratory_missing_Hook_log_stages':2,'two_pilot_records_descriptive_only_protocol_log_complete_false':True,'actual_responses_usage_seed_bindings_all_generations_verified':True,'resources':resources,'formal_reference_reread':False,'actual_visual_inspection_pending':True})
 print('INDEPENDENT_RECOVERY_V3_FIXED_SCORE_QA_PASS;no_reference_reread;formal_strict_pilot_gaps_explicit')
if __name__=='__main__':main()
