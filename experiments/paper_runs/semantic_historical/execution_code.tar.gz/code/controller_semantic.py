"""One immutable controller, two A100 lanes. Unknown failures block final scoring."""
from pathlib import Path
import os,sys,subprocess,time,json,traceback,concurrent.futures,socket
from common import ROOT,PY,load,save
def run(cmd,path,env):
 with Path(path).open("x") as f:
  p=subprocess.Popen(list(map(str,cmd)),cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
  save(Path(str(path)+".pid.json"),{"pid":p.pid,"command":list(map(str,cmd)),"at":time.time()})
  rc=p.wait()
 if rc:raise RuntimeError("exit "+str(rc)+": "+str(path))
def lane(gpu,names):
 env={**os.environ,"EF_GPU":str(gpu),"OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","MKL_NUM_THREADS":"2","PYTHONDONTWRITEBYTECODE":"1"}
 records=[]
 try:
  run([PY,ROOT/"code/model_service.py","start"],ROOT/"logs"/("gpu"+str(gpu)+"_service_start.log"),env)
  for i,name in enumerate(names):
   save(ROOT/"status"/("lane"+str(gpu)+".json"),{"gpu":gpu,"index":i,"total":len(names),"case":name,"at":time.time()})
   try:
    run([PY,ROOT/"code/worker_semantic.py","case","--case",ROOT/"cases"/name,"--gpu",gpu],ROOT/"logs"/(name+"_worker.log"),env)
    records.append({"case":name,"status":"closed"})
   except Exception as e:
    records.append({"case":name,"status":"failed","error":repr(e)})
    save(ROOT/"cases"/name/"status/controller_case_failure.json",{"error":repr(e),"at":time.time(),"no_automatic_case_replay":True})
  save(ROOT/"status"/("lane"+str(gpu)+".json"),{"gpu":gpu,"index":len(names),"total":len(names),"done":True,"records":records,"at":time.time()})
 except Exception as e:
  save(ROOT/"status"/("lane"+str(gpu)+"_error.json"),{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()})
  raise
 finally:
  # No more requests in this lane. Only the exact local owner may be stopped.
  if (ROOT/"services"/("gpu"+str(gpu))/"owner.json").exists():
   try:run([PY,ROOT/"code/model_service.py","stop"],ROOT/"logs"/("gpu"+str(gpu)+"_service_stop.log"),env)
   except Exception as e:save(ROOT/"status"/("resource_stop_error_gpu"+str(gpu)+".json"),{"error":repr(e)})
 return records
def main():
 if (ROOT/"status/controller_owner.json").exists():raise RuntimeError("Owner exists; inspect, never duplicate")
 save(ROOT/"status/controller_owner.json",{"pid":os.getpid(),"host":socket.gethostname(),"started":time.time(),"scope":"six controlled semantic cases, frozen algorithm"})
 from semantic_preflight import main as preflight
 # Preflight already ran in a separate process. Its role guard must not govern orchestration/scoring.
 if not (ROOT/"audit/semantic_preflight_pass.json").exists():raise RuntimeError("Preflight missing")
 names=load(ROOT/"configs/semantic_cases.json");lanes=[names[0::2],names[1::2]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(lane,g,lanes[g]) for g in range(2)]
  outcomes=[]
  for f in fs:outcomes+=f.result()
 save(ROOT/"status/outcomes.json",outcomes)
 if any(x["status"]!="closed" for x in outcomes):raise RuntimeError("Unknown failures preserved; final scoring blocked")
 run([PY,ROOT/"code/audit_semantic_ready.py"],ROOT/"logs/audit_ready.log",os.environ.copy())
 save(ROOT/"status/all_model_outputs_closed.json",{"cases":len(names),"at":time.time()})
 run([PY,ROOT/"code/score_semantic.py"],ROOT/"logs/score_semantic.log",os.environ.copy())
 save(ROOT/"status/run_complete.json",{"at":time.time(),"cases":len(names),"delivery_still_requires_independent_review":True})
if __name__=="__main__":
 try:main()
 except Exception as e:
  save(ROOT/"status/controller_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time(),"scoring_blocked_unless_already_started":True})
  raise
