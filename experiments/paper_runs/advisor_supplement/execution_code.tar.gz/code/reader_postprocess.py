"""仅对已完成一次独立评分的固定结果后处理；不执行修复、不读取原始正式参考。"""
from pathlib import Path
import math,statistics,collections,json,html,time,unicodedata
from common import ROOT,load,save,sha,read_csv
SEEDS=[1013,1014,1015]
DATA={"car_evaluation":"Car（分类）","concrete":"Concrete（回归）","hospital":"Hospital（自然脏）","flights":"Flights（自然脏）"}
ARMS={"full":"完整 EvidForge","no_transforms":"关闭学得纠错变换","no_generated_execution":"关闭9B生成规则执行","no_final_gate":"关闭最终置信门槛","no_feedback":"关闭源内反馈改写","no_predictive_context":"关闭跨字段预测证据","no_llm":"完全不使用LLM","reuse":"复用封存技能","tabclean":"TabClean（同9B适配）"}
def stat(v):
    v=list(v);good=[x for x in v if x is not None]
    if len(good)!=3:return {"mean":None,"sd":None,"n":len(good),"values":v}
    mean=math.fsum(good)/3
    return {"mean":mean,"sd":math.sqrt(math.fsum((x-mean)**2 for x in good)/2),"n":3,"values":v}
def close(a,b):
    return a is None and b is None or a is not None and b is not None and math.isclose(a,b,abs_tol=1e-12,rel_tol=1e-12)
def fmt(s,mul=1):
    return "N/A("+str(s["n"])+"/3)" if s["mean"] is None else f'{s["mean"]*mul:.3f} ± {s["sd"]*mul:.3f}'
def main():
    assert (ROOT/"status/scoring_complete.json").exists()
    raw=load(ROOT/"reports/all_scores.json")
    frozen_raw=sha(ROOT/"reports/all_scores.json")
    assert len({(r["id"],r["arm"]) for r in raw})==len(raw)
    old_scores=load(ROOT/"audit/old_scores_frozen.json")
    assert all(sha(Path(p))==h for p,h in old_scores.items())
    # Independent count-based arithmetic, without opening reference rows.
    verified=0
    for r in raw:
        m=r["repair"]
        if m["F1"] is None:continue
        denominator=m["errors"]+m["changes"]
        f1=2*m["exact"]/denominator if denominator else 0.
        assert close(f1,m["F1"])
        assert close(m["exact"]/m["changes"] if m["changes"] else None,m["P"])
        assert close(m["damaged"]/m["normal"] if m["normal"] else None,m["normal_damage"])
        verified+=1
    keys=["suite","dataset","rate","error_type","learning_fraction","arm"]
    groups=collections.defaultdict(list)
    for r in raw:groups[tuple(r[k] for k in keys)].append(r)
    aggregate=[];by_group={}
    for key,rs in groups.items():
        assert len({r["seed"] for r in rs})==len(rs)
        by={r["seed"]:r for r in rs};record=dict(zip(keys,key))
        for metric in ["P","R","F1","normal_damage","detection_AUC"]:
            record[metric]=stat([by.get(seed,{}).get("repair",{}).get(metric) for seed in SEEDS])
        for metric in ["macro_F1","AUC","R2","MAE"]:
            record[metric]=stat([(by.get(seed,{}).get("downstream") or {}).get(metric) for seed in SEEDS])
        original=next(a for a in load(ROOT/"reports/aggregate.json") if all(a[k]==record[k] for k in keys))
        for m in ["P","R","F1","normal_damage","detection_AUC","macro_F1","AUC","R2","MAE"]:
            assert original[m]["n"]==record[m]["n"] and close(original[m]["mean"],record[m]["mean"]) and close(original[m]["sd"],record[m]["sd"])
        aggregate.append(record);by_group[key]=record
    save(ROOT/"reports/independent_aggregate_review.json",aggregate)
    paired=collections.defaultdict(list)
    for r in raw:
        if r["arm"] in ["full","reuse"]:continue
        full=next(a for a in raw if a["id"]==r["id"] and a["arm"]=="full")
        paired[tuple(r[k] for k in keys)].append({"seed":r["seed"],"F1_full_minus_arm":None if r["repair"]["F1"] is None else full["repair"]["F1"]-r["repair"]["F1"],"harm_arm_minus_full":None if r["repair"]["normal_damage"] is None else r["repair"]["normal_damage"]-full["repair"]["normal_damage"]})
    paired_rows=[]
    for key,values in paired.items():
        by={r["seed"]:r for r in values}
        paired_rows.append({**dict(zip(keys,key)),**{m:stat([by.get(seed,{}).get(m) for seed in SEEDS]) for m in ["F1_full_minus_arm","harm_arm_minus_full"]}})
    save(ROOT/"reports/paired_mean_sd_review.json",paired_rows)
    def qualified(a):
        selection_arm=a["arm"] if a["arm"] in ["no_llm","no_feedback","no_predictive_context"] else "full"
        passed=[]
        for seed in SEEDS:
            rr=next((r for r in raw if all(r[k]==a[k] for k in keys[:-1]) and r["seed"]==seed),None)
            if rr is None:continue
            p=ROOT/"cases"/rr["id"]/"work"/selection_arm/"selection.json"
            if p.exists() and load(p)["passed"]:passed.append(seed)
        return len(passed)
    def readable(a):
        classification=a["dataset"]=="car_evaluation"
        name=ARMS.get(a["arm"],a["arm"])
        if a["arm"].startswith("threshold_"):name="基础置信阈值偏移 "+a["arm"].split("_",1)[1].replace("m","-").replace("p",".")
        result={"数据集":DATA[a["dataset"]],"条件":name,"污染率":None if a["suite"]=="natural" else a["rate"],"错误类型":"自然错误" if a["suite"]=="natural" else a["error_type"],"教学组比例":a["learning_fraction"]}
        for label,m,mul in [("修复F1","F1",1),("精确率P%","P",100),("召回率R%","R",100),("正常误改%","normal_damage",100),("下游宏F1或R²","macro_F1" if classification else "R2",1),("下游AUC或MAE","AUC" if classification else "MAE",1)]:
            result[label+"均值"]=None if a[m]["mean"] is None else a[m]["mean"]*mul
            result[label+"SD"]=None if a[m]["sd"] is None else a[m]["sd"]*mul
            result[label+"有效seed数"]=a[m]["n"]
        result["独立外校合格seed数"]=None if a["arm"]=="tabclean" else qualified(a)
        return result
    tables={}
    for suite,title in [("main","主消融"),("natural","真实脏表"),("sample_size","样例数量"),("robustness","污染鲁棒性")]:
        tables[title]=[readable(a) for a in aggregate if a["suite"]==suite and not a["arm"].startswith("threshold_") and a["arm"] not in ["reuse","tabclean"]]
    tables["置信门槛"]=[readable(a) for a in aggregate if a["suite"]=="main" and (a["arm"]=="full" or a["arm"].startswith("threshold_"))]
    tables["TabClean对照"]=[readable(a) for a in aggregate if a["suite"] in ["main","natural"] and a["arm"] in ["full","no_llm","tabclean"]]
    tables["同种子配对差值"]=[]
    for a in paired_rows:
        tables["同种子配对差值"].append({"实验":a["suite"],"数据集":DATA[a["dataset"]],"条件":ARMS.get(a["arm"],a["arm"]),"污染率":None if a["suite"]=="natural" else a["rate"],"错误类型":"自然错误" if a["suite"]=="natural" else a["error_type"],"教学比例":a["learning_fraction"],"F1完整减消融均值":a["F1_full_minus_arm"]["mean"],"F1差值SD":a["F1_full_minus_arm"]["sd"],"F1有效seed数":a["F1_full_minus_arm"]["n"],"误改消融减完整百分点":None if a["harm_arm_minus_full"]["mean"] is None else 100*a["harm_arm_minus_full"]["mean"],"误改差值SD百分点":None if a["harm_arm_minus_full"]["sd"] is None else 100*a["harm_arm_minus_full"]["sd"]})
    # Costs include failed calls. Timing is reported by measured component and hardware.
    costs=load(ROOT/"reports/actual_model_costs.json");eff=[];source=[];impacts=[]
    names=load(ROOT/"configs/cases.json")
    for index,name in enumerate(names):
        case=ROOT/"cases"/name;cfg=load(case/"case.json");lane=index%3
        compact=lambda text:text.replace("_","").replace("-","")
        caseprefix=compact(name)
        for arm in ["full","no_feedback","no_predictive_context"]:
            selected=case/"work"/arm/"selection.json"
            if not selected.exists():continue
            sel=load(selected);p=case/"work"/arm
            cc=[r for r in costs if r["tag"].startswith("Advisor"+caseprefix+compact(arm))]
            source_seconds=load(p/"onboarding/prior_prepared/prepare_receipt.json")["seconds"]
            continued=case/"status"/(arm+"_source_continuation_v4.json")
            if continued.exists():
                source_seconds+=load(p/"onboarding/prior_prepared/base_skill/base/skill.json").get("learning_summary",{}).get("seconds",0)
            native_seconds=sum(load(p/k/"native_v3/result.json")["seconds"] for k in ["prior_stage","context_stage"])
            context_seconds=load(p/"context/prepare_receipt.json")["seconds"]
            output_seconds=load(case/"outputs"/arm/"receipt.json")["seconds"]
            eff.append({"case":name,"实验":cfg["suite"],"数据集":DATA[cfg["dataset"]],"seed":cfg["seed"],"硬件":"RTX4090物理5+7 TP2" if lane==2 else "A100 GPU"+str(lane)+" TP1","条件":ARMS[arm],"真实调用数":len(cc),"输入token":sum(r["input_tokens"] for r in cc),"输出token":sum(r["output_tokens"] for r in cc),"源准备记录秒":source_seconds,"原生学习秒":native_seconds,"上下文准备秒":context_seconds,"正式修复秒":output_seconds,"已记录阶段秒数之和":source_seconds+native_seconds+context_seconds+output_seconds,"独立外校通过":sel["passed"],"计时说明":"阶段耗时之和，不是排队墙钟；已恢复源拟合按记录组成"})
        full=load(case/"outputs/full/receipt.json");reuse=load(case/"outputs/reuse/receipt.json")
        eff.append({"case":name,"实验":cfg["suite"],"数据集":DATA[cfg["dataset"]],"seed":cfg["seed"],"硬件":"RTX4090物理5+7 TP2" if lane==2 else "A100 GPU"+str(lane)+" TP1","条件":"复用封存技能","真实调用数":0,"输入token":0,"输出token":0,"正式修复秒":reuse["seconds"],"逐字节一致":reuse["byte_parity"],"计时说明":"零新增学习，配对同硬件；noLLM共享pre-native拟合不能把复制当独立冷训"})
        eff.append({"case":name,"实验":cfg["suite"],"数据集":DATA[cfg["dataset"]],"seed":cfg["seed"],"硬件":"RTX4090物理5+7 TP2" if lane==2 else "A100 GPU"+str(lane)+" TP1","条件":"完全不使用LLM","真实调用数":0,"输入token":0,"输出token":0,"正式修复秒":load(case/"outputs/no_llm/receipt.json")["seconds"],"计时说明":"复用同一未接触native的源拟合检查点；此行不是独立从零拟合成本"})
        if cfg["suite"] in ["main","natural"]:
            cc=[r for r in costs if r["tag"].startswith("Tab"+caseprefix)]
            available=(case/"outputs/tabclean/receipt.json").exists()
            eff.append({"case":name,"实验":cfg["suite"],"数据集":DATA[cfg["dataset"]],"seed":cfg["seed"],"硬件":"RTX4090物理5+7 TP2" if lane==2 else "A100 GPU"+str(lane)+" TP1","条件":"TabClean（同9B适配）","真实调用数":len(cc),"输入token":sum(r["input_tokens"] for r in cc),"输出token":sum(r["output_tokens"] for r in cc),"模型请求秒数之和":sum(r["seconds"] for r in cc),"执行状态":"有效闭合" if available else "N/A，原始失败保留","计时说明":"包含失败调用的完整成本，模型请求耗时之和不是完整图墙钟"})
        prepared=case/"work/full/onboarding/prior_prepared";frames=load(prepared/"backend_only.json")["frames"]
        from unseen_table.common import equal
        erroneous=[f for f in frames if f["expected_local_only"]!="" and not equal(f["original"],f["expected_local_only"])]
        coverage=sum(any(equal(q["value"],f["expected_local_only"]) for q in f["options"]) for f in erroneous)
        source.append({"case":name,"数据集":DATA[cfg["dataset"]],"seed":cfg["seed"],"教学错误格数":len(erroneous),"正确值在候选中":coverage,"正确候选覆盖率":coverage/len(erroneous) if erroneous else None,"候选缺失格数":len(erroneous)-coverage,"范围":"只分析已授权教学交叉验证，不是正式测试成绩"})
        fields,output=read_csv(case/"outputs/full/repair_output.csv")
        targets=load(case/"public/declaration.json")["targets"]
        for arm in load(case/"status/closed.json")["arms"]:
            _,other=read_csv(case/"outputs"/arm/"repair_output.csv")
            differences=sum(not equal(a[c],b[c]) for a,b in zip(output,other) for c in targets)
            impacts.append({"case":name,"数据集":DATA[cfg["dataset"]],"seed":cfg["seed"],"条件":ARMS.get(arm,arm),"与完整输出不同格数":differences})
    tables["效率与复用"]=eff;tables["教学候选覆盖"]=source;tables["开关影响格数"]=impacts
    save(ROOT/"reports/component_costs_review.json",eff)
    save(ROOT/"reports/source_candidate_coverage.json",source)
    save(ROOT/"reports/component_output_impact.json",impacts)
    # Three deterministic descriptive examples from already-scored logs, never source tuning.
    examples=[]
    for p in sorted((ROOT/"cases").glob("*/case_studies.json")):
        for row in load(p):
            case=p.parent
            if row["arm"]=="full" and row["kind"] in ["correct","wrong_repair"]:
                typ="成功修复" if row["kind"]=="correct" else "失败修复"
            elif row["arm"]=="no_final_gate" and row["kind"]=="normal_damage":
                _,fullrows=read_csv(case/"outputs/full/repair_output.csv")
                if not equal(fullrows[row["row"]][row["field"]],row["before"]):continue
                typ="置信门槛保留原值"
            else:continue
            if any(r["类型"]==typ for r in examples):continue
            examples.append({"类型":typ,"case":case.name,"行":row["row"],"字段":row["field"],"原值":row["before"],"消融或完整输出":row["after"],"参考值":row["reference"],"说明":"描述性定例，不用于参数选择"})
    if not any(r["类型"]=="失败修复" for r in examples):
        missing=next((x for x in source if x["候选缺失格数"]>0),None)
        if missing:
            case=ROOT/"cases"/missing["case"];frames=load(case/"work/full/onboarding/prior_prepared/backend_only.json")["frames"]
            f=next(f for f in frames if f["expected_local_only"]!="" and not equal(f["original"],f["expected_local_only"]) and not any(equal(q["value"],f["expected_local_only"]) for q in f["options"]))
            examples.append({"类型":"教学候选缺失（失败机制）","case":case.name,"字段":f["column"],"原值":f["original"],"参考值":f["expected_local_only"],"说明":"已授权教学样本，候选池无正确值；仅调分不能恢复。不是正式格成功率证明"})
    tables["典型案例"]=examples;save(ROOT/"reports/typical_cases_review.json",examples)
    import openpyxl
    from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
    workbook=ROOT/"reports/EvidForge_导师补充实验汇总.xlsx";wb=openpyxl.load_workbook(workbook)
    notes=["三种子1013/1014/1015，等权均值与样本SD（ddof=1）；仅n=3给汇总，N/A不填0。",
           "正常误改%与P/R%使用百分数；SD为百分点。分类报告宏F1/概率AUC，回归R²/MAE。",
           "Hospital/Flights不新增污染，分别20/10/15与20/10/70实体分组；这些旧来源不是新盲测。",
           "外校未通过时使用预定研究prior；不等于自动部署合格。没有足够证据的组件不作稳定增益结论。",
           "复用零新增模型调用且逐字节一致。noLLM共享pre-native源拟合，计时不能解释成独立冷训练。",
           "TabClean为官方图同9B受限适配；真实响应超过8192输出预算的失败保留并标N/A，不代表原GPT结果。"]
    for name,rows in tables.items():
        assert name not in wb.sheetnames
        ws=wb.create_sheet(name);ws.sheet_view.showGridLines=False
        ws["A1"]=name;ws["A1"].font=Font(name="Arial",size=14,bold=True)
        columns=list(dict.fromkeys(k for row in rows for k in row))
        for j,key in enumerate(columns,1):
            c=ws.cell(3,j,key);c.font=Font(name="Arial",size=10,bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="245D87");c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        for i,row in enumerate(rows,4):
            for j,key in enumerate(columns,1):
                v=row.get(key);c=ws.cell(i,j,"N/A" if v is None else v)
                c.font=Font(name="Arial",size=10);c.alignment=Alignment(horizontal="right" if isinstance(v,(int,float)) or v is None else "left",vertical="center")
                if isinstance(v,float):c.number_format="0.000"
                elif isinstance(v,int):c.number_format="#,##0"
            ws.row_dimensions[i].height=19
        ws.row_dimensions[3].height=36
        for col in ws.columns:
            values=[str(c.value or "") for c in col]
            width=max(sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in text) for text in values)
            ws.column_dimensions[col[0].column_letter].width=min(70,max(13,width+2))
        ws.freeze_panes="C4";ws.auto_filter.ref=f"A3:{ws.cell(max(3,ws.max_row),max(1,len(columns))).coordinate}"
        ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation="landscape";ws.page_setup.paperSize=ws.PAPERSIZE_A3;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0;ws.print_title_rows="1:3"
        ws.sheet_properties.tabColor="245D87"
    ws=wb.create_sheet("口径与限制");ws.append(["说明"])
    for note in notes:ws.append([note])
    ws.column_dimensions["A"].width=125
    for row in ws:
        for c in row:c.font=Font(name="Arial",size=10);c.alignment=Alignment(wrap_text=True,vertical="top")
    for i in range(1,len(notes)+2):ws.row_dimensions[i].height=32
    order=list(tables)+[n for n in wb.sheetnames if n not in tables]
    wb._sheets=[wb[n] for n in order];wb.active=0;wb.save(workbook)
    # Reopen and inspect every authored sheet; no Excel formulas or error concealment.
    check=openpyxl.load_workbook(workbook,data_only=False)
    preview=[]
    for name,rows in tables.items():
        ws=check[name];assert ws.max_row==len(rows)+3
        assert ws.freeze_panes=="C4"
        preview.append("<h2>"+html.escape(name)+"</h2><div class=scroll><table>")
        for row in ws.iter_rows(min_row=3):
            preview.append("<tr>"+"".join("<"+("th" if row[0].row==3 else "td")+">"+html.escape(str(c.value if c.value is not None else ""))+"</"+("th" if row[0].row==3 else "td")+">" for c in row)+"</tr>")
        preview.append("</table></div>")
    (ROOT/"reports/Excel内容预览.html").write_text("<!doctype html><meta charset=utf-8><style>body{font-family:Arial,'Noto Sans CJK SC',sans-serif;margin:24px;color:#18202a}table{border-collapse:collapse;font-size:13px}td,th{padding:7px 10px;border-bottom:1px solid #ddd;white-space:nowrap}th{background:#245d87;color:white;position:sticky;top:0}.scroll{overflow:auto;max-height:650px}</style><h1>导师补充实验</h1><p>由最终Excel重新读取的内容预览；不是Excel应用截图。</p>"+"".join(preview))
    lines=["# 导师补充实验结果总览","",*notes,""]
    for suite in ["main","natural"]:
        lines+=["## "+("Car分类与Concrete回归" if suite=="main" else "自然脏表"),"","|数据集|条件|修复F1|正常误改%|下游宏F1或R²|","|---|---|---|---|---|"]
        for a in aggregate:
            if a["suite"]!=suite or a["arm"]=="reuse" or a["arm"].startswith("threshold_"):continue
            lines.append("|"+"|".join([DATA[a["dataset"]],ARMS[a["arm"]],fmt(a["F1"]),fmt(a["normal_damage"],100),fmt(a["macro_F1"] if a["dataset"]=="car_evaluation" else a["R2"]) if suite=="main" else "不适用"])+"|")
    (ROOT/"reports/导师讨论用结果总览.md").write_text("\n".join(lines)+"\n")
    assert sha(ROOT/"reports/all_scores.json")==frozen_raw
    save(ROOT/"audit/report_postprocess_review.json",{"at":time.time(),"raw_score_sha":frozen_raw,"count_based_rows_recomputed":verified,"aggregate_groups_independently_recomputed":len(aggregate),"paired_groups":len(paired_rows),"sheets_checked":list(tables),"formal_reference_rows_read":0,"preview":"HTML reads saved workbook; native Excel renderer unavailable on server","workbook_sha":sha(workbook),"all_original_scores_unchanged":True})
    save(ROOT/"status/delivery_ready.json",{"at":time.time(),"workbook":str(workbook),"review":"audit/report_postprocess_review.json","human_interpretation_and_resource_checks_still_required":True})
if __name__=="__main__":main()
