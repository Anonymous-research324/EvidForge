
"""Post-closure evidence audit only; does not execute skills or read formal references."""
from pathlib import Path
import json,collections,time
from common import ROOT,load,save,sha
def main():
 assert (ROOT/"status/learning_all_closed.json").exists()
 total=collections.Counter();details=[]
 for name in load(ROOT/"configs/cases.json"):
  c=ROOT/"cases"/name
  for stage in ["prior","context"]:
   p=c/"work/full"/(stage+"_stage/native_v3");result=load(p/"result.json")
   events=[json.loads(l) for l in (p/"native_hooks.jsonl").read_text().splitlines() if l.strip()]
   counts=collections.Counter(x["event"] for x in events)
   assert counts["PreToolUse"]==counts["PostToolUse"]==result["real9B_calls"]==5
   assert counts["Stop"]>=1
   total.update(counts);details.append({"case":name,"stage":stage,"calls":result["real9B_calls"],"hook_events":dict(counts),"hooks_sha":sha(p/"native_hooks.jsonl")})
 assert len(details)==12
 save(ROOT/"audit/actual_hooks_review.json",{"passed":True,"at":time.time(),"sessions":details,"actual_hooks":dict(total),"formal_rows_read":0,"new_calls":0})
if __name__=="__main__":main()
