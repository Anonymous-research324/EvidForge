"""Only import/seed context recovery around original frozen coverage audit."""
import os,subprocess
from pathlib import Path
from common import ROOT,PY,load
def audit_prior(case,prior):
    if (case/"teaching_coverage.json").exists():return
    env={**os.environ,"EF_SEED":str(load(case/"case.json")["seed"]),"EF_ARM":"full","PYTHONDONTWRITEBYTECODE":"1"}
    log=case/"logs/full/coverage_v3.log"
    with log.open("x") as f:p=subprocess.run([PY,"-B",ROOT/"code/coverage_entry_v3.py","--case",case,"--prior",prior],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError("Coverage subprocess failed; preserve "+str(log))
