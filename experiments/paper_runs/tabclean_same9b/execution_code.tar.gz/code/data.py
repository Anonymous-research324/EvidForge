"""CURATOR only: download official UCI sources; permanent discovery/confirmation group split."""
from pathlib import Path
import os,sys,json,io,csv,zipfile,urllib.request,hashlib,random,math,collections,concurrent.futures,decimal
from common import ROOT,load,save,sha,freeze,write_csv
sys.path[:0]=[str(ROOT/'dependencies'),str(ROOT/'engine/source_runtime')]
from unseen_table.common import equal
P=load(ROOT/'configs/protocol_v1.json')
CAT={x['id']:x for x in P['candidates']}
def canon(v):
 if isinstance(v,bytes):v=v.decode()
 if isinstance(v,(int,)):return str(v)
 try:
  d=decimal.Decimal(str(v))
  if not d.is_finite():raise ValueError('Unknown/nonfinite source value')
  return format(d.normalize(),'f')
 except decimal.InvalidOperation:
  return str(v)
def source(ds):
 spec=CAT[ds];folder=ROOT/'sources'/ds;folder.mkdir(parents=True,exist_ok=True);arc=folder/'original.zip'
 if not arc.exists():
  url='https://archive.ics.uci.edu/static/public/'+str(spec['uci'])+'/'+spec['source'].rsplit('/',1)[-1]+'.zip'
  with urllib.request.urlopen(url,timeout=120) as r:b=r.read()
  zipfile.ZipFile(io.BytesIO(b)).testzip()
  with arc.open('xb') as f:f.write(b)
  save(folder/'download.json',{'url':url,'sha256':sha(arc),'role':'curator source only'})
 if (folder/'canonical.json').exists():return load(folder/'canonical.json')
 z=zipfile.ZipFile(arc)
 names=z.namelist()
 def pick(ends):
  a=[n for n in names if n.lower().endswith(ends.lower()) and not n.startswith('__MACOSX')]
  if len(a)!=1:raise ValueError(('Ambiguous source',ds,ends,a))
  return z.read(a[0])
 original_ids=[]
 if ds=='banknote':
  raw=list(csv.reader(io.StringIO(pick('data_banknote_authentication.txt').decode())))
  headers=['variance','skewness','curtosis','entropy'];X=[r[:4] for r in raw if r];Y=[r[4] for r in raw if r]
 elif ds=='retinopathy':
  from scipy.io import arff
  data,meta=arff.loadarff(io.StringIO(pick('messidor_features.arff').decode()))
  headers=['quality','pre_screening',*[f'ma{i}' for i in range(1,7)],*[f'exudate{i}' for i in range(1,9)],'macula_disc_distance','disc_diameter','am_fm']
  X=[list(r)[:-1] for r in data];Y=[r[-1] for r in data]
 elif ds=='wdbc':
  raw=[r for r in csv.reader(io.StringIO(pick('wdbc.data').decode())) if r]
  base=['radius','texture','perimeter','area','smoothness','compactness','concavity','concave_points','symmetry','fractal_dimension']
  headers=[n+'_'+kind for kind in ['mean','se','worst'] for n in base]
  X=[r[2:] for r in raw];Y=[r[1] for r in raw];original_ids=[r[0] for r in raw]
 elif ds=='airfoil':
  raw=[r.split() for r in pick('airfoil_self_noise.dat').decode().splitlines() if r.strip()]
  headers=['frequency','attack_angle','chord_length','free_stream_velocity','suction_displacement_thickness'];X=[r[:-1] for r in raw];Y=[r[-1] for r in raw]
 elif ds=='wine_red':
  raw=list(csv.DictReader(io.StringIO(pick('winequality-red.csv').decode()),delimiter=';'))
  orig=[k for k in raw[0] if k!='quality'];headers=[k.replace(' ','_') for k in orig];X=[[r[k] for k in orig] for r in raw];Y=[r['quality'] for r in raw]
 else:
  import openpyxl
  if ds=='energy':suffix='ENB2012_data.xlsx'
  elif ds=='real_estate':suffix='Real estate valuation data set.xlsx'
  else:suffix='Dry_Bean_Dataset.xlsx'
  sheet=openpyxl.load_workbook(io.BytesIO(pick(suffix)),read_only=True,data_only=True).active
  raw=[list(r) for r in sheet.iter_rows(values_only=True)]
  raw=[r for r in raw[1:] if r and r[0] is not None]
  if ds=='energy':
   headers=['relative_compactness','surface_area','wall_area','roof_area','height','orientation','glazing_area','glazing_distribution'];X=[r[:8] for r in raw];Y=[r[8] for r in raw]
  elif ds=='real_estate':
   headers=['transaction_date','house_age','distance_mrt','convenience_stores','latitude','longitude'];X=[r[1:7] for r in raw];Y=[r[7] for r in raw];original_ids=[canon(r[0]) for r in raw]
  else:
   headers=['area','perimeter','major_axis_length','minor_axis_length','aspect_ratio','eccentricity','convex_area','equiv_diameter','extent','solidity','roundness','compactness','shape_factor1','shape_factor2','shape_factor3','shape_factor4'];X=[r[:16] for r in raw];Y=[r[16] for r in raw]
 X=[[canon(v) for v in row] for row in X];Y=[canon(y) for y in Y]
 assert len(X)==spec['rows'] and len(headers)==spec['features']
 assert all(len(r)==len(headers) and all(v not in ['', '?','None','nan'] for v in r) for r in X)
 # Public IDs are unique in supplied source sets; exact-feature duplicates stay together, all rows retained.
 groups=['g'+hashlib.sha256(json.dumps(row,separators=(',',':')).encode()).hexdigest()[:20] for row in X]
 uniq=sorted(set(groups),key=lambda g:hashlib.sha256(('permanent-pilot-v1:'+ds+':'+g).encode()).hexdigest())
 pilot=set(uniq[:round(.2*len(uniq))]);confirm=set(uniq)-pilot
 assert not pilot&confirm
 res={'dataset':ds,'headers':headers,'X':X,'y':Y,'groups':groups,'pilot_groups':sorted(pilot),'confirm_groups':sorted(confirm),'source_sha':sha(arc),'all_rows_preserved':True,'task':spec['task'],'original_public_id_count':len(set(original_ids)) if original_ids else 0}
 save(folder/'canonical.json',res);save(ROOT/'splits/private'/(ds+'.json'),{'pilot_groups':sorted(pilot),'confirmation_groups':sorted(confirm),'canonical_sha':sha(folder/'canonical.json'),'row_count':len(X),'group_count':len(uniq)})
 return res
def rows_for(src,zone,seed):
 groups=src['pilot_groups'] if zone=='pilot' else src['confirm_groups']
 order=list(groups);random.Random(seed).shuffle(order);n=len(order)
 if zone=='pilot':k=round(.4*n);v=round(.2*n);split={'learning':order[:k],'validation':order[k:k+v],'repair':order[k+v:]}
 else:
  k=round(.2*n);v=round(.1*n);w=round(.5*n);split={'learning':order[:k],'validation':order[k:k+v],'repair':order[k+v:k+v+w],'holdout':order[k+v+w:]}
 assert len(split['learning'])>=20 and len(split['validation'])>=10 and len(split['repair'])>=10
 return split
def build(ds,phase,seed,profile):
 ident=f'{phase}_{ds}_s{seed}_{profile}';c=ROOT/'cases'/ident
 if (c/'input_freeze.json').exists():
  for part in ['public','private']:
   for rel,h in load(c/'input_freeze.json')[part].items():assert sha(c/part/rel)==h
  return ident
 if c.exists():raise RuntimeError('Partial input preserved, curator review required: '+ident)
 src=source(ds);split=rows_for(src,phase,seed)
 for n in ['public','private','work','outputs','status','logs']:(c/n).mkdir(parents=True,exist_ok=True)
 cols=src['headers'];fields=['entity_id',*cols]
 rng=random.Random(seed+int(hashlib.sha256((ds+profile).encode()).hexdigest()[:8],16));ann=[];byzone={};counts={}
 families=['scale','affix'] if profile=='structured_repeat' else ['blank','digit','scale','affix']
 groupzone={g:z for z,gs in split.items() for g in gs}
 for zone in split:
  items=[]
  for i,(values,g) in enumerate(zip(src['X'],src['groups'])):
   if groupzone.get(g)!=zone:continue
   truth=dict(zip(cols,values));dirty={'entity_id':g,**truth}
   items.append({'row_key':ds+'-'+str(i),'group':g,'dirty':dirty,'truth':truth,'y':src['y'][i]})
  if zone!='holdout':
   choices=[(i,col) for i in range(len(items)) for col in cols];rng.shuffle(choices)
   for j,(i,col) in enumerate(choices[:round(.3*len(choices))]):
    t=items[i]['truth'][col];kind=families[j%len(families)]
    if kind=='scale':
     num=decimal.Decimal(t)
     if num==0:kind='affix'
     else:new=format(num*100,'f')
    if kind=='affix':new='ERR'+t+'BAD'
    elif kind=='blank':new=''
    elif kind=='digit':
     ix=[k for k,ch in enumerate(t) if ch.isdigit()];pos=rng.choice(ix);new=t[:pos]+rng.choice([d for d in '0123456789' if d!=t[pos]])+t[pos+1:]
    assert not equal(new,t)
    items[i]['dirty'][col]=new
    ann.append({'zone':zone,'row_key':items[i]['row_key'],'group':items[i]['group'],'field':col,'mechanism':kind})
  byzone[zone]=items
  counts[zone]={'rows':len(items),'groups':len(split[zone]),'errors':sum(not equal(a['dirty'][col],a['truth'][col]) for a in items for col in cols)}
 bundle={zone:[{'group':g,'provenance':'authorized controlled teaching, not formal test','records':[{k:a[k] for k in ['row_key','dirty','truth']} for a in byzone[zone] if a['group']==g]} for g in split[zone]] for zone in ['learning','validation']}
 decl={'id':ident,'provenance':'UCI original schema, newly controlled errors; source previously may be known; not natural dirty/new blind','entity_fields':['entity_id'],'targets':cols,'protected_fields':[],'visible_context_fields':[],'fields':{'entity_id':{'role':'identity','type':'string','identity':True},**{k:{'role':'target','type':'number','meaning':'Original UCI input field: '+k} for k in cols}}}
 pub=c/'public';save(pub/'development_bundle.json',bundle);save(pub/'declaration.json',decl);save(pub/'context.json',{'dataset':ds,'source':'uci-controlled-protocol-20261024','seed':str(seed),'schema_meanings':'Original source feature names, all labels/IDs excluded'})
 write_csv(pub/'repair_dirty.csv',fields,[a['dirty'] for a in byzone['repair']])
 write_csv(c/'private/repair_reference.csv',fields+['class'],[{'entity_id':a['group'],**a['truth'],'class':a['y']} for a in byzone['repair']])
 save(c/'private/repair_rowkeys.json',{'row_keys':[a['row_key'] for a in byzone['repair']]})
 save(c/'private/error_annotations.json',{'cells':ann})
 if 'holdout' in byzone:write_csv(c/'private/holdout_reference.csv',fields+['class'],[{'entity_id':a['group'],**a['truth'],'class':a['y']} for a in byzone['holdout']])
 meta={'id':ident,'dataset':ds,'seed':seed,'suite':'confirmatory','phase':phase,'profile':profile,'task':src['task'],'constructed_errors':True,'original_natural_dataset':False,'rate':.3,'zones':counts,'source_sha':src['source_sha'],'targets':cols,'categorical_columns':[],'protected_labels':True}
 save(c/'case.json',meta);save(pub/'dataset_metadata.json',meta)
 save(c/'input_freeze.json',{'public':freeze(pub),'private':freeze(c/'private'),'case_sha':sha(c/'case.json')})
 return ident
def pilot_all():
 sources={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  fs={pool.submit(source,d):d for d in CAT}
  for f,d in [(f,fs[f]) for f in fs]:sources[d]=f.result();print('SOURCE',d,len(sources[d]['X']),flush=True)
 names=[]
 # Fixed priority order, matched lanes include each method on same hardware.
 dsorder=[x['id'] for x in sorted(P['candidates'],key=lambda x:(x['priority'],x['task']))]
 for d in dsorder:
  for seed in P['selection']['pilot_seeds']:
   for prof in ['structured_repeat','mixed']:names.append(build(d,'pilot',seed,prof))
 save(ROOT/'configs/pilot_cases.json',names);save(ROOT/'audit/pilot_inputs_frozen.json',{'cases':{n:sha(ROOT/'cases'/n/'input_freeze.json') for n in names},'no_formal_score_read':True})
 print('PILOT_INPUTS_CLOSED',len(names),flush=True)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='formal':
  selection=load(ROOT/'configs/selected_datasets.json')
  names=[build(d,'confirmation',s,p) for d in selection['selected'] for s in P['selection']['confirmation_seeds'] for p in ['structured_repeat','mixed']]
  save(ROOT/'configs/confirmation_cases.json',names)
  save(ROOT/'audit/confirmation_inputs_frozen.json',{'cases':{n:sha(ROOT/'cases'/n/'input_freeze.json') for n in names},'selection_sha':sha(ROOT/'configs/selected_datasets.json')})
  print('CONFIRMATION_INPUTS_CLOSED',len(names),flush=True)
 else:pilot_all()
