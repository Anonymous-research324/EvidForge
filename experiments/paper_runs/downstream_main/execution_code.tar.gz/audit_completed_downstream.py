"""Post-completion verification only; no fitting, rescoring, or row-level truth parsing."""
from pathlib import Path
import json,hashlib,math,time,socket,datetime,os
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def alive(pid):
 p=Path('/proc')/str(pid)/'stat'
 return p.exists() and p.read_text().split()[2]!='Z'
def main():
 P=load(ROOT/'protocol.json');done=load(ROOT/'status/complete.json')
 assert not alive(load(ROOT/'status/owner.json')['pid'])
 for f,h in load(ROOT/'audit/controller_freeze.json')['files'].items():assert sha(ROOT/f)==h,'Frozen controller changed '+f
 assert sha(Path(P['original_scores']))==P['original_scores_sha256']
 ag=load(ROOT/'reports/three_seed_downstream_aggregate.json')
 scores={1013:load(Path(P['original_scores']))}
 summary={};total_files=0
 for s in [1014,1015]:
  b=Path(P['new_roots'][str(s)]);detail={}
  assert not list((b/'status/failures').glob('*.json'))
  for f,h in load(b/'audit/run_code_freeze.json')['files'].items():assert sha(b/f)==h,'New adapter changed '+f
  for f,h in load(b/'audit/frozen_v23_files.json')['files'].items():assert sha(b/f)==h,'Original core changed '+f
  before=load(b/'audit/pre_score_output_verification.json')['time'];sc=load(b/'audit/scoring_started.json')['started']
  assert before<=sc
  assert load(b/'status/scoring_complete.json')['rows']==51
  values=load(b/f'reports/final_seed{s}/scores.json');assert len(values)==51 and all(x['status']=='complete' for x in values)
  assert all(x['parameters']['random_state']==s for x in values)
  scores[s]=values
  input_files=0;outfiles=0;stages=0
  for n in P['datasets']:
   inp=load(b/'datasets'/n/'input_freeze.json');assert inp['seed']==s
   for group,folder in [('public','public'),('private','private'),('supervised_labels','downstream_training')]:
    for f,h in inp[group].items():
     assert sha(b/'datasets'/n/folder/f)==h,'Input mutated';input_files+=1
   for stage in ['primary_llm','tool_llm','raha_holoclean','garf','cdc']+(['caafe'] if n in P['classification'] else []):
    folder=b/'outputs'/n/stage
    for f,h in load(folder/'output_freeze.json')['files'].items():
     assert sha(folder/f)==h,'Method output mutated '+str(folder/f);outfiles+=1
    stages+=1
  req=list((b/'models_service/requests').glob('*/request.json'))
  usage={'prompt_tokens':0,'completion_tokens':0,'total_tokens':0}
  for p in req:
   x=load(p);assert x['seed']==s and x['temperature']==0 and x['model']==f'evidforge-downstream-seed{s}'
   reply=load(p.parent/'response.json')
   for k in usage:usage[k]+=reply.get('usage',{}).get(k,0) or 0
  assert len(req)==468 and len(list((b/'models_service/requests').glob('*/response.json')))==468
  native=[]
  for p in (b/'outputs/stages').glob('*/native/result.json'):
   x=load(p);assert x['native_exit_code']==0 and x['closed'] and x['synthetic_control_count']==0 and x['test_gold_read']==False
   assert x['real9B_calls']==5
   native.append({'stage':p.parent.parent.name,'calls':x['real9B_calls'],'deferred':x.get('deferred'),'has_candidate':x.get('candidate') is not None})
  assert len(native)==12
  sel={p.parent.name:load(p)['passed'] for p in (b/'outputs/v23').glob('*/selection.json')};assert len(sel)==6
  fallback={n:load(b/'outputs'/n/'tool_llm/receipt.json').get('fallback',False) for n in P['datasets']}
  own=load(b/'models_service/owner.json');assert not alive(own['pid']) and (b/'models_service/stopped.json').exists()
  assert (b/'status/postgres_stopped.json').exists() and not (b/'outputs/postgres/cluster/postmaster.pid').exists()
  for port in [P['model_ports'][str(s)],P['postgres_ports'][str(s)]]:
   with socket.socket() as sock:
    sock.settimeout(1);assert sock.connect_ex(('127.0.0.1',port))!=0,'Owned port still active'
  total_files+=outfiles
  summary[s]={'core_files':124,'input_hashes_verified':input_files,'output_hashes_verified':outfiles,'closed_output_stages_including_features':stages,
    'scores_complete':51,'request_response_pairs':len(req),'usage':usage,'native_sessions':native,
    'native_actual_calls':60,'native_synthetic_count':0,'selection_passed':sel,'tool_pure_fallback':fallback,'owned_gpu_server_and_pg_stopped':True}
 checks=0;comparisons={}
 for row in ag['records']:
  n=row['dataset'];m=row['method']
  for k,stats in row['metrics'].items():
   vals=[]
   for s in [1013,1014,1015]:
    match=[x for x in scores[s] if x['dataset']==n and x['method']==m];assert len(match)==1
    v=match[0]['metrics'][k];assert math.isfinite(v);vals.append(v)
    assert math.isclose(v,stats['per_seed'][str(s)],rel_tol=0,abs_tol=1e-12)
   mean=sum(vals)/3;sd=math.sqrt(sum((v-mean)**2 for v in vals)/2)
   assert stats['n']==3 and stats['ddof']==1
   assert math.isclose(mean,stats['mean'],abs_tol=1e-12,rel_tol=0)
   assert math.isclose(sd,stats['sample_sd'],abs_tol=1e-12,rel_tol=0);checks+=1
 lookup={(x['dataset'],x['method']):x for x in ag['records']}
 for n in P['datasets']:
  comparisons[n]={}
  for method in ['dirty','pure_llm','tool_llm','raha_holoclean','garf','cdc']+(['caafe'] if n in P['classification'] else []):
   comps={}
   for k,v in lookup[n,'v23']['metrics'].items():
    delta=v['mean']-lookup[n,method]['metrics'][k]['mean']
    comps[k]={'system_minus_control':delta,'system_better':delta<0 if k=='MAE' else delta>0}
   comparisons[n][method]=comps
 stamp=time.time()
 result={'verified_at':stamp,'original_1013_scores_unchanged':True,'controller_and_new_adapters_and_core_unchanged':True,
 'aggregate_cells':len(ag['records']),'mean_and_sample_sd_pairs_recomputed':checks,'sample_size':3,'sample_sd_ddof':1,
 'per_seed':summary,'output_hashes_verified':total_files,'mean_metric_comparisons':comparisons,
 'individual_formal_reference_rows_parsed':False,'new_model_calls':0,'rerun_or_rescore':False,
 'completed_cst':datetime.datetime.fromtimestamp(done['time'],datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'elapsed_minutes':(done['time']-load(ROOT/'status/owner.json')['started'])/60,
 'scope':'Previously selected six tables, not a new blind test; original eight retained; three repetitions do not establish statistical significance'}
 save(ROOT/'audit/completed_downstream_three_seed_audit.json',result)
 save(ROOT/'reports/交付文件指纹.json',{str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'reports/第二个实验_三种子下游均值与标准差.md',ROOT/'reports/three_seed_downstream_aggregate.json',ROOT/'audit/completed_downstream_three_seed_audit.json']})
 print(json.dumps({'all_checks_passed':True,'metrics_recomputed':checks,'requests':sum(x['request_response_pairs'] for x in summary.values()),'native_actual_calls':120,'output_files_hashed':total_files,'qualification':{s:d['selection_passed'] for s,d in summary.items()},'completed_cst':result['completed_cst'],'elapsed_minutes':result['elapsed_minutes']},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
