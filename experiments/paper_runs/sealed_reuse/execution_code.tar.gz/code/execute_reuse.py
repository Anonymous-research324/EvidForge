
"""One CPU process executes B1/B2/B3, then concatenation control, without fit/network."""
from pathlib import Path
import os,time,argparse,copy
from common import ROOT,ENGINE,load,save,sha,freeze,read_csv,write_csv

def verify(case):
 capsule=load(case/"sealed/capsule.json")
 for p,h in capsule["files"].items():
  if sha(p)!=h:raise ValueError("Frozen capsule mismatch: "+p)
 return capsule

def perform(case):
 if not (ROOT/"status/inference_disabled.json").exists():raise RuntimeError("Global model-off barrier missing")
 if (case/"status/execution_started.json").exists():raise RuntimeError("Partial execution needs fixed-output recovery")
 meta=load(case/"case.json")
 os.environ.update(EF_SEED=str(meta["seed"]),EF_ROLE="execution",EF_ARM="full",EF_CASE=str(case),CUDA_VISIBLE_DEVICES="",OMP_NUM_THREADS="2",OPENBLAS_NUM_THREADS="2",MKL_NUM_THREADS="2")
 from runtime_v4 import install
 install()
 from source_cache import install as install_cache
 from offline_guard import install as offline,stop_profile
 from workflow.packages import execute
 capsule=verify(case);events=[];install_cache(load(case/"sealed/source_cache.json"),events)
 targets=set(load(case/"source/declaration.json")["targets"])
 save(case/"status/execution_started.json",{"pid":os.getpid(),"at":time.time(),"capsule_sha":sha(case/"sealed/capsule.json")})
 combined=[];keys_combined=[];batch_outputs=[]
 for label in ["B1","B2","B3","combined_control"]:
  verify(case);out=case/"outputs"/label
  if out.exists():raise FileExistsError("Never overwrite partial output "+str(out))
  out.mkdir()
  if label=="combined_control":rows=combined;keys=keys_combined
  else:
   fields,rows=read_csv(case/"batches"/label/"dirty.csv");keys=load(case/"batches"/label/"row_keys.json")
   combined.extend(copy.deepcopy(rows));keys_combined.extend(keys)
  event_start=len(events);counts=offline(out/"offline_events.jsonl",ENGINE)
  t=time.monotonic()
  try:output,decisions=execute(rows,capsule["selected_skill"])
  finally:elapsed=time.monotonic()-t;stop_profile()
  if any(counts.values()):raise ValueError("Forbidden inference action attempted")
  if len(rows)!=len(output) or any(set(x)!=set(fields) for x in output):raise ValueError("Output shape changed")
  if any(a[c]!=b[c] for a,b in zip(rows,output) for c in fields if c not in targets):raise ValueError("Protected ID changed")
  if label=="combined_control":
   if output!=batch_outputs:raise ValueError("Split versus combined output differs; preserve and review")
   parity=True
  else:batch_outputs.extend(copy.deepcopy(output));parity=None
  write_csv(out/"repair_output.csv",fields,output);save(out/"row_keys.json",keys);save(out/"decisions.json",decisions)
  save(out/"receipt.json",{"rows":len(rows),"seconds":elapsed,"new_model_calls":0,"new_tokens":0,"fit_attempts":counts["fit_attempts"],"network_attempts":counts["network_attempts"],"subprocess_attempts":counts["subprocess_attempts"],"source_cache_hits":events[event_start:],"combined_parity":parity,"capsule_sha":sha(case/"sealed/capsule.json"),"skill_sha":sha(Path(capsule["selected_skill"])/"manifest.json"),"formal_reference_read":False,"cpu_only":True})
  verify(case);save(out/"output_freeze.json",{"files":freeze(out)})
 save(case/"status/outputs_closed.json",{"at":time.time(),"batches":["B1","B2","B3"],"combined_parity":True,"new_model_calls":0,"fit_attempts":0,"formal_reference_read":False})

def main():
 p=argparse.ArgumentParser();p.add_argument("--case",required=True);a=p.parse_args();case=Path(a.case)
 try:perform(case)
 except Exception as e:
  import traceback
  save(case/"status/execution_failure.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
if __name__=="__main__":main()
