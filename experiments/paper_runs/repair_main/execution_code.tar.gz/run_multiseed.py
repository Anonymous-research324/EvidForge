"""Two additional fixed-method seeds. All data/code stay on A100."""
from pathlib import Path
import os,sys,json,time,subprocess,concurrent.futures,fcntl,traceback,hashlib
ROOT=Path(__file__).resolve().parent
PY="/root/fsas/home/anonymous/envs/dataforge-run/bin/python"
SEEDS=[1014,1015]
NAMES=["qsar","monks1","bc_original","cmc","mammographic","ilpd","climate","voting"]
BASE=Path("/root/fsas/home/anonymous/projects/DataForge_V23_Benchmark_seed1013")
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 t=p.with_name(p.name+"."+str(os.getpid())+"."+str(time.time_ns())+".tmp")
 t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+"\n");os.replace(t,p)
def load(p):return json.loads(Path(p).read_text())
def case(seed):return ROOT.parent/f"EvidForge_Benchmark_seed{seed}"
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(seed):
 r=case(seed)
 for rel,h in load(r/"audit/run_code_freeze.json")["files"].items():assert digest(r/rel)==h,rel
 for rel,h in load(r/"audit/frozen_v23_files.json")["files"].items():assert digest(r/rel)==h,rel
def live_command(pid):
 try:return Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0",b" ").decode()
 except FileNotFoundError:return ""
def invoke(seed,stage,script,*,dataset=None,environment=None,timeout=None,args=None):
 r=case(seed);tag=(dataset+"_" if dataset else "")+stage
 log=r/"logs"/(tag+".log")
 if log.exists():raise RuntimeError("Existing attempt must be inspected before resuming: "+str(log))
 py=str(r/"environments"/environment/"bin/python") if environment else PY
 cmd=[py,"-B",str(r/"code"/script),*(["--dataset",dataset] if dataset else []),*(args or [])]
 state=r/"status"/(stage+".json")
 with log.open("x") as f:
  p=subprocess.Popen(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,
   env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"4","OPENBLAS_NUM_THREADS":"4","MKL_NUM_THREADS":"4",
        **({"CUDA_VISIBLE_DEVICES":""} if environment else {})})
  save(state,{"phase":"running","pid":p.pid,"seed":seed,"dataset":dataset,"command":cmd,"started":time.time(),"controller":os.getpid()})
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:raise RuntimeError("Process still running after startup wait; inspect PID, do not duplicate "+str(p.pid))
 if rc:raise RuntimeError(f"seed{seed} {tag}: exit{rc}, inspect {log}")
 save(state,{"phase":"complete","seed":seed,"dataset":dataset,"pid":p.pid,"finished":time.time()})
def gpu(seed):
 r=case(seed)
 verify(seed)
 invoke(seed,"service_start","model_service.py",args=["start"],timeout=900)
 for name in NAMES:
  if not (r/"outputs/v23"/name/"selection.json").exists():
   invoke(seed,"learning_"+name,"run_v23_learning.py",dataset=name)
  if not (r/"outputs"/name/"primary_llm/output_freeze.json").exists():
   invoke(seed,"primary_"+name,"run_primary_llm_v3.py",dataset=name)
  if not (r/"outputs"/name/"tool_llm/output_freeze.json").exists():
   invoke(seed,"tool_"+name,"run_tool_llm_v5.py",dataset=name)
 verify(seed)
 invoke(seed,"service_stop","model_service.py",args=["stop"],timeout=90)
 save(r/"status/gpu_queue_complete.json",{"seed":seed,"time":time.time(),"all_model_stages_closed":True})
def garf(seed):
 for name in NAMES:
  r=case(seed)
  if not (r/"outputs"/name/"garf/output_freeze.json").exists():
   invoke(seed,"garf_"+name,"run_garf.py",dataset=name,environment="garf")
def detection_and_holo():
 for name in NAMES:
  for seed in SEEDS:
   r=case(seed)
   if not (r/"outputs"/name/"raha_detection/output_freeze.json").exists():
    invoke(seed,"raha_detection_"+name,"run_raha_detection.py",dataset=name,environment="raha")
   if not (r/"outputs"/name/"raha_holoclean/output_freeze.json").exists():
    invoke(seed,"holoclean_"+name,"run_holoclean.py",dataset=name,environment="holoclean")
def cdc():
 for name in NAMES:
  for seed in SEEDS:
   r=case(seed)
   if not (r/"outputs"/name/"cdc/output_freeze.json").exists():
    invoke(seed,"cdc_"+name,"run_cdc.py",dataset=name,environment="cdc")
def overview():
 counts={}
 methods=["pure_llm","tool_llm","raha_holoclean","garf","cdc","v23"]
 for seed in SEEDS:
  r=case(seed);states={}
  for n in NAMES:
   states[n]={m:(r/"outputs"/n/("primary_llm" if m in ["pure_llm","v23"] else m)/"output_freeze.json").exists() for m in methods}
  counts[str(seed)]={"closed":sum(sum(x.values()) for x in states.values()),"total":48,"datasets":states}
 save(ROOT/"status/overview.json",{"time":time.time(),"seeds":counts,"old1013_unchanged":True})
 return counts
def check_outputs(seed):
 r=case(seed)
 verify(seed)
 import csv
 for name in NAMES:
  with (r/"datasets"/name/"public/repair_dirty.csv").open() as f:
   rd=csv.DictReader(f);cols=rd.fieldnames;ids=[x["entity_id"] for x in rd]
  for method in ["primary_llm","tool_llm","raha_holoclean","garf","cdc"]:
   out=r/"outputs"/name/method
   for rel,h in load(out/"output_freeze.json")["files"].items():
    assert digest(out/rel)==h,str(out/rel)
   names=["pure_output.csv","v23_output.csv"] if method=="primary_llm" else ["repair_output.csv"]
   for filename in names:
    with (out/filename).open() as f:
     rd=csv.DictReader(f);assert rd.fieldnames==cols
     assert [x["entity_id"] for x in rd]==ids
 save(r/"audit/all48_public_output_integrity.json",{"seed":seed,"passed":True,"formal_reference_read":False,"time":time.time()})
def main():
 (ROOT/"status").mkdir(exist_ok=True)
 with (ROOT/"status/controller.lock").open("a") as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  save(ROOT/"status/owner.json",{"pid":os.getpid(),"time":time.time(),"command":sys.argv})
  # First generate every input without reading existing formal evaluation labels.
  for seed in SEEDS:
   r=case(seed);verify(seed)
   missing=[n for n in NAMES if not (r/"datasets"/n/"input_freeze.json").exists()]
   if missing:
    invoke(seed,"generate_inputs","generate_benchmarks.py",args=["--datasets",*missing])
   if not (r/"status/postgres.json").exists():
    invoke(seed,"postgres_start","start_owned_postgres.py",timeout=120)
  work={"gpu1014":lambda:gpu(1014),"gpu1015":lambda:gpu(1015),
        "garf1014":lambda:garf(1014),"garf1015":lambda:garf(1015),
        "raha_holoclean":detection_and_holo,"cdc":cdc}
  errors={}
  with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
   futures={pool.submit(fn):key for key,fn in work.items()}
   while futures:
    done,_=concurrent.futures.wait(futures,timeout=25,return_when=concurrent.futures.FIRST_COMPLETED)
    overview()
    for f in done:
     key=futures.pop(f)
     try:f.result();save(ROOT/"status"/(key+"_complete.json"),{"time":time.time()})
     except Exception as e:
      errors[key]={"error":repr(e),"traceback":traceback.format_exc()}
      save(ROOT/"status/failures.json",errors)
   overview()
  if errors:raise RuntimeError("Branches require interface review, no scoring: "+str(list(errors)))
  # Check all new outputs, then score both new seeds ONCE without changing any parameters.
  for seed in SEEDS:
   check_outputs(seed)
   r=case(seed)
   for name in NAMES:
    receipt=load(r/"datasets"/name/"input_freeze.json")
    for zone in ["public","private"]:
     for rel,h in receipt[zone].items():assert digest(r/"datasets"/name/zone/rel)==h
   marker=r/"audit/scoring_started.json"
   if marker.exists():raise RuntimeError("Scoring receipt exists; inspect without regrading")
   save(marker,{"time":time.time(),"all48_closed":True})
   invoke(seed,"final_scoring","score_all.py")
   invoke(seed,"postgres_stop","start_owned_postgres.py",args=["stop"],timeout=90)
  result=subprocess.run([PY,"-B",str(ROOT/"aggregate_three_seeds.py")],cwd=ROOT)
  if result.returncode:raise RuntimeError("Aggregation failed; preserve all scores")
  save(ROOT/"status/complete.json",{"time":time.time(),"seeds":[1013,1014,1015],"standard_deviation":"sample, ddof=1"})
if __name__=="__main__":
 try:main()
 except Exception as e:
  save(ROOT/"status/controller_error.json",{"time":time.time(),"error":repr(e),"traceback":traceback.format_exc()})
  raise
