"""CURATOR role only: new controlled, domain-valid corruptions on known natural tables."""
from pathlib import Path
import json,csv,random,hashlib,collections,copy,datetime
ROOT=Path(__file__).resolve().parents[1]
OLD=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("x") as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def table(p):
 with Path(p).open(newline="",encoding="utf-8-sig") as f:r=csv.DictReader(f);return r.fieldnames,list(r)
def write(p,fields,rows):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("x",newline="") as f:w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n");w.writeheader();w.writerows(rows)
def freeze(p):return {str(x.relative_to(p)):sha(x) for x in sorted(p.rglob("*")) if x.is_file()}
def make(dataset,seed):
 old=OLD/"cases"/("natural_"+dataset+"_s"+str(seed))
 c=ROOT/"cases"/("semantic_"+dataset+"_s"+str(seed))
 if c.exists():
  if (c/"input_freeze.json").exists():raise RuntimeError("Closed input must not be regenerated")
  assert not list((c/"public").glob("*")) and not list((c/"private").glob("*"))
 else:c.mkdir()
 for d in ["public","private","outputs","work","logs","status"]:(c/d).mkdir(exist_ok=True)
 bundle=load(old/"public/development_bundle.json");decl=load(old/"public/declaration.json")
 source=OLD/"references/TabClean_author/datasets"/("hospital" if dataset=="hospital" else "flight2")/"clean.csv"
 fields,clean=table(source)
 identity="ProviderNumber" if dataset=="hospital" else "flight"
 ordered_entities=sorted({row[identity] for row in clean})
 pseudonym={ident:"g"+format(i,"06d") for i,ident in enumerate(ordered_entities)}
 outfields,repair=table(old/"public/repair_dirty.csv")
 targeted=["Condition","MeasureName","Stateavg"] if dataset=="hospital" else decl["targets"]
 # Donor domain comes ONLY from authorized external teaching, not formal values.
 domains={col:sorted({r["truth"][col] for g in bundle["learning"] for r in g["records"] if r["truth"].get(col,"").strip()}) for col in targeted}
 assert all(len(d)>1 for d in domains.values())
 for g in bundle["learning"]+bundle["validation"]:
  for r in g["records"]:
   # Start each new controlled sample from its original clean reference.
   r["dirty"]={**r["dirty"],**r["truth"]}
   source_i=int(r["row_key"].rsplit("-",1)[1])
   assert pseudonym[clean[source_i][identity]]==g["group"]
   r["dirty"][identity]=clean[source_i][identity]
 rng=random.Random(seed);annotations=[];summary={}
 def corrupt(rows,zone):
  # row=(stable key, entity group, dirty dict, known truth dict)
  choices=[(i,col) for i,(_,_,d,t) in enumerate(rows) for col in targeted if t.get(col,"").strip() and any(v!=t[col] for v in domains[col])]
  rng.shuffle(choices);n=round(.30*len(choices));selected=choices[:n]
  for j,(i,col) in enumerate(selected):
   key,group,d,t=rows[i];candidates=[v for v in domains[col] if v!=t[col]]
   mechanism="domain_valid_cross_field_substitution" if dataset=="hospital" else "domain_valid_time_substitution"
   after=rng.choice(candidates)
   if dataset=="flights" and j%2==0:
    partner={"sched_dep_time":"act_dep_time","act_dep_time":"sched_dep_time","sched_arr_time":"act_arr_time","act_arr_time":"sched_arr_time"}[col]
    if t.get(partner,"").strip() and t[partner]!=t[col]:
     after=t[partner];mechanism="schedule_actual_field_confusion"
   assert after!=t[col];d[col]=after
   annotations.append({"zone":zone,"row_key":key,"group":group,"field":col,"clean":t[col],"dirty":after,"mechanism":mechanism,"constructed":True})
  summary[zone]={"rows":len(rows),"eligible_target_cells":len(choices),"injected_cells":n,"rate":n/len(choices) if choices else None}
 for zone in ["learning","validation"]:
  rows=[(r["row_key"],g["group"],r["dirty"],r["truth"]) for g in bundle[zone] for r in g["records"]]
  corrupt(rows,zone)
 formal=[]
 for row in repair:
  index=int(row["index"])-1 if dataset=="flights" else None
  if dataset=="hospital":
   # Row key to source index is known from the original curator, not a method prediction.
   # Original repair order preserves entity order, so align via full public row identity against original dirty.
   pass
 # Resolve source row indices without guessing: original public dirty rows are exact known source rows.
 _,dirty_source=table(source.with_name("dirty.csv"))
 index_map=collections.defaultdict(list)
 for i,d in enumerate(dirty_source):index_map[tuple(d[f] for f in fields)].append(i)
 consumed=collections.Counter()
 for row in repair:
  k=tuple(row[f] for f in fields);position=consumed[k];ids=index_map[k]
  if position>=len(ids):raise ValueError("Ambiguous/unmatched source alignment")
  idx=ids[position];consumed[k]+=1;ref=clean[idx]
  identity="ProviderNumber" if dataset=="hospital" else "flight"
  if pseudonym[ref[identity]]!=row["entity_id"]:raise ValueError("Source pseudonym entity mismatch")
  truth={col:ref[col] for col in decl["targets"]}
  observed={**row,**truth,identity:ref[identity]}
  formal.append((dataset+"-"+str(idx),row["entity_id"],observed,truth))
 corrupt(formal,"repair")
 # All non-targeted features are clean in this controlled construction; not true of original natural dataset.
 decl["id"]="controlled-semantic-"+dataset+"-"+str(seed)
 decl["provenance"]="Previously known real table, curator-generated domain-valid controlled errors; NOT original natural dirty data or new blind data"
 groups={z:{g["group"] for g in bundle[z]} for z in ["learning","validation"]}
 groups["repair"]={r[1] for r in formal}
 assert not groups["learning"]&groups["validation"] and not groups["learning"]&groups["repair"] and not groups["validation"]&groups["repair"]
 for zone in ["learning","validation"]:
  for g in bundle[zone]:
   for r in g["records"]:
    assert all(r["dirty"][f]==r["truth"][f] for f in decl["targets"] if f not in targeted)
 pub=c/"public"
 save(pub/"development_bundle.json",bundle);save(pub/"declaration.json",decl)
 save(pub/"context.json",{"dataset":dataset,"source":"controlled-semantic-known-natural-table","seed":str(seed)})
 write(pub/"repair_dirty.csv",outfields,[r[2] for r in formal])
 write(c/"private/repair_reference.csv",outfields,[{**r[2],**r[3]} for r in formal])
 save(c/"private/error_annotations.json",{"cells":annotations,"selection":"uniform hash-independent of method performance; fixed random.Random seed","known_blank_reference":"exclude"})
 meta={"id":c.name,"dataset":dataset,"seed":seed,"suite":"semantic_controlled","task":"repair_only","constructed_errors":True,"original_natural_dataset":False,"previously_seen_source":True,"rate_on_eligible_selected_fields":.30,"controlled_fields":targeted,
 "zones":summary,"source_clean_sha256":sha(source),"source_dirty_sha256":sha(source.with_name("dirty.csv")),"same_original_entity_partitions":True,"model_sees_formal_annotations":False,"unmodified_other_features":"curator-confirmed; available identically to all methods"}
 save(c/"case.json",meta);save(pub/"dataset_metadata.json",meta)
 save(c/"input_freeze.json",{"public":freeze(pub),"private":freeze(c/"private"),"case_sha256":sha(c/"case.json")})
 return c.name
def main():
 save(ROOT/"status/curator_v2_started.json",{"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"role":"curator-only"})
 cases=[make(d,s) for s in [1013,1014,1015] for d in ["hospital","flights"]]
 save(ROOT/"configs/semantic_cases.json",cases)
 save(ROOT/"audit/semantic_inputs_frozen.json",{"cases":{n:sha(ROOT/"cases"/n/"input_freeze.json") for n in cases},"formal_performance_read":False,"curator_used_clean_source_to_construct_dataset":True})
 print("SEMANTIC_INPUTS_FROZEN",len(cases))
if __name__=="__main__":main()
