"""两张owned A100同权重BF16服务；每个请求独立绑定种子，完整计账。"""
from pathlib import Path
import os,sys,json,time,subprocess,socket,signal,urllib.request
from common import ROOT,PY,load,save
GPU=int(os.environ.get("EF_GPU","0"));DEVICES=os.environ.get("EF_DEVICES",str(GPU));PORT=8321+GPU;NAME="evidforge-realcompatv3-20261028-gpu"+str(GPU);SERVICE=ROOT/"services_v3"/("gpu"+str(GPU))
def start():
 assert socket.gethostname()==load(ROOT/"configs/protocol.json")["hardware_host"]
 SERVICE.mkdir(parents=True,exist_ok=True)
 if (SERVICE/"owner.json").exists():raise RuntimeError("Owner exists: inspect rather than duplicate")
 rows=subprocess.check_output(["nvidia-smi","--query-gpu=index,memory.used","--format=csv,noheader,nounits"],text=True)
 used={int(x.split(",")[0]):int(x.split(",")[1]) for x in rows.splitlines()}
 if any(used[int(g)]>=512 for g in DEVICES.split(",")):raise RuntimeError("GPU occupied")
 with socket.socket() as s:s.bind(("127.0.0.1",PORT))
 weights="/root/fshare/models/Qwen/Qwen3.5-9B"
 manifest=ROOT/"configs/model-files-9B.sha256"
 check=load(ROOT/'audit/weights_verified.json')
 from common import sha
 assert check['passed'] and check['manifest_sha256']==sha(manifest)
 for f,st in check['stats'].items():
  q=Path(weights)/f;actual=q.stat();assert [actual.st_size,actual.st_mtime_ns]==st
 save(SERVICE/'weights_check.json',{'passed':True,'global_receipt_sha':sha(ROOT/'audit/weights_verified.json')})
 cmd=["/root/fsas/home/anonymous/envs/dataforge-infer/bin/python","-m","vllm.entrypoints.openai.api_server","--model",weights,"--served-model-name",NAME,"--host","127.0.0.1","--port",str(PORT),"--tensor-parallel-size",str(len(DEVICES.split(","))),"--dtype","bfloat16","--language-model-only","--max-model-len","131072","--max-num-seqs","1","--gpu-memory-utilization",".90","--reasoning-parser","qwen3","--seed","1013","--default-chat-template-kwargs",'{"enable_thinking":false}']
 env={**os.environ,"CUDA_VISIBLE_DEVICES":DEVICES,"HF_HUB_OFFLINE":"1","TRANSFORMERS_OFFLINE":"1","OMP_NUM_THREADS":"1","VLLM_USE_FLASHINFER_SAMPLER":"0","PYTHONDONTWRITEBYTECODE":"1"}
 with (SERVICE/"server.log").open("x") as f:p=subprocess.Popen(cmd,env=env,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 save(SERVICE/"owner.json",{"pid":p.pid,"pgid":p.pid,"gpu":GPU,"physical_devices":DEVICES,"host":__import__("socket").gethostname(),"port":PORT,"name":NAME,"command":cmd})
 for _ in range(900):
  if p.poll() is not None:raise RuntimeError("Owned server exited")
  try:
   with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/v1/models",timeout=2) as r:m=json.load(r)
   save(SERVICE/"ready.json",{"models":m,"at":time.time()});return
  except OSError:time.sleep(2)
 raise TimeoutError("Owned service not ready; do not duplicate")
def call():
 body=json.load(sys.stdin);tag=body.pop("_trace_tag");seed=int(os.environ["EF_SEED"]);body.update(model=NAME,seed=seed,temperature=0,chat_template_kwargs={"enable_thinking":False})
 if not tag.isalnum():raise ValueError("Invalid trace tag")
 p=SERVICE/"requests"/tag;p.mkdir(parents=True,exist_ok=False);save(p/"request.json",body);t=time.monotonic()
 try:
  req=urllib.request.Request(f"http://127.0.0.1:{PORT}/v1/chat/completions",json.dumps(body).encode(),{"Content-Type":"application/json"})
  with urllib.request.urlopen(req,timeout=300) as r:d=json.load(r)
  save(p/"response.json",d);print(json.dumps(d,ensure_ascii=False),flush=True)
 except Exception as e:save(p/"failure.json",{"error":repr(e)});raise
 finally:save(p/"timing.json",{"seconds":time.monotonic()-t,"seed":seed})
def stop():
    assert socket.gethostname()==load(ROOT/"configs/protocol.json")["hardware_host"]
    owner=load(SERVICE/"owner.json")
    assert owner["host"]==socket.gethostname()
    proc=Path("/proc")/str(owner["pid"])/"cmdline"
    if proc.exists() and proc.read_bytes():
        text=proc.read_bytes().replace(b"\0",b" ").decode()
        if NAME not in text or "--port "+str(PORT) not in text or os.getpgid(owner["pid"])!=owner["pgid"]:
            raise RuntimeError("Ownership mismatch; will not stop another process")
        os.killpg(owner["pid"],signal.SIGTERM)
    for _ in range(180):
        with socket.socket() as ss:
            active=ss.connect_ex(("127.0.0.1",PORT))==0
        if not active and not (Path("/proc")/str(owner["pid"])).exists():
            break
        time.sleep(1)
    else:
        raise RuntimeError("Owned process/port not fully released")
    save(SERVICE/"stopped.json",{"at":time.time(),"pid":owner["pid"],"host":socket.gethostname(),"owned_port_closed":True})

if __name__=="__main__":{"start":start,"call":call,"stop":stop}[sys.argv[1]]()
