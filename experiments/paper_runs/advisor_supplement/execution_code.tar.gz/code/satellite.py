"""第三并行队列：4090物理5/7同一9B BF16 TP2；每case所有方法同硬件。"""
import os,time,subprocess,traceback
from common import ROOT,PY,load,save,status
from controller import run
if __name__=="__main__":
 try:
  if (ROOT/"status/satellite_owner.json").exists():raise RuntimeError("Satellite owner exists")
  save(ROOT/"status/satellite_owner.json",{"pid":os.getpid(),"physical_devices":[5,7],"host":"rtx4090","at":time.time()})
  env={**os.environ,"EF_GPU":"2","EF_DEVICES":"5,7","EF_SEED":"1013","OMP_NUM_THREADS":"2"}
  rc=run("model_service.py",["start"],ROOT/"logs/service_start_gpu2.log",env)
  if rc:raise RuntimeError("4090 TP2 service failed; no restart")
  outcomes={}
  for i,n in enumerate(load(ROOT/"configs/cases.json")):
   if i%3!=2:continue
   case=ROOT/"cases"/n;status("gpu2",case=n,phase="EvidForge")
   rc=run("worker.py",["case","--case",case,"--gpu",2],ROOT/"logs"/(n+"_worker.log"),env)
   tabrc=None
   if load(case/"case.json")["suite"] in ["main","natural"]:
    status("gpu2",case=n,phase="TabClean")
    tabrc=run("tabclean.py",["--case",case,"--gpu",2],ROOT/"logs"/(n+"_tabclean.log"),env)
    if tabrc==0:save(case/"status/tabclean_closed.json",{"at":time.time()})
   outcomes[n]={"worker_returncode":rc,"tabclean_returncode":tabrc,"at":time.time(),"hardware":"4090x2 TP2"};save(ROOT/"status/outcomes_gpu2.json",outcomes)
  if any(x["worker_returncode"]!=0 or x["tabclean_returncode"] not in [None,0] for x in outcomes.values()):
   save(ROOT/"status/satellite_needs_review.json",outcomes)
  save(ROOT/"status/satellite_complete.json",{"at":time.time(),"cases":len(outcomes)})
  if not (ROOT/"status/satellite_needs_review.json").exists():run("model_service.py",["stop"],ROOT/"logs/service_stop_gpu2.log",env)
 except Exception as e:save(ROOT/"status/satellite_error.json",{"error":repr(e),"traceback":traceback.format_exc()});raise
