"""Historical cost summary only. No inference, repair or formal scoring."""
from pathlib import Path
import json,hashlib,statistics,time,collections
ROOT=Path(__file__).resolve().parents[1]
P=ROOT.parent
TABLES=["tic_tac_toe","car_evaluation","retinopathy","real_estate","concrete","airfoil"]
SEEDS=[1013,1014,1015]
HASHES={}
def read(p):
 p=Path(p);data=p.read_bytes();HASHES[str(p)]=hashlib.sha256(data).hexdigest();return json.loads(data)
def digest(p):
 p=Path(p);h=hashlib.sha256(p.read_bytes()).hexdigest();HASHES[str(p)]=h;return h
def save(p,x):
 with Path(p).open("x") as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def main():
 allrows=[];metadata=[]
 for seed in SEEDS:
  r=P/("EvidForge_Downstream_Study_seed"+str(seed))
  service_index=collections.defaultdict(list)
  for service in ["models_service","models_service_gpu1"]:
   requests=r/service/"requests"
   if requests.exists():
    for d in requests.iterdir():
     if d.is_dir():service_index[d.name].append(d)
  for name in TABLES:
   out=r/"outputs"/name/"primary_llm";v=r/"outputs/v23"/name;tag=name.replace("_","").title()
   receipts=read(out/"receipt.json");history=read(out/"progress.json")
   used=set()
   def api(req):
    a=read(req);label=a["_trace_tag"];dirs=service_index[label]
    if len(dirs)!=1:raise ValueError("Nonunique API tag "+label+" "+str(dirs))
    d=dirs[0];body=read(d/"request.json");response=read(d/"response.json");timing=read(d/"timing.json")
    assert body["seed"]==seed and body["temperature"]==0 and response.get("usage")
    if label in used:raise ValueError("Repeated cost "+label)
    used.add(label)
    return {"tag":label,"seconds":timing["seconds"],"usage":response["usage"],"model":body["model"],"request":str(d)}
   pure=[api(f) for f in sorted((out/"trace").glob("pure*_request.json"))]
   assert len(pure)==sum(z["calls"] for z in history)==receipts["calls"]-receipts["real_v23_dispatch_calls"]
   native=[];native_result_seconds=0.;native_receipts=[]
   for stage in ["Prior","Context"]:
    d=r/"outputs/stages"/(tag+stage+str(seed))/"native";result=read(d/"result.json")
    assert result["closed"] and result["native_exit_code"]==0 and result["synthetic_control_count"]==0
    qs=[api(f) for f in sorted(d.glob("actual9b-request*.json"))]
    assert len(qs)==result["real9B_calls"]==5
    native+=qs;native_result_seconds+=result["seconds"];native_receipts.append(str(d/"result.json"))
   dispatch=api(out/"system_dispatch_request.json")
   ef=native+[dispatch]
   prep=read(v/"onboarding/prior_prepared/prepare_receipt.json")["seconds"]
   ctx=read(v/"context_prepared/prepare_receipt.json")["seconds"]
   detect=read(r/"outputs"/name/"raha_detection/receipt.json")["elapsed_seconds"]
   holo=read(r/"outputs"/name/"raha_holoclean/receipt.json")["elapsed_seconds"]
   execute=receipts["program_seconds"]
   assert digest(out/"program_only.csv")==digest(out/"v23_output.csv")
   selected=read(v/"selection.json")
   rows=[
    {"method":"pure_llm","calls":len(pure),"model_seconds":sum(z["seconds"] for z in pure),"core_seconds":sum(z["seconds"] for z in history),"scope":"给定教学摘要后的正式批量修复","actual_usage":pure},
    {"method":"raha_holoclean","calls":0,"model_seconds":0.,"core_seconds":detect+holo,"scope":"Raha检测＋HoloClean训练/校验/修复","actual_usage":[]},
    {"method":"evidforge_first","calls":len(ef),"model_seconds":sum(z["seconds"] for z in ef),"core_seconds":prep+ctx+native_result_seconds+execute+dispatch["seconds"],"scope":"学习＋修复核心阶段；外校/封装另计","actual_usage":ef},
    {"method":"evidforge_sealed","calls":0,"model_seconds":0.,"core_seconds":execute,"scope":"原封存技能程序执行；无模型调度","actual_usage":[]}
   ]
   for x in rows:allrows.append({"dataset":name,"seed":seed,**x})
   metadata.append({"dataset":name,"seed":seed,"ef_qualified":selected["passed"],"native_results":native_receipts,"pure_calls_include_format_retries":True,"historical_model_service_tags_not_cumulative_archived_trials":True})
   print("EXTRACTED",seed,name,flush=True)
 methods=["pure_llm","raha_holoclean","evidforge_first","evidforge_sealed"];aggregate=[]
 for m in methods:
  values=[x for x in allrows if x["method"]==m]
  result={"method":m,"scope":values[0]["scope"]}
  for metric in ["calls","model_seconds","core_seconds"]:
   perseed=[statistics.mean(x[metric] for x in values if x["seed"]==s) for s in SEEDS]
   result[metric]={"mean":statistics.mean(perseed),"sample_sd":statistics.stdev(perseed),"n":3,"dataset_count_per_seed":6,"per_seed":dict(zip(map(str,SEEDS),perseed))}
  aggregate.append(result)
 # Verify old inputs remained unchanged. No old score rows are parsed for this task.
 for path,h in HASHES.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,path
 result={"scope":"Second experiment fixed six datasets x three seeds, historical cost summary, NOT a new standardized end-to-end timing benchmark","aggregation":"Average six tables equally within each seed, then mean/sample SD ddof1 over three seeds; SD is seed-mean variability, not table variability","model":"Same Qwen3.5-9B BF16, temperature0, original per-seed A100 services; CPU scheduling/load not standardized","no_new_model_calls":True,"no_raw_reference_reads":True,"definitions":{"evidforge_first_calls":"10 prior/context learning +1 original model dispatch, counted honestly","evidforge_sealed_calls":"0 model calls in the separately timed standalone program execution; same bytes as original system output","core_seconds":"Historical recorded phase sum. Timing ranges differ by method; EF excludes separately recorded outer validation/packaging. Do not label end-to-end or derive overall speedup.","qualification":"Includes predetermined research-prior executions when outer validation failed; does not certify deployment","reuse":"Sealed-execution row uses actual original program_seconds measurement, not a new repeat/new-batch generalization experiment"},"aggregate":aggregate,"records":allrows,"metadata":metadata}
 save(ROOT/"audit/source_hashes.json",HASHES);save(ROOT/"data/efficiency_evidence.json",result)
 save(ROOT/"audit/extraction_summary.json",{"at":time.time(),"records":len(allrows),"source_files":len(HASHES),"new_inference_calls":0,"formal_reference_reads":0,"all_source_hashes_unchanged":True})
 print(json.dumps(aggregate,ensure_ascii=False),flush=True)
if __name__=="__main__":main()
