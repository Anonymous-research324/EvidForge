"""Read-only closure audit; private inputs are hashed only, never parsed."""
from pathlib import Path
import json,time,collections
from common import ROOT,ENGINE,load,save,sha,read_csv
def main():
 for rel,h in load(ROOT/"audit/execution_freeze.json")["files"].items():assert sha(ROOT/rel)==h
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ENGINE/rel)==h
 for p,h in load(ROOT/"audit/old_scores_frozen.json").items():assert sha(p)==h
 cases=load(ROOT/"configs/cases.json");calls=0;sessions=0;requests=set();files=0;qualification=[]
 for name in cases:
  case=ROOT/"cases"/name;meta=load(case/"case.json");public=load(case/"public/development_bundle.json")
  assert (case/"status/closed.json").exists() and not (case/"status/failure.json").exists()
  for zone in ["public","private"]:
   for rel,h in load(case/"input_freeze.json")[zone].items():assert sha(case/zone/rel)==h;files+=1
  actual=load(case/"work/full/onboarding/prior_prepared/source_records_backend.json")["records"]
  assert {r["group"] for r in actual}=={g["group"] for g in public["learning"]}
  assert len({r["group"] for r in actual})==meta["learning_groups"]
  for rel,h in load(case/"work/full/learning_freeze.json")["files"].items():assert sha(case/"work/full"/rel)==h;files+=1
  for kind in ["prior","context"]:
   stage=case/"work/full"/(kind+"_stage")
   r=load(stage/"native_v3/result.json");b=load(stage/"native_v3/budget.json")
   assert r["closed"] and r["native_exit_code"]==0 and r["synthetic_control_count"]==0 and r["project_hook_registered"]
   assert r["real9B_calls"]==b["calls"] and 1<=b["calls"]<=5 and b["pending_call"] is None
   native_requests=list((stage/"native_v3").glob("actual9b-request-*.json"));assert len(native_requests)==b["calls"]
   owner=load(case/"status/owner.json");gpu=owner["gpu"];service=ROOT/"services"/("gpu"+str(gpu))
   for p in native_requests:
    wire=load(p);tag=wire["_trace_tag"];assert tag not in requests;requests.add(tag)
    body=load(service/"requests"/tag/"request.json");response=load(service/"requests"/tag/"response.json")
    assert body["seed"]==meta["seed"] and body["temperature"]==0 and body["model"]=="evidforge-example-budget-9b-gpu"+str(gpu)
    assert response["choices"][0]["finish_reason"]=="stop" and isinstance(response.get("usage"),dict)
   calls+=b["calls"];sessions+=1
  fields,dirty=read_csv(case/"public/repair_dirty.csv");targets=set(load(case/"public/declaration.json")["targets"])
  for arm in ["full","reuse"]:
   out=case/"outputs"/arm
   for rel,h in load(out/"output_freeze.json")["files"].items():assert sha(out/rel)==h;files+=1
   f,rows=read_csv(out/"repair_output.csv");assert f==fields and len(rows)==len(dirty)
   assert all(a[k]==b[k] for a,b in zip(dirty,rows) for k in fields if k not in targets)
  assert (case/"outputs/full/repair_output.csv").read_bytes()==(case/"outputs/reuse/repair_output.csv").read_bytes()
  assert load(case/"outputs/full/receipt.json")["new9B_calls"]==0
  assert load(case/"outputs/reuse/receipt.json")["new9B_calls"]==0
  sel=load(case/"work/full/selection.json");qualification.append({"case":name,"passed":sel["passed"],"kind":sel["kind"]})
 assert sessions==108 and calls<=540
 assert sum(len(list((ROOT/"services"/("gpu"+str(g))/"requests").glob("*/request.json"))) for g in [0,1])==calls
 save(ROOT/"audit/all_outputs_ready.json",{"passed":True,"cases":54,"native_sessions":sessions,"actual_model_calls":calls,"hashed_files":files,"source_counts_exact":True,"reuse_byte_parity":True,"request_seed_temp_model_binding":True,"formal_reference_rows_read":0,"qualification":qualification,"at":time.time()})
 print("ALL_OUTPUTS_READY",calls,flush=True)
if __name__=="__main__":main()
