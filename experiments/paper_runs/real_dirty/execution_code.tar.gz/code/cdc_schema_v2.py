"""Source-only type bridge; never reads validation/formal truth."""
import numpy as np
import pandas as pd

def infer_schema(frame, native_is_categorical):
    cats=[]
    for c in frame:
        values=frame[c].replace('',np.nan)
        nonempty=values.dropna()
        parsed=pd.to_numeric(nonempty,errors='coerce')
        numeric=bool(len(nonempty)) and bool(parsed.notna().all()) and bool(np.isfinite(parsed.astype(float)).all())
        if native_is_categorical(frame[c]) or not numeric:cats.append(c)
    return cats

def install_schema(cleaner_class,categorical_columns):
    fixed=tuple(categorical_columns)
    class SourceTypedCleaner(cleaner_class):
        def _guess_dtypes(self,data):
            self._categorical_columns=[c for c in data if c in fixed]
            self._numerical_columns=[c for c in data if c not in fixed]
    return SourceTypedCleaner
