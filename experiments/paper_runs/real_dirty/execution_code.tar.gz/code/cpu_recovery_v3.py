from pathlib import Path
import os,json,time,subprocess,socket,traceback,concurrent.futures,fcntl,signal
from common import ROOT as R,PY,load,save,sha
E=Path('/root/fsas/home/anonymous/projects/DataForge_V23_Benchmark_seed1013/environments')
def environment(name='',method=''):
 e={k:v for k,v in os.environ.items() if not k.startswith(('EF_','EVIDFORGE_'))};seed=load(R/'cases'/name/'case.json')['seed'] if name else 1013
 e.update(EF_SEED=str(seed),EF_ARM='full',EF_CONF_OFFSET='0',EF_CASE_ID=name,EF_METHOD=method,EF_PHASE='compat_recovery_v3_formal',CUDA_VISIBLE_DEVICES='',PYTHONPATH=str(R/'code'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',TMPDIR=f'/proc/{os.getpid()}/cwd/tmp');return e

def run(cmd,log,e,timeout):
 log.parent.mkdir(parents=True,exist_ok=True)
 with log.open('x') as h:
  p=subprocess.Popen(list(map(str,cmd)),cwd=R,env=e,stdout=h,stderr=subprocess.STDOUT,start_new_session=True);save(Path(str(log)+'.pid.json'),{'pid':p.pid,'pgid':p.pid,'at':time.time(),'cmd':list(map(str,cmd))})
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   assert os.getpgid(p.pid)==p.pid;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise TimeoutError('Original frozen method timeout')
 if rc:raise RuntimeError('Method exited'+str(rc)+' log '+str(log))

def one(name,m):
 c=R/'cases'/name;out=c/'outputs'/('cdc_v3' if m=='cdc' else m)
 if (out/'output_freeze.json').exists():
  assert all(sha(out/f)==h for f,h in load(out/'output_freeze.json')['files'].items());return 'reused'
 marker=c/'status'/f'{m}_cpu_recovery_v3_dispatch.json';assert not marker.exists(),'No replay'
 save(marker,{'at':time.time(),'method':m,'case':name,'version':'compat_v3_cpu_recovery','formal_reference_read':False})
 seed=load(c/'case.json')['seed'];env=environment(name,m)
 try:
  if m=='raha_holoclean':
   run([E/'raha/bin/python','-u','-B',R/'code/raha_detection_formal.py','--dataset',name],c/'logs/raha_cpu_recovery_v3_detection.log',environment(name,'raha_detection'),14400)
   cmd=[E/'holoclean/bin/python','-u','-B',R/'code/table1_runners'/f'seed{seed}'/'run_holoclean.py','--dataset',name]
  else:cmd=[E/m/'bin/python','-u','-B',R/'code'/f'run_{m}_seed{seed}_v{4 if m=="cdc" else 2}.py','--dataset',name]
  run(cmd,c/'logs'/f'{m}_cpu_recovery_v3.log',env,21600 if m=='garf' else 14400)
  assert (out/'output_freeze.json').exists() and all(sha(out/f)==h for f,h in load(out/'output_freeze.json')['files'].items())
  save(c/'status'/f'{m}_cpu_recovery_v3_closed.json',{'at':time.time(),'output_freeze_sha':sha(out/'output_freeze.json')});return 'closed'
 except BaseException:
  save(c/'status'/f'{m}_cpu_recovery_v3_failure.json',{'at':time.time(),'traceback':traceback.format_exc(),'not_zero_score':True});raise

def branch(method,names,threads):
 closed=[];failed=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as pool:
  fs={pool.submit(one,n,method):n for n in names}
  for f in concurrent.futures.as_completed(fs):
   try:closed.append({'case':fs[f],'state':f.result()})
   except BaseException:failed.append({'case':fs[f],'traceback':traceback.format_exc()})
 save(R/'status'/f'{method}_cpu_recovery_v3_finished.json',{'at':time.time(),'closed':closed,'failed':failed});return {'method':method,'closed':len(closed),'failed':failed}

def main():
 lock=(R/'status/cpu_recovery_v3.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (R/'status/cpu_recovery_v3_owner.json').exists(),'Inspect current queue'
 for name in ['controller_expansion.py','delivery_watcher_expansion.py']:
  # Original controller has already finished its cleanup; never interrupt live ownership.
  pass
 old=load(R/'status/controller_owner.json');proc=Path('/proc')/str(old['pid'])/'cmdline';assert not proc.exists() or b'controller_expansion.py' not in proc.read_bytes()
 names=load(R/'configs/cases.json');new=load(R/'configs/cases_formal_new.json')
 files={str(p.relative_to(R)):sha(p) for p in [Path(__file__),R/'code/baseline_contract.py',R/'code/common.py',*list((R/'code').glob('run_garf_seed*_v2.py')),*list((R/'code').glob('run_cdc_seed*_v4.py')),R/'code/cdc_schema_v4.py',R/'code/cdc_trainfold_io_v3.py']}
 save(R/'audit/cpu_recovery_v3_dispatch_freeze.json',{'files':files,'at':time.time(),'old_success_not_replayed':True,'before_new_method_runs':True})
 save(R/'status/cpu_recovery_v3_owner.json',{'pid':os.getpid(),'pgid':os.getpgrp(),'host':socket.gethostname(),'at':time.time()})
 run([PY,'-B',R/'code/postgres_expansion.py','start'],R/'logs/pg_cpu_recovery_v3_start.log',environment(method='postgres'),180)
 try:
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:
   f=[p.submit(branch,'garf',names,3),p.submit(branch,'cdc',names,1),p.submit(branch,'raha_holoclean',new,2)]
   results=[q.result() for q in f]
  save(R/'status/cpu_recovery_v3_complete.json',{'at':time.time(),'results':results,'failed':sum(len(x['failed']) for x in results)})
 finally:run([PY,'-B',R/'code/postgres_expansion.py','stop'],R/'logs/pg_cpu_recovery_v3_stop.log',environment(method='postgres'),180)
if __name__=='__main__':
 try:main()
 except BaseException:save(R/'status/cpu_recovery_v3_error.json',{'at':time.time(),'traceback':traceback.format_exc()});raise
