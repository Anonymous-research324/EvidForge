"""Read actual status, no startup, scoring or model calls."""
from pathlib import Path
import time,json,subprocess
from common import ROOT as R,load,save
def main():
 plan=load(R/'configs/cases.json');natives=[];closed=[];pending=[];fits=[];fails=[]
 for n in plan:
  c=R/'cases'/n
  if (c/'status/closed.json').exists():closed.append(n)
  if (c/'work/pre_native_shared_fit.json').exists():fits.append(n)
  fails.extend(str(p.relative_to(R)) for p in (c/'status').glob('*failure*.json'))
  for stage in ['prior','context']:
   p=c/'work/full'/f'{stage}_stage/native_v3'
   if (p/'result.json').exists():natives.append({'case':n,'stage':stage,**load(p/'result.json')})
   if (p/'budget.json').exists() and load(p/'budget.json')['pending_call'] is not None:pending.append({'case':n,'stage':stage,'budget':load(p/'budget.json')})
 req=list((R/'services').glob('gpu*/requests/*/request.json'));resp=list((R/'services').glob('gpu*/requests/*/response.json'))
 errors=[str(p.relative_to(R)) for p in (R/'status').glob('*error*.json')]
 owners={}
 for rel in ['status/controller_owner.json','status/watcher_owner.json','services/gpu0/owner.json','services/gpu1/owner.json']:
  p=R/rel
  if p.exists():
   o=load(p);proc=Path('/proc',str(o['pid']),'cmdline');owners[rel]={'pid':o['pid'],'alive':proc.exists(),'cmd':proc.read_bytes().replace(b'\0',b' ').decode(errors='replace')[:500] if proc.exists() else None}
 snap={'at':time.time(),'planned':len(plan),'closed':closed,'shared_fits':fits,'native_closed_count':sum(x['closed'] for x in natives),'actual_calls_closed':sum(x['real9B_calls'] for x in natives),'requests':len(req),'responses':len(resp),'pending':pending,'errors':errors,'failures':fails,'formal_markers':len(list((R/'cases').glob('*/status/audit_scoring_started.json'))),'scored':len(list((R/'cases').glob('*/status/scored.json'))),'owners':owners,'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader'],text=True)}
 save(R/'status/supervisor_snapshot.json',snap);print(json.dumps(snap,ensure_ascii=False))
if __name__=='__main__':main()
