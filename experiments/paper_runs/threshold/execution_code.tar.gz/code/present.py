"""Read-only statistics review and paper-style tables; never reads formal reference rows."""
import os,sys,time,json,csv,statistics,hashlib
from pathlib import Path
from common import ROOT,read,save,sha,tag
sys.dont_write_bytecode=True
os.environ["MPLCONFIGDIR"]=str(ROOT/"audit/mpl-cache")
NAMES=["tic_tac_toe","car_evaluation","retinopathy","real_estate","concrete","airfoil"]
LABELS=["Tic-Tac-Toe","Car","Retinopathy","Real Estate","Concrete","Airfoil"]
OFF=[-.1,-.05,0.,.05,.1]
def main():
 assert (ROOT/"status/scoring_complete.json").exists()
 scorepath=ROOT/"reports/all_scores.json";scorehash=sha(scorepath)
 rows=read(scorepath);aggregate=read(ROOT/"reports/aggregate.json")
 assert len(rows)==90 and len(aggregate)==30
 # Recompute counts and independent mean/sample-SD, without opening any truth.
 for x in rows:
  m=x["repair"];p=m["exact"]/m["changes"] if m["changes"] else None;r=m["exact"]/m["errors"] if m["errors"] else 0
  f=2*p*r/(p+r) if p and r else 0
  assert abs(f-m["F1"])<1e-12
  damage=m["normal_damage"]/m["normal"] if m["normal"] else None
  assert damage==m["damage"]
  assert x["receipt"]["new_model_calls"]==0
  if x["offset"]==0:assert x["receipt"]["zero_offset_original_A_byte_parity"] is True
 for a in aggregate:
  group=sorted([x for x in rows if (x["dataset"],x["offset"])==(a["dataset"],a["offset"])],key=lambda x:x["seed"])
  assert [x["seed"] for x in group]==[1013,1014,1015]
  for metric in ["P","R","F1","damage"]:
   v=[x["repair"][metric] for x in group];n=sum(x is not None for x in v);assert n==a[metric]["n"]
   if n==3:
    assert abs(statistics.mean(v)-a[metric]["mean"])<1e-12 and abs(statistics.stdev(v)-a[metric]["sd"])<1e-12
   else:assert a[metric]["mean"] is None and a[metric]["sd"] is None
 for obj in read(ROOT/"reports/paired_differences.json"):
  base={x["seed"]:x for x in rows if x["dataset"]==obj["dataset"] and x["offset"]==0}
  other={x["seed"]:x for x in rows if x["dataset"]==obj["dataset"] and x["offset"]==obj["offset"]}
  for k in ["F1","damage"]:
   v=[other[s]["repair"][k]-base[s]["repair"][k] for s in [1013,1014,1015]]
   assert abs(statistics.mean(v)-obj[k]["mean"])<1e-12 and abs(statistics.stdev(v)-obj[k]["sd"])<1e-12
 snapshot=read(ROOT/"audit/input_skill_snapshot.json")["files"]
 for p,h in snapshot.items():assert sha(p)==h
 checked=0
 for x in rows:
  folder=ROOT/"outputs"/(x["dataset"]+"_s"+str(x["seed"]))/tag(x["offset"])
  for rel,h in read(folder/"output_freeze.json")["files"].items():assert sha(folder/rel)==h;checked+=1
 save(ROOT/"audit/independent_statistics_review.json",{"count_rows":len(rows),"aggregate_groups":len(aggregate),"paired_groups":24,"input_skill_oldscore_hashes":len(snapshot),"output_files_checked":checked,"formal_rows_read":0,"score_sha256":scorehash,"status":"PASS"},once=True)
 lookup={(a["dataset"],a["offset"]):a for a in aggregate}
 def fmt(g,k):
  x=g[k]
  if x["n"]!=3:return "N/A ("+str(x["n"])+"/3)"
  scale=100 if k=="damage" else 1
  return format(x["mean"]*scale,".3f")+" ± "+format(x["sd"]*scale,".3f")
 out=ROOT/"reports"
 with (out/"threshold_summary.csv").open("x",newline="") as f:
  fields=["dataset","offset","F1_mean","F1_sd","damage_pct_mean","damage_pct_sd","n","qualified_seeds"]
  w=csv.DictWriter(f,fields);w.writeheader()
  for a in aggregate:
   w.writerow({"dataset":a["dataset"],"offset":a["offset"],"F1_mean":a["F1"]["mean"],"F1_sd":a["F1"]["sd"],"damage_pct_mean":a["damage"]["mean"]*100 if a["damage"]["mean"] is not None else None,"damage_pct_sd":a["damage"]["sd"]*100 if a["damage"]["sd"] is not None else None,"n":a["F1"]["n"],"qualified_seeds":a["qualified_seeds"]})
 main=["# 六表置信门槛敏感性：精简表","","每格：修复F1 / 正常误改率（%），均值 ± 样本SD，三seed。原门槛加上所示偏移；分差门槛和生成规则门槛不变。","",
 "|数据集|放宽0.10|原设定|收紧0.10|","|---|---:|---:|---:|"]
 for n,label in zip(NAMES,LABELS):
  gs=[lookup[n,d] for d in [-.1,0.,.1]]
  main.append("|"+label+("†" if gs[1]["qualified_seeds"]<3 else "")+"|"+"|".join(fmt(g,"F1")+" / "+fmt(g,"damage") for g in gs)+"|")
 main+=["","† 原完整技能有未通过独立外校的seed，按预定研究prior执行；不等于实验执行失败。完整资格和五档结果见附表。","",
 "范围：原六表、1013/1014/1015、每seed原消融A封存技能。没有重新学习或新增LLM调用。基础门槛影响执行链中的stage1可信上下文传播，不能说候选池完全固定，也不是Qwen生成规则的参数扫描。",
 "","本次扩展在看过Car/Concrete局部敏感性结果后提出，属于补充描述性分析；所有六表与全部五档保留，不宣称预注册新盲测或统计显著。"]
 (out/"置信门槛_六表精简表.md").write_text("\n".join(main)+"\n")
 detail=["# 六表全部五档结果",""]
 for metric,title in [("F1","单元格修复F1（越高越好）"),("damage","正常格误改率%（越低越好）")]:
  detail+=["## "+title,"","|数据集|−0.10|−0.05|0|+0.05|+0.10|","|---|---:|---:|---:|---:|---:|"]
  for n,label in zip(NAMES,LABELS):detail.append("|"+label+"|"+"|".join(fmt(lookup[n,d],metric) for d in OFF)+"|")
  detail.append("")
 detail+=["## 原封存资格","","|数据集|独立外校合格seed数|","|---|---:|"]
 for n,label in zip(NAMES,LABELS):detail.append("|"+label+"|"+str(lookup[n,0.]["qualified_seeds"])+"/3|")
 (out/"置信门槛_完整五档.md").write_text("\n".join(detail)+"\n")
 import matplotlib
 matplotlib.use("Agg")
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 fonts=Path(read(ROOT/"configs/table_profile.json")["font_directory"])
 chinese=FontProperties(fname=str(fonts/"SongtiSC-Regular.ttf"))
 bold=FontProperties(fname=str(fonts/"SongtiSC-Bold.ttf"))
 times=FontProperties(fname=str(fonts/"TimesNewRoman.ttf"))
 exports=[]
 with plt.rc_context({"pdf.fonttype":42,"ps.fonttype":42,"svg.fonttype":"none","axes.unicode_minus":False}):
  for compact in [True,False]:
   offsets=[-.1,0.,.1] if compact else OFF
   fig=plt.figure(figsize=(180/25.4,115/25.4),dpi=150,facecolor="white")
   ax=fig.add_axes([.035,.19,.93,.62]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
   fig.text(.035,.955,"基础修复置信门槛敏感性（三种子）",fontproperties=bold,fontsize=11)
   fig.text(.035,.90,"每格上行：修复 F1 ↑；下行：正常误改率（%）↓。均值 ± 样本标准差。",fontproperties=chinese,fontsize=8)
   first=.22 if compact else .19
   width=(1-first)/len(offsets);xs=[first+width*(i+.5) for i in range(len(offsets))]
   ax.plot([0,1],[.98,.98],color="black",lw=1)
   ax.plot([0,1],[.865,.865],color="black",lw=.65)
   ax.text(.005,.92,"数据集",fontproperties=chinese,fontsize=9,va="center")
   for d,x in zip(offsets,xs):
    label="原门槛" if d==0 else ("放宽" if d<0 else "收紧")+format(abs(d),".2f")
    ax.text(x,.92,label,fontproperties=chinese,fontsize=8.5 if compact else 8,ha="center",va="center")
   texts=[]
   for i,(n,label) in enumerate(zip(NAMES,LABELS)):
    y=.79-i*.13
    a=lookup[n,0.];mark="†" if a["qualified_seeds"]<3 else ""
    ax.text(.005,y,label+mark,fontproperties=times,fontsize=9 if compact else 8.1,va="center")
    for d,x in zip(offsets,xs):
     g=lookup[n,d]
     t=ax.text(x,y,fmt(g,"F1")+"\n"+fmt(g,"damage"),fontproperties=times,fontsize=9 if compact else 8.1,ha="center",va="center",linespacing=1.4,fontweight="normal")
     texts.append((t,x-width/2,x+width/2))
   ax.plot([0,1],[.055,.055],color="black",lw=1)
   fig.text(.035,.13,"门槛相对各自原设定偏移；分差门槛及生成规则门槛固定。",fontproperties=chinese,fontsize=7.5)
   fig.text(.035,.085,"† 含预定研究 prior；原外校合格 seed 数见完整结果。全六数据集和全部五档保留。",fontproperties=chinese,fontsize=7.5)
   fig.text(.035,.04,"分类、回归表均报告单元格修复 F1；三种子差异不解释为统计显著。",fontproperties=chinese,fontsize=7.5)
   fig.canvas.draw();renderer=fig.canvas.get_renderer()
   for t,lo,hi in texts:
    b=t.get_window_extent(renderer);bb=ax.transData.inverted().transform([[b.x0,b.y0],[b.x1,b.y1]])
    assert bb[0,0]>=lo-.005 and bb[1,0]<=hi+.005,"Numeric cell overflows its column"
   base="threshold_compact" if compact else "threshold_all_five"
   for ext in ["pdf","svg","png"]:
    p=out/(base+"."+ext);fig.savefig(p,dpi=600,facecolor="white");exports.append(p)
   plt.close(fig)
 assert sha(scorepath)==scorehash
 save(ROOT/"audit/table_render_qa.json",{"files":{str(p.relative_to(ROOT)):sha(p) for p in exports},"matplotlib_version":matplotlib.__version__,"width_mm":180,"height_mm":115,"dpi_png":600,"numeric_column_overflow":False,"visual_inspection":"PENDING human/assistant viewing; no manuscript integration claimed","formal_rows_read":0},once=True)
 save(ROOT/"status/delivery_files_ready.json",{"at":time.time(),"table_rows":6,"statistics_review":"PASS","visual_qa_pending":True,"new_model_calls":0},once=True)
 print("\n".join(main),flush=True)
if __name__=="__main__":main()
