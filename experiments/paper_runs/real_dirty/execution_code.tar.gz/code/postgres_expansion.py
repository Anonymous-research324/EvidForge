"""Owned PostgreSQL 14 service. Never operates on any other cluster or port."""
from pathlib import Path
import argparse,subprocess,socket,json,os
from common import ROOT,save
PG=Path('/root/fsas/home/anonymous/projects/DataForge_V23_Benchmark_seed1013/environments/postgres/bin')
BASE=ROOT/'services/postgres';DATA=BASE/'cluster';PORT=55443;USER='dataforgecompatv2'
def main(action):
 BASE.mkdir(parents=True,exist_ok=True)
 if action=='init':
  if DATA.exists():raise FileExistsError('Cluster already exists; init refused')
  subprocess.run([str(PG/'initdb'),'-D',str(DATA),'-U',USER,'--auth-local=trust','--auth-host=trust'],check=True)
  with (DATA/'postgresql.conf').open('a') as f:f.write("\nlisten_addresses = '127.0.0.1'\nport = 55443\nunix_socket_directories = ''\n")
  save(BASE/'owner.json',{'cluster':str(DATA),'port':PORT,'user':USER,'uid':os.getuid(),'owned':True,'tcp_only':True})
 elif action=='start':
  owner=json.loads((BASE/'owner.json').read_text());assert owner['cluster']==str(DATA) and owner['uid']==os.getuid() and owner['port']==PORT
  with socket.socket() as sock:sock.bind(('127.0.0.1',PORT))
  subprocess.run([str(PG/'pg_ctl'),'-D',str(DATA),'-l',str(BASE/'postgres.log'),'start'],check=True)
 elif action=='status':
  subprocess.run([str(PG/'pg_isready'),'-h','127.0.0.1','-p',str(PORT),'-U',USER],check=True)
 elif action=='stop':
  owner=json.loads((BASE/'owner.json').read_text());assert owner['cluster']==str(DATA) and owner['uid']==os.getuid()
  subprocess.run([str(PG/'pg_ctl'),'-D',str(DATA),'-m','fast','stop'],check=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['init','start','status','stop']);main(p.parse_args().action)
