"""Read-only delivery review: scores and frozen artifacts only, no raw formal rows."""
from pathlib import Path
import os,sys,time,statistics,collections,json
from common import ROOT,load,save,sha
sys.dont_write_bytecode=True
os.environ["MPLCONFIGDIR"]=str(ROOT/"audit/mpl-cache")
def validate(results,aggregate):
 assert len(results)==72 and len(aggregate)==24
 for r in results:
  m=r["repair"];p=m["exact"]/m["changes"] if m["changes"] else None;rec=m["exact"]/m["errors"] if m["errors"] else 0.
  f=2*p*rec/(p+rec) if p and rec else 0.
  assert abs(f-m["F1"])<1e-12
  assert (m["normal"]==0 and m["normal_damage"] is None) or m["normal"]>0 and abs(m["damaged"]/m["normal"]-m["normal_damage"])<1e-12
 for a in aggregate:
  rs=sorted([r for r in results if (r["rate"],r["error_type"],r["arm"])==(a["rate"],a["error_type"],a["arm"])],key=lambda r:r["seed"])
  assert [r["seed"] for r in rs]==[1013,1014,1015]
  for k in ["P","R","F1","normal_damage","detection_AUC"]:
   v=[r["repair"][k] for r in rs];n=sum(x is not None for x in v)
   assert n==a[k]["n"]
   if n==3:assert abs(statistics.mean(v)-a[k]["mean"])<1e-12 and abs(statistics.stdev(v)-a[k]["sd"])<1e-12
   else:assert a[k]["mean"] is None and a[k]["sd"] is None
 for p,h in load(ROOT/"audit/concrete_sources_frozen.json").items():assert sha(p)==h
 from audit_ready import verify
 counts=verify()
 hookevents=collections.Counter()
 for p in (ROOT/"cases").glob("*/work/full/*_stage/native_v3/native_hooks.jsonl"):
  for line in p.read_text().splitlines():hookevents[json.loads(line)["event"]]+=1
 costs=load(ROOT/"reports/actual_model_costs.json")
 assert len(costs)==counts["requests"]
 save(ROOT/"audit/independent_delivery_review.json",{"status":"PASS","raw_metrics_recomputed":len(results),"aggregate_groups":len(aggregate),"integrity_counts":counts,"hook_events":dict(hookevents),"actual_calls":len(costs),"formal_rows_read":0,"time":time.time()})
def draw(table):
 import matplotlib
 matplotlib.use("Agg")
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 fonts=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/reports/paper_ablation_tables_20261022/fonts")
 cjk=FontProperties(fname=str(fonts/"SongtiSC-Regular.ttf"));bold=FontProperties(fname=str(fonts/"SongtiSC-Bold.ttf"));numeric=FontProperties(fname=str(fonts/"TimesNewRoman.ttf"))
 def fmt(x,percent=False):
  if x["n"]!=3:return "N/A ("+str(x["n"])+"/3)"
  k=100 if percent else 1
  return format(x["mean"]*k,".3f")+" ± "+format(x["sd"]*k,".3f")
 profile={"backend":"Matplotlib","layout_strategy":"native_final_size","width_mm":180,"height_mm":145,"font_numeric_pt":9,"font_header_pt":8.5,"dpi":600,"error":"sample SD ddof1 n3","formats":["png","pdf","svg"],"colors":["black","white"],"journal_requirement":False,"manuscript_integration":"not performed"}
 save(ROOT/"reports/table_profile.json",profile)
 with plt.rc_context({"pdf.fonttype":42,"ps.fonttype":42,"svg.fonttype":"none","axes.unicode_minus":False}):
  fig=plt.figure(figsize=(180/25.4,145/25.4),dpi=150,facecolor="white")
  fig.text(.035,.965,"鲁棒性：污染程度与错误类型（三种子）",fontproperties=bold,fontsize=11)
  fig.text(.035,.925,"修复 F1 越高越好；正常误改率（%）越低越好。均值 ± 样本标准差（n=3）。",fontproperties=cjk,fontsize=8)
  texts=[]
  for panel,(rows,title,ypos) in enumerate([(table[:4],"（a）不同污染率：四类错误混合",.56),(table[4:],"（b）不同错误类型：污染率固定30%",.19)]):
   ax=fig.add_axes([.035,ypos,.93,.30]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
   ax.text(0,1.13,title,fontproperties=bold,fontsize=9.5)
   ax.plot([0,1],[1.02,1.02],color="black",lw=1)
   ax.text(.005,.85,"污染率" if panel==0 else "错误类型",fontproperties=cjk,fontsize=9,va="center")
   xs=[.265,.475,.685,.895]
   for x,d,k in zip(xs,["Retinopathy","Concrete","Retinopathy","Concrete"],["修复 F1","修复 F1","正常误改（%）","正常误改（%）"]):
    ax.text(x,.91,d,fontproperties=numeric,fontsize=9,ha="center",va="center")
    ax.text(x,.78,k,fontproperties=cjk,fontsize=8,ha="center",va="center")
   ax.plot([0,1],[.68,.68],color="black",lw=.65)
   for i,r in enumerate(rows):
    y=.57-i*.15
    label=str(round(r["rate"]*100))+"%" if panel==0 else {"blank":"空值错误","digit":"数字错误","scale":"倍率错误","affix":"前后缀错误"}[r["type"]]
    ax.text(.005,y,label,fontproperties=cjk,fontsize=9,va="center")
    vals=[fmt(r["Retinopathy"]["F1"]),fmt(r["Concrete"]["F1"]),fmt(r["Retinopathy"]["normal_damage"],True),fmt(r["Concrete"]["normal_damage"],True)]
    for x,value in zip(xs,vals):texts.append((ax,ax.text(x,y,value,fontproperties=numeric,fontsize=9,ha="center",va="center"),x-.105,x+.105))
   ax.plot([0,1],[.025,.025],color="black",lw=1)
  fig.text(.035,.12,"每个污染条件重新学习后评估；不是固定技能面对未知错误的零样本测试。",fontproperties=cjk,fontsize=7.5)
  fig.text(.035,.085,"Retinopathy为新增研究，Concrete为旧封存结果；原Car失败记录保留。",fontproperties=cjk,fontsize=7.5)
  fig.text(.035,.05,"原资格未过者采用预定研究prior；三种子差异不解释为统计显著。",fontproperties=cjk,fontsize=7.5)
  fig.canvas.draw();renderer=fig.canvas.get_renderer()
  for ax,t,lo,hi in texts:
   b=t.get_window_extent(renderer);coords=ax.transData.inverted().transform([[b.x0,b.y0],[b.x1,b.y1]])
   assert coords[0,0]>=lo and coords[1,0]<=hi,"Numeric column overflow"
  paths=[]
  for ext in ["png","pdf","svg"]:
   p=ROOT/"reports"/("robustness_compact."+ext);fig.savefig(p,dpi=600,facecolor="white");paths.append(p)
  plt.close(fig)
 save(ROOT/"audit/table_render_qa.json",{"files":{str(p.relative_to(ROOT)):sha(p) for p in paths},"matplotlib":matplotlib.__version__,"size_mm":[180,145],"numeric_column_overflow":False,"actual_viewing":"PENDING; no manuscript-integration claim"})
def main():
 assert (ROOT/"status/scoring_complete.json").exists()
 p=ROOT/"reports/all_scores.json";before=sha(p)
 results=load(p);aggregate=load(ROOT/"reports/aggregate.json")
 validate(results,aggregate);draw(load(ROOT/"reports/comparison_all_conditions.json"))
 assert sha(p)==before
 save(ROOT/"status/delivery_files_ready.json",{"time":time.time(),"scores_sha256":before,"independent_review":"PASS","visual_and_resources_review_pending":True,"no_rescore":True})
if __name__=="__main__":main()
