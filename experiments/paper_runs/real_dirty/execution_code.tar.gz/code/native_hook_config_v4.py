"""Per-invocation hook registration: no workspace discovery or global edits."""
import json
EVENTS=('SessionStart','PreToolUse','PostToolUse','Stop')
def definition(command):
 return {event:[{'hooks':[{'type':'command','command':command,'timeout':30}]}] for event in EVENTS}
def toml_value(x):
 if isinstance(x,dict):return '{ '+', '.join(json.dumps(k)+' = '+toml_value(v) for k,v in x.items())+' }'
 if isinstance(x,list):return '['+', '.join(toml_value(v) for v in x)+']'
 return json.dumps(x)
def cli_arguments(hooks):
 result=[]
 for event,value in hooks.items():result.extend(['-c','hooks.'+event+'='+toml_value(value)])
 return result
