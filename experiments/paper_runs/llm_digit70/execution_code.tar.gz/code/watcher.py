from pathlib import Path
import time,subprocess,traceback,os
from common import ROOT as R,PY,save
def main():
 save(R/'status/watcher_owner.json',{'pid':os.getpid(),'at':time.time()})
 while not (R/'status/run_complete.json').exists():
  if (R/'status/controller_error.json').exists():raise RuntimeError('Controller blocked: preserve failures')
  time.sleep(20)
 with (R/'logs/final_review.log').open('x') as f:subprocess.run([PY,'-u','-B',R/'code/final_review.py'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=='__main__':
 try:main()
 except BaseException:save(R/'status/delivery_error.json',{'at':time.time(),'traceback':traceback.format_exc()});raise
