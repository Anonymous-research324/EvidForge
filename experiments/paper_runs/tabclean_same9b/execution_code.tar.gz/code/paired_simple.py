"""Same-case sequential full/noLLM/reuse and author TabClean on one fixed GPU lane."""
from pathlib import Path
import os,sys,time,subprocess,traceback,json
from common import ROOT,PY,load,save
def main(case,gpu):
 from runtime import guard
 guard()
 meta=load(case/'case.json')
 if (case/'status/paired_closed.json').exists():return
 env={**os.environ,'EF_SEED':str(meta['seed']),'EF_GPU':str(gpu),'EF_CASE_ID':case.name,'EF_PHASE':meta['phase'],'EF_METHOD':'full','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'}
 save(case/'status/pair_owner.json',{'pid':os.getpid(),'gpu':gpu,'at':time.time()})
 def run(cmd,name,en):
  log=case/'logs'/name
  if log.exists():raise RuntimeError('Stage log exists without verified closure: '+str(log))
  with log.open('x') as f:
   p=subprocess.Popen(list(map(str,cmd)),cwd=ROOT,env=en,stdout=f,stderr=subprocess.STDOUT)
   save(case/'status'/(name+'.pid.json'),{'pid':p.pid,'command':list(map(str,cmd)),'at':time.time()})
   rc=p.wait()
  if rc:raise RuntimeError('Stage failed '+str(log))
 if not (case/'status/closed.json').exists():run([PY,'-B',ROOT/'code/worker_simple.py','case','--case',case,'--gpu',gpu],'evidforge_worker.log',env)
 if not (case/'status/tabclean_closed.json').exists():run([PY,'-B',ROOT/'code/tabclean.py','--case',case,'--gpu',gpu],'tabclean_worker.log',{**env,'EF_METHOD':'tabclean'})
 save(case/'status/paired_closed.json',{'at':time.time(),'gpu':gpu,'arms':['full','tabclean'],'formal_reference_read':False})
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--gpu',type=int,required=True);a=p.parse_args();case=Path(a.case)
 try:main(case,a.gpu)
 except Exception as e:save(case/'status/paired_failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'at':time.time(),'no_case_replay':True});raise
