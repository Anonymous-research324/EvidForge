"""Curator-only exact legacy generator: modify only registered rate/type and seed."""
from pathlib import Path
import sys,json,shutil,time,ast
from common import ROOT,save,sha,freeze
import common
common.digest=common.sha
SOURCE=ROOT.parent/"EvidForge_Downstream_Study_seed1014"
def make(seed,rate,kind):
 ident=("robustness_retinopathy_s"+str(seed)+"_r"+str(rate)+"_"+kind).replace(".","p")
 case=ROOT/"cases"/ident;case.mkdir()
 for n in ["status","logs","work","outputs"]:(case/n).mkdir()
 cache=case/"generator_inputs/private/retinopathy";cache.mkdir(parents=True)
 old=SOURCE/"generator_inputs/private/retinopathy"
 for n in ["source.zip","provenance.json"]:shutil.copyfile(old/n,cache/n)
 gen=SOURCE/"code/generate_benchmarks.py";s=gen.read_text()
 assert s.count("round(.7*len(eligible))")==1
 s=s.replace("round(.7*len(eligible))","round("+repr(rate)+"*len(eligible))")
 if kind!="mixed":
  assert s.count("['blank','digit','scale','affix']")==1
  s=s.replace("['blank','digit','scale','affix']",repr([kind]))
 module=type(sys)("locked_curator");module.__file__=str(gen);exec(compile(s,str(gen),"exec"),module.__dict__)
 module.ROOT=case;module.SEED=seed;module.generate("retinopathy")
 dataset=case/"datasets/retinopathy"
 shutil.move(str(dataset/"public"),case/"public");shutil.move(str(dataset/"private"),case/"private")
 meta={"id":ident,"dataset":"retinopathy","seed":seed,"suite":"robustness","rate":rate,"error_type":kind,"learning_fraction":1.,"provenance":{"original_generator":str(gen),"source_sha256":sha(gen),"only_changes":"declared rate/type and operational seed","raw_archive_sha256":sha(cache/"source.zip"),"no_old_formal_answers_used":True}}
 save(case/"case.json",meta)
 save(case/"input_freeze.json",{"public":freeze(case/"public"),"private":freeze(case/"private"),"case_sha256":sha(case/"case.json")})
 return ident
def main():
 if (ROOT/"status/curator_started.json").exists():raise RuntimeError("Inspect existing execution; never regenerate frozen input")
 save(ROOT/"status/curator_started.json",{"at":time.time(),"role":"curator"})
 protocol=json.loads((ROOT/"configs/protocol.json").read_text());cases=[]
 for seed in protocol["seeds"]:
  for spec in protocol["conditions"]:cases.append(make(seed,spec["rate"],spec["type"]))
 save(ROOT/"configs/cases.json",cases)
 save(ROOT/"audit/all_inputs_frozen.json",{"case_count":len(cases),"files":{n:sha(ROOT/"cases"/n/"input_freeze.json") for n in cases},"all_before_first_learning":True})
 print("ALL_INPUTS_FROZEN",len(cases),flush=True)
if __name__=="__main__":main()
