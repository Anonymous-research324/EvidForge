"""按真实PID/冻结输出接续；只对已审查的长度契约失败标N/A，其他错误阻止评分。"""
from pathlib import Path
import os,sys,time,json,subprocess,traceback
from common import ROOT,PY,load,save,sha,status
from controller import run
def active(case,kind):
 for p in Path("/proc").iterdir():
  if not p.name.isdigit():continue
  try:b=(p/"cmdline").read_bytes()
  except OSError:continue
  if str(case).encode() in b and kind.encode() in b and b"-c" not in b.split(b"\0")[:3]:return True
 return False
def review_tab_length(case):
 p=case/"status/tabclean_failure.json"
 if not p.exists() or "Truncated TabClean model output" not in load(p).get("error",""):return False
 prefix=("Tab"+case.name).replace("_","").replace("-","")
 found=[]
 for r in (ROOT/"services").glob("gpu*/requests/"+prefix+"*"):
  if (r/"response.json").exists() and load(r/"response.json")["choices"][0]["finish_reason"]=="length":found.append(str(r))
 if not found:return False
 save(case/"status/tabclean_closed_unavailable.json",{"status":"N/A","reason":"Real same9B free-text output exhausted preregistered8192-token per-call budget (repetitive output); no code/result fabricated","requests":found,"actual_failure_log_kept":True,"not_original_GPT_TabClean_failure_claim":True})
 return True
def reviewed_metadata(case):
 p=case/"status/recovery_failure_v3.json"
 if not p.exists():return True
 error=load(p).get("error","")
 log=case/"logs/full/prepare.log"
 if load(case/"case.json")["dataset"]!="flights" or "logs/full/prepare.log" not in error or not log.exists() or "KeyError: 'training_groups'" not in log.read_text():return False
 save(case/"status/metadata_failure_reviewed_v4.json",{"old_failure_sha":sha(p),"old_prepare_log_sha":sha(log),"scope":"nonnumeric group metadata access only; numerical model remains empty; original fit reused","original_failure_preserved":True})
 return True

def wait_legacy_children():
 # Controllers are retired, but their already-running children may finish.
 # Wait for all lanes on this host before dispatching earlier unfinished cases.
 while True:
  found=[]
  for p in Path("/proc").iterdir():
   if not p.name.isdigit():continue
   try:b=(p/"cmdline").read_bytes()
   except OSError:continue
   if str(ROOT).encode() in b and b"-c" not in b.split(b"\0")[:3] and any(x in b for x in [b"/worker_v3.py",b"/tabclean.py"]):found.append(int(p.name))
  if not found:return
  status("legacy_children_wait_"+("satellite" if sys.argv[1]=="satellite" else "master"),pids=found)
  time.sleep(5)
def process_case(n,gpu):
 case=ROOT/"cases"/n;env={**os.environ,"EF_GPU":str(gpu),"EF_SEED":str(load(case/"case.json")["seed"]),"OMP_NUM_THREADS":"2","LANGSMITH_TRACING":"false","LANGCHAIN_TRACING_V2":"false"}
 if gpu==2:env["EF_DEVICES"]="5,7"
 # Original TabClean child is allowed to finish before recovered native work uses this model queue.
 while active(case,"tabclean.py"):status(f"gpu{gpu}",case=n,phase="wait_original_TabClean");time.sleep(5)
 while active(case,"worker"):status(f"gpu{gpu}",case=n,phase="wait_original_worker");time.sleep(5)
 rc=0
 if not (case/"status/closed.json").exists():
  if (case/"status/recovery_failure_v4.json").exists() or ((case/"status/recovery_failure_v3.json").exists() and not reviewed_metadata(case)):rc=1
  else:
   status(f"gpu{gpu}",case=n,phase="EvidForge_recovery_v4")
   rc=run("worker_v4.py",["case","--case",case,"--gpu",gpu],ROOT/"logs"/(n+"_queue_worker_v4.log"),env)
 tabrc=None
 if load(case/"case.json")["suite"] in ["main","natural"]:
  if (case/"outputs/tabclean/output_freeze.json").exists():save(case/"status/tabclean_closed.json",{"at":time.time(),"reused_real_completed_output":True});tabrc=0
  elif review_tab_length(case):tabrc=0
  elif (case/"status/tabclean_failure.json").exists():tabrc=1
  else:
   status(f"gpu{gpu}",case=n,phase="TabClean")
   log=ROOT/"logs"/(n+"_tabclean.log")
   if log.exists():tabrc=1
   else:
    tabrc=run("tabclean.py",["--case",case,"--gpu",gpu],log,env)
    if tabrc==0:save(case/"status/tabclean_closed.json",{"at":time.time()})
    elif review_tab_length(case):tabrc=0
 return {"worker_returncode":rc,"tabclean_returncode":tabrc,"at":time.time(),"gpu":gpu}
def lane(gpu):
 outcomes={};names=load(ROOT/"configs/cases.json")
 for i,n in enumerate(names):
  if i%3!=gpu:continue
  outcomes[n]=process_case(n,gpu);save(ROOT/"status"/f"outcomes_lane{gpu}_v4.json",outcomes)
  status(f"lane{gpu}_progress",completed=len(outcomes),planned=len([j for j in range(len(names)) if j%3==gpu]),failed=sum(q["worker_returncode"]!=0 or q["tabclean_returncode"] not in [None,0] for q in outcomes.values()))
 return outcomes
def finalize():
 names=load(ROOT/"configs/cases.json");out={}
 for g in [0,1,2]:out.update(load(ROOT/"status"/f"outcomes_lane{g}_v4.json"))
 save(ROOT/"status/outcomes_v4.json",out)
 bad={k:v for k,v in out.items() if v["worker_returncode"]!=0 or v["tabclean_returncode"] not in [None,0]}
 if bad:save(ROOT/"status/needs_interface_review_v4.json",bad);return
 assert len(out)==len(names)
 from audit_ready_v4 import verify
 verify()
 save(ROOT/"status/all_model_outputs_closed.json",{"at":time.time(),"cases":len(names),"reviewed_TabClean_contract_NA":True})
 for g in [0,1]:run("model_service.py",["stop"],ROOT/"logs"/f"service_stop_gpu{g}_v4.log",{**os.environ,"EF_GPU":str(g)})
 rc=run("score_v2.py",[],ROOT/"logs/independent_scoring_v2.log",dict(os.environ))
 if rc:raise RuntimeError("Fixed-output scoring failed; preserve once markers")
 save(ROOT/"status/complete.json",{"at":time.time(),"cases":len(names)})
if __name__=="__main__":
 try:
  wait_legacy_children()
  if sys.argv[1]=="satellite":
   save(ROOT/"status/satellite_owner_v4.json",{"pid":os.getpid(),"at":time.time(),"host":"rtx4090","gpu":[5,7]})
   if not (ROOT/"services/gpu2/ready.json").exists():raise RuntimeError("Owned TP2 service not ready")
   lane(2);save(ROOT/"status/satellite_complete_v4.json",{"at":time.time()})
   run("model_service.py",["stop"],ROOT/"logs/service_stop_gpu2_v4.log",{**os.environ,"EF_GPU":"2","EF_DEVICES":"5,7"})
  else:
   save(ROOT/"status/controller_owner_v4.json",{"pid":os.getpid(),"at":time.time(),"host":"a100"})
   from concurrent.futures import ThreadPoolExecutor
   with ThreadPoolExecutor(2) as p:
    for f in [p.submit(lane,0),p.submit(lane,1)]:f.result()
   while not (ROOT/"status/satellite_complete_v4.json").exists():
    if (ROOT/"status/satellite_error_v4.json").exists():raise RuntimeError("Satellite needs review")
    time.sleep(15)
   finalize()
 except Exception as e:save(ROOT/"status"/("satellite_error_v4.json" if sys.argv[1]=="satellite" else "controller_error_v4.json"),{"error":repr(e),"traceback":traceback.format_exc()});raise
