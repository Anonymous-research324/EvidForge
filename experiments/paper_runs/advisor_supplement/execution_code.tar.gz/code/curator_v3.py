"""恢复原解析器依赖路径；31份已冻结输入不重做。"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"dependencies"))
import curator_v2
if __name__=="__main__":curator_v2.original.main()
