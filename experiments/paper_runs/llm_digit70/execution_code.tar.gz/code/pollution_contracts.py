"""Exact direct70%quota and allowed teaching-cell checks, no private reference parsing."""
from pathlib import Path
import json,time
from common import ROOT as R,load,save
from original_curator_functions import canonical
def main():
 src=(R/'code/curator.py').read_text()
 assert 'round(.30' not in src and 'len(nominal)' not in src
 assert [(7*n+5)//10 for n in [100,1000,2185,14003]]==[70,700,1530,9802]
 allrows=[]
 for name in load(R/'configs/cases.json'):
  c=R/'cases'/name;m=load(c/'case.json');b=load(c/'public/development_bundle.json')
  for zone,z in m['counts'].items():
   expected=(7*z['eligible_cells']+5)//10
   assert z['selected_cells']==z['actual_changed_cells']==expected
   assert abs(z['actual_changed_cells']-.7*z['eligible_cells'])<=.5
   if zone in b:
    actual=sum(canonical(rec['dirty'][col])!=canonical(t) for group in b[zone] for rec in group['records'] for col,t in rec['truth'].items() if t!='')
    assert actual==expected,(name,zone,actual,expected)
  sums={k:sum(z[k] for z in m['counts'].values()) for k in ['eligible_cells','actual_changed_cells','target_cells','all_table_cells_including_ID']}
  allrows.append({'case':name,**sums,'actual_eligible_rate':sums['actual_changed_cells']/sums['eligible_cells'],'all_cell_rate_including_ID':sums['actual_changed_cells']/sums['all_table_cells_including_ID']})
 save(R/'audit/direct70_pollution_contract.json',{'at':time.time(),'synthetic_quota_examples_pass':True,'public_teaching_counts_rechecked':True,'repair_counts_verified_in_memory_by_curator':True,'private_reference_rows_reparsed':0,'source_fits':0,'model_calls':0,'cases':allrows})
 print('DIRECT70_POLLUTION_PASS',json.dumps(allrows[:2]),flush=True)
if __name__=='__main__':main()
