"""Independent post-run arithmetic and integrity checks; no fitting or rescoring."""
from pathlib import Path
import json,math,hashlib,socket,time,datetime,subprocess
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def arithmetic(v,target):
 valid=[x for x in v.values() if isinstance(x,(int,float)) and math.isfinite(x)]
 assert len(valid)==target['n'] and target['ddof']==1
 for s,x in v.items():assert target['per_seed'][str(s)]==x
 if len(valid)<3:
  assert target['mean'] is None and target['sample_sd'] is None;return False
 m=sum(valid)/3;sd=math.sqrt(sum((x-m)**2 for x in valid)/2)
 assert math.isclose(m,target['mean'],abs_tol=1e-12,rel_tol=0)
 assert math.isclose(sd,target['sample_sd'],abs_tol=1e-12,rel_tol=0)
 return True
def main():
 assert (ROOT/'status/complete.json').exists()
 assert sha(Path(P['original_ablation_scores']))==P['original_ablation_scores_sha256']
 for path,h in P['downstream_scores_sha256'].items():assert sha(Path(path))==h
 for f,h in load(ROOT/'audit/controller_freeze.json')['files'].items():assert sha(ROOT/f)==h
 roots={1013:Path(P['original_ablation_root']),**{s:Path(P['new_roots'][str(s)]) for s in [1014,1015]}}
 scores={s:load(b/'reports/scores.json') for s,b in roots.items()}
 idx={s:{(x['dataset'],x['arm']):x for x in rows} for s,rows in scores.items()}
 assert all(len(v)==36 for v in scores.values())
 stats={};filecount=learningcount=0
 for s,b in roots.items():
  core=b/'frozen_workspace/DataForge_UnseenTable_v23'
  for f,h in load(b/'audit/core124.json')['files'].items():assert sha(core/f)==h,'Original core changed'
  for f,h in load(b/'audit/experiment_code_freeze.json')['files'].items():assert sha(b/f)==h,'Adapter changed '+str(b/f)
  old=Path(P['downstream_roots'].get(str(s),str(b.parent/'EvidForge_Downstream_Study_seed1013')))
  parity={};native={};changed={};counts={'output_files':0,'learning_files':0}
  for n in P['display_order']:
   infreeze=load(old/'datasets'/n/'input_freeze.json')
   for category,folder in [('public','public'),('private','private'),('supervised_labels','downstream_training')]:
    for f,h in infreeze[category].items():assert sha(old/'datasets'/n/folder/f)==h,'Source input changed'
   original=old/'outputs'/n/'primary_llm/v23_output.csv'
   assert (b/'outputs'/n/'A_saved/repair_output.csv').read_bytes()==original.read_bytes()
   parity[n]=(b/'outputs'/n/'A/repair_output.csv').read_bytes()==original.read_bytes()
   assert parity[n]
   for arm in ['A_saved','A','B','C','D','E','F']:
    out=b/'outputs'/n/arm
    for f,h in load(out/'output_freeze.json')['files'].items():assert sha(out/f)==h,'Output changed';counts['output_files']+=1
   for arm in ['A','E','F']:
    case=b/'work'/n/arm
    for f,h in load(case/'learning_freeze.json')['files'].items():assert sha(case/f)==h,'Learning file changed';counts['learning_files']+=1
   for stage in ['prior','context']:
    q=load(b/'work'/n/'A'/(stage+'_stage/work/hypothesis_state.json'))
    z=load(b/'work'/n/'E'/(stage+'_stage/work/hypothesis_state.json'))
    assert q['attempted_proposals']==z['attempted_proposals']
  for arm in ['A','E','F']:
   results=list((b/'work').glob('*/'+arm+'/*_stage/native/result.json'))
   assert len(results)==12
   calls=controls=events=nonempty=0
   for path in results:
    v=load(path)
    assert v['closed'] and v['native_exit_code']==0 and v['project_hook_registered']==(arm!='F')
    assert v['real9B_calls']==5 and v['synthetic_control_count']==0
    calls+=v['real9B_calls'];controls+=v['synthetic_control_count']
    hooks=path.parent/'native_hooks.jsonl'
    h=[json.loads(l) for l in hooks.read_text().splitlines() if l.strip()] if hooks.exists() else []
    events+=len(h);nonempty+=sum(bool(x.get('verdict')) for x in h)
   if arm=='F':assert events==0
   native[arm]={'sessions':12,'real9B_calls':calls,'synthetic_controls':controls,'hook_events':events,'nonempty_hook_verdicts':nonempty}
  requests=None
  if s!=1013:
   assert not list((b/'status').glob('failure_*.json'))
   assert load(b/'status/scoring_complete.json')['rows']==36
   assert load(b/'audit/outputs_and_learning_pre_score.json')['time']<=load(b/'audit/scoring_started.json')['time']
   reqs=list((b/'models_service/requests').glob('*/request.json'));assert len(reqs)==180
   usage={'prompt_tokens':0,'completion_tokens':0,'total_tokens':0}
   for path in reqs:
    v=load(path);assert v['seed']==s and v['temperature']==0 and v['model']==f'evidforge-ablation-seed{s}'
    result=load(path.parent/'response.json')
    for k in usage:usage[k]+=result.get('usage',{}).get(k,0) or 0
   requests={'actual_pairs':len(reqs),'usage':usage}
   own=load(b/'models_service/owner.json');assert (b/'models_service/stopped.json').exists()
   proc=Path('/proc')/str(own['pid'])/'cmdline'
   if proc.exists():assert own['name'] not in proc.read_bytes().replace(b'\0',b' ').decode()
   with socket.socket() as sock:sock.settimeout(1);assert sock.connect_ex(('127.0.0.1',own['port']))!=0
  filecount+=counts['output_files'];learningcount+=counts['learning_files']
  stats[s]={'hash_counts':counts,'A_saved_parity_all6':True,'A_new_parity':parity,'native':native,'requests':requests}
 agg=load(ROOT/'reports/three_seed_ablation_aggregate.json');allmeans=pairedmeans=missing=0
 for r in agg['records']:
  n=r['dataset'];arm=r['arm']
  for category,metrics in r['metrics'].items():
   for k,target in metrics.items():
    v={s:idx[s][n,arm][category][k] for s in [1013,1014,1015]}
    if arithmetic(v,target):allmeans+=1
    else:missing+=1
 for r in agg['paired_differences']:
  n=r['dataset'];arm=r['ablated_arm']
  for category,metrics in r['metrics'].items():
   for k,target in metrics.items():
    v={}
    for s in [1013,1014,1015]:
     a=idx[s][n,'A'][category][k];z=idx[s][n,arm][category][k]
     v[s]=a-z if isinstance(a,(int,float)) and isinstance(z,(int,float)) else None
    if arithmetic(v,target):pairedmeans+=1
    else:missing+=1
 # Independent count-to-rate checks, only aggregate counts, not individual truth.
 for s,rows in scores.items():
  for r in rows:
   x=r['repair'];pr=x['exact']/x['changes'] if x['changes'] else None
   rr=x['exact']/x['errors'] if x['errors'] else 0
   f=2*pr*rr/(pr+rr) if pr and rr else 0
   assert (pr is None and x['P'] is None) or math.isclose(pr,x['P'],abs_tol=1e-12)
   assert math.isclose(rr,x['R'],abs_tol=1e-12) and math.isclose(f,x['F1'],abs_tol=1e-12)
   assert math.isclose(x['normal_damage']/x['normal'],x['damage'],abs_tol=1e-12)
 done=load(ROOT/'status/complete.json');start=load(ROOT/'status/owner.json')['started']
 summary={'passed':True,'verified_at':time.time(),'original_ablation_and_all_downstream_scores_unchanged':True,
  'core124_each_and_all_adapter_and_controller_freezes_passed':True,'output_files_sha_verified':filecount,'learning_files_sha_verified':learningcount,
  'aggregate_mean_sd_pairs_recomputed':allmeans,'paired_difference_mean_sd_pairs_recomputed':pairedmeans,'honest_undefined_precision_statistics':missing,
  'sample_size':3,'ddof':1,'per_seed':stats,'new_actual9B_calls':360,'all_three_seed_actual9B_calls':540,
  'all_three_seed_native_sessions':108,'owned_8081_8082_stopped_and_ports_closed':True,
  'formal_reference_rows_parsed':False,'new_model_calls':0,'rescoring_or_fitting':False,
  'completed_cst':datetime.datetime.fromtimestamp(done['time'],datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'elapsed_minutes':(done['time']-start)/60,
  'three_seed_statistics_are_not_significance_or_novelty_proofs':True}
 save(ROOT/'audit/completed_three_seed_ablation_audit.json',summary)
 print(json.dumps({k:summary[k] for k in ['passed','output_files_sha_verified','learning_files_sha_verified','aggregate_mean_sd_pairs_recomputed','paired_difference_mean_sd_pairs_recomputed','honest_undefined_precision_statistics','completed_cst','elapsed_minutes']},ensure_ascii=False),flush=True)
 print('HOOKS',json.dumps({s:d['native'] for s,d in stats.items()},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
