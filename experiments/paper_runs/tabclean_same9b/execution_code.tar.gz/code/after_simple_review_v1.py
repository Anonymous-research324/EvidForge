"""Wait for fixed-score/report completion and resource stop, then run read-only final review once."""
from pathlib import Path
import os,time,subprocess,fcntl,traceback
from common import ROOT,PY,load,save,sha
def main():
 lock=(ROOT/'status/final_review_watcher.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (ROOT/'status/final_review_watcher_owner.json').exists():raise RuntimeError('Watcher exists')
 save(ROOT/'status/final_review_watcher_owner.json',{'pid':os.getpid(),'at':time.time(),'no_model_or_scoring_calls':True})
 while True:
  scored=(ROOT/'status/scoring_complete.json').exists();reports=(ROOT/'status/reports_ready.json').exists()
  stopped=all((ROOT/'services'/('gpu'+str(g))/'stopped.json').exists() for g in [0,1])
  if scored and reports and stopped:break
  if (ROOT/'status/controller_error.json').exists() and not scored:
   save(ROOT/'status/final_review_waiting_recovery.json',{'at':time.time(),'reason':'controller needs independent recovery; no final review or rescoring dispatched'});return
  time.sleep(10)
 freeze=load(ROOT/'audit/final_review_code_freeze_simple_v1.json');assert sha(ROOT/freeze['path'])==freeze['sha256']
 log=ROOT/'logs/final_independent_review_v1.log'
 with log.open('x') as f:
  r=subprocess.run([PY,'-B',str(ROOT/freeze['path'])],cwd=ROOT,env={**os.environ,'PYTHONPATH':str(ROOT/'code'),'PYTHONDONTWRITEBYTECODE':'1'},stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError('Independent review failed; inspect preserved log, never rescore')
 save(ROOT/'status/final_independent_review_ready.json',{'at':time.time(),'passed':True,'human_visual_review_and_chat_delivery_still_pending':True})
if __name__=='__main__':
 try:main()
 except Exception as e:save(ROOT/'status/final_review_watcher_error.json',{'at':time.time(),'error':repr(e),'traceback':traceback.format_exc()});raise
