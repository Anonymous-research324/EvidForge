"""Immutable files, actual source learning, inputs and request identity; no truth parsing."""
from pathlib import Path
import time,json
from common import ROOT,load,save,sha,read_csv
def verify():
 counts={"cases":0,"outputs":0,"native_sessions":0,"native_calls":0,"requests":0,"learning_packages":0}
 for rel,h in load(ROOT/"audit/execution_freeze.json")["files"].items():assert sha(ROOT/rel)==h,rel
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ROOT/"engine"/rel)==h,rel
 for rel,h in load(ROOT/"audit/old_scores_frozen.json").items():assert sha(rel)==h,rel
 for rel,h in load(ROOT/"audit/concrete_sources_frozen.json").items():assert sha(rel)==h,rel
 assigned=load(ROOT/"configs/lane_assignment.json")
 traced=set()
 for n in load(ROOT/"configs/cases.json"):
  case=ROOT/"cases"/n;cfg=load(case/"case.json");counts["cases"]+=1
  f=load(case/"input_freeze.json")
  assert sha(case/"case.json")==f["case_sha256"]
  for zone in ["public","private"]:
   for rel,h in f[zone].items():assert sha(case/zone/rel)==h
  fields,rows=read_csv(case/"public/repair_dirty.csv");targets=set(load(case/"public/declaration.json")["targets"])
  arms=load(case/"status/closed.json")["arms"];assert set(arms)=={"full","no_llm","reuse"}
  for a in arms:
   out=case/"outputs"/a
   for rel,h in load(out/"output_freeze.json")["files"].items():assert sha(out/rel)==h
   fields2,after=read_csv(out/"repair_output.csv")
   assert fields==fields2 and len(rows)==len(after)
   assert all(x[k]==y[k] for x,y in zip(rows,after) for k in fields if k not in targets)
   counts["outputs"]+=1
  assert sha(case/"outputs/full/repair_output.csv")==sha(case/"outputs/reuse/repair_output.csv")
  for arm in ["full","no_llm"]:
   w=case/"work"/arm
   for rel,h in load(w/"learning_freeze.json")["files"].items():assert sha(w/rel)==h
   counts["learning_packages"]+=1
  sel=load(case/"work/no_llm/selection.json");assert sel["actual9B_calls"]==0 and sel["pre_native_checkpoint"]
  assert not (Path(sel["skill"])/"compiled_candidate.json").exists()
  for stage in ["prior_stage","context_stage"]:
   native=case/"work/full"/stage/"native_v3"
   result=load(native/"result.json");assert result["closed"] and result["native_exit_code"]==0 and result["synthetic_control_count"]==0
   counts["native_sessions"]+=1;counts["native_calls"]+=result["real9B_calls"]
   for p in native.glob("actual9b-request-*.json"):
    wire=load(p);tag=wire["_trace_tag"];assert tag not in traced;traced.add(tag)
    req=ROOT/"services"/("gpu"+str(assigned[n]))/"requests"/tag
    a=load(req/"request.json");response=load(req/"response.json");timing=load(req/"timing.json")
    assert a["seed"]==cfg["seed"]==timing["seed"] and a["temperature"]==0 and a["model"]=="evidforge-robustness-retino-9b-gpu"+str(assigned[n])
    assert a["messages"]==wire["messages"] and response["choices"][0]["finish_reason"]=="stop"
    assert response.get("usage") is not None
    counts["requests"]+=1
 alltags={p.name for p in (ROOT/"services").glob("gpu*/requests/*") if (p/"request.json").exists()}
 assert alltags==traced and counts["cases"]==24 and counts["outputs"]==72
 assert counts["requests"]==counts["native_calls"]
 save(ROOT/"audit/all_outputs_integrity.json",{"status":"PASS","counts":counts,"formal_rows_parsed":0,"time":time.time()})
 return counts
if __name__=="__main__":print(verify(),flush=True)
