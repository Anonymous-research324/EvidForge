"""Independent final checks from frozen scores/counts only; no formal reference reads."""
from pathlib import Path
import json,math,hashlib,collections,os,socket,subprocess,time
from common import ROOT,load,save,sha
def close(a,b):
 if a is None or b is None:
  if a is not None or b is not None:raise ValueError("None mismatch")
 elif not math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-12):raise ValueError("Numeric mismatch "+str((a,b)))
def calc(values):
 if len(values)!=3 or any(x is None for x in values):return None,None
 m=sum(values)/3
 return m,math.sqrt(sum((x-m)**2 for x in values)/2)
def main():
 if not (ROOT/"status/scoring_complete.json").exists() or not (ROOT/"status/reports_ready.json").exists():raise RuntimeError("Not complete")
 scores=load(ROOT/"reports/all_scores.json");agg=load(ROOT/"reports/aggregate.json")
 assert len(scores)==48
 ix={(x["dataset"],x["seed"],x["arm"]):x for x in scores};assert len(ix)==48
 reviewed=0
 for item in scores:
  for z in [item["repair"],*item["by_field"].values()]:
   tp,c,e,n,h=[z[k] for k in ["exact","changes","errors","normal","damaged"]]
   close(z["P"],tp/c if c else None);close(z["R"],tp/e if e else 0)
   close(z["F1"],2*tp/(c+e) if c+e else 0)
   close(z["normal_damage"],h/n if n else None)
   close(z["detection_AUC"],(1+(c-h)/e-h/n)/2 if e and n else None)
   assert 0<=tp<=min(c,e) and 0<=h<=min(n,c)
   reviewed+=1
  for z in item["by_constructed_mechanism"].values():close(z["exact_repair_recall"],z["exact"]/z["errors"] if z["errors"] else None)
 for a in agg["aggregate"]:
  vals=[ix[(a["dataset"],s,a["arm"])]["repair"][a["metric"]] for s in [1013,1014,1015]]
  m,sd=calc(vals);close(m,a["mean"]);close(sd,a["sample_sd"])
  assert a["n"]==sum(v is not None for v in vals)
 for a in agg["paired"]:
  metric=a["metric"].removeprefix("full_minus_arm_")
  vals=[]
  for s in [1013,1014,1015]:
   u=ix[(a["dataset"],s,"full")]["repair"][metric];v=ix[(a["dataset"],s,a["arm"])]["repair"][metric]
   vals.append(u-v if u is not None and v is not None else None)
  m,sd=calc(vals);close(m,a["mean"]);close(sd,a["sample_sd"])
 for a in agg["mechanisms"]:
  vals=[ix[(a["dataset"],s,a["arm"])]["by_constructed_mechanism"].get(a["mechanism"],{}).get("exact_repair_recall") for s in [1013,1014,1015]]
  m,sd=calc(vals);close(m,a["mean"]);close(sd,a["sample_sd"])
 checked=0
 for base,hs in [(ROOT,load(ROOT/"audit/execution_freeze.json")["files"]),(ROOT/"engine",load(ROOT/"audit/core124.json")["files"]),(Path("/"),load(ROOT/"audit/old_scores_frozen.json")),(Path("/"),load(ROOT/"audit/old_advisor_results_frozen.json"))]:
  for rel,h in hs.items():assert sha(base/rel)==h;checked+=1
 old=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/engine")
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(old/rel)==h;checked+=1
 native_sessions=native_calls=0;hooks=collections.Counter();request_usage=collections.Counter()
 for name in load(ROOT/"configs/semantic_cases.json"):
  c=ROOT/"cases"/name;f=load(c/"input_freeze.json")
  for zone in ["public","private"]:
   for rel,h in f[zone].items():assert sha(c/zone/rel)==h;checked+=1
  assert sha(c/"private/repair_rowkeys.json")==load(ROOT/"audit/input_alignment_extension.json")["new_private_rowkeys_sha"][name]
  assert sha(c/"outputs/full/repair_output.csv")==sha(c/"outputs/reuse/repair_output.csv")
  for arm in load(c/"status/closed.json")["arms"]:
   for rel,h in load(c/"outputs"/arm/"output_freeze.json")["files"].items():assert sha(c/"outputs"/arm/rel)==h;checked+=1
  for arm in ["full","no_llm","no_feedback","no_predictive_context"]:
   w=c/"work"/arm
   for rel,h in load(w/"learning_freeze.json")["files"].items():assert sha(w/rel)==h;checked+=1
   sel=load(w/"selection.json")
   if arm=="no_llm":
    assert sel["actual9B_calls"]==0 and sel["pre_native_checkpoint"]
    assert not (Path(sel["skill"])/"compiled_candidate.json").exists()
   else:
    for stage in ["prior_stage","context_stage"]:
     v=w/stage/"native_v3";rc=load(v/"result.json")
     assert rc["closed"] and rc["native_exit_code"]==0 and rc["synthetic_control_count"]==0
     assert 0<rc["real9B_calls"]<=5
     native_sessions+=1;native_calls+=rc["real9B_calls"]
     hks=[json.loads(l) for l in (v/"native_hooks.jsonl").read_text().splitlines() if l.strip()]
     h=collections.Counter(x["event"] for x in hks)
     assert h["PreToolUse"]==rc["real9B_calls"] and h["PostToolUse"]==rc["real9B_calls"] and h["Stop"]>=1
     hooks.update(h)
     if arm=="no_feedback":
      a=load(c/"work/full"/stage/"work/hypothesis_state.json");b=load(w/stage/"work/hypothesis_state.json")
      assert a["attempted_proposals"]==b["attempted_proposals"]
 assert native_sessions==36
 costs=load(ROOT/"reports/actual_model_costs.json")
 for row in costs["calls"]:
  p=Path(row["path"]);a=load(p/"request.json");b=load(p/"response.json")
  assert sha(p/"request.json")==row["request_sha"] and sha(p/"response.json")==row["response_sha"]
  assert b["usage"]==row["usage"] and a["temperature"]==0
  request_usage["requests"]+=1
  for k in ["prompt_tokens","completion_tokens","total_tokens"]:request_usage[k]+=b["usage"].get(k,0)
 assert dict(request_usage)==costs["totals"] and request_usage["requests"]==native_calls
 for f in ["语义跨字段消融表.png","语义跨字段消融表.pdf","语义跨字段消融表.svg"]:assert (ROOT/"reports"/f).stat().st_size>1000
 resources=[]
 for g in [0,1]:
  service=ROOT/"services"/("gpu"+str(g));owner=load(service/"owner.json")
  assert (service/"stopped.json").exists()
  cmd=Path("/proc")/str(owner["pid"])/"cmdline"
  if cmd.exists():assert owner["name"] not in cmd.read_bytes().decode(errors="replace")
  with socket.socket() as sock:active=sock.connect_ex(("127.0.0.1",owner["port"]))==0
  assert not active
  resources.append({"gpu":g,"owner_pid":owner["pid"],"owned_server_gone":True,"port":owner["port"],"port_closed":True})
 gpu=subprocess.check_output(["nvidia-smi","--query-gpu=index,memory.used,utilization.gpu","--format=csv,noheader"],text=True)
 compute=subprocess.check_output(["nvidia-smi","--query-compute-apps=pid,gpu_uuid,used_gpu_memory","--format=csv,noheader"],text=True)
 for line in compute.splitlines():
  pid=int(line.split(",")[0])
  try:
   pgid=os.getpgid(pid)
   assert pgid not in [load(ROOT/"services"/("gpu"+str(g))/"owner.json")["pgid"] for g in [0,1]]
  except ProcessLookupError:pass
 review={"at":time.time(),"status":"PASS","reviewed_metric_sets":reviewed,"aggregate_groups":len(agg["aggregate"]),"paired_groups":len(agg["paired"]),"mechanism_groups":len(agg["mechanisms"]),"sha_checks":checked,"native_sessions":native_sessions,"real_model_calls":native_calls,"actual_usage":dict(request_usage),"actual_hooks":dict(hooks),"resources":resources,"gpu_snapshot":gpu,"compute_snapshot":compute,"formal_reference_rows_read":0,"raw_scores_unchanged":True,"visual_review_still_required":True}
 save(ROOT/"audit/final_independent_review.json",review)
 print(json.dumps(review,ensure_ascii=False))
if __name__=="__main__":main()
