"""两张owned A100同权重BF16服务；每个请求独立绑定种子，完整计账。"""
from pathlib import Path
import os,sys,json,time,subprocess,socket,signal,urllib.request
from common import ROOT,PY,load,save
GPU=int(os.environ.get("EF_GPU","0"));DEVICES=os.environ.get("EF_DEVICES",str(GPU));PORT=8211+GPU;NAME="evidforge-original-newerrors-gpu"+str(GPU)+"-9b";SERVICE=ROOT/"services"/("gpu"+str(GPU))
def start():
 assert socket.gethostname()==load(ROOT/"configs/execution_host.json")["hostname"]
 SERVICE.mkdir(parents=True,exist_ok=True)
 if (SERVICE/"owner.json").exists():raise RuntimeError("Owner exists: inspect rather than duplicate")
 rows=subprocess.check_output(["nvidia-smi","--query-gpu=index,memory.used","--format=csv,noheader,nounits"],text=True)
 used={int(x.split(",")[0]):int(x.split(",")[1]) for x in rows.splitlines()}
 if any(used[int(g)]>=512 for g in DEVICES.split(",")):raise RuntimeError("GPU occupied")
 with socket.socket() as s:s.bind(("127.0.0.1",PORT))
 weights="/root/fshare/models/Qwen/Qwen3.5-9B"
 manifest=ROOT/"configs/model-files-9B.sha256"
 with (SERVICE/"weights_check.txt").open("x") as f:r=subprocess.run(["sha256sum","-c",str(manifest)],cwd=weights,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError("Weights hash mismatch")
 fresh=subprocess.check_output(["nvidia-smi","--query-gpu=index,memory.used","--format=csv,noheader,nounits"],text=True)
 now={int(x.split(",")[0]):int(x.split(",")[1]) for x in fresh.splitlines()}
 if any(now[int(g)]>=512 for g in DEVICES.split(",")):raise RuntimeError("Selected card occupied after weight check")
 cmd=["/root/fsas/home/anonymous/envs/dataforge-infer/bin/python","-m","vllm.entrypoints.openai.api_server","--model",weights,"--served-model-name",NAME,"--host","127.0.0.1","--port",str(PORT),"--tensor-parallel-size",str(len(DEVICES.split(","))),"--dtype","bfloat16","--language-model-only","--max-model-len","131072","--max-num-seqs","1","--gpu-memory-utilization",".90","--reasoning-parser","qwen3","--seed","1013","--default-chat-template-kwargs",'{"enable_thinking":false}']
 env={**os.environ,"CUDA_VISIBLE_DEVICES":DEVICES,"HF_HUB_OFFLINE":"1","TRANSFORMERS_OFFLINE":"1","OMP_NUM_THREADS":"3","VLLM_USE_FLASHINFER_SAMPLER":"0","PYTHONDONTWRITEBYTECODE":"1"}
 with (SERVICE/"server.log").open("x") as f:p=subprocess.Popen(cmd,env=env,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 save(SERVICE/"owner.json",{"pid":p.pid,"pgid":p.pid,"gpu":GPU,"physical_devices":DEVICES,"host":__import__("socket").gethostname(),"port":PORT,"name":NAME,"command":cmd})
 for _ in range(300):
  if p.poll() is not None:raise RuntimeError("Owned server exited")
  try:
   with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/v1/models",timeout=2) as r:m=json.load(r)
   save(SERVICE/"ready.json",{"models":m,"at":time.time()});return
  except OSError:time.sleep(2)
 raise TimeoutError("Owned service not ready; do not duplicate")
def call():
 body=json.load(sys.stdin);tag=body.pop("_trace_tag");seed=int(os.environ["EF_SEED"]);body.update(model=NAME,seed=seed,temperature=0,chat_template_kwargs={"enable_thinking":False})
 if not tag.isalnum():raise ValueError("Invalid trace tag")
 p=SERVICE/"requests"/tag;p.mkdir(parents=True,exist_ok=False);save(p/"request.json",body);t=time.monotonic()
 try:
  req=urllib.request.Request(f"http://127.0.0.1:{PORT}/v1/chat/completions",json.dumps(body).encode(),{"Content-Type":"application/json"})
  with urllib.request.urlopen(req,timeout=300) as r:d=json.load(r)
  save(p/"response.json",d);print(json.dumps(d,ensure_ascii=False),flush=True)
 except Exception as e:save(p/"failure.json",{"error":repr(e)});raise
 finally:save(p/"timing.json",{"seconds":time.monotonic()-t,"seed":seed})
def stop():
 assert socket.gethostname()==load(ROOT/"configs/execution_host.json")["hostname"]
 owner=load(SERVICE/"owner.json");p=Path("/proc")/str(owner["pid"])/"cmdline"
 if p.exists():
  text=p.read_bytes().replace(b"\0",b" ").decode()
  if NAME not in text or "--port "+str(PORT) not in text or os.getpgid(owner["pid"])!=owner["pgid"]:raise RuntimeError("Ownership mismatch")
  os.killpg(owner["pid"],signal.SIGTERM)
  for _ in range(60):
   with socket.socket() as s:active=s.connect_ex(("127.0.0.1",PORT))==0
   if not active:break
   time.sleep(1)
 for _ in range(90):
  with socket.socket() as s:active=s.connect_ex(("127.0.0.1",PORT))==0
  if not active and not Path("/proc",str(owner["pid"])).exists():break
  time.sleep(1)
 else:raise RuntimeError("Owned service has not completely exited; preserve owner and block scoring")
 save(SERVICE/"stopped.json",{"at":time.time(),"pid":owner["pid"]})
if __name__=="__main__":{"start":start,"call":call,"stop":stop}[sys.argv[1]]()
