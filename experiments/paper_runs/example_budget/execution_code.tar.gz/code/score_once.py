"""Single final reference read per case after all 54 fixed outputs and native sessions close."""
import sys,time,statistics,collections
from pathlib import Path
from common import ROOT,load,save,read_csv,sha
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/"engine/source_runtime"))
from unseen_table.common import equal
def metric(dirty,rows,truth,cols):
 e=n=c=tp=harm=0
 for a,b,t in zip(dirty,rows,truth):
  for k in cols:
   if not t.get(k,"").strip():continue
   bad=not equal(a[k],t[k]);changed=not equal(a[k],b[k])
   e+=bad;n+=not bad;c+=changed;tp+=bad and changed and equal(b[k],t[k]);harm+=not bad and changed
 p=tp/c if c else None;r=tp/e if e else 0.
 return {"P":p,"R":r,"F1":2*p*r/(p+r) if p and r else 0.,"normal_damage":harm/n if n else None,"errors":e,"normal":n,"changes":c,"exact":tp,"damaged":harm}
def main():
 assert load(ROOT/"audit/all_outputs_ready.json")["passed"] and (ROOT/"status/all_outputs_closed.json").exists()
 if (ROOT/"audit/scoring_started.json").exists():raise RuntimeError("Do not repeat scoring or delete marker")
 save(ROOT/"audit/scoring_started.json",{"at":time.time(),"all54_fixed":True,"role":"independent scorer, no feedback"})
 scores=[]
 for name in load(ROOT/"configs/cases.json"):
  case=ROOT/"cases"/name;meta=load(case/"case.json")
  assert not (case/"audit_scoring_started.json").exists()
  save(case/"audit_scoring_started.json",{"at":time.time(),"fixed_output_sha":sha(case/"outputs/full/repair_output.csv")})
  fields,d=read_csv(case/"public/repair_dirty.csv");_,t=read_csv(case/"private/repair_reference.csv");_,b=read_csv(case/"outputs/full/repair_output.csv")
  assert len(d)==len(t)==len(b) and [r["entity_id"] for r in d]==[r["entity_id"] for r in t]==[r["entity_id"] for r in b]
  cols=load(case/"public/declaration.json")["targets"];m=metric(d,b,t,cols)
  assert sum(len(g["records"]) for g in load(case/"public/development_bundle.json")["learning"])==meta["zones"]["learning"]["rows"]
  sel=load(case/"work/full/selection.json")
  cost={"actual_calls":0,"prompt_tokens":0,"completion_tokens":0,"native_seconds":0.,"stage_details":{}}
  for kind in ["prior","context"]:
   receipt=load(case/"work/full"/(kind+"_stage/native_v3/result.json"));cost["actual_calls"]+=receipt["real9B_calls"];cost["native_seconds"]+=receipt["seconds"]
   cost["stage_details"][kind]={"calls":receipt["real9B_calls"],"seconds":receipt["seconds"],"deferred":receipt["deferred"]}
   for usage in receipt["actual_usage"]:
    # Gateway stores actual OpenAI usage dictionaries.
    u=usage.get("usage",usage) if isinstance(usage,dict) else {}
    cost["prompt_tokens"]+=u.get("prompt_tokens",0);cost["completion_tokens"]+=u.get("completion_tokens",0)
  item={**meta,"repair":m,"qualified":sel["passed"],"selected_kind":sel["kind"],"learning_seconds":sel["seconds"],"repair_seconds":load(case/"outputs/full/receipt.json")["seconds"],"reuse_seconds":load(case/"outputs/reuse/receipt.json")["seconds"],"cost":cost,"actual_formal_corruption_rate":m["errors"]/(m["errors"]+m["normal"]) if m["errors"]+m["normal"] else None}
  scores.append(item);save(case/"scores.json",item);save(case/"status/scored.json",{"at":time.time(),"rows":1});save(ROOT/"reports/all_scores.json",scores)
 # Read-only reporting computes aggregation/cost directly from persisted real service request usage.
 from report import build
 build(scores)
 save(ROOT/"status/scoring_complete.json",{"cases":len(scores),"at":time.time()})
 print("BUDGET_SCORING_COMPLETE",len(scores),flush=True)
if __name__=="__main__":main()
