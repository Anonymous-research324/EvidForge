"""等待独立评分完毕后做可审查汇总；不启动模型、不重新评分。"""
import os,time,subprocess,traceback
from common import ROOT,PY,save,load
if __name__=="__main__":
    save(ROOT/"status/report_watcher_owner.json",{"pid":os.getpid(),"at":time.time()})
    try:
        while not (ROOT/"status/scoring_complete.json").exists():time.sleep(30)
        if not (ROOT/"status/delivery_ready.json").exists():
            with (ROOT/"logs/reader_postprocess.log").open("x") as log:
                proc=subprocess.run([PY,"-B",ROOT/"code/reader_postprocess.py"],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            if proc.returncode:raise RuntimeError("Postprocessing failed; fixed raw scores preserved, see log")
    except Exception as e:
        save(ROOT/"status/report_watcher_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()})
        raise
