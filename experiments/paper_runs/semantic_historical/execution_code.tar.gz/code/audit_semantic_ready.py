"""仅对冻结文件做SHA及公开输入输出结构审计；不解析正式参考。"""
from pathlib import Path
from common import ROOT,load,save,sha,read_csv
import time
def check(path,expected):
 if sha(path)!=expected:raise ValueError("Frozen SHA differs: "+str(path))
def verify():
 count={"cases":0,"outputs":0,"learning_packages":0,"native_sessions":0,"real_native_calls":0,"requests":0}
 for rel,h in load(ROOT/"audit/execution_freeze.json")["files"].items():check(ROOT/rel,h)
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():check(ROOT/"engine"/rel,h)
 for f,h in load(ROOT/"audit/old_scores_frozen.json").items():check(Path(f),h)
 for name in load(ROOT/"configs/semantic_cases.json"):
  case=ROOT/"cases"/name;cfg=load(case/"case.json")
  count["cases"]+=1
  frozen=load(case/"input_freeze.json")
  for role in ["public","private"]:
   for f,h in frozen[role].items():check(case/role/f,h)
  check(case/"case.json",frozen["case_sha256"])
  fields,dirty=read_csv(case/"public/repair_dirty.csv")
  targets=set(load(case/"public/declaration.json")["targets"])
  arms=load(case/"status/closed.json")["arms"]
  if set(arms)!={"full","no_llm","reuse","no_transforms","no_generated_execution","no_final_gate","no_feedback","no_predictive_context"}:raise ValueError("Missing predeclared arm")
  check(case/"private/repair_rowkeys.json",load(ROOT/"audit/input_alignment_extension.json")["new_private_rowkeys_sha"][name])
  for arm in arms:
   out=case/"outputs"/arm
   for f,h in load(out/"output_freeze.json")["files"].items():check(out/f,h)
   columns,rows=read_csv(out/"repair_output.csv")
   if columns!=fields or len(rows)!=len(dirty):raise ValueError("Output dimensions differ")
   if any(a[k]!=b[k] for a,b in zip(dirty,rows) for k in fields if k not in targets):raise ValueError("Protected field/ID changed")
   count["outputs"]+=1
  check(case/"outputs/reuse/repair_output.csv",sha(case/"outputs/full/repair_output.csv"))
  for arm in ["full","no_llm"]+(["no_feedback","no_predictive_context"] if cfg["suite"] in ["main","natural","semantic_controlled"] else []):
   w=case/"work"/arm
   for f,h in load(w/"learning_freeze.json")["files"].items():check(w/f,h)
   count["learning_packages"]+=1
   if arm=="no_llm":
    selection=load(w/"selection.json")
    assert selection["actual9B_calls"]==0 and selection["pre_native_checkpoint"]
   else:
    for stage in ["prior_stage","context_stage"]:
     receipt=load(w/stage/"native_v3/result.json")
     if not receipt["closed"] or receipt["native_exit_code"] or receipt["synthetic_control_count"]:raise ValueError("Native not real/closed")
     count["native_sessions"]+=1;count["real_native_calls"]+=receipt["real9B_calls"]
   if arm=="no_feedback":
    for stage in ["prior_stage","context_stage"]:
     a=load(case/"work/full"/stage/"work/hypothesis_state.json")
     b=load(w/stage/"work/hypothesis_state.json")
     if a["attempted_proposals"]!=b["attempted_proposals"]:raise ValueError("Unpaired no_feedback proposal count")
 for req in (ROOT/"services").glob("gpu*/requests/*"):
  if not (req/"request.json").exists():continue
  a=load(req/"request.json")
  if a["seed"] not in [1013,1014,1015] or a["temperature"]!=0 or not a["model"].startswith("evidforge-semantic-9b-gpu"):raise ValueError("Request model/seed/temp mismatch")
  if not (req/"response.json").exists():raise ValueError("Unreviewed request without response")
  matched=[n for n in load(ROOT/"configs/semantic_cases.json") if ("Semantic"+n).replace("_","").replace("-","") in req.name]
  if len(matched)!=1:raise ValueError("Unknown/colliding request case identity")
  cfg=load(ROOT/"cases"/matched[0]/"case.json")
  expected_gpu=0 if cfg["dataset"]=="hospital" else 1
  if a["seed"]!=cfg["seed"] or a["model"]!="evidforge-semantic-9b-gpu"+str(expected_gpu) or req.parents[1].name!="gpu"+str(expected_gpu):raise ValueError("Per-case request seed/lane mismatch")
  if load(req/"response.json").get("usage") is None:raise ValueError("Missing actual usage")
  count["requests"]+=1
 save(ROOT/"audit/all_outputs_ready_integrity.json",{"at":time.time(),"counts":count,"formal_reference_rows_parsed":0,"passed":True})
 return count
if __name__=="__main__":print(verify())
