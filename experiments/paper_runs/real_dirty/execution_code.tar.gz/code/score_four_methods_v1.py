"""User-authorized four-method delivery. Original numerical scorer is imported unchanged."""
from pathlib import Path
import os,json,time,inspect,copy,socket,signal,fcntl,csv,statistics
import score_recovery_v3 as S
from common import ROOT as R,load,save,sha,read_csv
SELECTED=['full','raha_holoclean','cdc','tabclean']

def write_once(p,x):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as h:json.dump(x,h,ensure_ascii=False,indent=2);h.flush();os.fsync(h.fileno())

def main():
 lock=(R/'status/scoring_four_methods_v1.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (R/'status/scoring_four_methods_complete_v1.json').exists(),'No repeated scoring'
 assert not list(R.glob('cases/*/scoring_started*.json')),'Preserve existing markers; inspect partial scoring'
 S.self_test();p=S.config();S.verify_selection();names=load(R/'configs/cases.json');pilots=load(R/'configs/cases_pilot.json');imports=S.import_inventory()
 assert len(names)==24 and not load(R/'status/recovery_gpu_complete_v3.json')['failed']
 assert not list(R.glob('cases/*/status/*recovery_v3_failure.json'))
 for q in [R/'status/cpu_recovery_v3_error.json',R/'status/gpu_recovery_v3_error.json']:assert not q.exists()
 # Retire only the waiting delivery coordinator; GARF's CPU controller is untouched.
 owner=load(R/'status/delivery_recovery_v3_owner.json');proc=Path('/proc')/str(owner['pid'])/'cmdline'
 if proc.exists():
  assert b'delivery_recovery_v3.py' in proc.read_bytes();os.kill(owner['pid'],signal.SIGTERM)
 write_once(R/'audit/four_methods_delivery_amendment_v1.json',{'at':time.time(),'user_requested_GARF_excluded_and_continues':True,'methods':SELECTED,'original_score_entry_sha':sha(R/'code/score_recovery_v3.py'),'original_metric_unchanged':True,'original_thresholds_splits_unchanged':True,'waiting_delivery_coordinator_retired':owner['pid'],'CPU_GARF_controller_untouched':True,'all_selected_outputs_already_frozen_before_scoring':True,'scope_marker':'scoring_started_four_methods_v1.json','future_GARF_must_import_these_scores_without_regrading_selected_methods':True,'future_GARF_may_read_reference_for_its_unscored_output_only':True})
 evidence={}
 for rel in ['status/controller_error.json','status/delivery_error.json','status/pilot_errors.json','audit/pilot_hook_gap_review_v3.json','audit/io_guard_strengthening_review_v3.json','audit/preflight_failures_reviewed.json','audit/native_v4_ready.json']:
  f=R/rel
  if f.exists():evidence[rel]=sha(f)
 for n in ['beers_s9013','jobposting_small_s9013']:
  for rel in ['status/full_expansion_failure.json','status/recovery_failure_v4.json','logs/full_expansion.log','logs/full/prior_native_v3.log']:
   f=R/'cases'/n/rel
   if f.exists():evidence[str(f.relative_to(R))]=sha(f)
 save(R/'audit/four_methods_failures_reviewed_v1.json',{'passed':True,'no_unknown_failures':True,'at':time.time(),'evidence_files':evidence,'GARF_pending_not_claimed_complete':True})
 ns=dict(S.__dict__)
 text=inspect.getsource(S.verify_frozen_code).replace('recovery_failures_reviewed_v3.json','four_methods_failures_reviewed_v1.json');exec(compile(text,'<four-method-scope-freeze-check>','exec'),ns);ns['verify_frozen_code']()
 S.verify_inputs(names+pilots)
 available=[]
 for n in names:
  c=R/'cases'/n;meta=load(c/'case.json')
  for m in SELECTED:
   out=S.output_dir(n,m,imports);fr=out/'output_freeze.json';assert fr.exists(),(n,m)
   if (n,m) in imports:assert sha(fr)==imports[n,m]['sha256']
   for rel,h in load(fr)['files'].items():assert sha(out/rel)==h,(n,m,rel)
   for zone in ['repair','validation']:
    f,a=read_csv(c/'public'/f'{zone}_dirty.csv');of,b=read_csv(out/f'{zone}_output.csv');assert f==of;b=S.align(a,b)
    assert all(x[k]==y[k] for x,y in zip(a,b) for k in meta['protected'])
   available.append({'case':n,'method':m,'freeze_sha':sha(fr)})
 assert len(available)==96
 # Same request/usage/Hook verifier, only completed-method iteration is scoped.
 ns=dict(S.__dict__);ns['METHODS']=SELECTED;exec(compile(inspect.getsource(S.verify_requests),'<four-method-request-scope>','exec'),ns)
 costs=ns['verify_requests'](names,pilots,imports)
 resources=[];ps=os.popen('ps -eo pid,pgid,args').read().splitlines()
 for generation in p['service_generations']:
  for g,port in enumerate(generation['ports']):
   d=R/generation['root']/f'gpu{g}';o=load(d/'owner.json');assert o['host']==socket.gethostname() and (d/'stopped.json').exists()
   q=Path('/proc')/str(o['pid'])/'cmdline';assert not q.exists() or o['name'].encode() not in q.read_bytes()
   assert not any(len(x.split(maxsplit=2))==3 and x.split(maxsplit=2)[1]==str(o['pgid']) for x in ps)
   with socket.socket() as so:assert so.connect_ex(('127.0.0.1',port))!=0
   resources.append(port)
 # PostgreSQL belongs to the continuing GARF queue: explicitly not claimed released.
 write_once(R/'audit/four_methods_outputs_ready_v1.json',{'passed':True,'at':time.time(),'outputs':available,'requests_checked':len(costs),'GPU_owned_ports_closed':resources,'GARF_and_owned_Postgres_may_continue':True,'formal_reference_parsed':False})
 old=load(S.O/'reports/all_scores.json');oldindex={(x['dataset'],x['seed'],x['method']):x for x in old};oldsha=sha(S.O/'reports/all_scores.json');allrows=[]
 for n in names:
  c=R/'cases'/n;meta=load(c/'case.json');new=[m for m in SELECTED if (n,m) not in imports]
  write_once(c/'scoring_started_four_methods_v1.json',{'at':time.time(),'entry_sha256':sha(Path(__file__)),'methods':SELECTED,'new_methods':new,'imported_methods':[m for m in SELECTED if (n,m) in imports],'old_score_sha256':oldsha,'no_existing_output_regraded':True,'formal_reference_read_once_for_selected_new_outputs':True})
  _,dirty=read_csv(c/'public/repair_dirty.csv');gold=S.truth_align(dirty,load(c/'private/repair_truth.json'))
  _,vd=read_csv(c/'public/validation_dirty.csv');vg=S.truth_align(vd,load(c/'private/validation_truth.json'))
  for zone,dr,gt in [('repair',dirty,gold),('validation',vd,vg)]:save(c/'audit'/f'four_methods_known_{zone}_v1.json',{'row_keys':[x['__rowkey__'] for x in dr],'known_fields':[sorted(t) for t in gt],'truth_values_included':False})
  rows=[]
  for m in SELECTED:
   if (n,m) in imports:
    base=copy.deepcopy(oldindex[meta['dataset'],meta['seed'],m]);assert base['status']=='scored';base.update(case=n,result_origin='imported_original_frozen_score',original_score_sha256=oldsha)
   else:
    out=S.output_dir(n,m,imports);_,actual=read_csv(out/'repair_output.csv');actual=S.align(dirty,actual);mr=S.metric(dirty,actual,gold,meta['targets'])
    _,vo=read_csv(out/'validation_output.csv');vo=S.align(vd,vo);mv=S.metric(vd,vo,vg,meta['targets'])
    qualified=mv['changes']>=5 and mv['clean']>=10 and mv['P']>=.98 and mv['normal_damage_rate'] is not None and mv['normal_damage_rate']<=.005
    base={'dataset':meta['dataset'],'seed':meta['seed'],'case':n,'method':m,'status':'scored','repair':mr,'validation':mv,'qualified':qualified,'result_origin':'new_frozen_output','output_folder':str(out)}
    if m=='full':base['original_evidforge_qualification']=load(c/'work/full/selection.json')['passed']
   base['experiment_partition']='formal';base['protocol_log_complete']=True;rows.append(base)
  write_once(c/'scores_four_methods_v1.json',rows);allrows+=rows
 assert len(allrows)==96 and sum(x['result_origin']=='imported_original_frozen_score' for x in allrows)==25
 ns=dict(S.__dict__);ns['METHODS']=SELECTED;exec(compile(inspect.getsource(S.aggregate_records),'<four-method-aggregation-scope>','exec'),ns)
 ag,pairs=ns['aggregate_records'](allrows,p['datasets'])
 dest=R/'reports/four_methods_v1';dest.mkdir(exist_ok=False)
 for f,v in [('all_scores.json',allrows),('aggregate.json',ag),('paired_differences.json',pairs),('actual_model_costs.json',costs)]:save(dest/f,v)
 # Independent arithmetic and public-output edit checks; no truth values reloaded.
 for x in allrows:
  for zone in ['repair','validation']:
   q=x[zone];E,M,C,N,D=[q[k] for k in ['errors','changes','exact','clean','normal_damage']]
   expected=2*C/(E+M) if E+M else 0.;assert abs(q['F1']-expected)<1e-12
   assert abs(q['P']-(C/M if M else 0))<1e-12 and abs(q['R']-(C/E if E else 0))<1e-12
   c=R/'cases'/x['case'];out=S.output_dir(x['case'],x['method'],imports);_,dr=read_csv(c/'public'/f'{zone}_dirty.csv');_,ar=read_csv(out/f'{zone}_output.csv');ar=S.align(dr,ar)
   mk=load(c/'audit'/f'four_methods_known_{zone}_v1.json');known=dict(zip(mk['row_keys'],mk['known_fields']))
   counted=sum(not S.equal(a[f],b[f]) for a,b in zip(dr,ar) for f in known[a['__rowkey__']]);assert counted==M,(x['case'],x['method'],zone,counted,M)
 for a in ag:
  values=[2*x['repair']['exact']/(x['repair']['errors']+x['repair']['changes']) if x['repair']['errors']+x['repair']['changes'] else 0 for x in allrows if x['dataset']==a['dataset'] and x['method']==a['method']]
  assert len(values)==3 and abs(a['mean']-sum(values)/3)<1e-12 and abs(a['sample_sd']-(sum((v-sum(values)/3)**2 for v in values)/2)**.5)<1e-12
 save(R/'audit/four_methods_independent_review_v1.json',{'passed':True,'at':time.time(),'formal_records':96,'imported_old_scores_unchanged':25,'new_outputs_scored_once':71,'P_R_F1_and_public_edits_recomputed':True,'mean_sampleSD_ddof1_checked':True,'raw_response_usage_Hooks_verified':True,'formal_reference_reread':False,'GPU_resources_closed':True,'GARF_continues_excluded_from_delivery':True})
 save(R/'status/scoring_four_methods_complete_v1.json',{'at':time.time(),'records':96,'passed':True,'GARF_excluded':True,'original_five_method_scorer_retired_do_not_run':True})
 print('FOUR_METHODS_96_FIXED_SCORE_QA_PASS')
 for a in ag:print(a['dataset'],a['method'],f"{a['mean']:.3f} ± {a['sample_sd']:.3f}", 'qualified',a['qualified_n'])
if __name__=='__main__':main()
