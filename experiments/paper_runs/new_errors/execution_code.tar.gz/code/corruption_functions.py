import copy,random
from decimal import Decimal
from unseen_table.common import number,equal
def swap(v):
 ix=[i for i,c in enumerate(v) if c.isdigit()]
 start=next((j for j,i in enumerate(ix) if v[i]!='0'),None)
 if start is None or start+1>=len(ix):return None
 a,b=ix[start:start+2]
 if v[a]==v[b]:return None
 out=list(v);out[a],out[b]=out[b],out[a];out=''.join(out)
 part=out.lstrip('-+').split('.')[0]
 if len(part)>1 and part[0]=='0':return None
 return out if not equal(out,v) else None
def corrupt(records,ds,profile,anchor,seed):
 out=copy.deepcopy(records);targets=list(records[0]['truth']);counts={}
 for col in targets:
  eligible=[]
  for i,r in enumerate(out):
   v=r['truth'][col];x=number(v)
   if x is None:continue
   if profile=='digit_transposition':changed=swap(v)
   elif profile=='cross_field_addition':
    if col==anchor:continue
    y=number(r['truth'][anchor])
    if y is None or not y:continue
    changed=format(x+y,'f')
   else:
    if not x:continue
    changed=format(x*Decimal('10'),'f')+'u'
   if changed is not None and not equal(changed,v):eligible.append((i,changed))
  rng=random.Random(f'{seed}:{ds}:{profile}:{col}');rng.shuffle(eligible);k=(3*len(eligible)+5)//10
  for i,v in eligible[:k]:out[i]['dirty'][col]=v
  counts[col]={'eligible':len(eligible),'changed':k}
 return out,counts
