"""仅恢复策展公共I/O别名；已冻结24份输入复用，原失败目录归档。"""
from pathlib import Path
import common
common.digest=common.sha
import curator as original
from common import ROOT,load,save,sha
old=original.make_case
def make_case(name,seed,suite,rate=.7,kind=None,fraction=1.):
 ident=f"{suite}_{name}_s{seed}"+(f"_r{rate}_{kind or 'mixed'}" if suite=="robustness" else f"_n{fraction}" if suite=="sample_size" else "")
 ident=ident.replace(".","p");case=ROOT/"cases"/ident
 if (case/"input_freeze.json").exists():
  meta=load(case/"case.json")
  assert meta["seed"]==seed and meta["suite"]==suite and meta["dataset"]==name
  return ident
 if case.exists():
  import shutil
  dest=ROOT/"audit/failed_initial_curator"/ident;dest.parent.mkdir(exist_ok=True)
  if dest.exists():raise RuntimeError("Prior failure archive exists")
  shutil.move(str(case),str(dest))
 return old(name,seed,suite,rate,kind,fraction)
original.make_case=make_case
if __name__=="__main__":original.main()
