"""唯一独立评分器：所有输出固定后一次读取参考；不反馈学习，不覆盖旧评分。"""
from pathlib import Path
import sys,time,math,statistics,collections,json
from common import ROOT,load,save,sha,freeze,read_csv
sys.path.insert(0,str(ROOT/"engine/source_runtime"))
from unseen_table.common import equal
def repair_metrics(dirty,rows,truth,cols):
 e=n=c=tp=harm=0
 for a,b,t in zip(dirty,rows,truth):
  for col in cols:
   if t.get(col,"")=="":continue
   wrong=not equal(a[col],t[col]);changed=not equal(a[col],b[col])
   e+=wrong;n+=not wrong;c+=changed;tp+=wrong and changed and equal(b[col],t[col]);harm+=not wrong and changed
 p=tp/c if c else None;r=tp/e if e else 0.
 return {"P":p,"R":r,"F1":2*p*r/(p+r) if p and r else 0.,"normal_damage":harm/n if n else None,"errors":e,"normal":n,"changes":c,"exact":tp,"damaged":harm,"detection_AUC":(1+(c-harm)/e-harm/n)/2 if e and n else None}
def score_case(case):
 if not (case/"status/closed.json").exists():raise RuntimeError("Case not closed")
 if (case/"audit_scoring_started.json").exists():raise RuntimeError("Once-only score marker exists; audited recovery required")
 arms=load(case/"status/closed.json")["arms"]+["tabclean"] if (case/"status/tabclean_closed.json").exists() else load(case/"status/closed.json")["arms"]
 for arm in arms:
  out=case/"outputs"/arm
  for f,h in load(out/"output_freeze.json")["files"].items():
   if sha(out/f)!=h:raise ValueError("Frozen output changed")
 for rel,h in load(case/"input_freeze.json")["public"].items():
  if sha(case/"public"/rel)!=h:raise ValueError("Frozen input changed")
 save(case/"audit_scoring_started.json",{"at":time.time(),"arms":arms,"role":"independent scorer; no future method updates","formal_read_first":True})
 meta=load(case/"public/dataset_metadata.json");cfg=load(case/"case.json");cols=load(case/"public/declaration.json")["targets"]
 fields,d=read_csv(case/"public/repair_dirty.csv");_,truth=read_csv(case/"private/repair_reference.csv")
 if len(d)!=len(truth) or any(a["entity_id"]!=b["entity_id"] for a,b in zip(d,truth)):raise ValueError("Reference alignment")
 rowkeys=load(case/"private/repair_rowkeys.json")["row_keys"]
 if len(rowkeys)!=len(d):raise ValueError("Row metadata mismatch")
 annotations=load(case/"private/error_annotations.json")["cells"]
 tags={(x["row_key"],x["field"]):x["mechanism"] for x in annotations if x["zone"]=="repair"}
 if len(tags)!=sum(not equal(a[c],t[c]) for a,t in zip(d,truth) for c in cols if t.get(c,"")!=""):raise ValueError("Constructed error labels/count mismatch")
 result=[];examples=[]
 for arm in arms:
  _,rows=read_csv(case/"outputs"/arm/"repair_output.csv")
  if len(rows)!=len(d) or any(a["entity_id"]!=b["entity_id"] for a,b in zip(d,rows)):raise ValueError("Method alignment")
  item={**cfg,"arm":arm,"repair":repair_metrics(d,rows,truth,cols),"downstream":None,"receipt":load(case/"outputs"/arm/"receipt.json")}
  if meta["task"]!="repair_only":
   import prediction,catalog
   catalog.XGB_PARAMETERS["random_state"]=cfg["seed"];prediction.XGB_PARAMETERS["random_state"]=cfg["seed"]
   _,held=read_csv(case/"private/holdout_reference.csv")
   item["downstream"]=prediction.evaluate_frames(prediction.frame(rows,cols),[t["class"] for t in truth],prediction.frame(held,cols),[t["class"] for t in held],meta["task"],meta["categorical_columns"])
  item["by_field"]={c:repair_metrics(d,rows,truth,[c]) for c in cols}
  strata=collections.defaultdict(lambda:{"errors":0,"edits":0,"exact":0})
  for i,(a,b,t) in enumerate(zip(d,rows,truth)):
   for col in cols:
    kind=tags.get((rowkeys[i],col))
    if kind is None:continue
    if equal(a[col],t[col]) or t[col]=="":raise ValueError("False constructed error annotation")
    strata[kind]["errors"]+=1;strata[kind]["edits"]+=not equal(a[col],b[col])
    strata[kind]["exact"]+=not equal(a[col],b[col]) and equal(b[col],t[col])
  for x in strata.values():x["exact_repair_recall"]=x["exact"]/x["errors"] if x["errors"] else None
  item["by_constructed_mechanism"]=dict(strata)
  result.append(item)
  # All error counts used for quantitative output; a deterministic small case-study sample is descriptive only.
  if arm in ["full","no_final_gate","no_llm"]:
   for i,(a,b,t) in enumerate(zip(d,rows,truth)):
    for c in cols:
     if t.get(c,"")=="" or equal(a[c],b[c]):continue
     kind="correct" if equal(b[c],t[c]) else "normal_damage" if equal(a[c],t[c]) else "wrong_repair"
     if sum(x["arm"]==arm and x["kind"]==kind for x in examples)>=3:continue
     examples.append({"arm":arm,"kind":kind,"row":i,"field":c,"before":a[c],"after":b[c],"reference":t[c]})
 save(case/"scores.json",result);save(case/"case_studies.json",examples);save(case/"status/scored.json",{"at":time.time(),"rows":len(result)})
 return result
def main():
 if not (ROOT/"status/all_model_outputs_closed.json").exists():raise ValueError("Global output closure required")
 if not load(ROOT/"audit/all_outputs_ready_integrity.json")["passed"]:raise ValueError("Independent integrity audit missing")
 results=[]
 for ident in load(ROOT/"configs/semantic_cases.json"):
  case=ROOT/"cases"/ident
  if (case/"status/scored.json").exists():results+=load(case/"scores.json")
  else:results+=score_case(case)
 save(ROOT/"reports/all_scores.json",results)
 from report_semantic import build
 build(results)
 save(ROOT/"status/scoring_complete.json",{"at":time.time(),"rows":len(results)})
if __name__=="__main__":main()
