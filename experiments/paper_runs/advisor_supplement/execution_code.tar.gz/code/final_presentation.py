"""独立交付展示调整：保留所有分数与原冻结入口，仅调整xlsx阅读布局和增加解释。"""
from pathlib import Path
import sys,json,hashlib,math,time,html,unicodedata,shutil
ROOT=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021")
sys.path[:0]=[str(ROOT/"dependencies")]
from openpyxl import load_workbook
from openpyxl.styles import Font,Alignment,PatternFill
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def width(v):return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in str(v))
def main():
    review=load(ROOT/"audit/final_independent_delivery_review.json")
    assert review["passed"]
    path=ROOT/"reports/EvidForge_导师补充实验汇总.xlsx"
    raw=ROOT/"reports/all_scores.json";raw_sha=sha(raw)
    before_sha=sha(path)
    backup=ROOT/"audit/workbook_before_final_presentation.xlsx"
    with backup.open("xb") as out:
        with path.open("rb") as src:shutil.copyfileobj(src,out)
    wb=load_workbook(path)
    before={(s.title,c.coordinate):c.value for s in wb for row in s for c in row if c.value is not None}
    allowed={}
    core=wb["核心对照"]
    core["A2"]="各区块指标不同；均值与样本SD分列，须结合区块标题和资格说明阅读。"
    core["A2"].font=Font(name="Arial",size=10,color="526172")
    core.freeze_panes="B3"
    for row in core:
        for c in row:
            if isinstance(c.value,(int,float)) and not isinstance(c.value,bool) and c.row<42:c.number_format="0.000"
        a=row[0]
        if isinstance(a.value,str) and a.value.startswith("独立外部校验合格的种子数"):
            allowed[(core.title,a.coordinate)]="所用学习技能的外校合格种子数（非对各消融输出重新认证）"
            a.value=allowed[(core.title,a.coordinate)]
    note_start=core.max_row+2
    extra=[
        "Flights：固定精确字符串口径下3seed均未编辑、F1=0；可评分正常格计数均0，所以误改率和检测AUC为N/A。",
        "公开教学例11:25 AM与11:25 a.m.表示同一时刻，但原字符串口径视为不同；未事后新增时间归一化或改变评分。",
        "B/C/D等复用完整学习技能的条件，资格栏引用该技能的外校结果；没有额外对各消融输出做部署资格认证。",
        "主消融中完全不使用LLM在Car/Hospital/Flights与完整相同，Concrete增益较小；不据此宣称每个组件都有明显贡献。",
    ]
    for i,note in enumerate(extra,note_start):core.cell(i,1,note)
    for row in core:
        a=row[0]
        if a.value is not None and all(c.value is None for c in row[1:]):
            core.merge_cells(start_row=a.row,start_column=1,end_row=a.row,end_column=9)
            a.alignment=Alignment(vertical="center",wrap_text=True)
            core.row_dimensions[a.row].height=34 if a.row>=note_start or a.row>=55 else 29
    core.sheet_view.zoomScale=90
    insight=wb.create_sheet("结果解读",1)
    insight.append(["导师补充实验：结果与边界"])
    insight.append(["问题","观察到的结果","使用边界"])
    rows=[
        ["实验是否完成","66个预定case均已闭合并一次评分：57成功运行、9个原保护拒绝；294条逐种子指标。","9个源NA和5个TabClean受限适配失败保留，失败不记0；不修改分区或重新污染。"],
        ["学得纠错变换","关闭后Car修复F1由0.657降为0.456，Concrete由0.463降为0.153。","对应配对均值/样本SD和下游效果见主消融、同种子配对差值；不能把各模块损失相加。"],
        ["最终置信门槛","Concrete去门槛后F1由0.463升为0.505，但正常误改由0.231%升为4.975%，下游R²由0.778降为0.676。","说明修复覆盖与正常值保护的取舍；不能只凭修复F1声称去门槛更差或完整系统全胜。"],
        ["LLM与源内反馈","主消融中零LLM在Car/Hospital/Flights与完整相同，Concrete F1为0.443对0.463；反馈关闭的差异也很小。","当前证据不支持将其写成跨表稳定的大幅收益；不删除相同或反向结果。"],
        ["跨字段预测证据","移除后的结果有正有负，例如Car下游宏F1提高。","不包装成稳定增益。"],
        ["自然脏表Flights","完整系统三个种子均未编辑，精确修复F1为0；按固定口径正常格数量均0。","误改率和检测AUC不可定义；时间字符串格式差异也算不一致，不能解读为所有航班事实均错误。"],
        ["独立外校资格","完整学习技能通过数：Car1/3、Concrete2/3、Hospital1/3、Flights0/3。","未通过者为预定研究prior回退；复用完整技能的消融不视为重新获得资格，不能称全部可自动部署。"],
        ["TabClean","官方图在同9B和8192输出预算下适配，全部真实调用保留；部分真实输出耗尽预算。","不是原GPT配置完整复现。Car/ Hospital有效，Concrete三seed均N/A，Flights仅1/3有效且不报伪三seed均值。"],
        ["鲁棒性缺失","Car的10%混合、30%blank、30%digit各三seed触发原重复观测保护。","这是运行适用性边界，9case均按N/A保留，不填0、删行、改分区。"],
        ["效率与复用","162个真实原生学习阶段、810次native模型调用；全部模型调用共983次（包括TabClean）。","复用在57个可用case中零新增调用且输出字节一致；NoLLM共享pre-native拟合，不能冒独立冷训练加速。"],
        ["硬件与计时","每case各条件固定相同硬件，三seed包含A100 TP1/4090 TP2。","跨seed SD也含设备差异；按硬件分开报告耗时。Flights1013原基础拟合完整墙钟未保存，完整阶段和记N/A。"],
        ["样例与门槛","原定样例数量、门槛偏移、污染率和单类错误条件全部保留。","各表均为3seed等权均值与样本SD(ddof=1)，缺失保留有效seed数；三seed不作显著性结论。"],
        ["文件与旧结果","新数据和全部日志/失败/代码在本服务器项目；原表1/2及旧九份scores SHA保持。","本轮没有修改论文和GitHub。原始JSON辅助表可在单元格编辑栏查看全文。"],
    ]
    for row in rows:insight.append(row)
    insight.freeze_panes="B3";insight.sheet_view.showGridLines=False
    for c,w in [("A",26),("B",85),("C",90)]:insight.column_dimensions[c].width=w
    insight.merge_cells("A1:C1");insight["A1"].font=Font(name="Arial",size=14,bold=True);insight.row_dimensions[1].height=29
    for c in insight[2]:c.fill=PatternFill("solid",fgColor="245D87");c.font=Font(name="Arial",bold=True,color="FFFFFF")
    for row in insight.iter_rows(min_row=3):
        for c in row:c.alignment=Alignment(vertical="top",wrap_text=True);c.font=Font(name="Arial",size=10)
        insight.row_dimensions[row[0].row].height=66
    reader_names=["主消融","真实脏表","样例数量","污染鲁棒性","置信门槛","TabClean对照","同种子配对差值","效率与复用","教学候选覆盖","开关影响格数","典型案例"]
    qualification_note="复用完整学习技能的消融引用完整技能的资格结果；非对该消融输出的重新部署资格认证。"
    for name in reader_names:
        s=wb[name];s.sheet_view.showGridLines=False;s.sheet_view.zoomScale=90
        s.row_dimensions[3].height=43
        for h in s[3]:
            label=str(h.value or "")
            w=16
            if label=="case":w=60
            elif label=="数据集":w=23
            elif label in ["条件","类型"]:w=33
            elif label in ["说明","范围","计时说明"]:w=72
            elif label=="状态" or label=="执行状态":w=32
            elif label=="硬件":w=28
            elif label=="实验":w=16
            elif label=="独立外校合格seed数":w=25;h.comment=Comment(qualification_note,"EvidForge QA")
            s.column_dimensions[h.column_letter].width=w;h.alignment=Alignment(wrap_text=True,vertical="center")
        for row in s.iter_rows(min_row=4):
            height=23
            for c in row:
                c.alignment=Alignment(wrap_text=isinstance(c.value,str),vertical="center",horizontal="right" if isinstance(c.value,(int,float)) else "left")
                if isinstance(c.value,str):
                    w=s.column_dimensions[c.column_letter].width
                    lines=max(1,math.ceil(width(c.value)/max(8,w-2)))
                    height=max(height,min(120,lines*14+7))
            s.row_dimensions[row[0].row].height=height
        if name=="开关影响格数":
            headers={x.value:x.column for x in s[3]}
            for row in s.iter_rows(min_row=4):
                diff=row[headers["与完整输出不同格数"]-1]
                status=row[headers["状态"]-1]
                if isinstance(diff.value,(int,float)) and status.value=="N/A":
                    status.value="有效闭合";allowed[(s.title,status.coordinate)]="有效闭合"
    wb.active=0
    wb.save(path)
    after=load_workbook(path,data_only=True)
    existing_checked=0
    for (name,coord),expected in before.items():
        if (name,coord) in allowed:expected=allowed[(name,coord)]
        actual=after[name][coord].value
        if isinstance(expected,(int,float)) and not isinstance(expected,bool):
            assert isinstance(actual,(int,float)) and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-12),(name,coord)
        else:assert actual==expected,(name,coord)
        existing_checked+=1
    assert sha(raw)==raw_sha
    def formatted(c):
        v=c.value
        if v is None:return ""
        if isinstance(v,bool):return "是" if v else "否"
        if isinstance(v,(int,float)) and "0.000" in c.number_format:return f"{v:.3f}"
        return str(v)
    body=["<!doctype html><meta charset=utf-8><style>body{font:14px Arial,'Microsoft YaHei',sans-serif;color:#203047;margin:24px}h2{margin-top:35px}.scroll{overflow:auto;max-height:720px;border:1px solid #d7e0e8}table{border-collapse:collapse}td{padding:7px 10px;border-bottom:1px solid #dce3e9;min-width:95px;max-width:650px;white-space:normal;overflow-wrap:anywhere;vertical-align:top}td:first-child{min-width:230px;background:#f1f6fa}tr:nth-child(even){background:#f7fafc}</style><h1>最终Excel内容预览</h1><p>从保存后的工作簿读取；数值按单元格格式显示。此页不是Excel应用截图，服务器无原生Excel渲染器。</p>"]
    for name in ["核心对照","结果解读"]+reader_names:
        s=after[name];body.append("<h2>"+html.escape(name)+"</h2><div class=scroll><table>")
        merged={}
        skipped=set()
        for rg in s.merged_cells.ranges:
            merged[(rg.min_row,rg.min_col)]=(rg.max_col-rg.min_col+1,rg.max_row-rg.min_row+1)
            for rr in range(rg.min_row,rg.max_row+1):
                for cc in range(rg.min_col,rg.max_col+1):
                    if (rr,cc)!=(rg.min_row,rg.min_col):skipped.add((rr,cc))
        for row in s:
            body.append("<tr>")
            for c in row:
                if (c.row,c.column) in skipped:continue
                span=merged.get((c.row,c.column),(1,1))
                body.append("<td colspan="+str(span[0])+" rowspan="+str(span[1])+">"+html.escape(formatted(c))+"</td>")
            body.append("</tr>")
        body.append("</table></div>")
    (ROOT/"reports/Excel最终内容预览.html").write_text("".join(body))
    notes="# 交付说明与结论\n\n本轮66个预定case均已闭合并完成一次正式评分：57个成功运行，9个原保护拒绝按N/A保留；共294条逐种子记录。三种子为1013/1014/1015，均值等权，样本SD的ddof=1。所有预定条件、原失败、真实调用、配对统计、参数/鲁棒性数据均在Excel和JSON。\n\n"
    for issue,fact,limit in rows:notes+="## "+issue+"\n\n"+fact+" "+limit+"\n\n"
    notes+="完整Excel：\n\n"+str(path)+"\n\n统计与数据复核：audit/final_independent_delivery_review.json。资源审计：audit/resources_final_a100.json、audit/resources_final_rtx4090.json。最终工作簿SHA以audit/final_presentation_qa.json为准；之前的reader/compact SHA是保留的历史导出值。HTML仅保存内容预览，不冒原生Excel截图。\n"
    (ROOT/"reports/交付说明与结论.md").write_text(notes)
    out={"at":time.time(),"passed":True,"previous_workbook_sha":before_sha,"final_workbook_sha":sha(path),"all_scores_sha_unchanged":raw_sha,"original_nonempty_cells_checked":existing_checked,"presentation_text_cells_amended":len(allowed),"all_original_numerical_cell_values_preserved":True,"freeze_panes":"B3","notes_merged_wrapped":True,"preview_float_format_matches_saved_cells":True,"preview":"reports/Excel最终内容预览.html","native_excel_renderer_unavailable":True,"raw_formal_reads":0,"scoring_repeated":False}
    (ROOT/"audit/final_presentation_qa.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n")
    (ROOT/"status/delivery_finalqa_ready.json").write_text(json.dumps({"at":time.time(),"workbook":str(path),"qa":"audit/final_presentation_qa.json","interpretation":"reports/交付说明与结论.md","independent_review":"audit/final_independent_delivery_review.json"},ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(out,ensure_ascii=False))
if __name__=="__main__":main()
