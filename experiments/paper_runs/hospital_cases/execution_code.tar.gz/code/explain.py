from pathlib import Path
import os,sys,json,hashlib
os.environ['EF_SEED']='1015';os.environ['EF_ARM']='full';sys.dont_write_bytecode=True
R=Path('/root/fsas/home/anonymous/projects/EvidForge_TabClean_CaseStudy_20261022');A=R.parent/'EvidForge_Advisor_Study_20261021';sys.path.insert(0,str(A/'code'))
from common import load,sha,read_csv
D=load(R/'audit/selected_evidence.json');C=Path(D['source_case']);skill=Path(D['skill'])
from runtime_v4 import install
install()
from skill_runtime.package import open_skill
from unseen_table.rank_candidates import predict_rows
from unseen_table.validate_skill import region,permitted
_,fitted,codec,family,policy=open_skill(skill/'base_skill')
assert not fitted.get('source_consensus'),'Batch-sensitive source context; review full-batch explanation first'
rows=read_csv(C/'public/repair_dirty.csv')[1];decisions=load(C/'outputs/full/decisions.json');ex=[]
for item in D['examples']:
 i,k=item['row'],item['field'];cell=next(c for c in predict_rows([rows[i]],fitted) if c['column']==k)
 p=fitted['policy'];reg=region(cell);gate=p if 'confidence_threshold' in p else p.get('by_region',{}).get(reg,p if 'score_threshold' in p else {})
 frozen=next(c for c in decisions if c['row']==i and c['field']==k)
 rids=set(cell['top'].get('rule_ids',[]));matched=[]
 for field in ['rules','relations']:
  for rule in fitted.get(field,[]):
   if rule.get('id') in rids:matched.append(dict(family=field,rule=rule))
 v=dict(id=item['id'],row=i+1,field=k,top=cell['top'],options=sorted(cell['options'],key=lambda c:-c['score']),margin=cell['margin'],region=reg,policy=gate,permitted=permitted(cell,p),tied=cell.get('tied'),repair_confidence=cell.get('repair_confidence'),reference_in_candidates=any(c['value']==item['reference'] for c in cell['options']),decision=frozen,matched_rules=matched)
 # Compare explanation to real final artifacts, not an invented replay.
 assert (cell['top']['value'] if v['permitted'] else rows[i][k])==item['outputs']['full'],(item['id'],cell['top'],v['permitted'],frozen)
 ex.append(v)
for path,h in D['source_sha'].items():assert sha(path)==h
(R/'audit/mechanism_explanation.json').write_text(json.dumps(dict(examples=ex,new_fit=False,new_scoring=False,model_calls=0,raw_reference_reads=0,all_source_hashes_unchanged=True),ensure_ascii=False,indent=2)+'\n')
for e in ex:print(json.dumps({k:v for k,v in e.items() if k not in ['options','matched_rules']},ensure_ascii=False))
for e in ex:print('RULES',e['id'],json.dumps(e['matched_rules'],ensure_ascii=False)[:6000])
