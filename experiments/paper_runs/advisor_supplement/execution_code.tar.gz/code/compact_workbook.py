"""固定评分和独立复核后，仅增加紧凑的Excel首屏；无模型/修复/正式参考读取。"""
from pathlib import Path
import os,time,math,traceback,html
from common import ROOT,load,save,sha
import sys
sys.path[:0]=[str(ROOT/"dependencies")]
from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from reader_postprocess_v3 import ARMS
DATASETS=[("main","car_evaluation","Car（分类）"),("main","concrete","Concrete（回归）"),("natural","hospital","Hospital"),("natural","flights","Flights")]
CONDITIONS=["full","no_transforms","no_generated_execution","no_final_gate","no_feedback","no_predictive_context","no_llm","reuse","tabclean"]
def build():
    path=ROOT/"reports/EvidForge_导师补充实验汇总.xlsx"
    raw_sha=sha(ROOT/"reports/all_scores.json");before=sha(path)
    aggregate=load(ROOT/"reports/independent_aggregate_review.json")
    lookup={(a["suite"],a["dataset"],a["arm"]):a for a in aggregate if a["suite"] in ["main","natural"]}
    wb=load_workbook(path)
    if "核心对照" in wb.sheetnames:raise ValueError("Compact sheet already exists; inspect before a second write")
    ws=wb.create_sheet("核心对照",0);ws.sheet_view.showGridLines=False
    ws["A1"]="EvidForge 导师补充实验（三种子）";ws["A1"].font=Font(name="Arial",size=14,bold=True)
    ws.row_dimensions[1].height=27
    ws.column_dimensions["A"].width=33
    for letter in "BCDEFGHI":ws.column_dimensions[letter].width=16
    tests=[];row=3
    def text(c):
        return ARMS.get(c,c)
    def number(cell,value):
        cell.value=value;cell.font=Font(name="Arial",size=10)
        cell.alignment=Alignment(horizontal="right" if isinstance(value,(int,float)) or str(value).startswith("N/A") else "left",vertical="center")
        if isinstance(value,float):cell.number_format="0.000"
        elif isinstance(value,int):cell.number_format="0"
    def section(title,columns):
        nonlocal row
        ws.cell(row,1,title).font=Font(name="Arial",size=11,bold=True)
        ws.row_dimensions[row].height=25;row+=1
        for j,label in enumerate(columns,1):
            c=ws.cell(row,j,label);c.font=Font(name="Arial",size=10,bold=True,color="FFFFFF")
            c.fill=PatternFill("solid",fgColor="245D87");c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        ws.row_dimensions[row].height=29;row+=1
    columns=["设置"]
    for _,_,label in DATASETS:columns.extend([label+"均值","SD"])
    for title,metric,multiplier in [("准确修复 F1（越高越好）","F1",1),("正常格误改率（%，越低越好；SD为百分点）","normal_damage",100)]:
        section(title,columns)
        for arm in CONDITIONS:
            number(ws.cell(row,1),text(arm))
            for i,(suite,dataset,label) in enumerate(DATASETS):
                value=lookup[(suite,dataset,arm)][metric]
                for offset,key in enumerate(["mean","sd"]):
                    c=ws.cell(row,2+i*2+offset)
                    v=None if value[key] is None else value[key]*multiplier
                    number(c,v if v is not None else "N/A("+str(value["n"])+"/3)")
                    tests.append((c.coordinate,v if v is not None else "N/A("+str(value["n"])+"/3)"))
            ws.row_dimensions[row].height=22;row+=1
        row+=2
    section("下游效用（Car为宏F1，Concrete为R²，越高越好）",["设置","Car宏F1均值","SD","Concrete R²均值","SD"])
    for arm in CONDITIONS:
        number(ws.cell(row,1),text(arm))
        for i,(dataset,metric) in enumerate([("car_evaluation","macro_F1"),("concrete","R2")]):
            s=lookup[("main",dataset,arm)][metric]
            for offset,key in enumerate(["mean","sd"]):
                c=ws.cell(row,2+i*2+offset);v=s[key] if s[key] is not None else "N/A("+str(s["n"])+"/3)"
                number(c,v);tests.append((c.coordinate,v))
        ws.row_dimensions[row].height=22;row+=1
    row+=2
    section("独立外部校验合格的种子数（每列共3个；不足3个的其余项为研究回退）",["设置",*[x[2] for x in DATASETS]])
    for arm in CONDITIONS:
        number(ws.cell(row,1),text(arm))
        for i,(suite,dataset,label) in enumerate(DATASETS,2):
            if arm=="tabclean":number(ws.cell(row,i),"不适用");continue
            source_arm=arm if arm in ["no_llm","no_feedback","no_predictive_context"] else "full"
            paths=[ROOT/"cases"/f"{suite}_{dataset}_s{seed}"/"work"/source_arm/"selection.json" for seed in [1013,1014,1015]]
            value=sum(load(p)["passed"] for p in paths) if all(p.exists() for p in paths) else "N/A"
            number(ws.cell(row,i),value)
        ws.row_dimensions[row].height=22;row+=1
    row+=2
    notes=[
        "均值与样本标准差由1013、1014、1015三个种子等权计算（ddof=1）；N/A保留有效seed数，不填0。",
        "各case内所有方法使用同一设备；跨seed包含A100 TP1与RTX4090 TP2，SD也含执行设备差异。",
        "Hospital、Flights未额外污染，分别按20/10/15与20/10/70实体组划分；它们只评估修复。",
        "Car部分鲁棒条件触发原重复观测保护而N/A，原失败证据保留在原始记录；没有重新分区或删行。",
        "TabClean为官方流程的同9B适配；输出预算超限的实际失败为N/A，不能当成原GPT方法的零分。",
        "复用技能与完整输出逐字节一致，零新增模型调用；调用/token/分硬件耗时见效率与复用表。",
    ]
    for note in notes:
        ws.cell(row,1,note).font=Font(name="Arial",size=10,color="44505B")
        ws.row_dimensions[row].height=23;row+=1
    ws.freeze_panes="B5";ws.sheet_properties.tabColor="173E5D";wb.active=0
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation="landscape";ws.page_setup.paperSize=ws.PAPERSIZE_A3;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
    ws.print_options.horizontalCentered=True;ws.print_area=f"A1:I{row-1}"
    # Short labels in the reader-facing coverage view; full reasons remain in frozen JSON/raw sheets.
    coverage=wb["教学候选覆盖"]
    headers={c.value:c.column for c in coverage[3]}
    if "范围" in headers:
        for rr in range(4,coverage.max_row+1):
            c=coverage.cell(rr,headers["范围"])
            if isinstance(c.value,str) and c.value.startswith("N/A，尚未拟合"):
                c.value="N/A：源内重复观测保护拒绝，详见原失败记录"
    wb.save(path)
    after=load_workbook(path,data_only=True)
    for coordinate,expected in tests:
        actual=after["核心对照"][coordinate].value
        if isinstance(expected,float):
            if actual is None or not math.isclose(actual,expected,abs_tol=1e-12,rel_tol=1e-12):raise ValueError("Displayed value mismatch "+coordinate)
        elif actual!=expected:raise ValueError("Displayed missing/typed value mismatch "+coordinate)
    assert sha(ROOT/"reports/all_scores.json")==raw_sha
    # Preview is explicitly content rendered from saved cells, not an Excel-app screenshot.
    body=[]
    for cells in after["核心对照"].iter_rows():
        body.append("<tr>"+"".join("<td>"+html.escape(str(c.value if c.value is not None else ""))+"</td>" for c in cells)+"</tr>")
    (ROOT/"reports/核心对照预览.html").write_text("<!doctype html><meta charset=utf-8><style>body{font:14px Arial,sans-serif;margin:24px;color:#192530}table{border-collapse:collapse}td{padding:7px 12px;white-space:nowrap;border-bottom:1px solid #ddd}</style><h1>核心对照</h1><p>最终Excel内容预览；均值和SD分列。不是Excel应用截图。</p><table>"+"".join(body)+"</table>")
    save(ROOT/"audit/compact_workbook_qa.json",{"at":time.time(),"previous_workbook_sha":before,"final_workbook_sha":sha(path),"raw_score_sha_unchanged":raw_sha,"numeric_or_NA_cells_checked":len(tests),"no_raw_formal_reads":True,"native_renderer_unavailable":True,"scope":"reader presentation only; all numerical scores unchanged"})
    save(ROOT/"status/delivery_compact_ready.json",{"at":time.time(),"workbook":str(path),"resource_and_interpretation_review_still_required":True})
if __name__=="__main__":
    save(ROOT/"status/compact_watcher_owner.json",{"pid":os.getpid(),"at":time.time()})
    try:
        while not (ROOT/"status/delivery_ready.json").exists():time.sleep(30)
        build()
    except Exception as e:
        save(ROOT/"status/compact_watcher_error.json",{"at":time.time(),"error":repr(e),"traceback":traceback.format_exc()})
        raise
