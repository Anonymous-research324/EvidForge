
"""Read-only real process and freeze monitor; no restart, no scoring."""
from pathlib import Path
import time,os
from common import ROOT,load,save,sha
def main():
 from audit_reuse import fixed
 fixed()
 out={"at":time.time(),"cases":[],"native_sessions":0,"calls":0,"responses":0,"failures":[],"controller":None,"formal_markers":0}
 p=ROOT/"status/controller_owner.json"
 if p.exists():
  owner=load(p);cmd=Path("/proc")/str(owner["pid"])/"cmdline";out["controller"]={**owner,"alive":cmd.exists() and b"controller_reuse.py" in cmd.read_bytes()}
 for n in load(ROOT/"configs/cases.json"):
  c=ROOT/"cases"/n
  out["cases"].append({"name":n,"learning_closed":(c/"status/learning_closed.json").exists(),"outputs_closed":(c/"status/outputs_closed.json").exists(),"scored":(c/"status/scored.json").exists()})
  out["failures"] += [str(x.relative_to(ROOT)) for x in (c/"status").glob("*failure*.json")]
  out["formal_markers"]+=(c/"audit/scoring_started.json").exists()
  for p in (c/"work").glob("*/*_stage/native_v3/result.json"):
   x=load(p);out["native_sessions"]+=1;out["calls"]+=x["real9B_calls"]
 for p in (ROOT/"services").glob("gpu*/requests/*/response.json"):out["responses"]+=1
 out["inflight_requests"]=len(list((ROOT/"services").glob("gpu*/requests/*/request.json")))-out["responses"]
 for n in ["controller_error.json","run_complete.json","reports_ready.json"]:
  if (ROOT/"status"/n).exists():out[n]=load(ROOT/"status"/n)
 save(ROOT/"status/supervisor_snapshot.json",out)
 print(__import__("json").dumps(out,ensure_ascii=False))
if __name__=="__main__":main()
