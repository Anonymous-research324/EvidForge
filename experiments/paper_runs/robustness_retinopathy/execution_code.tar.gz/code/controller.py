"""Single RTX host controller, owned physical5/7 services and no automatic retries."""
from pathlib import Path
import os,time,subprocess,socket,concurrent.futures,traceback,fcntl,threading
from common import ROOT,PY,load,save,sha
def run(entry,args,log,env):
 with Path(log).open("x") as f:return subprocess.run([PY,"-B",str(ROOT/"code"/entry),*map(str,args)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
def main():
 lock=(ROOT/"status/controller.lock").open("a");fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (ROOT/"status/owner.json").exists():raise RuntimeError("Owner exists; inspect instead of restart")
 save(ROOT/"status/owner.json",{"pid":os.getpid(),"host":socket.gethostname(),"started":time.time(),"physical_devices":{"0":"5","1":"7"},"scope":"24 Retinopathy robustness cases"})
 for rel,h in load(ROOT/"audit/execution_freeze.json")["files"].items():assert sha(ROOT/rel)==h
 assert (ROOT/"audit/all_source_guards_pass.json").exists() and (ROOT/"audit/preflight_pass.json").exists()
 names=load(ROOT/"configs/cases.json");assigned=load(ROOT/"configs/lane_assignment.json")
 results={};mu=threading.Lock()
 def lane(gpu):
  env={**os.environ,"EF_GPU":str(gpu),"EF_DEVICES":"5" if gpu==0 else "7","EF_SEED":"1013","OPENBLAS_NUM_THREADS":"2","OMP_NUM_THREADS":"2","MKL_NUM_THREADS":"2","PYTHONDONTWRITEBYTECODE":"1"}
  rc=run("model_service.py",["start"],ROOT/"logs"/("start_gpu"+str(gpu)+".log"),env)
  if rc:raise RuntimeError("Model service start failed; inspect owner/log, do not duplicate")
  tasks=[n for n in names if assigned[n]==gpu]
  for i,n in enumerate(tasks):
   case=ROOT/"cases"/n
   save(ROOT/"status"/("gpu"+str(gpu)+"_progress.json"),{"case":n,"attempted":i,"total":len(tasks),"phase":"source/native/standalone","at":time.time()})
   rc=run("worker_v4.py",["case","--case",case,"--gpu",gpu],ROOT/"logs"/(n+"_worker.log"),env)
   with mu:
    results[n]={"returncode":rc,"gpu":gpu,"at":time.time()}
    save(ROOT/"status/outcomes.json",results)
    save(ROOT/"status/overview.json",{"attempted":len(results),"total":len(names),"failures":sum(x["returncode"]!=0 for x in results.values()),"at":time.time()})
  save(ROOT/"status"/("gpu"+str(gpu)+"_progress.json"),{"attempted":len(tasks),"total":len(tasks),"phase":"queue_complete","at":time.time()})
 with concurrent.futures.ThreadPoolExecutor(2) as pool:
  futures=[pool.submit(lane,g) for g in [0,1]]
  for f in futures:f.result()
 if any(x["returncode"] for x in results.values()):
  save(ROOT/"status/needs_review.json",{"failures":{k:v for k,v in results.items() if v["returncode"]},"scoring_blocked":True,"no_auto_retry":True});return
 rc=run("audit_ready.py",[],ROOT/"logs/audit_ready.log",dict(os.environ))
 if rc:raise RuntimeError("Pre-scoring audit failed")
 save(ROOT/"status/all_model_outputs_closed.json",{"at":time.time(),"cases":len(names),"outputs":72})
 for gpu in [0,1]:
  rc=run("model_service.py",["stop"],ROOT/"logs"/("stop_gpu"+str(gpu)+".log"),{**os.environ,"EF_GPU":str(gpu)})
  if rc:raise RuntimeError("Owned cleanup failed")
 rc=run("score.py",[],ROOT/"logs/independent_scoring.log",{**os.environ,"OPENBLAS_NUM_THREADS":"2","OMP_NUM_THREADS":"2"})
 if rc:raise RuntimeError("Once-only scoring failed; preserve all markers")
 save(ROOT/"status/complete.json",{"at":time.time(),"cases":len(names),"all72_outputs_scored":True,"resource_and_visual_review_pending":True})
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/controller_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
