"""Explicit source-only AutoGluon internal-validation IO bridge.
Only an all-singleton classifier trainfold uses itself for model selection;
conformal calibration remains disjoint. This is an optimistic CPU adapter,
not independent internal holdout validation. No learning algorithm is replaced.
"""
import hashlib
from sklearn.model_selection import GroupShuffleSplit

def frame_hash(frame):
    return hashlib.sha256(frame.to_json(orient='split',force_ascii=False).encode()).hexdigest()

def install(native_ag,source_frame,group_ids,seed,audit_sink):
    tr,ca=next(GroupShuffleSplit(n_splits=1,test_size=.4,random_state=seed).split(source_frame,groups=group_ids))
    train=source_frame.iloc[tr];cal=source_frame.iloc[ca]
    expected=frame_hash(train);calhash=frame_hash(cal)
    original=native_ag.TabularPredictor.fit
    def fit(predictor,train_data,*args,**kwargs):
        actual=frame_hash(train_data)
        assert actual==expected,'CDC may train on the fixed source TRAIN fold only'
        assert not set(train_data.index)&set(cal.index),'Conformal calibration leaked into fit'
        target=predictor.label
        counts=train_data[target].value_counts(dropna=False)
        eligible=predictor.problem_type in ('multiclass','binary') and len(counts)>1 and bool((counts==1).all())
        assert 'tuning_data' not in kwargs,'Unexpected upstream tuning input'
        if eligible:kwargs['tuning_data']=train_data.copy()
        audit_sink({'field':target,'train_rows':len(train_data),'calibration_rows':len(cal),'train_sha256':actual,'calibration_sha256':calhash,'train_calibration_disjoint':True,'all_singleton_classifier':eligible,'tuning_data_origin':'same TRAIN fold only; optimistic model selection, not independent holdout' if eligible else 'original internal holdout .5','external_validation_read':False,'formal_reference_read':False,'numeric_hyperparameters_changed':False})
        return original(predictor,train_data,*args,**kwargs)
    native_ag.TabularPredictor.fit=fit
    return {'train_indices':list(map(int,tr)),'calibration_indices':list(map(int,ca)),'train_sha256':expected,'calibration_sha256':calhash}
