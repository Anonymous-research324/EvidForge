import os,time,subprocess,traceback
from common import ROOT,PY,save,read,sha
def main():
 save(ROOT/"status/presentation_owner.json",{"pid":os.getpid(),"started":time.time()},once=True)
 while not (ROOT/"status/scoring_complete.json").exists():
  if any((ROOT/"status"/n).exists() for n in ["controller_error.json","needs_review.json"]):
   save(ROOT/"status/presentation_waiting_review.json",{"at":time.time(),"no_scoring_or_render_retry":True},once=True);return
  time.sleep(20)
 frozen=read(ROOT/"audit/presentation_code_freeze.json")
 for rel,h in frozen["files"].items():assert sha(ROOT/rel)==h
 with (ROOT/"logs/presentation.log").open("x") as f:subprocess.run([PY,"-B",str(ROOT/"code/present.py")],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/presentation_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()},once=True);raise
