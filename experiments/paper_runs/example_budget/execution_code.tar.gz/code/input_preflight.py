"""All real-input partitions and count/source boundaries, before model requests."""
from pathlib import Path
import os,sys,json,ast,time,subprocess
from common import ROOT,ENGINE,PY,load,save,sha
def main():
 for p in (ROOT/"code").glob("*.py"):ast.parse(p.read_text())
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ENGINE/rel)==h
 names=load(ROOT/"configs/cases.json");assert len(names)==54
 for name in names:
  case=ROOT/"cases"/name
  for zone in ["public","private"]:
   for rel,h in load(case/"input_freeze.json")[zone].items():assert sha(case/zone/rel)==h
 from runtime import install
 install()
 from unseen_table.common import normalize_bundle,observation_signatures
 from workflow.onboarding import split_learning
 tests={}
 for ident in names:
  case=ROOT/"cases"/ident;meta=load(case/"case.json");b=load(case/"public/development_bundle.json");s=load(case/"public/declaration.json")
  normal,audit=normalize_bundle(b,s)
  inner,_=split_learning(b,s)
  assert len(b["learning"])==len(b["validation"])==meta["learning_groups"]
  assert sum(len(g) for g in [inner["learning"],inner["validation"]])==meta["learning_groups"]
  from common import read_csv
  _,formal=read_csv(case/"public/repair_dirty.csv")
  ids={r["entity_id"] for r in formal};assert len(ids)==60
  for z in normal:
   assert not ids & {r["dirty"]["entity_id"] for r in normal[z]}
   obs=observation_signatures(formal,s["entity_fields"],s.get("source_field"))
   assert not obs & set(audit[z]["signatures"]),"Public formal observation overlaps source: "+ident
  key=(meta["dataset"],meta["seed"])
  if key not in tests:tests[key]={"formal_sha":sha(case/"public/repair_dirty.csv"),"tiers":[],"sources":{}}
  assert tests[key]["formal_sha"]==sha(case/"public/repair_dirty.csv")
  tests[key]["tiers"].append(meta["learning_groups"])
  tests[key]["sources"][meta["learning_groups"]]={z:b[z] for z in b}
 for key,g in tests.items():
  assert sorted(g["tiers"])==[5,10,20]
  for z in ["learning","validation"]:
   for n in [5,10]:assert g["sources"][n][z]==g["sources"][20][z][:n]
 # Child role must deny another tier and formal reference, while own public input remains readable.
 env={**os.environ,"EF_CASE":names[0],"EF_SEED":"1013","PYTHONPATH":str(ROOT/"code"),"OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"}
 child="import runtime;runtime.install()\nfrom pathlib import Path\nr=Path("+repr(str(ROOT))+")\nfor p in [r/'cases'/"+repr(names[1])+"/'public/development_bundle.json',r/'cases'/"+repr(names[0])+"/'private/repair_reference.csv']:\n try:p.read_text()\n except PermissionError:pass\n else:raise AssertionError('Role guard failed')\nprint('CROSS_TIER_AND_FORMAL_DENIAL_PASS')"
 with (ROOT/"logs/role_preflight.log").open("x") as f:proc=subprocess.run([PY,"-B","-c",child],env=env,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
 assert proc.returncode==0
 save(ROOT/"audit/input_preflight_pass.json",{"cases":54,"cohorts":18,"counts_and_nested":True,"formal60_identical_all_tiers":True,"normalization_and_group_guards":True,"cross_tier_and_formal_denial":True,"core124":True,"actual_model_calls":0,"formal_rows_read":0,"at":time.time()})
 print("REAL_INPUT_PREFLIGHT_PASS",flush=True)
if __name__=="__main__":main()
