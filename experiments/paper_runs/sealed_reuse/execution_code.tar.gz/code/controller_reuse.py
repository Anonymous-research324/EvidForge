
"""One owned scheduler: learn once, global model-off barrier, CPU-only batches, score once."""
from pathlib import Path
import os,time,subprocess,socket,traceback,concurrent.futures,json
from common import ROOT,PY,load,save,sha,freeze
def run(cmd,log,env=None):
 with Path(log).open("x") as f:p=subprocess.run(list(map(str,cmd)),cwd=ROOT,env=env or os.environ,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError("Stage failed; preserve log: "+str(log))
def lane(gpu):
 cases=[ROOT/"cases"/n for n in load(ROOT/"configs/cases.json") if load(ROOT/"cases"/n/"case.json")["gpu"]==gpu]
 env={**os.environ,"EF_GPU":str(gpu),"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2"}
 save(ROOT/"status"/("lane"+str(gpu)+".json"),{"phase":"model_start","at":time.time(),"gpu":gpu})
 run([PY,"-B",ROOT/"code/model_service.py","start"],ROOT/"logs"/("service"+str(gpu)+"_start.log"),env)
 failures=[]
 for c in cases:
  save(ROOT/"status"/("lane"+str(gpu)+".json"),{"phase":"learning","case":c.name,"at":time.time(),"gpu":gpu})
  try:run([PY,"-B",ROOT/"code/learn_reuse.py","--case",c],c/"logs/learning_worker.log",env)
  except Exception as e:failures.append({"case":c.name,"error":repr(e)})
 if failures:
  save(ROOT/"status"/("lane"+str(gpu)+"_failures.json"),failures)
  raise RuntimeError("Unknown case failure blocks all repair and scoring; no automatic replay")
 save(ROOT/"status"/("lane"+str(gpu)+".json"),{"phase":"learning_closed","at":time.time(),"gpu":gpu})
 run([PY,"-B",ROOT/"code/model_service.py","stop"],ROOT/"logs"/("service"+str(gpu)+"_stop.log"),env)
 return gpu
def main():
 if (ROOT/"status/controller_owner.json").exists():raise RuntimeError("Inspect existing owner, never duplicate")
 save(ROOT/"status/controller_owner.json",{"pid":os.getpid(),"pgid":os.getpgrp(),"at":time.time(),"script":str(Path(__file__))})
 from audit_reuse import fixed,input_case,requests,resource_snapshot,audit_ready
 fixed()
 assert load(ROOT/"audit/preflight_pass.json")["actual_model_calls"]==0
 assert load(ROOT/"audit/source_isolation_pass.json")["passed"]
 for n in load(ROOT/"configs/cases.json"):input_case(ROOT/"cases"/n)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  outcomes=list(pool.map(lane,[0,1]))
 for n in load(ROOT/"configs/cases.json"):assert (ROOT/"cases"/n/"status/learning_closed.json").exists()
 save(ROOT/"status/learning_all_closed.json",{"at":time.time(),"cases":6})
 # Natural worker shutdown may release CUDA a few seconds after the HTTP port closes.
 for _ in range(60):
  resource=resource_snapshot()
  if not any(v["listening"] for v in resource["ports"].values()) and not any(v["owned_server_alive"] for v in resource["services"].values()) and not resource["compute"]:break
  time.sleep(2)
 else:raise RuntimeError("GPU release barrier not satisfied; do not run any batch")
 save(ROOT/"audit/model_shutdown_resource.json",resource)
 ledger={"requests":requests(),"at":time.time()};assert len(ledger["requests"])==60
 save(ROOT/"audit/requests_at_model_shutdown.json",ledger)
 save(ROOT/"status/inference_disabled.json",{"at":time.time(),"ports":[8141,8142],"requests":60,"request_ledger_sha":sha(ROOT/"audit/requests_at_model_shutdown.json"),"resource_sha":sha(ROOT/"audit/model_shutdown_resource.json")})
 cases=[ROOT/"cases"/n for n in load(ROOT/"configs/cases.json")]
 def cpu(c):run([PY,"-B",ROOT/"code/execute_reuse.py","--case",c],c/"logs/offline_worker.log",{**os.environ,"CUDA_VISIBLE_DEVICES":"","PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2"});return c.name
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:closed=list(pool.map(cpu,cases))
 save(ROOT/"status/all_outputs_closed.json",{"at":time.time(),"cases":closed})
 audit_ready()
 run([PY,"-B",ROOT/"code/score_reuse.py"],ROOT/"logs/scorer.log")
 run([PY,"-B",ROOT/"code/report_reuse.py"],ROOT/"logs/report.log")
 run([PY,"-B",ROOT/"code/final_review_reuse.py"],ROOT/"logs/final_review.log")
 save(ROOT/"status/run_complete.json",{"at":time.time(),"delivered_to_user":False,"needs_visual_QA":True})
if __name__=="__main__":
 try:main()
 except Exception as e:
  save(ROOT/"status/controller_error.json",{"at":time.time(),"error":repr(e),"traceback":traceback.format_exc()});raise
