"""Teaching OOF only; diagnose pool reachability without changing any candidates."""
from pathlib import Path
import collections,time
from common import ROOT,load,save,sha
def audit_prior(case,prior):
    out=case/"teaching_coverage.json"
    if out.exists():return
    from sklearn.model_selection import GroupKFold
    from unseen_table.common import equal
    from unseen_table.rank_candidates import predict_rows
    records=load(prior/"source_records_backend.json")["records"]
    counts=collections.Counter();seven={"affix","scale","shift","mapping","strip","casefold","edit"}
    for fold,(u,v) in enumerate(GroupKFold(3).split(records,groups=[r["group"] for r in records])):
        model=load(prior/"base_skill"/("fold-"+str(fold)+"-model.json"))
        query=[records[int(i)] for i in v];source_groups={records[int(i)]["group"] for i in u}
        from advisor_metadata_v4 import fit_groups
        assert set(fit_groups(model))==source_groups
        cells=predict_rows([r["dirty"] for r in query],model)
        for cell in cells:
            rec=query[cell["row"]];col=cell["column"];truth=rec["truth"][col]
            if truth=="" or equal(rec["dirty"][col],truth):continue
            correct=[q for q in cell["options"] if equal(q["value"],truth)]
            counts["errors"]+=1
            counts["exact_in_base_pool"]+=bool(correct)
            counts["exact_from_seven_single_field_transforms"]+=any(seven.intersection(q["kinds"]) for q in correct)
    frames=load(prior/"backend_only.json")["frames"]
    for f in frames:
        if not f["expected_local_only"] or equal(f["original"],f["expected_local_only"]):continue
        counts["learning_frames_wrong"]+=1
        counts["exact_in_llm_frame_pool"]+=any(equal(q["value"],f["expected_local_only"]) for q in f["options"])
        counts["exact_in_llm_explainable_pool"]+=any(equal(q["value"],f["expected_local_only"]) and q["features"]["forward_explainable"] for q in f["options"])
    save(out,{"counts":dict(counts),"teaching_only":True,"outer_validation_used":False,"formal_reference_rows_read":0,"new_model_calls":0,"no_fit_or_candidate_changes":True,"case":case.name,"at":time.time(),"source_backend_sha":sha(prior/"source_records_backend.json"),"limitation":"Base OOF pools and original prior frames only; no whole-system completeness claim; not selection of formal cells."})
