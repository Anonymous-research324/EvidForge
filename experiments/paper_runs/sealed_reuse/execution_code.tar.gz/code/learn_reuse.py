"""每case完整配对学习与执行；不读取正式参考，失败保留并阻止评分。"""
from pathlib import Path
import argparse,os,sys,subprocess,shutil,time,json,copy
from common import ROOT,ENGINE,PY,load,save,freeze,read_csv,write_csv,status,sha
WRAP=ROOT/"code/ef-python-v4"
def run(cmd,log,env):
 cmd=[str(ROOT/"code/native_v3.py") if str(x)==str(ROOT/"code/native.py") else x for x in cmd]
 log=Path(log);log.parent.mkdir(parents=True,exist_ok=True)
 with log.open("x") as f:r=subprocess.run(list(map(str,cmd)),cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError("Stage failed: "+str(log))
def seal_off(skill):
 cfg=load(skill/"configuration.json");cfg["base_skill_path"]=str((skill/"base_skill").resolve());save(skill/"configuration.json",cfg)
 save(skill/"no_llm_receipt.json",{"actual_calls":0,"generated_program":False,"source_only_fit":True})
 save(skill/"manifest.json",{"files":freeze(skill),"format_version":cfg["format_version"],"status":"pending_independent_validation"})
def native(case,skill,arm,kind,env):
 stage=case/"work"/arm/(kind+"_stage");logs=case/"logs"/arm
 if not stage.exists():run([WRAP,ENGINE/"tools/stage_native.py","--prepared",skill,"--out",stage],logs/(kind+"_stage.log"),env)
 ne={**env,"EVIDFORGE_NATIVE_STAGE":str(stage),"EVIDFORGE_NATIVE_VARIANT":"no_feedback" if arm=="no_feedback" else "full"}
 if arm=="no_feedback":
  st=load(case/"work/full"/(kind+"_stage/work/hypothesis_state.json"));ne["EVIDFORGE_PROPOSAL_TARGET"]=str(st["attempted_proposals"])
 tag=("Reuse"+case.name+arm+kind).replace("_","").replace("-","")
 if not (stage/"native_v3/result.json").exists():
  if (stage/"native_v3").exists():raise RuntimeError("Partial native directory requires per-call review; do not replay")
  run([PY,ROOT/"code/native_v3.py","--work",stage/"work","--out",stage/"native_v3","--codex","/root/fsas/home/anonymous/bin/codex","--remote-helper",ROOT/"code/model_service.py","--tag",tag],logs/(kind+"_native_v3.log"),ne)
 r=load(stage/"native_v3/result.json")
 if not r["closed"] or r["native_exit_code"] or r["synthetic_control_count"]:raise ValueError("Incomplete/nonreal native session")
 if not (skill/"manifest.json").exists():run([WRAP,ENGINE/"tools/seal_skill.py","--skill",skill,"--native",stage/"native_v3"],logs/(kind+"_seal.log"),env)
 return r
def assess(case,skill,kind,arm,env):
 folder=case/"work"/arm/(kind+"_external")
 existing=case/"work"/arm/(kind+"_assessment/assessment.json")
 if existing.exists():return load(existing)
 if (folder/"assessment_started.json").exists():raise RuntimeError("Validation interrupted; fixed-output recovery required")
 folder.mkdir(exist_ok=True)
 onboarding=case/"work"/arm/"onboarding"
 for n in ["heldout_validation_local.json","learning_only_bundle.json","partition_freeze.json","declaration.json","context.json"]:shutil.copyfile(onboarding/n,folder/n)
 log=case/"logs"/arm
 if not (folder/"assessment_freeze.json").exists():run([WRAP,ENGINE/"repair_platform.py","freeze-validation","--workflow",folder,"--skill",skill],log/(kind+"_freeze.log"),env)
 out=case/"work"/arm/(kind+"_assessment")
 run([WRAP,ENGINE/"repair_platform.py","validate","--workflow",folder,"--out",out],log/(kind+"_assessment.log"),env)
 return load(out/"assessment.json")

def learn(case,env):
 t=time.monotonic();arm="full";base=case/"work/full";wf=base/"onboarding";pub=case/"source";logs=case/"logs/full"
 if (case/"status/learning_closed.json").exists():return
 if (case/"status/learning_started.json").exists():raise RuntimeError("Partial learning needs stage-specific review, never whole-case replay")
 save(case/"status/learning_started.json",{"pid":os.getpid(),"at":time.time()})
 base.mkdir(parents=True,exist_ok=True)
 run([WRAP,ENGINE/"repair_platform.py","prepare-heldout","--labels",pub/"development_bundle.json","--declaration",pub/"declaration.json","--context",pub/"context.json","--out",wf],logs/"prepare.log",env)
 prior=wf/"prior_prepared";receipts={"prior":native(case,prior,arm,"prior",env)}
 context=base/"context"
 run([WRAP,ENGINE/"repair_platform.py","prepare-context","--prior",prior,"--out",context],logs/"context_prepare.log",env)
 receipts["context"]=native(case,context,arm,"context",env)
 results={k:assess(case,s,k,arm,env) for k,s in [("prior",prior),("context",context)]}
 passed=[k for k in results if results[k]["passed"]]
 chosen=max(passed,key=lambda k:(results[k]["metrics"]["F1"],k=="prior")) if passed else "prior"
 save(base/"selection.json",{"kind":chosen,"skill":str(prior if chosen=="prior" else context),"passed":bool(passed),"candidate_assessments":results,"native":receipts,"seconds":time.monotonic()-t,"selection_uses":"independent source validation only; no new-batch data"})
 save(base/"learning_freeze.json",{"files":freeze(base)})
 run([PY,ROOT/"code/seal_capsule.py","--case",case],case/"logs/seal_capsule.log",{**env,"EF_ROLE":"seal"})
 save(case/"status/learning_closed.json",{"at":time.time(),"selection_sha":sha(base/"selection.json"),"capsule_sha":sha(case/"sealed/capsule.json"),"formal_reference_read":False})
def main():
 p=argparse.ArgumentParser();p.add_argument("--case",required=True);a=p.parse_args();case=Path(a.case)
 meta=load(case/"case.json")
 env={**os.environ,"EF_SEED":str(meta["seed"]),"EF_GPU":str(meta["gpu"]),"EF_ARM":"full","EF_ROLE":"learning","EF_CASE":str(case),"OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","MKL_NUM_THREADS":"2","PYTHONDONTWRITEBYTECODE":"1"}
 os.environ.update(env)
 from runtime import guard
 guard()
 save(case/"status/learning_owner.json",{"pid":os.getpid(),"gpu":meta["gpu"],"at":time.time()})
 try:learn(case,env)
 except Exception as e:
  import traceback
  save(case/"status/learning_failure.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
if __name__=="__main__":main()
