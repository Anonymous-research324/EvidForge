"""Published CDC conformal cleaner, group calibration inside authorized first10 only."""
from pathlib import Path
import argparse,os,sys,time,json,random,copy,uuid,traceback
from common import ROOT,SEED,load,save,read_csv,write_csv,freeze,sha
from baseline_contract import install_guard
install_guard()
os.environ['CUDA_VISIBLE_DEVICES']='';os.environ['OMP_NUM_THREADS']='4'
import numpy as np,pandas as pd
from sklearn.model_selection import GroupShuffleSplit
sys.path.insert(0,str(ROOT/'references/cdc'))
from conformal_data_cleaning.cleaner.conformal import ConformalAutoGluonCleaner
from conformal_data_cleaning.cleaner import _base as cleanbase
from cdc_schema_v4 import infer_schema,install_schema
from cdc_trainfold_io_v3 import install as install_trainfold_io
from conformal_data_cleaning.utils import is_categorical as native_is_categorical
from conformal_inference.models.automl import autogluon as native_ag
random.seed(SEED);np.random.seed(SEED)
# The published sample-with-replacement heuristic otherwise calls EVERY feature
# categorical when teaching has <=200 rows. Cap its sample to actual source size.
cleanbase.is_categorical=lambda s:native_is_categorical(s,n_samples=min(1000,len(s)))
def guard(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=str(Path(os.fsdecode(args[0])).resolve())
  if '/datasets/' in p and '/private/' in p or '/local_private/' in p:raise PermissionError('Formal reference unavailable')
  if p.endswith(('development_bundle.json','validation_only.json')):raise PermissionError('Only first10 source may train')
sys.addaudithook(guard)
def main(name,resume_reviewed=False):
 start=time.monotonic();pub=ROOT/'datasets'/name/'public';out=ROOT/'outputs'/name/'cdc_v3'
 if (out/'output_freeze.json').exists():
  assert all(sha(out/k)==h for k,h in load(out/'output_freeze.json')['files'].items());return
 if out.exists():
  assert resume_reviewed and (ROOT/'audit'/('cdc_v3_resume_review_'+name+'.json')).exists(),'Partial field recovery requires exact independent review'
 out.mkdir(parents=True,exist_ok=True)
 cols=load(pub/'declaration.json')['targets'];groups=load(pub/'learning_only.json')['learning']
 records=[{**r,'source_group':g['group']} for g in groups for r in g['records']]
 fields,val=read_csv(pub/'validation_dirty.csv');_,formal=read_csv(pub/'repair_dirty.csv')
 rawteach=pd.DataFrame([{c:r['truth'][c] for c in cols} for r in records],columns=cols)
 categories=infer_schema(rawteach,cleanbase.is_categorical)
 Cleaner=install_schema(ConformalAutoGluonCleaner,categories)
 teach=rawteach.copy()
 for c in cols:
  teach[c]=teach[c].astype(object) if c in categories else pd.to_numeric(teach[c].replace('',np.nan),errors='raise').astype(float)
 raw=val+formal;query=pd.DataFrame([{c:r[c] for c in cols} for r in raw],columns=cols)
 for c in cols:
  query[c]=query[c].replace('',np.nan).astype(object) if c in categories else pd.to_numeric(query[c],errors='coerce').astype(float)
 group_ids=np.array([r['source_group'] for r in records])
 def grouped_split(X,*a,**kw):
  assert len(X)==len(teach) and list(X.index)==list(teach.index),'Calibration may use teaching only'
  tr,ca=next(GroupShuffleSplit(n_splits=1,test_size=float(kw.get('test_size',.4)),random_state=SEED).split(X,groups=group_ids))
  return X.iloc[tr],X.iloc[ca]
 native_ag.train_test_split=grouped_split
 io_audit=load(out/'native_trainfold_io_audit.json') if (out/'native_trainfold_io_audit.json').exists() else []
 def audit_io(item):
  io_audit.append(item);save(out/'native_trainfold_io_audit.json',io_audit)
 trainfold_binding=install_trainfold_io(native_ag,teach,group_ids,SEED,audit_io)
 policy={'seed':SEED,'confidence_level':.9,'internal_calibration_fraction':.4,'calibration_grouped':True,'AutoGluon_learner_random_state':1013,'estimator_seeds':1013,
 'training_source_fraction':.1,'external_validation_used_for_fitting':False,'per_field_time_limit_seconds':60,'categorical_columns':categories,
 'hyperparameter_trials':10,'native_cleaner_code_unchanged':True,'type_bridge_version':'source_schema_v4 explicit known empty categorical + all-singleton trainfold IO v3; no formal tuning','internal_model_selection_exception':'all-singleton classifier uses its own TRAIN fold as tuning_data; optimistic internal selection; conformal calibration remains disjoint','trainfold_binding':trainfold_binding,'type_sample_cap':'min(1000, authorized_source_rows), source-only small-table adaptation',
 'optional_model_families_available':['LightGBM','CatBoost','RandomForest','ExtraTrees','KNN'],'reuse_intermediate':False,'missing_prediction_reuse_shape_bug_avoided_using_native_option':True,'GPU_used':False,'test_gold_read':False}
 if (out/'method_freeze.json').exists():assert load(out/'method_freeze.json')==policy
 else:save(out/'method_freeze.json',policy)
 result=[dict(r) for r in raw];column_status=[];scores=np.zeros((len(raw),len(cols)))
 for j,c in enumerate(cols):
  checkpoint=out/'column_checkpoints'/(str(j)+'.json')
  if checkpoint.exists():
   ck=load(checkpoint);assert ck['column']==c and ck['method_sha256']==sha(out/'method_freeze.json')
   assert len(ck['values'])==len(result)
   for row,value in zip(result,ck['values']):row[c]=value
   column_status.append(ck['status']);continue
  if teach[c].nunique()<2:
   column_status.append({'column':c,'status':'abstained_constant_source'})
   save(checkpoint,{'column':c,'values':[r[c] for r in result],'status':column_status[-1],'method_sha256':sha(out/'method_freeze.json')})
   save(out/'column_status.json',column_status);continue
  # A cleaner for one target avoids mutation of other predictors' keyword dicts.
  cleaner=Cleaner(confidence_level=.9,seed=SEED)
  try:
   cleaner.fit(teach,target_columns=[c],ci_ag_predictor_params={'path_prefix':out/'models'/c/('attempt_'+uuid.uuid4().hex),'verbosity':1,'learner_kwargs':{'random_state':1013}},
     ci_calibration_size=.4,ci_ag_fit_params={'time_limit':60,'holdout_frac':.5,'num_cpus':4,'num_gpus':0,
       'hyperparameters':{'GBM':{'seed':1013},'CAT':{'random_seed':1013},'RF':{'random_state':1013},'XT':{'random_state':1013},'KNN':{}},
       'hyperparameter_tune_kwargs':{'num_trials':10},'ag_args_fit':{'num_cpus':4,'num_gpus':0}})
   cleaned,mask,sets=cleaner.transform(query,reuse_intermediate=False)
   for i in range(len(raw)):
    if bool(mask.iloc[i][c]):
     value=cleaned.iloc[i][c]
     if not pd.isna(value):result[i][c]=str(value);scores[i,j]=1.
   column_status.append({'column':c,'status':'fit_and_transformed','changed_or_imputed':int(mask[c].sum())})
  except Exception as e:
   # A computational failure is not a performance score. No output closes if any field crashes.
   save(out/'column_status.json',column_status+[{'column':c,'status':'failed','exception':type(e).__name__,'message':str(e)[:500]}])
   raise
  save(checkpoint,{'column':c,'values':[r[c] for r in result],'status':column_status[-1],'method_sha256':sha(out/'method_freeze.json')})
  save(out/'column_status.json',column_status)
  print('CDC_FIELD_DONE',name,j+1,'/',len(cols),flush=True)
 write_csv(out/'validation_output.csv',fields,result[:len(val)])
 write_csv(out/'repair_output.csv',fields,result[len(val):])
 save(out/'receipt.json',{**policy,'elapsed_seconds':time.monotonic()-start,'source_groups':len(groups),'source_rows':len(records),'classification_labels_used':False})
 save(out/'output_freeze.json',{'files':freeze(out),'formal_reference_read':False})
 print('CDC_OUTPUT_CLOSED',name,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);p.add_argument('--resume-reviewed',action='store_true');args=p.parse_args()
 try:main(args.dataset,args.resume_reviewed)
 except Exception as e:
  save(ROOT/'cases'/args.dataset/'status/cdc_v4_failure.json',{'at':time.time(),'error':repr(e),'traceback':traceback.format_exc(),'completed_columns_preserved':True,'no_zero_fallback':True});raise
