"""Public teaching only: all original split guards, no fit or formal truth read."""
import sys,os,time,statistics
from pathlib import Path
from common import ROOT,save,load,sha
from runtime_v4 import install
def main():
 install()
 from unseen_table.common import normalize_bundle,fingerprint
 from workflow.onboarding import split_learning
 cases=load(ROOT/"configs/cases.json");results=[]
 for name in cases:
  c=ROOT/"cases"/name;pub=c/"public";b=load(pub/"development_bundle.json");d=load(pub/"declaration.json")
  _,audit=normalize_bundle(b,d);inner,_=split_learning(b,d);normalize_bundle(inner,d)
  vals={col:{r["truth"][col] for g in b["learning"] for r in g["records"] if r["truth"].get(col,"").strip()} for col in d["targets"]}
  meta=load(c/"case.json")
  results.append({"case":name,"seed":meta["seed"],"rate":meta["rate"],"type":meta["error_type"],"external_and_internal_split_guards":"PASS","learning_groups":len(b["learning"]),"validation_groups":len(b["validation"]),"learning_unique_values_by_field":{k:len(v) for k,v in vals.items()},"input_freeze_sha":sha(c/"input_freeze.json")})
 # The old high-rate public input must be byte identical to the previously used seed dataset.
 checks=[]
 for name in cases:
  c=ROOT/"cases"/name;m=load(c/"case.json")
  if m["rate"]==.7 and m["error_type"]=="mixed":
   old=ROOT.parent/("EvidForge_Downstream_Study_seed"+str(m["seed"]))/"datasets/retinopathy/public"
   files=["repair_dirty.csv","holdout_dirty.csv","development_bundle.json","declaration.json"]
   # holdout contents may include protected y, so only hash, not parse.
   for n in files:
    if n=="holdout_dirty.csv":continue
    assert sha(c/"public"/n)==sha(old/n),(name,n)
   checks.append({"seed":m["seed"],"same_existing_public_inputs":True})
 save(ROOT/"audit/all_source_guards_pass.json",{"cases":results,"old70_input_parity":checks,"formal_rows_read":0,"fit_calls":0,"model_calls":0})
 print("ALL_SOURCE_GUARDS_PASS",len(results),flush=True)
if __name__=="__main__":main()
