"""Curator-only fixed splits and gold masks; no method performance inspection."""
from pathlib import Path
import sys,collections,random,re,json,hashlib,time,csv
from common import ROOT,load,save,sha,read_csv,write_csv,freeze
PLAN=ROOT.parent/'EvidForge_RealDirty_MainStudy_Plan_20261026'
sys.path[:0]=[str(ROOT/'engine'),str(ROOT/'engine/source_runtime')]
from workflow.onboarding import split_learning
P=load(ROOT/'configs/protocol.json')
PROTECTED={'beers':['index','id','brewery_id'],'movies':['id'],'flights':['tuple_id','src','flight'],'rayyan':['id'],'hospital':['index','provider_number'],'allergen':['code','rowid'],'address_shoppingcenter':[]}
KEYS={'beers':[['brewery_id'],['brewery_name','city','state']],'movies':[['id'],['name','year']],'flights':[['flight']],'rayyan':[['id'],['article_title']],'hospital':[['provider_number'],['name','address_1','zip'],['phone']],'allergen':[['code']],'address_shoppingcenter':[['name','road','postcode','locality']]}
def norm(x):return re.sub(r'[^\w]+','',x.casefold())
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def dataset(ds):
 if ds=='allergen':
  with (PLAN/'sources'/ds/'dirty.csv').open(newline='',encoding='utf-8-sig') as f:r=csv.DictReader(f,delimiter=';');fields=r.fieldnames;dirty=list(r)
 else:fields,dirty=read_csv(PLAN/'sources'/ds/'dirty.csv')
 rf,ref=read_csv(PLAN/'sources'/ds/'reference.csv')
 if ds=='allergen':
  gold={r['code']:r for r in ref};assert len(gold)==len(ref)
  truth=[{c:gold[r['code']][c] for c in rf if c!='code'} if r['code'] in gold else {} for r in dirty]
 else:
  assert len(dirty)==len(ref) and len(fields)==len(rf)
  # Semantic map reviewed against published paired schema; preserve dirty column names and strings.
  mapping=dict(zip(fields,rf));truth=[{c:r[mapping[c]] for c in fields} for r in ref]
 targets=[c for c in fields if c not in PROTECTED[ds]]
 truth=[{c:r[c] for c in targets if c in r} for r in truth]
 n=len(dirty);parent=list(range(n));edges=collections.Counter()
 def find(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 def union(a,b,mode):
  a,b=find(a),find(b)
  if a!=b:parent[b]=a;edges[mode]+=1
 for cols in KEYS[ds]:
  seen={}
  for i,row in enumerate(dirty):
   key=tuple(norm(row[c]) for c in cols)
   if not all(key):continue
   if key in seen:union(i,seen[key],'dirty_entity:'+','.join(cols))
   else:seen[key]=i
 # Protect benchmark entity identity when business key contains a typo. This is curator metadata only.
 if ds!='allergen':
  for cols in KEYS[ds]:
   seen={}
   for i,row in enumerate(ref):
    key=tuple(norm(row[dict(zip(fields,rf))[c]]) for c in cols)
    if not all(key):continue
    if key in seen:union(i,seen[key],'reference_entity_metadata:'+','.join(cols))
    else:seen[key]=i
 seen={}
 for i,r in enumerate(dirty):
  # Equal allergy vectors on different product codes are different entities.
  duplicate_fields=[c for c in fields if c!='rowid'] if ds=='allergen' else targets
  key=tuple(r[c] for c in duplicate_fields)
  if key in seen:union(i,seen[key],'exact_observed_target_duplicate')
  else:seen[key]=i
 groups=collections.defaultdict(list)
 for i in range(n):groups[find(i)].append(i)
 groups={f'g{min(ids):06d}':ids for ids in groups.values()}
 # Original source guard forbids fully confirmed equal target observations across learning/outer.
 # Keep those signatures in indivisible partition blocks, while retaining actual entity groups.
 gp=list(groups);bp={g:g for g in gp}
 def bf(g):
  while bp[g]!=g:bp[g]=bp[bp[g]];g=bp[g]
  return g
 sig={}
 for g,ids in groups.items():
  for i in ids:
   if set(truth[i])!=set(targets):continue
   s=digest(truth[i])
   if s in sig:bp[bf(g)]=bf(sig[s])
   else:sig[s]=g
 blocks=collections.defaultdict(list)
 for g in gp:blocks[bf(g)].append(g)
 eligible=[b for b in blocks.values() if all(any(truth[i] for i in groups[g]) for g in b)]
 unknown=[g for b in blocks.values() if b not in eligible for g in b]
 return fields,dirty,truth,targets,groups,eligible,unknown,dict(edges)
def main():
 assert not list(ROOT.glob('cases/*/scores.json'))
 inventory=[];cases=[];fail=[]
 for ds in P['datasets']:
  fields,dirty,truth,targets,groups,blocks,unknown,edges=dataset(ds)
  for seed in P['seeds']:
   name=f'{ds}_s{seed}';c=ROOT/'cases'/name
   if (c/'input_freeze.json').exists():
    frozen=load(c/'input_freeze.json')
    for part in ['public','private']:
     for rel,h in frozen[part].items():assert sha(c/part/rel)==h
    assert sha(c/'case.json')==frozen['case_sha']
    cases.append(name);inventory.append(load(c/'case.json'));continue
   assert not c.exists(),name
   for part in ['public','private','work','outputs','logs','status','audit']:(c/part).mkdir(parents=True,exist_ok=True)
   ordered=sorted(blocks,key=lambda b:digest([seed,ds,sorted(b)]))
   count=sum(map(len,ordered));k,v=max(20,int(count*.1+.5)),max(10,int(count*.1+.5))
   # Prefer a feasible source guard split by a deterministic cyclic traversal, based only on metadata.
   chosen=None
   for rotation in range(len(ordered)):
    seq=ordered[rotation:]+ordered[:rotation];zones={'learning':[],'validation':[],'repair':list(unknown)}
    for b in seq:
     z='learning' if len(zones['learning'])<k else 'validation' if len(zones['validation'])<v else 'repair'
     zones[z]+=b
    if len(zones['learning'])>=20 and len(zones['validation'])>=10 and len(zones['repair'])>=1:
     chosen=zones;break
   if chosen is None:
    save(c/'status/input_incompatible.json',{'reason':'Original minimum groups and confirmed-duplicate guard cannot be satisfied','entity_groups':len(groups),'confirmed_signature_blocks':len(blocks),'no_algorithm_change':True})
    fail.append(name);continue
   zones=chosen;gid={i:g for g,ids in groups.items() for i in ids}
   def row(i):return {'entity_id':gid[i],'__rowkey__':f'r{i:06d}',**dirty[i]}
   allfields=['entity_id','__rowkey__',*fields]
   bundle={z:[{'group':g,'provenance':'Pinned author public reference; whole entity source-only authorization','records':[{'row_key':f'r{i:06d}','dirty':row(i),'truth':truth[i]} for i in groups[g]]} for g in zones[z]] for z in ['learning','validation']}
   protected=['entity_id','__rowkey__',*PROTECTED[ds]]
   declaration={'id':name,'provenance':'Published benchmark schema mapped literally, protected business IDs, curator entity components','fields':{f:{'role':'target' if f in targets else 'identity' if f=='entity_id' else 'protected','identity':f in protected,'type':'string'} for f in allfields},'targets':targets,'entity_fields':['entity_id'],'protected_fields':protected,'visible_context_fields':[]}
   try:split_learning(bundle,declaration)
   except Exception as e:
    save(c/'status/input_incompatible.json',{'reason':repr(e),'no_algorithm_change':True});fail.append(name);continue
   save(c/'public/development_bundle.json',bundle)
   save(c/'public/learning_only.json',{'learning':bundle['learning']})
   save(c/'public/declaration.json',declaration)
   save(c/'public/context.json',{'dataset':ds,'source_version':'public_real_dirty_20261026','schema':'original_dirty_headers','seed':seed})
   ids={z:sorted(i for g in gs for i in groups[g]) for z,gs in zones.items()}
   for z in ['learning','validation','repair']:
    write_csv(c/'public'/(z+'_dirty.csv'),allfields,[row(i) for i in ids[z]])
   for z in ['validation','repair']:
    save(c/'private'/(z+'_truth.json'),{'row_keys':[f'r{i:06d}' for i in ids[z]],'truth':[truth[i] for i in ids[z]],'known_mask':[[f for f in targets if f in truth[i]] for i in ids[z]]})
   meta={'dataset':ds,'seed':seed,'phase':'real_dirty_formal_three_seeds','suite':'real_dirty','targets':targets,'protected':protected,'rows':{z:len(ids[z]) for z in ids},'groups':{z:len(zones[z]) for z in zones},'learning_label_cells':sum(len(truth[i]) for i in ids['learning']),'validation_label_cells':sum(len(truth[i]) for i in ids['validation']),'test_unknown_cells':sum(len(targets)-len(truth[i]) for i in ids['repair']),'no_repollution':True,'strict_literal_main_metric':True}
   save(c/'case.json',meta)
   save(c/'audit/curation.json',{'at':time.time(),'edges':edges,'all_rows_preserved':sum(meta['rows'].values())==len(dirty),'original_source_guard_passed':True,'truth_signature_blocks':len(blocks),'entity_groups':len(groups),'zone_groups':zones,'source_files_sha':{str(p):sha(p) for p in (PLAN/'sources'/ds).glob('*.csv')},'source_metadata_reference_read':True,'formal_method_scores_read':False,'literal_values_unchanged':True})
   save(c/'input_freeze.json',{'public':freeze(c/'public'),'private':freeze(c/'private'),'case_sha':sha(c/'case.json')})
   cases.append(name);inventory.append(meta)
 save(ROOT/'configs/cases.json',cases);save(ROOT/'audit/curation_summary.json',{'at':time.time(),'cases':inventory,'incompatible':fail,'original124_unchanged':True,'model_calls':0,'formal_scores':0})
 print(json.dumps({'prepared':len(cases),'incompatible':fail,'first_seed':[x for x in inventory if x['seed']==9013]},ensure_ascii=False))
if __name__=='__main__':main()
