"""Sole fixed-output expansion scorer. Existing successful scores are imported, never regraded."""
from pathlib import Path
import json,time,os,socket,fcntl,collections,statistics,sys,copy,subprocess
from decimal import Decimal,InvalidOperation
from common import ROOT as R,load,save,sha,read_csv
O=R.parent/'EvidForge_RealDirty_Formal5_ThreeSeeds_20261027'
METHODS=['full','raha_holoclean','garf','cdc','tabclean']
FORMAL_SEEDS=[1013,1014,1015]
RETAINED={'address_museum','movies','address_shoppingcenter'}
NEW={'beers','library_official','school_small','government_small','jobposting_small'}

def number(v):
 try:
  x=Decimal(str(v).strip());return x if x.is_finite() else None
 except InvalidOperation:return None

def equal(a,b):
 x,y=number(a),number(b);return x==y if x is not None and y is not None else str(a)==str(b)

def metric(dirty,output,truth,targets):
 E=M=C=N=D=detected=known=unknown=unknown_edits=0
 assert len(dirty)==len(output)==len(truth)
 for a,b,t in zip(dirty,output,truth):
  for c in targets:
   change=not equal(a[c],b[c])
   if c not in t:unknown+=1;unknown_edits+=change;continue
   known+=1;wrong=not equal(a[c],t[c]);E+=wrong;N+=not wrong;M+=change
   C+=wrong and change and equal(b[c],t[c]);D+=(not wrong) and change;detected+=wrong and change
 precision=C/M if M else 0.;recall=C/E if E else 0.
 return {'P':precision,'R':recall,'F1':2*precision*recall/(precision+recall) if precision+recall else 0.,'normal_damage_rate':D/N if N else None,'edit01_AUC':(1+detected/E-D/N)/2 if E and N else None,'errors':E,'changes':M,'exact':C,'clean':N,'normal_damage':D,'known_cells':known,'unknown_cells':unknown,'unknown_edits':unknown_edits,'net_correct_cells':C-D,'precision_no_edit_convention':'0, unchanged table1 convention'}

def align(before,after):
 keys=[r['__rowkey__'] for r in before];got=[r['__rowkey__'] for r in after]
 assert len(keys)==len(set(keys)) and len(got)==len(set(got)) and set(keys)==set(got)
 by=dict(zip(got,after));return [by[k] for k in keys]

def truth_align(dirty,value):
 keys=value['row_keys'];assert len(keys)==len(set(keys))==len(value['truth']);by=dict(zip(keys,value['truth']));assert set(by)=={r['__rowkey__'] for r in dirty}
 return [by[r['__rowkey__']] for r in dirty]

def self_test():
 d=[{'a':'9','b':'8','c':'3','u':'6','empty':'X'}];o=[{'a':'1.0','b':'7','c':'6','u':'7','empty':''}];t=[{'a':'1','b':'2','c':'3','empty':''}]
 m=metric(d,o,t,['a','b','c','u','empty']);assert (m['errors'],m['changes'],m['exact'],m['normal_damage'],m['unknown_cells'])==(3,4,2,1,1) and abs(m['F1']-4/7)<1e-12
 assert equal('1.0','1') and not equal('Foo','foo')
 assert metric([{'x':'1'}],[{'x':'1'}],[{'x':'2'}],['x'])['F1']==0
 print('METRIC_FIXTURE_PASS;0formal reads')


def config():
 p=load(R/'configs/protocol_recovery_v3.json');initial=load(R/'configs/protocol.json')
 assert p['methods']==METHODS or set(p['methods'])==set(METHODS)
 assert p['seeds']==FORMAL_SEEDS
 for key in ['seeds','methods','split_budget','LLM','cpu_concurrency','timeouts_seconds','quality_gates_unchanged','core124_disk_unchanged','no_injected_errors','all_rows_preserved','main_metric','known_mask']:
  assert p[key]==initial[key],('Recovery numerical contract differs',key)
 assert set(p['datasets'])==RETAINED|NEW
 assert p['model_ports']==list(range(8321,8329)) and p['postgres_port']==55443
 assert p['service_generations']==[{'root':'services','ports':list(range(8301,8309))},{'root':'services_v3','ports':list(range(8321,8329))}]
 return p

def output_dir(name,method,imports=None):
 if imports is None:imports=import_inventory()
 key=(name,method)
 if key in imports:return Path(imports[key]['frozen_output']).parent
 folders=config().get('output_folder_by_method',{})
 return R/'cases'/name/'outputs'/folders.get(method,method)

def import_inventory():
 x=load(R/'audit/preserved_output_inventory.json');assert x['count']==25
 expected={}
 for a in x['validated_outputs']:
  key=(a['case'],a['method']);assert key not in expected;expected[key]=a
 assert len(expected)==25
 for name,method in expected:
  assert load(R/'cases'/name/'case.json')['dataset'] in RETAINED
  assert method in ['full','raha_holoclean','tabclean']
 assert sum(m=='full' for n,m in expected)==9 and sum(m=='raha_holoclean' for n,m in expected)==9 and sum(m=='tabclean' for n,m in expected)==7
 return expected

def verify_selection():
 x=load(R/'audit/completion_protocol_amendment_v3.json')
 assert set(x['fixed_datasets'])==NEW and len(x['fixed_datasets'])==5
 for key in ['references_unread','no_formal_performance_filter','source_diagnostics_reported','quality_gates_unchanged','old_input_splits_and_case_hashes_unchanged','before_first_new_formal_reference_read','zero_results_retained']:assert x[key] is True,key
 # Government source F1=0 remains a registered negative condition; formal scores do not filter data.
 return x

def verify_frozen_code():
 # Executed original phases are immutable. The unused early preparation freeze is not an execution claim.
 phases=['dispatch_phase_freeze.json','source_probe_dispatch_freeze.json','garf_true_preflight_freeze.json','scoring_review_code_freeze.json','cpu_recovery_v3_dispatch_freeze.json','recovery_gpu_dispatch_freeze_v3.json','recovery_code_freeze.json']
 transition=load(R/'audit/io_guard_strengthening_review_v3.json')
 assert transition['passed'] and transition['all_other_historical_code_hashes_unchanged'] and transition['formal_reference_read'] is False
 assert len(transition['transitions'])==1;guard=transition['transitions'][0]
 assert Path(guard['path'])==R/'code/baseline_contract.py' and guard['original_freeze']=='audit/garf_true_preflight_freeze.json'
 assert guard['old_sha256']=='669500312688134a7f0e23228f2ef3b221744cb983a467769e3e5e8c258b5e70' and guard['new_sha256']=='0980a0dea0b5dc0dbf647016411b15c1208b711284044b4237df24a2681c5475'
 snapshot=R/guard['old_snapshot'];assert sha(snapshot)==guard['old_sha256'] and sha(guard['path'])==guard['new_sha256']
 assert Path(guard['path']).read_text()==snapshot.read_text().replace("('private','local_private')","('private','local_private','sources','candidate_sources')")
 assert guard['current_guard_stricter'] and guard['GARF_firstcase_original_guard_private_references_still_denied'] and not guard['training_or_scoring_logic_changed']
 for filename in phases:
  fr=load(R/'audit'/filename);assert isinstance(fr['files'],dict) and fr['files'],filename
  for rel,h in fr['files'].items():
   if sha(R/rel)==h:continue
   assert filename=='garf_true_preflight_freeze.json' and (R/rel)==Path(guard['path']) and h==guard['old_sha256'] and sha(R/rel)==guard['new_sha256'],('Unreviewed frozen file change',filename,rel)
 # The early CDC interface generation used list receipts, preserved independently from new entries.
 cdc=load(R/'audit/cdc_trainfold_v3_code_freeze.json')
 for entry in cdc['files']:assert sha(entry['entry'])==entry['sha256']
 assert sha(R/'code/cdc_trainfold_io_v3.py')==cdc['helper_sha256']
 for rel,h in load(R/'audit/core124.json')['files'].items():assert sha(R/'engine'/rel)==h,('core124',rel)
 oldfreeze=R/'audit/old_results_frozen.json'
 if oldfreeze.exists():
  for old,h in load(oldfreeze).items():assert sha(old)==h,old
 inv=load(R/'audit/preserved_output_inventory.json')
 for fname,h in inv['old_fixed_score_files'].items():assert sha(O/'reports'/fname)==h,('Preserved original scores',fname)
 assert load(O/'audit/final_independent_fixedscore_review.json')['passed']
 for filename in ['preflight_failures_reviewed.json','recovery_failures_reviewed_v3.json']:
  rev=load(R/'audit'/filename);assert rev['passed'] and rev['no_unknown_failures'],filename
  for rel,h in rev.get('evidence_files',{}).items():assert sha(R/rel)==h,('Reviewed failure evidence',filename,rel)
 verify_hook_gap_review()

def verify_resources(p):
 lines=subprocess.check_output(['ps','-eo','pid,pgid,args'],text=True).splitlines()[1:];resources=[]
 for generation in p['service_generations']:
  for g,port in enumerate(generation['ports']):
   d=R/generation['root']/f'gpu{g}';o=load(d/'owner.json')
   assert o['host']==socket.gethostname() and o['port']==port and (d/'stopped.json').exists()
   q=Path('/proc')/str(o['pid'])/'cmdline';assert not q.exists() or o['name'].encode() not in q.read_bytes()
   assert not any(len(row.split(maxsplit=2))==3 and row.split(maxsplit=2)[1]==str(o['pgid']) for row in lines)
   with socket.socket() as so:assert so.connect_ex(('127.0.0.1',port))!=0
   resources.append({'generation':generation['root'],'physical_gpu':g,'owned_port_closed':port,'owner_process_and_process_group_absent':True})
 with socket.socket() as so:assert so.connect_ex(('127.0.0.1',55443))!=0
 assert not any('postgres' in x.lower() and str(R/'services/postgres') in x for x in lines)
 return resources

def verify_inputs(names):
 for name in names:
  c=R/'cases'/name;fr=load(c/'input_freeze.json');assert sha(c/'case.json')==fr['case_sha']
  for part in ['public','private']:
   for rel,h in fr[part].items():assert sha(c/part/rel)==h,('input hash',name,part,rel)
  # Only hashes are read here; formal reference JSON is not parsed before its once marker.


def verify_hook_gap_review():
 x=load(R/'audit/pilot_hook_gap_review_v3.json');assert x['passed'] and x['not_protocol_complete'] and x['exploratory_only']
 exceptions={(a['case'],a['stage']):a for a in x['exceptions']}
 assert set(exceptions)=={('beers_s9013','prior'),('jobposting_small_s9013','prior')} and len(x['exceptions'])==2
 for (name,stage),a in exceptions.items():
  assert a['actual_calls']==5 and a['native_exit_code']==0 and a['closed'] and a['only_hook_log_missing']
  assert a.get('observed_MCP_decide_calls')==5 and a.get('other_tools_observed') is False
  required={str((R/'cases'/name/'work/full'/f'{stage}_stage/native_v3'/n).relative_to(R)) for n in ['session.json','budget.json','result.json','command_freeze.json','native_events.jsonl','native_stderr.log']}
  assert required<=set(a['evidence_files'])
  for rel,h in a['evidence_files'].items():assert sha(R/rel)==h,('Exact reviewed exploratory Hook gap evidence',name,rel)
 return exceptions

def verify_requests(names,pilot_names,imports):
 valid_names=set(names+pilot_names);index={};cost=[];gap=verify_hook_gap_review();native_stats=collections.Counter()
 for generation in config()['service_generations']:
  for f in sorted((R/generation['root']).glob('gpu*/requests/*/request.json')):
   tag=f.parent.name;assert tag not in index,('Repeated actual request tag across service generations; no replay allowed',tag)
   b=load(f.parent/'binding.json');q=load(f);r=load(f.parent/'response.json');timing=load(f.parent/'timing.json')
   assert b['case'] in valid_names and b['method'] in ['full','tabclean']
   assert (b['case'],b['method']) not in imports,'Imported method unexpectedly issued a new request'
   seed=load(R/'cases'/b['case']/'case.json')['seed'];owner=load(f.parent.parent.parent/'owner.json')
   assert owner['host']==socket.gethostname() and q['model']==owner['name'] and b['port']==owner['port'] and owner['port'] in generation['ports']
   assert q['seed']==b['seed']==seed and q['temperature']==0 and 0<q['max_tokens']<=8192
   assert q.get('chat_template_kwargs',{}).get('enable_thinking') is False
   assert r['choices'] and r.get('usage') is not None
   for k in ['prompt_tokens','completion_tokens','total_tokens']:assert isinstance(r['usage'].get(k),int) and r['usage'][k]>=0
   index[tag]={'binding':b,'request':q,'response':r,'directory':f.parent,'generation':generation['root']}
   cost.append({'case':b['case'],'method':b['method'],'seed':seed,'usage':r['usage'],'finish_reason':r['choices'][0]['finish_reason'],'seconds':timing['seconds'],'request_dir':str(f.parent),'service_generation':generation['root'],'attempt_origin':'new_compat_expansion'})
 seen=set()
 for name in names+pilot_names:
  for method in (['full'] if name in pilot_names else METHODS):
   if (name,method) in imports:continue
   out=output_dir(name,method,imports)
   if method=='full':
    base=R/'cases'/name/'work/full';learning=load(base/'learning_freeze.json')
    for rel,h in learning['files'].items():assert sha(base/rel)==h,('Sealed learned skill/native evidence',name,rel)
    for stage in ['prior','context']:
     d=base/f'{stage}_stage/native_v3';res=load(d/'result.json');budget=load(d/'budget.json')
     assert res['closed'] and res['native_exit_code']==0 and res['real9B_calls']==5 and res['synthetic_control_count']==0 and res.get('gateway_failure') is None
     assert budget['calls']==5 and budget['pending_call'] is None and len(budget['actual_usage'])==5 and res['actual_usage']==budget['actual_usage']
     events=[json.loads(x) for x in (d/'native_events.jsonl').read_text().splitlines()];assert all(x.get('type')!='turn.failed' for x in events)
     completed=[x['item'] for x in events if x.get('type')=='item.completed' and x.get('item',{}).get('type')=='mcp_tool_call']
     assert len(completed)==5 and len({x['id'] for x in completed})==5
     assert all(x['server']=='dataforge_learning' and x['tool']=='decide' and x['status']=='completed' and x.get('error') is None for x in completed)
     assert not any(x.get('item',{}).get('type') in ['command_execution','file_change','web_search','collab_tool_call'] for x in events)
     hookfile=d/'native_hooks.jsonl';hookrows=[json.loads(x) for x in hookfile.read_text().splitlines()] if hookfile.exists() else [];hc=collections.Counter(x['event'] for x in hookrows)
     if (name,stage) in gap:
      assert name in pilot_names and stage=='prior' and not hookrows
      assert res['hook_contract_passed'] is False and all(res.get('actual_hook_counts',{}).get(x,0)==0 for x in ['PreToolUse','PostToolUse','Stop'])
      native_stats['exploratory_hook_log_gap']+=1
     else:
      assert hc['PreToolUse']==5 and hc['PostToolUse']==5 and hc['Stop']>=1 and res['hook_contract_passed']
      if name in names or (name in ['beers_s9013','jobposting_small_s9013'] and stage=='context'):
       assert hc['SessionStart']>=1 and hookrows[0]['event']=='SessionStart'
       assert res.get('session_hooks_registered') is True and res.get('startup_hook_before_model_required') is True and res.get('hook_registration')=='explicit_cli_session_toml'
       assert load(d/'registered_hooks_v4.json')['registration']=='explicit_cli_session_toml';native_stats['strict_v4_sessions']+=1
      else:native_stats['old_strict_pilot_sessions']+=1
     native_stats['formal_sessions' if name in names else 'pilot_sessions']+=1
     files=list(d.glob('actual9b-request-*.json'));assert len(files)==5
     for i in range(1,6):
      wire=load(d/f'wire-request-{i}.json');tag=wire['_trace_tag'];assert tag in index and tag not in seen;seen.add(tag)
      rec=index[tag];assert rec['binding']['case']==name and rec['binding']['method']=='full'
      actual=load(d/f'actual9b-request-{tag}.json');assert actual==wire
      expected=copy.deepcopy(wire);expected.pop('_trace_tag');expected.update(model=rec['request']['model'],temperature=0,seed=load(R/'cases'/name/'case.json')['seed'],chat_template_kwargs={'enable_thinking':False});expected['max_tokens']=min(expected['max_tokens'],8192)
      assert expected==rec['request']
      raw=load(d/f'actual9b-response-{i}.json');assert raw==rec['response'] and raw['usage']==budget['actual_usage'][i-1]
      assert load(d/f'codex-response-{i}.json')['actual_model_usage']==raw['usage']
      if name in names:assert rec['generation']=='services_v3','All new formal native sessions must use reviewed v4 generation'
   elif method=='tabclean':
    calls=sorted(x for x in out.glob('call_*.json') if x.stem[-3:].isdigit());receipt=load(out/'receipt.json')
    assert len(calls)==receipt['calls'] and receipt['seed']==load(R/'cases'/name/'case.json')['seed'];assert load(out/'program_freeze.json')['actual_calls']==len(calls)
    for i,cf in enumerate(calls,1):
     assert cf.name==f'call_{i:03d}.json';meta=load(cf);raw=load(cf.with_name(cf.stem+'_actual_response.json'));tag=('Tab'+name+meta['agent']+str(i)).replace('_','').replace('-','')
     assert tag in index and tag not in seen;seen.add(tag);assert index[tag]['binding']['case']==name and index[tag]['binding']['method']=='tabclean'
     assert raw==index[tag]['response'] and meta['usage']==raw['usage'] and raw['choices'][0]['finish_reason'] in ['stop','length']
    assert sha(out/'frozen_program.py')==load(out/'program_freeze.json')['sha256']
 assert seen==set(index),'Every old/new actual request must bind to exactly one closed call; no reset/replay/unmatched request'
 assert dict(native_stats)=={'exploratory_hook_log_gap':2,'pilot_sessions':10,'strict_v4_sessions':32,'formal_sessions':30,'old_strict_pilot_sessions':6},dict(native_stats)
 return cost

def verify():
 p=config();verify_selection();verify_frozen_code()
 names=load(R/'configs/cases.json');pilot=load(R/'configs/cases_pilot.json');imports=import_inventory()
 assert len(names)==24==len(set(names)) and len(pilot)==5==len(set(pilot)) and not set(names)&set(pilot)
 metas=[load(R/'cases'/n/'case.json') for n in names]
 assert {x['dataset'] for x in metas}==RETAINED|NEW
 assert {(x['dataset'],x['seed']) for x in metas}=={(ds,s) for ds in RETAINED|NEW for s in FORMAL_SEEDS}
 assert {load(R/'cases'/n/'case.json')['dataset'] for n in pilot}==NEW and all(load(R/'cases'/n/'case.json')['seed']==9013 for n in pilot)
 assert (R/'status/cpu_recovery_v3_complete.json').exists() and (R/'status/recovery_gpu_complete_v3.json').exists()
 done=load(R/'status/all_attempts_complete_recovery_v3.json');assert not done.get('failed') and not done.get('branch_errors'),'No missing or execution-failed branch may enter this complete table'
 verify_inputs(names+pilot);available=[]
 for name in names+pilot:
  c=R/'cases'/name;meta=load(c/'case.json')
  for method in (['full'] if name in pilot else METHODS):
   out=output_dir(name,method,imports);fr=out/'output_freeze.json';assert fr.exists(),('missing frozen output',name,method)
   if (name,method) in imports:assert sha(fr)==imports[name,method]['sha256']
   for rel,h in load(fr)['files'].items():assert sha(out/rel)==h,('output freeze',name,method,rel)
   for zone in ['repair','validation']:
    f,d=read_csv(c/'public'/f'{zone}_dirty.csv');of,rows=read_csv(out/f'{zone}_output.csv');assert of==f and len(rows)==len(d);rows=align(d,rows)
    assert all(a[k]==b[k] for a,b in zip(d,rows) for k in meta['protected'])
   available.append({'case':name,'method':method,'pilot':name in pilot,'imported':(name,method) in imports,'folder':str(out),'output_freeze_sha256':sha(fr)})
 assert len(available)==125 and sum(x['imported'] for x in available)==25
 costs=verify_requests(names,pilot,imports);resources=verify_resources(p)
 return names,pilot,imports,available,costs,resources

def aggregate_records(rows,datasets):
 aggregate=[];paired=[]
 for ds in datasets:
  for method in METHODS:
   group=[x for x in rows if x['dataset']==ds and x['method']==method];assert len(group)==3 and all(x['status']=='scored' for x in group)
   vals=[x['repair']['F1'] for x in group];damage=[x['repair']['normal_damage_rate'] for x in group if x['repair']['normal_damage_rate'] is not None]
   aggregate.append({'dataset':ds,'method':method,'n':3,'expected_n':3,'mean':statistics.mean(vals),'sample_sd':statistics.stdev(vals),'normal_damage_mean':statistics.mean(damage) if len(damage)==3 else None,'qualified_n':sum(bool(x['qualified']) for x in group),'complete':True})
  for method in METHODS[1:]:
   differences=[]
   for seed in FORMAL_SEEDS:
    a=next(x for x in rows if x['dataset']==ds and x['seed']==seed and x['method']=='full');b=next(x for x in rows if x['dataset']==ds and x['seed']==seed and x['method']==method)
    differences.append({'seed':seed,'F1_full_minus_baseline':a['repair']['F1']-b['repair']['F1']})
   vals=[x['F1_full_minus_baseline'] for x in differences];paired.append({'dataset':ds,'baseline':method,'n':3,'differences':differences,'mean':statistics.mean(vals),'sample_sd':statistics.stdev(vals)})
 return aggregate,paired

def main():
 if '--self-test' in sys.argv:self_test();return
 lock=(R/'status/scoring_recovery_v3.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 names,pilots,imports,available,costs,resources=verify()
 assert not list(R.glob('cases/*/scoring_started_expansion.json')) and not list(R.glob('cases/*/scoring_started_recovery_v3.json')),'Existing once marker: preserve partial scoring and use reviewed fixed-output interface recovery only'
 assert not (R/'status/scoring_complete.json').exists()
 save(R/'audit/all_expansion_outputs_ready.json',{'passed':True,'at':time.time(),'outputs':available,'valid_main':120,'valid_pilot':5,'imported_scores':25,'new_main_scores':95,'resources':resources,'formal_reference_parsed':False})
 old_rows=load(O/'reports/all_scores.json');old_index={(x['dataset'],x['seed'],x['method']):x for x in old_rows};oldsha=sha(O/'reports/all_scores.json')
 allrows=[];pilotrows=[];qualification=[];budgets=[]
 for name in names+pilots:
  c=R/'cases'/name;meta=load(c/'case.json');methods=['full'] if name in pilots else METHODS
  new_methods=[m for m in methods if (name,m) not in imports];assert new_methods
  with (c/'scoring_started_recovery_v3.json').open('x') as f:
   json.dump({'at':time.time(),'entry_sha256':sha(Path(__file__)),'role':'sole fixed-output scorer new methods only','new_methods':new_methods,'imported_methods':[m for m in methods if (name,m) in imports],'old_score_sha256':oldsha,'formal_reference_read_once_for_new_outputs_only':True},f);f.flush();os.fsync(f.fileno())
  _,dirty=read_csv(c/'public/repair_dirty.csv');gold=truth_align(dirty,load(c/'private/repair_truth.json'))
  _,vd=read_csv(c/'public/validation_dirty.csv');vg=truth_align(vd,load(c/'private/validation_truth.json'))
  mask={'row_keys':[r['__rowkey__'] for r in dirty],'known_fields':[sorted(t) for t in gold],'truth_values_included':False}
  if meta['dataset'] in RETAINED:
   previous=load(O/'cases'/name/'audit/scoring_known_cells.json');assert previous==mask
  save(c/'audit/scoring_known_cells_expansion.json',mask)
  save(c/'audit/scoring_known_validation_cells_expansion.json',{'row_keys':[r['__rowkey__'] for r in vd],'known_fields':[sorted(t) for t in vg],'truth_values_included':False})
  rows=[]
  for method in methods:
   if (name,method) in imports:
    base=copy.deepcopy(old_index[meta['dataset'],meta['seed'],method]);assert base['status']=='scored'
    base.update(case=name,result_origin='imported_original_frozen_score',original_score_sha256=oldsha,original_output_freeze_sha256=imports[name,method]['sha256'],original_output_folder=str(output_dir(name,method,imports)))
   else:
    out=output_dir(name,method,imports);_,actual=read_csv(out/'repair_output.csv');m=metric(dirty,align(dirty,actual),gold,meta['targets']);_,qo=read_csv(out/'validation_output.csv');q=metric(vd,align(vd,qo),vg,meta['targets'])
    qualified=q['changes']>=5 and q['clean']>=10 and q['P']>=.98 and q['normal_damage_rate'] is not None and q['normal_damage_rate']<=.005
    base={'dataset':meta['dataset'],'seed':meta['seed'],'case':name,'method':method,'learning_rows':meta['rows']['learning'],'validation_rows':meta['rows']['validation'],'learning_groups':meta['groups']['learning'],'validation_groups':meta['groups']['validation'],'status':'scored','repair':m,'validation':q,'qualified':qualified,'result_origin':'new_frozen_output','output_folder':str(out)}
    base['count_audit']={'repair_detected_error_edits':sum((not equal(a[f],t[f])) and (not equal(a[f],b[f])) for a,b,t in zip(dirty,align(dirty,actual),gold) for f in meta['targets'] if f in t),'validation_detected_error_edits':sum((not equal(a[f],t[f])) and (not equal(a[f],b[f])) for a,b,t in zip(vd,align(vd,qo),vg) for f in meta['targets'] if f in t)}
    if method=='full':base['original_evidforge_qualification']=load(c/'work/full/selection.json')['passed']
   base['experiment_partition']='pilot' if name in pilots else 'formal'
   base['protocol_log_complete']=not (name in ['beers_s9013','jobposting_small_s9013'] and name in pilots and method=='full')
   if base['protocol_log_complete'] is False:base['protocol_log_limitation']='Original prior actual5 MCP calls closed successfully; Hook log missing, exact review retained; descriptive exploratory result only, excluded from formal means'
   rows.append(base)
   qualification.append({k:base.get(k) for k in ['dataset','seed','method','status','qualified','original_evidforge_qualification','result_origin','experiment_partition','protocol_log_complete','protocol_log_limitation']})
  save(c/'scores_expansion.json',rows);save(c/'status/scored_expansion.json',{'at':time.time(),'new_methods':new_methods,'formal_truth_read_once':True,'records':len(rows),'old_methods_not_regraded':True,'entry':'score_recovery_v3.py'})
  if name in pilots:pilotrows+=rows
  else:allrows+=rows
  budgets.append({'dataset':meta['dataset'],'seed':meta['seed'],'partition':'pilot' if name in pilots else 'formal','groups':meta['groups'],'rows':meta['rows'],'learning_label_cells':meta['learning_label_cells'],'learning_plus_validation_row_fraction':(meta['rows']['learning']+meta['rows']['validation'])/sum(meta['rows'].values())})
 assert len(allrows)==120 and len(pilotrows)==5
 order=config().get('datasets',['address_museum','movies','address_shoppingcenter','beers','library_official','school_small','government_small','jobposting_small']);assert set(order)==RETAINED|NEW
 ag,pair=aggregate_records(allrows,order)
 oldcosts=load(O/'reports/actual_model_costs.json');import_keys={(x['case'],x['method']) for x in available if x['imported']}
 for x in oldcosts:
  key=(x['case'],x['method'])
  if key in import_keys:costs.append({**x,'attempt_origin':'imported_success_historical_calls','original_study':str(O)})
  elif x['case'] in {n for n in names if load(R/'cases'/n/'case.json')['dataset'] in RETAINED} and x['method']=='tabclean':costs.append({**x,'attempt_origin':'retained_prior_failed_TabClean_attempt_cost','original_study':str(O)})
 for path,value in [('all_scores.json',allrows),('pilot_scores.json',pilotrows),('aggregate.json',ag),('paired_differences.json',pair),('qualification.json',qualification),('actual_split_budgets.json',budgets),('actual_model_costs.json',costs)]:save(R/'reports'/path,value)
 save(R/'status/scoring_complete.json',{'at':time.time(),'records':120,'pilot_records':5,'valid':120,'failed':0,'imported':25,'new_main_scored':95,'no_rescoring_allowed':True,'entry':'score_recovery_v3.py','exploratory_pilot_hook_log_gaps':2,'formal_native_hook_complete':True})
 save(R/'status/reports_numerical_ready.json',{'at':time.time(),'fixedscore_review_and_visual_QA_required':True});print('RECOVERY_V3_SCORING_COMPLETE125;main120;imported25;strict_formal_Hooks;2exploratory_gaps_disclosed')
if __name__=='__main__':main()
