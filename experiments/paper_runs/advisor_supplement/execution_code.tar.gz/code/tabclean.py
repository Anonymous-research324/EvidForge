"""作者TabClean同9B适配：只给相同学习区配对，正式数据仅执行已固定脚本。"""
from pathlib import Path
import os,sys,json,time,subprocess,types,uuid,random
from common import ROOT,PY,load,save,sha,freeze,read_csv,write_csv
AUTHOR=ROOT/"references/TabClean_author"
sys.path.insert(0,str(ROOT/"dependencies/tabclean"))
sys.path.insert(0,str(AUTHOR))
def main(case,gpu):
 from runtime import guard
 guard()
 import pandas as pd
 import pipeline as p
 seed=load(case/"case.json")["seed"];random.seed(seed)
 out=case/"outputs/tabclean";out.mkdir(parents=True,exist_ok=False)
 work=out/"author_work";work.mkdir()
 b=load(case/"public/development_bundle.json");cols=load(case/"public/declaration.json")["targets"]
 rs=[r for g in b["learning"] for r in g["records"]]
 # All methods have the same independently grouped teaching boundary.
 fields=["entity_id",*cols]
 dirty=[{"entity_id":g["group"],**{c:r["dirty"][c] for c in cols}} for g in b["learning"] for r in g["records"]]
 write_csv(work/"teaching_dirty.csv",fields,dirty)
 df=pd.DataFrame(dirty);order=list(df.sample(n=len(df),random_state=42).index)
 lines=["# dev_row | column | dirty_value | correct_value"]
 for local,i in enumerate(order):
  for c,v in rs[i]["truth"].items():
   if c in cols and str(rs[i]["dirty"][c])!=str(v):lines.append(f"{local} | {c} | {rs[i]['dirty'][c]} | {v}")
 p.OPENAI_API_KEY="local-only";count=0
 class Model:
  model_name="Qwen3.5-9B"
 def make(*a,**k):return Model()
 def call(llm,prompt,agent):
  nonlocal count
  count+=1
  body={"_trace_tag":("Tab"+case.name+agent+str(count)).replace("_","").replace("-",""),"messages":[{"role":"user","content":prompt}],"max_tokens":8192,"seed":seed,"temperature":0}
  env={**os.environ,"EF_GPU":str(gpu),"EF_SEED":str(seed)}
  t=time.monotonic();r=subprocess.run([PY,"-B",str(ROOT/"code/model_service.py"),"call"],input=json.dumps(body),capture_output=True,text=True,env=env,timeout=330)
  if r.returncode:raise RuntimeError(r.stderr)
  raw=json.loads(r.stdout);save(out/f"call_{count:03d}.json",{"agent":agent,"usage":raw.get("usage"),"seconds":time.monotonic()-t,"response_finish":raw["choices"][0]["finish_reason"]})
  if raw["choices"][0]["finish_reason"]!="stop":raise ValueError("Truncated TabClean model output")
  return raw["choices"][0]["message"]["content"]
 def safe_run(code,where,timeout=120):
  ident="exec_"+uuid.uuid4().hex;script=Path(where)/(ident+".py");script.write_text(code)
  cmd=[PY,"-B",str(ROOT/"code/safe_exec.py"),str(script),str(case),str(work)]
  try:
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"2"})
   save(Path(where)/(ident+".json"),{"returncode":r.returncode,"stdout":r.stdout,"stderr":r.stderr})
   return {"ok":r.returncode==0,"stdout":r.stdout,"stderr":r.stderr}
  except subprocess.TimeoutExpired as e:return {"ok":False,"stdout":"","stderr":"Execution timeout"}
 p._make_llm=make;p._call_llm=call;p.run_code=safe_run
 state={k:"" for k in p.State.__annotations__}
 state.update(dirty_path=str((work/"teaching_dirty.csv").resolve()),work_dir=str(work.resolve()),dev_rows=len(dirty),dev_gt_errors="\n".join(lines),best_f1=-1.,best_iteration=0,iteration=0,no_improve_count=0,eval_history="{}")
 start=time.monotonic();result=p.build_pipeline().invoke(state,{"recursion_limit":120})
 code=result.get("best_cleaning_code") or result.get("cleaning_code","")
 if not code:raise ValueError("No executable TabClean program")
 (out/"frozen_program.py").write_text(code)
 save(out/"program_freeze.json",{"sha256":sha(out/"frozen_program.py"),"author_sha":load(ROOT/"audit/author_source.json")["commit"],"actual_calls":count,"development_rows":len(dirty),"formal_reference_read":False,"author_max_iterations":p.MAX_ITERATIONS,"teacher_only_original_pipeline":True,"adaptations":["all agents same local9B BF16 temp0 seeded","fixed same learning groups; no adaptive formal annotation","author development graph on teaching only","bounded file/network execution","fixed script applied to formal dirty data without debugger"]})
 # Formal input has no labels and no original answers. No code revision after this freeze.
 src_fields,src=read_csv(case/"public/repair_dirty.csv")
 projected=[{c:r[c] for c in fields} for r in src]
 write_csv(work/"formal_dirty.csv",fields,projected)
 prefix=f"INPUT_PATH = {str(work/'formal_dirty.csv')!r}\nOUTPUT_PATH = {str(work/'formal_output.csv')!r}\n"
 er=safe_run(prefix+code,work,300)
 if not er["ok"] or not (work/"formal_output.csv").exists():raise RuntimeError("Fixed TabClean formal execution failed: "+er["stderr"][-1000:])
 ff,rows=read_csv(work/"formal_output.csv")
 if ff!=fields or len(rows)!=len(src) or any(a["entity_id"]!=b["entity_id"] for a,b in zip(rows,src)):raise ValueError("TabClean output shape/IDs changed")
 output=[{**original,**{c:r[c] for c in cols}} for original,r in zip(src,rows)]
 write_csv(out/"repair_output.csv",src_fields,output);save(out/"receipt.json",{"seconds":time.monotonic()-start,"calls":count,"seed":seed,"same_model_adaptation_not_original_GPT_result":True,"formal_reference_read":False})
 save(out/"output_freeze.json",{"files":freeze(out)})
if __name__=="__main__":
 import argparse,traceback
 a=argparse.ArgumentParser();a.add_argument("--case",required=True);a.add_argument("--gpu",type=int,required=True);a=a.parse_args();case=Path(a.case)
 try:main(case,a.gpu)
 except Exception as e:save(case/"status/tabclean_failure.json",{"error":repr(e),"traceback":traceback.format_exc()});raise
