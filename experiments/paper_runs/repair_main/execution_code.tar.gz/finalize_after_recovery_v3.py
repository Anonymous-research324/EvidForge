"""Finalization after reviewed original branch interruptions; no algorithm changes."""
from pathlib import Path
import sys,time,os,traceback,subprocess,fcntl
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import run_multiseed as locked
import continue_cdc_and_finalize_v2 as recovery
def main():
 with (ROOT/"status/finalize_v3.lock").open("a") as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  locked.save(ROOT/"status/finalize_v3_owner.json",{"pid":os.getpid(),"started":time.time()})
  original=locked.load(ROOT/"status/owner.json")["pid"]
  while locked.live_command(original) or not (ROOT/"status/gpu1015_recovery_complete.json").exists() or not (ROOT/"status/cdc_recovery_complete.json").exists():
   errors=[str(p) for p in [ROOT/"status/gpu1015_recovery_error.json",ROOT/"status/cdc_recovery_error.json"] if p.exists()]
   # CDC v2 may reject the now reviewed extra gpu1015 failure after waiting; that rejection is expected.
   unexpected=[]
   for p in errors:
    if p.endswith("cdc_recovery_error.json") and "Additional original branch failure requires review" in locked.load(p)["error"]:continue
    unexpected.append(p)
   if unexpected:raise RuntimeError("Recovery needs review: "+str(unexpected))
   time.sleep(25)
  failures=locked.load(ROOT/"status/failures.json")
  assert set(failures)=={"cdc","gpu1015"},"Unreviewed failures: "+str(failures)
  for seed in locked.SEEDS:
   r=locked.case(seed);recovery.check_all(seed)
   for name in locked.NAMES:
    manifest=locked.load(r/"datasets"/name/"input_freeze.json")
    for zone in ["public","private"]:
     for rel,h in manifest[zone].items():assert locked.digest(r/"datasets"/name/zone/rel)==h
   marker=r/"audit/scoring_started.json"
   assert not marker.exists(),"Once-only marker exists; do not regrade"
   locked.save(marker,{"time":time.time(),"available_outputs_closed":True,"reviewed_cdc_NA":True,"pure_format_recovery_disclosed":True})
   locked.invoke(seed,"final_scoring","score_all.py",args=["--close-incomplete"])
   locked.invoke(seed,"postgres_stop","start_owned_postgres.py",args=["stop"],timeout=90)
  p=subprocess.run([locked.PY,"-B",str(ROOT/"aggregate_three_seeds.py")],cwd=ROOT)
  assert p.returncode==0
  locked.save(ROOT/"status/complete.json",{"time":time.time(),"seeds":[1013,1014,1015],"sample_sd_ddof":1,
   "reviewed_native_failures_disclosed_na":True,"format_recovery_retained_and_disclosed":True})
if __name__=="__main__":
 try:main()
 except Exception as e:
  locked.save(ROOT/"status/finalize_v3_error.json",{"time":time.time(),"error":repr(e),"traceback":traceback.format_exc()})
  raise
