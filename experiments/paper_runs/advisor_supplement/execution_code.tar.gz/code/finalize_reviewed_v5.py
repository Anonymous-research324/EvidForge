"""等待唯一原队列自然结束，只闭合逐项已审查N/A；其他未知错误继续阻止评分。"""
from pathlib import Path
import os,time,traceback
from common import ROOT,PY,load,save
from controller import run
from review_source_unavailable_v5 import review
def active(pid,entry):
    p=Path("/proc")/str(pid)/"cmdline"
    return p.exists() and entry.encode() in p.read_bytes()
def main():
    save(ROOT/"status/finalizer_owner_v5.json",{"pid":os.getpid(),"at":time.time()})
    while True:
        for n in load(ROOT/"configs/cases.json"):review(ROOT/"cases"/n)
        a=load(ROOT/"status/current_dispatch_v4.json")["pid"];b=load(ROOT/"status/current_satellite_dispatch_v4.json")["pid"]
        if not active(a,"queue_v4.py") and not active(b,"queue_v4.py"):break
        time.sleep(20)
    if (ROOT/"status/controller_error_v4.json").exists() or (ROOT/"status/satellite_error_v4.json").exists():raise ValueError("Unknown controller error; independent review required")
    outcomes=load(ROOT/"status/outcomes_v4.json")
    names=load(ROOT/"configs/cases.json")
    if set(outcomes)!=set(names):raise ValueError("Not all cases attempted")
    unavailable=[]
    for n in names:
        c=ROOT/"cases"/n;r=outcomes[n]
        if r["worker_returncode"]!=0:
            if not review(c):raise ValueError("Unknown worker failure: "+n)
            unavailable.append(n)
        elif not (c/"status/closed.json").exists():raise ValueError("Missing successful closure: "+n)
        if r["tabclean_returncode"] not in [None,0]:raise ValueError("Unknown TabClean failure: "+n)
    from audit_ready_v5 import verify
    counts=verify()
    save(ROOT/"status/all_model_outputs_closed.json",{"at":time.time(),"cases":len(names),"reviewed_source_unavailable":unavailable,"counts":counts,"original_failures_preserved":True})
    for g in [0,1]:
        rc=run("model_service.py",["stop"],ROOT/"logs"/f"service_stop_gpu{g}_v5.log",{**os.environ,"EF_GPU":str(g)})
        if rc:raise ValueError("Owned model cleanup needs review")
    rc=run("score_review_v3.py",[],ROOT/"logs/independent_scoring_review_v3.log",dict(os.environ))
    if rc:raise RuntimeError("Fixed-output scoring failed; preserve all once markers")
    save(ROOT/"status/complete_reviewed_v5.json",{"at":time.time(),"unavailable":unavailable,"cases":len(names)})
if __name__=="__main__":
    try:main()
    except Exception as e:
        save(ROOT/"status/finalize_review_v5_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()})
        raise
