"""同原评分公式；仅为已审查的源内保护拒绝项写显式N/A，不读取其正式参考。"""
import time
from common import ROOT,load,save
import score_v2
previous=score_v2.score.score_case
def patched(case):
    p=case/"status/source_closed_unavailable.json"
    if not p.exists():return previous(case)
    if (case/"audit_scoring_started.json").exists():raise ValueError("Once marker exists; preserve fixed-output audit")
    receipt=load(p);cfg=load(case/"case.json")
    save(case/"audit_scoring_started.json",{"at":time.time(),"arms":receipt["arms"],"role":"independent closure of reviewed unavailable source","formal_reference_read":False})
    results=[{**cfg,"arm":arm,"status":"N/A","reason":receipt,"repair":{k:None for k in ["P","R","F1","normal_damage","detection_AUC","errors","normal","changes","exact","damaged"]},"downstream":None,"receipt":{"unavailable":True,"actual_model_calls":0}} for arm in receipt["arms"]]
    save(case/"scores.json",results);save(case/"status/scored.json",{"at":time.time(),"rows":len(results),"unavailable":True,"formal_reference_read":False})
    return results
score_v2.score.score_case=patched
if __name__=="__main__":score_v2.score.main()
