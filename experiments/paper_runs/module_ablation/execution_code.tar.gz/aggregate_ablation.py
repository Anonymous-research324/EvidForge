"""Only aggregate frozen per-seed ablation scores and public execution records."""
from pathlib import Path
import json,math,statistics,time,hashlib
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
SEEDS=[1013,1014,1015];ARMS=['A','B','C','D','E','F'];NAMES=P['display_order']
def load(p):return json.loads(Path(p).read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stats(v):
 ok={s:x for s,x in v.items() if isinstance(x,(int,float)) and math.isfinite(x)}
 return {'n':len(ok),'expected_n':3,'per_seed':v,'mean':statistics.mean(ok.values()) if len(ok)==3 else None,'sample_sd':statistics.stdev(ok.values()) if len(ok)==3 else None,'ddof':1,'status':'complete_n3' if len(ok)==3 else 'N/A_incomplete_n3'}
def cell(v,mult=1):
 return f"{mult*v['mean']:.3f} ± {mult*v['sample_sd']:.3f}" if v['mean'] is not None else f"N/A（{v['n']}/3）"
def main():
 paths={1013:Path(P['original_ablation_scores']),**{s:Path(P['new_roots'][str(s)])/'reports/scores.json' for s in [1014,1015]}}
 assert sha(paths[1013])==P['original_ablation_scores_sha256']
 rows={s:load(p) for s,p in paths.items()}
 assert all(len(v)==36 for v in rows.values())
 idx={s:{(x['dataset'],x['arm']):x for x in v} for s,v in rows.items()}
 records=[];lookup={};paired=[]
 labels={'A':'完整EvidForge','B':'关闭学得的纠错变换','C':'关闭9B新增规则执行','D':'关闭最终置信门槛','E':'关闭反馈改写','F':'关闭项目Hook'}
 for n in NAMES:
  for a in ARMS:
   v={s:idx[s][n,a] for s in SEEDS};task=v[1013]['task']
   down=['macro_F1','AUC'] if task=='classification' else ['R2','MAE']
   metrics={'repair':{k:stats({s:x['repair'][k] for s,x in v.items()}) for k in ['P','R','F1','damage']},
            'downstream':{k:stats({s:x['downstream'][k] for s,x in v.items()}) for k in down}}
   unqualified=[]
   for s in SEEDS:
    if a in ['A','E','F']:
     root=Path(P['original_ablation_root'] if s==1013 else P['new_roots'][str(s)])
     selected=load(root/'work'/n/a/'selection.json')
     if not selected['passed']:unqualified.append(s)
    else:
     root=Path(P['original_ablation_root'] if s==1013 else P['new_roots'][str(s)])
     if not load(root/'work'/n/'A/selection.json')['passed']:unqualified.append(s)
   item={'dataset':n,'arm':a,'label':labels[a],'task':task,'metrics':metrics,'per_seed_records':v,'research_prior_fallback_seeds':unqualified}
   lookup[n,a]=item;records.append(item)
  for a in ARMS[1:]:
   entry={'dataset':n,'ablated_arm':a,'definition':'complete A minus ablation, paired within same seed','metrics':{}}
   for group,keys in [('repair',['P','R','F1','damage']),('downstream',down)]:
    entry['metrics'][group]={}
    for k in keys:
     values={}
     for s in SEEDS:
      full=idx[s][n,'A'][group][k];ablated=idx[s][n,a][group][k]
      values[s]=full-ablated if isinstance(full,(int,float)) and isinstance(ablated,(int,float)) else None
     entry['metrics'][group][k]=stats(values)
   paired.append(entry)
 lines=['# EvidForge 第三个实验：三种子消融（均值 ± 标准差）','',
 '原1013结果不变；补充1014、1015。每个新种子复用其第二实验的同污染输入、划分、固定XGBoost及源内基础拟合。六表为此前选定展示范围，非新盲测；旧八表完整保留。','',
 '六组设置原样保留，组件关闭后没有变化或更好均如实报告。A/E/F从固定同种子学习起点重新真实native学习；B/C/D使用同轮A已学技能，仅关闭对应执行机制，不作按正式答案补偿。','',
 '每项为三个种子等权均值 ± 样本标准差（ddof=1，n=3）。标准差反映本次随机划分/污染/学习的重复波动，不代表置信区间或统计显著性。','',
 '## 表1：准确修复F1 / 正常格误改率（%）','',
 'F1越高越好，正常格误改率越低越好。未改任何格时F1可为0，修复P无定义时保留N/A，不伪造精确率。','']
 def header(task=False):
  h=['| 设置 / 数据集 | '+' | '.join(P['display_names'][n] for n in NAMES)+' |','|---|'+'---:|'*len(NAMES),
     '| 原始样本数 | '+' | '.join(str(P['catalog'][n]['rows']) for n in NAMES)+' |',
     '| 特征数 | '+' | '.join(str(P['catalog'][n]['columns']) for n in NAMES)+' |']
  if task:h+=['| 任务 / 指标 | '+' | '.join('分类 F1/AUC' if n in P['classification'] else '回归 R²/MAE' for n in NAMES)+' |']
  return h
 lines+=header()
 for a in ARMS:
  v=[]
  for n in NAMES:
   item=lookup[n,a];m=item['metrics']['repair']
   v.append(cell(m['F1'])+' / '+cell(m['damage'],100)+'%'+('†' if item['research_prior_fallback_seeds'] else ''))
  lines.append('| '+('**'+labels[a]+'**' if a=='A' else labels[a])+' | '+' | '.join(v)+' |')
 lines+=['','## 表2：下游预测表现','',
 '三分类格为宏F1 / 概率ROC-AUC（均越高越好）；三回归格为R² / MAE（前者越高越好，后者越低越好）。分类F1与表1格子修复F1不同。','']+header(True)
 for a in ARMS:
  v=[]
  for n in NAMES:
   item=lookup[n,a]
   v.append(' / '.join(cell(x) for x in item['metrics']['downstream'].values())+('†' if item['research_prior_fallback_seeds'] else ''))
  lines.append('| '+('**'+labels[a]+'**' if a=='A' else labels[a])+' | '+' | '.join(v)+' |')
 lines+=['','## 配对差值：完整系统A − 关闭组件','',
 '修复F1差值为正代表完整系统更高，误改率差值为负代表完整系统更安全。以下按同种子先相减，再计算均值/样本标准差，不能把组件贡献直接相加。','']
 lines+=['| 关闭的组件 / 数据集 | '+' | '.join(P['display_names'][n] for n in NAMES)+' |','|---|'+'---:|'*len(NAMES)]
 for a in ARMS[1:]:
  values=[]
  for n in NAMES:
   m=next(x for x in paired if x['dataset']==n and x['ablated_arm']==a)['metrics']['repair']
   values.append(cell(m['F1'])+' / '+cell(m['damage'],100)+'个百分点')
  lines.append('| '+labels[a]+' | '+' | '.join(values)+' |')
 lines+=['','## 实际开关影响、复现及真实调用','']
 costs={}
 for s in [1013,1014,1015]:
  b=Path(P['original_ablation_root'] if s==1013 else P['new_roots'][str(s)])
  counts={};parity={};changes={}
  for a in ['A','E','F']:
   native=[load(p) for p in (b/'work').glob('*/'+a+'/*_stage/native/result.json')]
   assert len(native)==12 and all(x['closed'] and x['native_exit_code']==0 for x in native)
   counts[a]={'native_sessions':len(native),'actual9B_calls':sum(x['real9B_calls'] for x in native),'synthetic_controls':sum(x['synthetic_control_count'] for x in native),
    'native_seconds_sum':sum(x['seconds'] for x in native),'usage':{k:sum((u.get(k,0) or 0) for x in native for u in x.get('actual_usage',[])) for k in ['prompt_tokens','completion_tokens','total_tokens']}}
  if s!=1013:parity=load(b/'audit/outputs_and_learning_pre_score.json')['new_A_old_full_byteparity']
  else:parity={n:True for n in NAMES}
  import csv
  for n in NAMES:
   def read(a):
    with (b/'outputs'/n/a/'repair_output.csv').open(newline='') as f:return list(csv.DictReader(f))
   full=read('A');changes[n]={}
   for a in ARMS[1:]:
    out=read(a);assert len(full)==len(out)
    changes[n][a]=sum(x[k]!=y[k] for x,y in zip(full,out) for k in x if k!='entity_id')
  costs[s]={'by_arm':counts,'new_A_matches_existing_complete':parity,'changed_output_cells':changes}
  lines.append('- seed'+str(s)+'：A/E/F真实调用分别'+ '/'.join(str(counts[a]['actual9B_calls']) for a in ['A','E','F'])+'；A与对应第二实验完整输出字节一致 '+str(sum(parity.values()))+'/6。')
 lines+=['','† 对应组有种子未通过独立外部部署校验，按预定规则采用prior研究回退；不是运行失败，也不代表已合格登记。具体种子：']
 for x in records:
  if x['research_prior_fallback_seeds']:lines.append('- '+P['display_names'][x['dataset']]+' / '+labels[x['arm']]+'：'+','.join(map(str,x['research_prior_fallback_seeds']))+'。')
 lines+=['','方法边界：B只关闭七种学得变换候选来源；C只不执行可选9B生成配置；D只去最后采用函数score/margin门槛，其他保护保留；E只关闭检验反馈驱动改写、提案数配对A且评价器和外部校验仍在；F只不注册项目Hook，后端权限/验证保留。不能将Hook或循环无F1改善写成成功贡献，不预设三个变量都必须阳性。真实Codex+MCP+Hook负责学习，正式repair为standalone程序。','',
 '全部输出封存后每个新种子只一次独立scorer读取正式参考/未污染留出，聚合只读scores与公开输出/学习记录；未按正式答案选规则或调参。缺失不填0、不用n2伪装三种子SD；原1013和第二实验结果完全保留。']
 result={'seeds':SEEDS,'ddof':1,'records':records,'paired_differences':paired,'process_statistics':costs,'scores_sha256':{s:sha(p) for s,p in paths.items()},'selected_six_not_new_blind':True,'created_at':time.time()}
 save(ROOT/'reports/three_seed_ablation_aggregate.json',result)
 (ROOT/'reports/第三个实验_三种子消融均值与标准差.md').write_text('\n'.join(lines)+'\n')
 print('ABLATION_AGGREGATED',len(records),'cells',flush=True)
if __name__=='__main__':main()
