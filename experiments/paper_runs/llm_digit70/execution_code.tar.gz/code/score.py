"""Only formal scorer, after all10cases frozen. Original equal/P-R-F1 unchanged."""
from pathlib import Path
import sys,time,collections
from common import ROOT as R,load,save,sha,read_csv
sys.path.insert(0,str(R/'engine/source_runtime'))
from unseen_table.common import equal
def metrics(dirty,out,truth,targets):
 errors=normal=changes=exact=damaged=0
 for a,b,t in zip(dirty,out,truth):
  for col in targets:
   if t.get(col,'')=='':continue
   wrong=not equal(a[col],t[col]);changed=not equal(a[col],b[col])
   errors+=wrong;normal+=not wrong;changes+=changed
   exact+=wrong and changed and equal(b[col],t[col]);damaged+=not wrong and changed
 p=exact/changes if changes else None;rec=exact/errors if errors else 0.
 return {'P':p,'R':rec,'F1':2*p*rec/(p+rec) if p and rec else 0.,'normal_damage_percent':100*damaged/normal if normal else None,'errors':errors,'normal':normal,'changes':changes,'exact':exact,'damaged':damaged,'edit01_AUC':(1+(changes-damaged)/errors-damaged/normal)/2 if errors and normal else None}
def case_score(c):
 if (c/'status/scored.json').exists():return load(c/'scores.json')
 marker=c/'status/audit_scoring_started.json'
 if marker.exists():raise RuntimeError('Once-only marker exists; reviewed fixed-output recovery only')
 meta=load(c/'case.json');targets=load(c/'public/declaration.json')['targets']
 fields,dirty=read_csv(c/'public/repair_dirty.csv')
 for arm in ['full','no_llm']:
  for p,h in load(c/'outputs'/arm/'output_freeze.json')['files'].items():assert sha(c/'outputs'/arm/p)==h
 save(marker,{'at':time.time(),'formal_reference_read':True,'no_future_method_updates':True,'all_fixed_outputs':True})
 tf,truth=read_csv(c/'private/repair_reference.csv');keys=load(c/'private/repair_rowkeys.json')['row_keys'];tags=load(c/'private/error_annotations.json')['cells']
 assert fields==tf and len(truth)==len(dirty)==len(keys)
 assert all(a['entity_id']==b['entity_id'] for a,b in zip(dirty,truth))
 expected={(keys[i],col) for i,(a,t) in enumerate(zip(dirty,truth)) for col in targets if t[col]!='' and not equal(a[col],t[col])}
 assert expected=={(x['row_key'],x['field']) for x in tags if x['zone']=='repair'}
 evidence=load(c/'outputs/no_llm/candidate_evidence.json')['cells']
 reach={};den=collections.Counter()
 for q in evidence:
  i,col=q['row'],q['field'];t=truth[i][col]
  if t=='' or equal(dirty[i][col],t):continue
  inpool=any(equal(x['value'],t) for x in q['options']);allowed=any(equal(x['value'],t) and x['forward'] for x in q['options'])
  label='reachable' if allowed else 'in_pool_forward_blocked' if inpool else 'pool_absent'
  reach[(i,col)]=label;den[label]+=1
 outs={arm:read_csv(c/'outputs'/arm/'repair_output.csv')[1] for arm in ['full','no_llm']}
 pair=collections.Counter()
 for i,col in reach:
  f=equal(outs['full'][i][col],truth[i][col]);n=equal(outs['no_llm'][i][col],truth[i][col])
  pair['added_correct']+=f and not n;pair['lost_correct']+=n and not f
 pair['net_new_correct']=pair['added_correct']-pair['lost_correct']
 rows=[]
 for arm,out in outs.items():
  assert len(out)==len(truth) and all(x['entity_id']==y['entity_id'] for x,y in zip(out,truth))
  num=collections.Counter()
  for (i,col),label in reach.items():num[label]+=equal(out[i][col],truth[i][col])
  strata={k:{'errors':den[k],'exact':num[k],'R':num[k]/den[k] if den[k] else None} for k in ['reachable','in_pool_forward_blocked','pool_absent']}
  sel=load(c/'work'/arm/'selection.json')
  rows.append({**meta,'arm':arm,'repair':metrics(dirty,out,truth,targets),'candidate_strata':strata,'pair':dict(pair),'qualified':sel['passed'],'selected_kind':sel['kind'],'receipt':load(c/'outputs'/arm/'receipt.json')})
 save(c/'scores.json',rows);save(c/'status/scored.json',{'at':time.time(),'records':2})
 return rows
def main():
 assert load(R/'audit/all_outputs_ready_integrity.json')['passed']
 rows=[]
 for n in load(R/'configs/cases.json'):rows+=case_score(R/'cases'/n)
 save(R/'reports/all_scores.json',rows)
 save(R/'audit/scored_outputs_freeze.json',{'all_scores':sha(R/'reports/all_scores.json'),'cases':{n:sha(R/'cases'/n/'scores.json') for n in load(R/'configs/cases.json')}})
 save(R/'status/scoring_complete.json',{'at':time.time(),'records':len(rows)})
 print('SCORED',len(rows),flush=True)
if __name__=='__main__':main()
