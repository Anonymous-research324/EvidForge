
"""Hash/closure/usage audit; private material is hashed only, never parsed."""
from pathlib import Path
import os,time,json,socket,subprocess
from common import ROOT,ENGINE,load,save,sha
def fixed():
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ENGINE/rel)==h,rel
 for p,h in load(ROOT/"audit/protected_old_files.json").items():assert sha(p)==h,p
 for record in ["curation_freeze.json","execution_freeze.json"]:
  for rel,h in load(ROOT/"audit"/record)["files"].items():assert sha(ROOT/rel)==h,rel
def input_case(case):
 f=load(case/"input_freeze.json")
 for section in ["source","batches","private","curator","generator_inputs"]:
  for rel,h in f[section].items():assert sha(case/section/rel)==h,str(case/section/rel)
 assert sha(case/"case.json")==f["case_sha"]
 assert sha(case/"audit/partition_assertions.json")==f["partition_sha"]
def requests():
 cases=load(ROOT/"configs/cases.json");rows=[]
 for gpu in [0,1]:
  for p in sorted((ROOT/"services"/("gpu"+str(gpu))/"requests").glob("*")):
   if not p.is_dir():continue
   req=load(p/"request.json");res=load(p/"response.json")
   matched=[n for n in cases if ("Reuse"+n+"full").replace("_","") in p.name]
   assert len(matched)==1,("Unbound trace",p.name)
   meta=load(ROOT/"cases"/matched[0]/"case.json")
   assert req["seed"]==meta["seed"] and gpu==meta["gpu"]
   assert req["temperature"]==0 and req["model"]=="evidforge-reuse-9b-gpu"+str(gpu)
   assert not (p/"failure.json").exists()
   rows.append({"case":matched[0],"gpu":gpu,"tag":p.name,"request_sha":sha(p/"request.json"),"response_sha":sha(p/"response.json"),"usage":res.get("usage",{}),"seconds":load(p/"timing.json")["seconds"]})
 return rows
def resource_snapshot():
 result={"at":time.time(),"ports":{},"services":{}}
 for gpu in [0,1]:
  port=8141+gpu
  with socket.socket() as s:active=s.connect_ex(("127.0.0.1",port))==0
  result["ports"][str(port)]={"listening":active}
  owner=load(ROOT/"services"/("gpu"+str(gpu))/"owner.json")
  cmd=Path("/proc")/str(owner["pid"])/"cmdline"
  own_alive=cmd.exists() and owner["name"].encode() in cmd.read_bytes()
  result["services"][str(gpu)]={"owner":owner,"owned_server_alive":own_alive}
 result["compute"]=subprocess.check_output(["nvidia-smi","--query-compute-apps=pid,gpu_uuid,used_memory","--format=csv,noheader,nounits"],text=True).strip().splitlines()
 result["gpus"]=subprocess.check_output(["nvidia-smi","--query-gpu=index,memory.used,utilization.gpu","--format=csv,noheader,nounits"],text=True).strip().splitlines()
 return result
def audit_ready():
 fixed();details=[];native=[]
 assert (ROOT/"status/inference_disabled.json").exists()
 for name in load(ROOT/"configs/cases.json"):
  c=ROOT/"cases"/name;input_case(c)
  assert (c/"status/learning_closed.json").exists() and (c/"status/outputs_closed.json").exists()
  assert not list((c/"status").glob("*failure*.json")),name
  cap=load(c/"sealed/capsule.json")
  assert sha(c/"sealed/capsule.json")==load(c/"status/learning_closed.json")["capsule_sha"]
  for path,h in cap["files"].items():assert sha(path)==h,path
  for label in ["B1","B2","B3","combined_control"]:
   out=c/"outputs"/label
   for rel,h in load(out/"output_freeze.json")["files"].items():assert sha(out/rel)==h
   rec=load(out/"receipt.json");assert rec["new_model_calls"]==rec["new_tokens"]==rec["fit_attempts"]==rec["network_attempts"]==rec["subprocess_attempts"]==0
   assert rec["capsule_sha"]==sha(c/"sealed/capsule.json")
   if label=="combined_control":assert rec["combined_parity"] is True
  for kind in ["prior","context"]:
   session=c/"work/full"/(kind+"_stage/native_v3");n=load(session/"result.json");budget=load(session/"budget.json")
   assert n["closed"] and n["native_exit_code"]==n["synthetic_control_count"]==0
   assert n["real9B_calls"]==budget["calls"]==5
   assert n["project_hook_registered"] and budget["pending_call"] is None
   native.append({"case":name,"kind":kind,"result":n,"result_sha":sha(session/"result.json"),"budget_sha":sha(session/"budget.json")})
  details.append({"case":name,"capsule_sha":sha(c/"sealed/capsule.json"),"batch_inputs_sha":load(c/"input_freeze.json")["batches"],"qualification_passed":cap["qualification_passed"],"combined_parity":True})
 calls=requests();assert len(calls)==sum(n["result"]["real9B_calls"] for n in native)==60
 assert len(native)==12
 assert sha(ROOT/"audit/requests_at_model_shutdown.json")==load(ROOT/"status/inference_disabled.json")["request_ledger_sha"]
 assert calls==load(ROOT/"audit/requests_at_model_shutdown.json")["requests"]
 resource=resource_snapshot()
 assert not any(v["listening"] for v in resource["ports"].values())
 assert not any(v["owned_server_alive"] for v in resource["services"].values())
 save(ROOT/"audit/outputs_ready.json",{"passed":True,"at":time.time(),"cases":details,"native":native,"requests":calls,"resource":resource,"formal_rows_read":0})
 return details
if __name__=="__main__":audit_ready()
