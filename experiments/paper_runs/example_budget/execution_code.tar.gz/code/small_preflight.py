"""Invented data only: 5/10/20 group source preparation, no model/reference access."""
from pathlib import Path
import os,sys,subprocess,time,traceback,hashlib,json
from common import ROOT,ENGINE,PY,save,load,sha
def main():
 out=ROOT/"audit/synthetic";out.mkdir(exist_ok=False)
 schema={"id":"invented-budget","provenance":"invented preflight, not empirical data","entity_fields":["entity_id"],"targets":["a","b"],"protected_fields":[],"visible_context_fields":[],"fields":{"entity_id":{"role":"identity","type":"string","identity":True},"a":{"role":"target","type":"number"},"b":{"role":"target","type":"number"}}}
 def groups(ids):
  return [{"group":"g"+str(i),"provenance":"invented-only","records":[{"row_key":"r"+str(i),"dirty":{"entity_id":"g"+str(i),"a":str(2*(i+10)) if i%2 else "ERR"+str(i+10)+"BAD","b":str(100+i*3)},"truth":{"a":str(i+10),"b":str(100+i*3)}}]} for i in ids]
 save(out/"declaration.json",schema);save(out/"context.json",{"dataset":"invented_budget"})
 records=[]
 for n,enabled in [(5,True),(10,True),(20,True),(20,False)]:
  name="n"+str(n)+("_old_admission" if not enabled else "")
  p=out/(name+"_bundle.json");save(p,{"learning":groups(range(n)),"validation":groups(range(100,100+n))})
  env={**os.environ,"EF_SEED":"1013","EF_ARM":"full","EF_BUDGET_ADAPTER":"1" if enabled else "0","OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1","PYTHONDONTWRITEBYTECODE":"1"}
  t=time.monotonic()
  with (out/(name+".log")).open("x") as f:
   cmd=[str(ROOT/"code/ef-python"),str(ENGINE/"repair_platform.py"),"prepare-heldout","--labels",str(p),"--declaration",str(out/"declaration.json"),"--context",str(out/"context.json"),"--out",str(out/(name+"_onboarding"))]
   proc=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
  records.append({"learning_groups":n,"validation_groups":n,"small_adapter":enabled,"exit_code":proc.returncode,"seconds":time.monotonic()-t})
  save(ROOT/"audit/synthetic_progress.json",records)
  if proc.returncode:raise RuntimeError("Synthetic source preparation failed: "+name)
  assert load(out/(name+"_onboarding/partition_freeze.json"))["validation_sent_to_learning"] is False
 # Old vs new counts have identical 20-group numerical fold artifacts, excluding timing metadata.
 def numerical(v):
  if isinstance(v,dict):return {k:numerical(x) for k,x in v.items() if k not in {"seconds","elapsed_seconds","timestamp","created_at"}}
  if isinstance(v,list):return [numerical(x) for x in v]
  return v
 compared=[]
 for i in range(3):
  rel="prior_prepared/base_skill/fold-"+str(i)+"-model.json"
  a=load(out/"n20_onboarding"/rel);b=load(out/"n20_old_admission_onboarding"/rel)
  assert numerical(a)==numerical(b),rel
  compared.append(rel)
 save(ROOT/"audit/small_sample_preflight_pass.json",{"stages":records,"numerical20_new_old_equal":compared,"formal_reads":0,"actual_model_calls":0,"supported_learning_groups":[5,10,20],"at":time.time()})
 print("SMALL_SAMPLE_PREFLIGHT_PASS",flush=True)
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"audit/small_sample_preflight_failure.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
