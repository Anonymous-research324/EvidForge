"""Stage-only continuation; original numerical worker is imported unchanged."""
from pathlib import Path
import os,argparse,traceback,time,json
from common import ROOT as R,PY,load,save,sha
import worker as W
original_run=W.run

def run(cmd,log,env):
 cmd=[str(R/'code/native_v4.py') if str(x) in [str(R/'code/native_v3.py'),str(R/'code/native.py')] else str(R/'code/model_service_recovery_v3.py') if str(x)==str(R/'code/model_service.py') else x for x in cmd]
 return original_run(cmd,log,env)
W.run=run

def main():
 a=argparse.ArgumentParser();a.add_argument('action',choices=['case','execute']);a.add_argument('--case',required=True);a.add_argument('--gpu',type=int,default=0);a.add_argument('--arm');a.add_argument('--skill');q=a.parse_args();c=Path(q.case)
 if q.action=='execute':W.execute_impl(c,q.arm,Path(q.skill));return
 from runtime import guard
 guard();meta=load(c/'case.json');env={**os.environ,'EF_SEED':str(meta['seed']),'EF_GPU':str(q.gpu),'OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'}
 if (c/'outputs/full/output_freeze.json').exists():
  assert all(sha(c/'outputs/full'/p)==h for p,h in load(c/'outputs/full/output_freeze.json')['files'].items());return
 prior=c/'work/full/prior_stage/native_v3/result.json'
 if prior.exists() and not load(prior).get('hook_contract_passed',True):
  review=load(R/'audit/pilot_hook_gap_review_v3.json');row=next(x for x in review['exceptions'] if x['case']==c.name and x['stage']=='prior');assert meta['seed']==9013 and review['exploratory_only'] and review['not_protocol_complete']
  for p,h in row['evidence_files'].items():assert sha(R/p)==h
 save(c/'status/recovery_owner_v3.json',{'pid':os.getpid(),'gpu':q.gpu,'at':time.time(),'original_source_fits_and_calls_reused':True})
 W.learn(c,'full',env);W.execute(c,'full',env)
 save(c/'status/closed_recovery_v3.json',{'at':time.time(),'arms':['full'],'formal_reference_read':False,'pilot_protocol_log_exception_disclosed':meta['seed']==9013})
if __name__=='__main__':
 try:main()
 except BaseException:
  try:save(Path(__import__('sys').argv[__import__('sys').argv.index('--case')+1])/'status/full_recovery_v3_failure.json',{'at':time.time(),'traceback':traceback.format_exc()})
  except Exception:pass
  raise
