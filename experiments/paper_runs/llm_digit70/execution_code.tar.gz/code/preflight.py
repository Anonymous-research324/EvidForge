"""No fit/model/formal reference parsing. Check original normalize guards and actual inputs."""
from pathlib import Path
import os,sys,subprocess,socket,time,ast,json
from common import ROOT as R,PY,load,save,sha,read_csv
def main():
 # Verify private files by hashes before installing repair-role guard.
 for n in load(R/'configs/cases.json'):
  c=R/'cases'/n;f=load(c/'input_freeze.json')
  for z in ['public','private']:
   for p,h in f[z].items():assert sha(c/z/p)==h
  assert sha(c/'case.json')==f['case_sha256']
 from runtime_v4 import install
 install()
 from workflow.onboarding import split_learning
 passed=[]
 for n in load(R/'configs/cases.json'):
  c=R/'cases'/n;b=load(c/'public/development_bundle.json')
  normalized,audit=split_learning(b,load(c/'public/declaration.json'))
  sets={k:{g['group'] for g in b[k]} for k in ['learning','validation']}
  fields,rows=read_csv(c/'public/repair_dirty.csv');sets['repair']={x['entity_id'] for x in rows}
  assert all(not sets[a]&sets[b] for a,b in [('learning','validation'),('learning','repair'),('validation','repair')])
  assert 'class' not in fields and set(fields)==set(load(c/'public/declaration.json')['fields'])
  passed.append(n)
 for p in (R/'code').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
 try:open(R/'cases'/passed[0]/'private/repair_reference.csv')
 except PermissionError:pass
 else:raise AssertionError('Guard allowed formal reference')
 save(R/'audit/input_preflight.json',{'cases_passed':passed,'original_source_normalize_guards':True,'private_guard_denies':True,'no_fit':True,'no_call':True,'no_formal_rows_parsed':True})
 save(R/'status/preflight_pass.json',{'at':time.time(),'cases':len(passed)})
 print('PASS',len(passed))
if __name__=='__main__':main()
