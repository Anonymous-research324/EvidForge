from pathlib import Path
import time,os,subprocess,traceback
from common import ROOT,PY,save,load,sha
def main():
 if (ROOT/"status/presentation_owner.json").exists():raise RuntimeError("Inspect existing watcher")
 save(ROOT/"status/presentation_owner.json",{"pid":os.getpid(),"started":time.time(),"host":__import__("socket").gethostname()})
 while not (ROOT/"status/scoring_complete.json").exists():
  if any((ROOT/"status"/n).exists() for n in ["controller_error.json","needs_review.json"]):
   save(ROOT/"status/presentation_waiting_review.json",{"at":time.time(),"no_auto_retry":True});return
  time.sleep(20)
 for rel,h in load(ROOT/"audit/presentation_freeze.json")["files"].items():assert sha(ROOT/rel)==h
 with (ROOT/"logs/presentation.log").open("x") as f:
  subprocess.run([PY,"-B",str(ROOT/"code/present.py")],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/presentation_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
