"""独立策展角色：生成/复制冻结输入。正式参考只写private，修复进程禁止读取。"""
from pathlib import Path
import sys,os,importlib.util,random,collections,shutil,copy,time,json,csv
from common import ROOT,load,save,sha,freeze,read_csv,write_csv
P=ROOT.parent;OLD=P/"EvidForge_Downstream_Study_seed1014"
sys.path.insert(0,str(OLD/"code"))
def source_module(rate=.7,kind=None):
 p=OLD/"code/generate_benchmarks.py";s=p.read_text()
 s=s.replace("round(.7*len(eligible))",f"round({rate!r}*len(eligible))")
 if kind:s=s.replace("['blank','digit','scale','affix']",repr([kind]))
 m=type(sys)("new_curator_generator");m.__file__=str(p);exec(compile(s,str(p),"exec"),m.__dict__);return m
def existing(case,name,seed):
 old=P/f"EvidForge_Downstream_Study_seed{seed}"/"datasets"/name
 shutil.copytree(old/"public",case/"public")
 (case/"private").mkdir()
 for n in ["repair_reference.csv","holdout_reference.csv"]:shutil.copyfile(old/"private"/n,case/"private"/n)
 return {"old_dataset":str(old),"old_input_freeze_sha256":sha(old/"input_freeze.json"),"method_inputs":"same pre-existing group partitions"}
def controlled(case,name,seed,rate,kind):
 c=case/"generator_inputs/private"/name;c.mkdir(parents=True)
 old=OLD/"generator_inputs/private"/name
 for n in ["source.zip","provenance.json"]:shutil.copyfile(old/n,c/n)
 m=source_module(rate,kind);m.ROOT=case;m.SEED=seed;m.generate(name)
 dataset=case/"datasets"/name
 shutil.move(str(dataset/"public"),case/"public");shutil.move(str(dataset/"private"),case/"private")
 return {"generator_source_sha256":sha(OLD/"code/generate_benchmarks.py"),"rate":rate,"type":kind or "mixed","numerical_changes":"only declared pollution rate/type"}
def natural(case,name,seed):
 src=ROOT/"references/TabClean_author/datasets"/("hospital" if name=="hospital" else "flight2")
 fields,d=read_csv(src/"dirty.csv");cf,t=read_csv(src/"clean.csv")
 if len(d)!=len(t):raise ValueError("Unaligned natural rows")
 if name=="hospital":
  protected=["ProviderNumber"];key="ProviderNumber";context=[]
 else:
  protected=[c for c in ["index","src","flight"] if c in fields];key="flight";context=["src"]
  if any(a["flight"]!=b["flight"] or a["src"]!=b["src"] for a,b in zip(d,t)):raise ValueError("Flight row alignment differs")
 targets=[c for c in fields if c not in protected]
 groups=collections.defaultdict(list)
 for i,(a,b) in enumerate(zip(d,t)):groups[b[key]].append(i)
 gs=sorted(groups);rng=random.Random(seed);rng.shuffle(gs)
 nl=max(20,round(.1*len(gs)));nv=max(10,round(.1*len(gs)))
 if nl+nv>=len(gs):raise ValueError("Not enough independent natural entities for current learner")
 zones={"learning":gs[:nl],"validation":gs[nl:nl+nv],"repair":gs[nl+nv:]}
 groupid={g:f"g{k:06d}" for k,g in enumerate(sorted(groups))}
 # Internal entity keys are pseudonyms. Original protected columns are retained but never correction targets.
 outfields=["entity_id",*fields];dirty=[{"entity_id":groupid[b[key]],**a} for a,b in zip(d,t)]
 schema={"id":name+"-natural-"+str(seed),"provenance":"official public TabClean bundled benchmark; previously known source, no artificial additional corruption","entity_fields":["entity_id"],"targets":targets,"protected_fields":[c for c in protected if c not in context],"visible_context_fields":context,
 "fields":{"entity_id":{"role":"identity","type":"string","identity":True},**{c:{"role":"target" if c in targets else "context","type":"string","identity":c in protected and c not in context,"meaning":c} for c in fields}}}
 if name=="flights" and len({(r["flight"],r["src"]) for r in d})==len(d):schema["source_field"]="src"
 # Source role must be usable as source context but never as target.
 bundle={z:[{"group":groupid[g],"provenance":"authorized paired natural teaching","records":[{"row_key":name+"-"+str(i),"dirty":dirty[i],"truth":{c:t[i][c] for c in targets}} for i in groups[g]]} for g in zones[z]] for z in ["learning","validation"]}
 # Drop target columns with no teaching truth, preserving them as protected context.
 supported={c for z in ["learning"] for g in bundle[z] for r in g["records"] for c in r["truth"]}
 unsupported=[c for c in targets if c not in supported]
 if unsupported:
  targets=[c for c in targets if c in supported];schema["targets"]=targets;schema["protected_fields"]+=unsupported
  for c in unsupported:schema["fields"][c]["role"]="context"
  for z in bundle:
   for g in bundle[z]:
    for r in g["records"]:r["truth"]={c:v for c,v in r["truth"].items() if c in targets}
 pub=case/"public";priv=case/"private";pub.mkdir();priv.mkdir()
 for n,v in [("development_bundle.json",bundle),("declaration.json",schema),("context.json",{"dataset":name,"source":"TabClean_author_natural","seed":str(seed)})]:save(pub/n,v)
 ids=[i for g in zones["repair"] for i in groups[g]]
 write_csv(pub/"repair_dirty.csv",outfields,[dirty[i] for i in ids])
 write_csv(priv/"repair_reference.csv",outfields,[{**dirty[i],**{c:t[i][c] for c in targets}} for i in ids])
 meta={"name":name,"task":"repair_only","rows":len(d),"targets":targets,"categorical_columns":[],"zones":{z:{"groups":len(g),"rows":sum(len(groups[k]) for k in g)} for z,g in zones.items()},"protected_fields":schema["protected_fields"],"naturally_blank_reference_excluded":True,"semantic_annotations":"no invented per-cell semantic labels; column/category analysis reported separately","all_rows_retained":True,"previously_seen_source":True}
 save(pub/"dataset_metadata.json",meta)
 return {"dirty_sha256":sha(src/"dirty.csv"),"reference_sha256":sha(src/"clean.csv"),"group_key":key,"natural_no_new_pollution":True,"unsupported_target_columns":unsupported}
def make_case(name,seed,suite,rate=.7,kind=None,fraction=1.):
 ident=f"{suite}_{name}_s{seed}"+(f"_r{rate}_{kind or 'mixed'}" if suite=="robustness" else f"_n{fraction}" if suite=="sample_size" else "")
 ident=ident.replace(".","p");case=ROOT/"cases"/ident
 if case.exists():raise FileExistsError(case)
 case.mkdir();(case/"status").mkdir();(case/"logs").mkdir();(case/"outputs").mkdir();(case/"work").mkdir()
 provenance=natural(case,name,seed) if suite=="natural" else controlled(case,name,seed,rate,kind) if suite=="robustness" else existing(case,name,seed)
 if suite=="sample_size":
  p=case/"public/development_bundle.json";b=load(p);g=sorted(b["learning"],key=lambda x:x["group"]);random.Random(seed).shuffle(g);n=max(20,round(len(g)*fraction));b["learning"]=g[:n];save(p,b)
  provenance.update(actual_learning_groups=len(b["learning"]),requested_fraction=fraction,external_validation_unchanged=True)
 meta={"id":ident,"dataset":name,"seed":seed,"suite":suite,"rate":rate,"error_type":kind or "mixed","learning_fraction":fraction,"provenance":provenance}
 save(case/"case.json",meta);save(case/"input_freeze.json",{"public":freeze(case/"public"),"private":freeze(case/"private"),"case_sha256":sha(case/"case.json")});return ident
def main():
 all=[]
 for seed in [1013,1014,1015]:
  for n in ["car_evaluation","concrete"]:all.append(make_case(n,seed,"main"))
 for seed in [1013,1014,1015]:
  for n in ["hospital","flights"]:all.append(make_case(n,seed,"natural"))
 for seed in [1013,1014,1015]:
  for n in ["car_evaluation","concrete"]:
   for frac in [.25,.5]:all.append(make_case(n,seed,"sample_size",fraction=frac))
 for seed in [1013,1014,1015]:
  for n in ["car_evaluation","concrete"]:
   for rate in [.1,.3,.5]:all.append(make_case(n,seed,"robustness",rate))
   for kind in ["blank","digit","scale","affix"]:all.append(make_case(n,seed,"robustness",.3,kind))
 save(ROOT/"configs/cases.json",all);save(ROOT/"audit/all_inputs_frozen.json",{"cases":len(all),"at":time.time(),"files":{n:sha(ROOT/"cases"/n/"input_freeze.json") for n in all}})
 print("CURATOR_COMPLETE",len(all),flush=True)
if __name__=="__main__":main()
