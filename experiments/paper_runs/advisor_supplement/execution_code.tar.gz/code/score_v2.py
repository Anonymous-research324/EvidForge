"""同一评分公式；补充已审查不可用基线的显式None，不伪造0或重评。"""
import sys,time
from common import ROOT,load,save
import score,report_v2
original=score.score_case
def patched(case):
 result=original(case)
 p=case/"status/tabclean_closed_unavailable.json"
 if p.exists():
  cfg=load(case/"case.json");result.append({**cfg,"arm":"tabclean","status":"N/A","reason":load(p),"repair":{k:None for k in ["P","R","F1","normal_damage","detection_AUC"]},"downstream":None,"receipt":{"unavailable":True}})
  save(case/"scores.json",result)
 return result
score.score_case=patched
sys.modules["report"]=report_v2
if __name__=="__main__":score.main()
