import os,time,subprocess,traceback
from common import ROOT,PY,save,load,sha
def main():
 save(ROOT/"status/postprocess_owner.json",{"pid":os.getpid(),"started":time.time()})
 while not (ROOT/"status/scoring_complete.json").exists():
  if (ROOT/"status/controller_error.json").exists():
   save(ROOT/"status/postprocess_waiting_review.json",{"at":time.time(),"no_automatic_retry":True});return
  time.sleep(20)
 for rel,h in load(ROOT/"audit/postprocess_freeze.json")["files"].items():assert sha(ROOT/rel)==h
 with (ROOT/"logs/postprocess.log").open("x") as f:subprocess.run([PY,"-B",str(ROOT/"code/present.py")],cwd=ROOT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1"},stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/postprocess_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
