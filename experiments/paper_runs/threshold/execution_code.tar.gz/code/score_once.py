"""Exactly one new read of each formal reference after all fixed outputs close."""
import sys,time,statistics
from pathlib import Path
from common import ROOT,read,save,sha,csvread,tag
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/"engine/source_runtime")]
from unseen_table.common import equal
OFFSETS=[-.1,-.05,0.,.05,.1]
def metrics(a,b,t,cols):
 n=err=chg=exact=damage=0
 for x,y,z in zip(a,b,t):
  for k in cols:
   if z[k]=="":continue
   bad=not equal(x[k],z[k]);changed=not equal(x[k],y[k])
   err+=bad;n+=not bad;chg+=changed
   exact+=bool(bad and changed and equal(y[k],z[k]));damage+=bool(changed and not bad)
 p=exact/chg if chg else None;r=exact/err if err else 0.
 return {"errors":err,"normal":n,"changes":chg,"exact":exact,"normal_damage":damage,"P":p,"R":r,"F1":2*p*r/(p+r) if p and r else 0.,"damage":damage/n if n else None}
def main():
 assert (ROOT/"status/all_outputs_closed.json").exists()
 assert not list((ROOT/"status").glob("failure_*.json"))
 for p,h in read(ROOT/"audit/input_skill_snapshot.json")["files"].items():assert sha(p)==h
 for rel,h in read(ROOT/"audit/code_freeze.json")["files"].items():assert sha(ROOT/rel)==h
 cases=read(ROOT/"configs/cases.json")
 for c in cases:
  for delta in OFFSETS:
   folder=ROOT/"outputs"/(c["dataset"]+"_s"+str(c["seed"]))/tag(delta)
   for rel,h in read(folder/"output_freeze.json")["files"].items():assert sha(folder/rel)==h
 save(ROOT/"audit/scoring_started.json",{"time":time.time(),"all90_outputs_closed":True,"new_method_fitting":False},once=True)
 scores=[]
 for c in cases:
  name=c["dataset"]+"_s"+str(c["seed"])
  save(ROOT/"audit"/("scoring_started_"+name+".json"),{"outputs_fixed":True,"time":time.time()},once=True)
  fields,dirty=csvread(c["input"]);_,truth=csvread(c["reference"]);cols=read(c["declaration"])["targets"]
  assert len(dirty)==len(truth) and [r["entity_id"] for r in dirty]==[r["entity_id"] for r in truth]
  old=next(x for x in read(c["original_score"]) if x["dataset"]==c["dataset"] and x["arm"]=="A")
  for delta in OFFSETS:
   folder=ROOT/"outputs"/name/tag(delta);_,rows=csvread(folder/"repair_output.csv")
   assert len(rows)==len(dirty) and [r["entity_id"] for r in rows]==[r["entity_id"] for r in dirty]
   m=metrics(dirty,rows,truth,cols)
   if delta==0:
    for k,v in old["repair"].items():
     if k not in m:continue
     assert (v is None and m[k] is None) or v is not None and m[k] is not None and abs(v-m[k])<1e-12,(name,k,v,m[k])
   scores.append({"dataset":c["dataset"],"seed":c["seed"],"offset":delta,"repair":m,"receipt":read(folder/"receipt.json")})
  save(ROOT/"reports/all_scores.json",scores)
  save(ROOT/"status"/("scored_"+name+".json"),{"count":5,"reference_reads":1},once=True)
 groups=[]
 for d in read(ROOT/"configs/protocol.json")["datasets"]:
  for delta in OFFSETS:
   values=sorted([x for x in scores if x["dataset"]==d and x["offset"]==delta],key=lambda x:x["seed"]);assert len(values)==3
   g={"dataset":d,"offset":delta,"qualified_seeds":sum(x["receipt"]["qualified_original"] for x in values)}
   for k in ["P","R","F1","damage"]:
    v=[x["repair"][k] for x in values];n=sum(x is not None for x in v)
    g[k]={"mean":statistics.mean(v) if n==3 else None,"sd":statistics.stdev(v) if n==3 else None,"n":n,"seed_values":v}
   groups.append(g)
 save(ROOT/"reports/aggregate.json",groups,once=True)
 paired=[]
 for d in read(ROOT/"configs/protocol.json")["datasets"]:
  for delta in [-.1,-.05,.05,.1]:
   base={x["seed"]:x for x in scores if x["dataset"]==d and x["offset"]==0}
   other={x["seed"]:x for x in scores if x["dataset"]==d and x["offset"]==delta}
   obj={"dataset":d,"offset":delta}
   for k in ["F1","damage"]:
    ds=[other[s]["repair"][k]-base[s]["repair"][k] if other[s]["repair"][k] is not None and base[s]["repair"][k] is not None else None for s in [1013,1014,1015]]
    n=sum(v is not None for v in ds);obj[k]={"mean":statistics.mean(ds) if n==3 else None,"sd":statistics.stdev(ds) if n==3 else None,"n":n,"paired_values":ds}
   paired.append(obj)
 save(ROOT/"reports/paired_differences.json",paired,once=True)
 save(ROOT/"status/scoring_complete.json",{"rows":len(scores),"groups":len(groups),"time":time.time()},once=True)
 print("SCORING_COMPLETE",len(scores),flush=True)
if __name__=="__main__":main()
