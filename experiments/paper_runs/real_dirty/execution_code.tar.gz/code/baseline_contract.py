from pathlib import Path
import os,sys
from common import load

def install_guard():
 def guard(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   p=Path(os.fsdecode(args[0])).resolve()
   if any(x in p.parts for x in ('private','local_private','sources','candidate_sources')) or p.name in ('development_bundle.json','validation_only.json'):
    raise PermissionError('Only public learning truth is authorized')
 sys.addaudithook(guard)

def case_input(value,method):
 case=Path(value).resolve();pub=case/'public';protected=load(case/'case.json')['protected']
 out=case/'outputs'/method;out.mkdir(parents=True,exist_ok=False)
 return case,pub,out,protected

def verify_rows(fields,before,after,targets,protected):
 assert len(before)==len(after)
 for original,result in zip(before,after):
  assert set(result)==set(fields)
  assert all(result[c]==original[c] for c in fields if c not in targets or c in protected)
