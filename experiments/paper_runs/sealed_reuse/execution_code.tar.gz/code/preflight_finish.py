
"""Resume only synthetic guard assertions; preserves first preflight and completed source fit."""
from pathlib import Path
import os,sys,ast,subprocess,time
from common import ROOT,ENGINE,PY,load,save,sha
def main():
 for p in (ROOT/"code").glob("*.py"):ast.parse(p.read_text())
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ENGINE/rel)==h
 for p,h in load(ROOT/"audit/protected_old_files.json").items():assert sha(p)==h
 folder=ROOT/"audit/synthetic"
 env={**os.environ,"EF_SEED":"1013","EF_ARM":"full","EF_ROLE":"learning","OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2"}
 with (folder/"negative_fit_resume.log").open("x") as f:p=subprocess.run([PY,"-B",str(folder/"negative_fit.py")],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0
 os.environ.update(env)
 from runtime_v4 import install
 install()
 from workflow.onboarding import split_learning
 checks=[]
 for name in load(ROOT/"configs/cases.json"):
  case=ROOT/"cases"/name;b=load(case/"source/development_bundle.json");d=load(case/"source/declaration.json")
  inner,audit=split_learning(b,d)
  assert {g["group"] for g in inner["learning"]+inner["validation"]}=={g["group"] for g in b["learning"]}
  assert not {g["group"] for g in b["learning"]}&{g["group"] for g in b["validation"]}
  checks.append({"case":name,"source_groups":len(b["learning"]),"external_groups":len(b["validation"]),"passed":True})
  try:(case/"batches/B1/dirty.csv").read_text()
  except PermissionError:pass
  else:raise AssertionError("Future batch readable during learning")
  try:(case/"private/B1_reference.csv").read_text()
  except PermissionError:pass
  else:raise AssertionError("Private reference readable")
 save(ROOT/"audit/source_isolation_pass.json",{"passed":True,"cases":checks,"formal_rows_read":0,"model_calls":0})
 from source_cache import materialize,install as install_cache
 from workflow.packages import execute
 from cache_codec import encode,decode
 from offline_guard import install as offline,stop_profile
 from metrics_reuse import repair_metrics,summary
 from unseen_table.common import equal
 import numpy as np,socket
 from decimal import Decimal
 sample={("key",1):np.asarray([[1.,float("nan")],[2.,float("inf")]]),"decimal":Decimal("1.200"),"tuple":("x",3),"set":{1,2}}
 assert encode(decode(encode(sample)))==encode(sample)
 skill=folder/"onboarding/prior_prepared";cache=materialize(skill)
 rows=[dict(g["records"][0]["dirty"]) for g in load(folder/"bundle.json")["learning"][:3]]
 before=execute(rows,skill);events=[];install_cache(cache,events)
 counts=offline(folder/"offline_resume.jsonl",ENGINE)
 try:after=execute(rows,skill)
 finally:stop_profile()
 assert encode(before)==encode(after) and len(events)>=3 and not any(counts.values())
 positive=dict(counts)
 try:socket.create_connection(("127.0.0.1",9),timeout=.1)
 except PermissionError:pass
 else:raise AssertionError("Network guard failed")
 assert counts["network_attempts"]==1
 d=[{"a":"bad","b":"2"}];truth=[{"a":"1","b":"2"}]
 assert repair_metrics(d,d,truth,["a","b"],equal)["P"] is None
 assert repair_metrics(d,truth,truth,["a","b"],equal)["F1"]==1.
 assert summary([1.,2.,3.])["sample_sd"]==1. and summary([1.,2.,None])["mean"] is None
 save(ROOT/"audit/preflight_pass.json",{"at":time.time(),"core124":"PASS","protected_old_files":"PASS","synthetic_full_fit":"PASS","type_preserving_cache_roundtrip":"PASS","cached_uncached_output_decision_parity":"PASS","offline_no_fit_positive":positive,"network_and_fit_negative_tests":"PASS","learning_batch_private_isolation":"PASS","metric_None_and_sample_sd":"PASS","original_preflight":"original failure was a test assertion about stacked audit-hook order; actual blocked network event was preserved","actual_model_calls":0,"formal_rows_read":0})
 print("PREFLIGHT_FINISHED_PASS",flush=True)
if __name__=="__main__":main()
