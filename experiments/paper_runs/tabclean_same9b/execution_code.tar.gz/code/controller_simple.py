"""Three-seed simple study: drain superseded work, inherit owned GPUs, run 21 fixed cases once."""
from pathlib import Path
import os,sys,time,json,signal,socket,subprocess,traceback,fcntl,concurrent.futures,urllib.request
from common import ROOT,PY,load,save,sha
OLD=ROOT.parent
def alive(pid,script=None):
 p=Path('/proc')/str(pid)
 if not (p/'stat').exists():return False
 stat=(p/'stat').read_text().split(') ',1)[1].split()
 if stat[0]=='Z':return False
 return script is None or script.encode() in (p/'cmdline').read_bytes()
def run(cmd,log,env):
 log=Path(log)
 with log.open('x') as f:
  child=subprocess.Popen(list(map(str,cmd)),cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
  save(Path(str(log)+'.pid.json'),{'pid':child.pid,'command':list(map(str,cmd)),'at':time.time()})
  code=child.wait()
 if code:raise RuntimeError('Stage failed '+str(log)+' rc='+str(code))
def inherit(gpu):
 if gpu==0:
  source=OLD/'sampler_v2/services/gpu0';parent=3749081;script=str(OLD/'sampler_v2/code/controller_v3.py');child=3752633
 else:
  source=OLD/'services/gpu1';parent=3738951;script=str(OLD/'code/controller.py');child=3750616
 while alive(child):
  save(ROOT/'status'/('drain_gpu'+str(gpu)+'.json'),{'at':time.time(),'child':child,'parent':parent,'scope':'superseded case drains, no extra dispatch'})
  time.sleep(3)
 if alive(parent,script):
  state=(Path('/proc')/str(parent)/'stat').read_text().split(') ',1)[1].split()[0]
  if state not in ['T','t']:raise RuntimeError('Superseded controller is not stopped; refuse race')
  os.kill(parent,signal.SIGTERM)
  try:os.kill(parent,signal.SIGCONT)
  except ProcessLookupError:pass
  for _ in range(30):
   if not alive(parent,script):break
   time.sleep(.1)
  if alive(parent,script):raise RuntimeError('Superseded controller did not retire')
 owner=load(source/'owner.json');assert alive(owner['pid'],owner['name'])
 cmd=(Path('/proc')/str(owner['pid'])/'cmdline').read_bytes()
 assert b'Qwen3.5-9B' in cmd and b'bfloat16' in cmd
 for p in source.glob('requests/*/request.json'):
  assert (p.parent/'response.json').exists() or (p.parent/'failure.json').exists(),'Prior request still in flight'
 with urllib.request.urlopen('http://127.0.0.1:'+str(owner['port'])+'/v1/models',timeout=5) as f:models=json.load(f)
 assert any(x['id']==owner['name'] for x in models['data'])
 dst=ROOT/'services'/('gpu'+str(gpu));dst.mkdir(exist_ok=True)
 assert not (dst/'owner.json').exists(),'Duplicate lane'
 save(dst/'owner.json',{**owner,'inherited_from':str(source),'source_owner_sha':sha(source/'owner.json'),'handover_at':time.time(),'superseded_parent_retired':parent})
 save(dst/'ready.json',{'at':time.time(),'models':models,'no_new_server_started':True})
 save(ROOT/'status'/('handover_gpu'+str(gpu)+'.json'),{'at':time.time(),'parent_retired':parent,'child_drained':child,'server_pid':owner['pid'],'port':owner['port'],'same_weights':True})
def diagnostics(gpu,env):
 if gpu!=0:return
 cfg=load(ROOT/'configs/runtime_diagnostics_simple_v1.json');results=[]
 for i,item in enumerate(cfg['sources']):
  source=Path(item['path']);assert sha(source/'request.json')==item['request_sha']
  original=load(source/'request.json');body={'_trace_tag':'SimpleOfficialDiagnostic'+str(i),'messages':original['messages'],'max_tokens':8192}
  en={**env,'EF_SEED':str(original['seed']),'EF_PHASE':'engineering_diagnostic','EF_METHOD':'completion_only_diagnostic'}
  en.pop('EF_CASE_ID',None)
  z=subprocess.run([PY,'-B',str(ROOT/'code/model_service.py'),'call'],input=json.dumps(body),text=True,capture_output=True,cwd=ROOT,env=en,timeout=1900)
  if z.returncode:raise RuntimeError('Diagnostic transport failed '+z.stderr[-1500:])
  response=json.loads(z.stdout);results.append({'source_case':item['case'],'finish':response['choices'][0]['finish_reason'],'usage':response.get('usage')})
 save(ROOT/'audit/completion_diagnostics_simple_v1.json',{'at':time.time(),'results':results,'quality_not_assessed':True,'does_not_guarantee_all_future_outputs_complete':True,'sampling_not_changed_afterwards':True})
def lane(gpu,names):
 inherit(gpu)
 env={**os.environ,'EF_GPU':str(gpu),'PYTHONPATH':str(ROOT/'code'),'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','MKL_NUM_THREADS':'2'}
 diagnostics(gpu,env);records=[]
 for i,name in enumerate(names):
  case=ROOT/'cases'/name
  save(ROOT/'status'/('lane'+str(gpu)+'.json'),{'at':time.time(),'gpu':gpu,'index':i,'total':len(names),'case':name})
  if (case/'status/paired_closed.json').exists():raise RuntimeError('Unexpected preexisting case result before first dispatch')
  try:
   run([PY,'-B',ROOT/'code/paired_simple.py','--case',case,'--gpu',gpu],ROOT/'logs'/(name+'_pair.log'),env)
   records.append({'case':name,'status':'closed','gpu':gpu})
  except Exception as e:
   records.append({'case':name,'status':'failed','gpu':gpu,'error':repr(e)})
   save(case/'status/controller_failure_simple.json',{'error':repr(e),'at':time.time(),'no_replay':True})
 save(ROOT/'status'/('lane'+str(gpu)+'.json'),{'at':time.time(),'gpu':gpu,'done':True,'index':len(names),'total':len(names),'records':records})
 return records
def stop_owned(gpu):
 d=ROOT/'services'/('gpu'+str(gpu))
 if not (d/'owner.json').exists():return
 owner=load(d/'owner.json');pid=owner['pid']
 if alive(pid):
  cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes().replace(b'\0',b' ')
  if owner['name'].encode() not in cmd or ('--port '+str(owner['port'])).encode() not in cmd or os.getpgid(pid)!=owner['pgid']:raise RuntimeError('Stop ownership mismatch')
  os.killpg(pid,signal.SIGTERM)
 for _ in range(90):
  with socket.socket() as s:open_port=s.connect_ex(('127.0.0.1',owner['port']))==0
  if not alive(pid) and not open_port:break
  time.sleep(1)
 save(d/'stopped.json',{'at':time.time(),'pid':pid,'port_closed':not open_port,'owner_exited':not alive(pid)})
 original=Path(owner['inherited_from'])
 save(original/'stopped_by_three_seed_handover.json',{'at':time.time(),'pid':pid,'new_owner_root':str(ROOT),'port_closed':not open_port,'owner_exited':not alive(pid)})
def main():
 lock=(ROOT/'status/controller.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (ROOT/'status/controller_owner.json').exists():raise RuntimeError('Controller exists; do not duplicate')
 save(ROOT/'status/controller_owner.json',{'pid':os.getpid(),'host':socket.gethostname(),'at':time.time(),'scope':'seven datasets x three seeds x one profile, no pilot expansion'})
 assert load(ROOT/'audit/preflight_pass_simple_v1.json')['passed']
 for rel,h in load(ROOT/'audit/execution_freeze_simple_v1.json')['files'].items():assert sha(ROOT/rel)==h
 names=load(ROOT/'configs/simple_cases.json');assert len(names)==21
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
  futures=[executor.submit(lane,g,names[g::2]) for g in [0,1]]
  records=[item for f in futures for item in f.result()]
 outcomes={r['case']:r for r in records};assert set(outcomes)==set(names)
 save(ROOT/'status/all_attempts_complete.json',{'at':time.time(),'outcomes':outcomes,'no_score_read':True})
 from study_simple import finalize
 finalize(names,outcomes)
 save(ROOT/'status/run_complete.json',{'at':time.time(),'cases':21,'seeds':3,'final_independent_and_visual_review_pending':True})
if __name__=='__main__':
 try:main()
 except Exception as e:
  save(ROOT/'status/controller_error.json',{'at':time.time(),'error':repr(e),'traceback':traceback.format_exc(),'formal_scoring_blocked_unless_already_marked':True})
  raise
 finally:
  for gpu in [0,1]:
   try:stop_owned(gpu)
   except Exception as e:save(ROOT/'status'/('stop_error_gpu'+str(gpu)+'.json'),{'error':repr(e),'at':time.time()})
