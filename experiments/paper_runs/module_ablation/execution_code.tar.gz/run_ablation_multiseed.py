"""Locked paired three-seed ablation continuation. No method redesign."""
from pathlib import Path
import os,sys,json,time,subprocess,concurrent.futures,hashlib,fcntl,traceback,csv,threading
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
PY='/root/fsas/home/anonymous/envs/dataforge-run/bin/python'
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','MKL_NUM_THREADS':'4','NUMEXPR_NUM_THREADS':'4','EVIDFORGE_MODEL_REPLICA':'primary'}
for key in ['EVIDFORGE_NATIVE_VARIANT','EVIDFORGE_NATIVE_STAGE','EVIDFORGE_ABLATION_ARM','EVIDFORGE_SUPERVISED_COMPONENT']:ENV.pop(key,None)
SEEDS=[1014,1015];NAMES=P['execution_order'];ARMS=['A','B','C','D','E','F']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 t=p.with_name(p.name+'.'+str(time.time_ns())+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n');os.replace(t,p)
def new(s):return Path(P['new_roots'][str(s)])
def old(s):return Path(P['downstream_roots'][str(s)])
def execute(s,stage,filename,extra=()):
 b=new(s);log=b/'logs'/(stage+'.log');assert not log.exists(),'Existing execution requires reviewed recovery '+str(log)
 with log.open('x') as f:
  cmd=[PY,'-B',str(b/'code'/filename),*map(str,extra)]
  c=subprocess.Popen(cmd,cwd=b,env=ENV,stdout=f,stderr=subprocess.STDOUT)
  save(b/'status'/('active_'+stage.split('__')[0]+'.json'),{'pid':c.pid,'controller':os.getpid(),'seed':s,'stage':stage,'started':time.time(),'log':str(log)})
  rc=c.wait()
 save(b/'status'/('closed_'+stage+'.json'),{'returncode':rc,'time':time.time(),'seed':s,'stage':stage})
 if rc:
  failure={'seed':s,'stage':stage,'returncode':rc,'log':str(log),'time':time.time(),'needs_review':True,'failed_not_zero':True}
  save(ROOT/'status/failures'/f'{s}_{stage}.json',failure)
  save(b/'status'/('failure_'+stage+'.json'),failure)
  raise RuntimeError(f'{s} {stage} failed; do not repeat closed requests')
def arm(s,n,a,skill):
 execute(s,'execute__'+n+'__'+a,'execute_arm.py',['--dataset',n,'--arm',a,'--skill',skill,'--out',new(s)/'outputs'/n/a])
def models(s,cpu,futures,mutex):
 execute(s,'service_start','service_start.py')
 for n in NAMES:
  for a in ['A','E','F']:
   execute(s,'learn__'+n+'__'+a,'learn_variant.py',['--dataset',n,'--arm',a])
   selected=load(new(s)/'work'/n/a/'selection.json')
   for target in ['A','B','C','D'] if a=='A' else [a]:
    f=cpu.submit(arm,s,n,target,selected['skill'])
    with mutex:futures.append(f)
  save(new(s)/'status'/(n+'_learning_closed.json'),{'time':time.time(),'seed':s})
 save(new(s)/'status/model_learning_complete.json',{'time':time.time()})
 execute(s,'service_stop','service_stop.py')
def verify(s):
 b=new(s);e=b/'frozen_workspace/DataForge_UnseenTable_v23'
 for f,h in load(b/'audit/core124.json')['files'].items():assert sha(e/f)==h,'Core changed'
 for f,h in load(b/'audit/experiment_code_freeze.json')['files'].items():assert sha(b/f)==h,'Adapter changed '+f
 for path,h in P['downstream_scores_sha256'].items():assert sha(Path(path))==h,'Existing downstream scores changed'
 stages=0;parity={}
 for n in NAMES:
  inp=load(old(s)/'datasets'/n/'input_freeze.json')
  for group,folder in [('public','public'),('private','private'),('supervised_labels','downstream_training')]:
   for f,h in inp[group].items():assert sha(old(s)/'datasets'/n/folder/f)==h,'Source input changed'
  with (old(s)/'datasets'/n/'public/repair_dirty.csv').open(newline='') as f:
   read=csv.DictReader(f);fields=read.fieldnames;ids=[r['entity_id'] for r in read]
  for a in ['A_saved',*ARMS]:
   out=b/'outputs'/n/a
   for f,h in load(out/'output_freeze.json')['files'].items():assert sha(out/f)==h,'Output changed'
   with (out/'repair_output.csv').open(newline='') as f:
    read=csv.DictReader(f);assert read.fieldnames==fields
    assert [r['entity_id'] for r in read]==ids
   stages+=1
  original=old(s)/'outputs'/n/'primary_llm/v23_output.csv'
  assert (b/'outputs'/n/'A_saved/repair_output.csv').read_bytes()==original.read_bytes()
  parity[n]=(b/'outputs'/n/'A/repair_output.csv').read_bytes()==original.read_bytes()
  for a in ['A','E','F']:
   case=b/'work'/n/a
   for f,h in load(case/'learning_freeze.json')['files'].items():assert sha(case/f)==h,'Sealed learning archive changed'
  for kind in ['prior','context']:
   state=load(b/'work'/n/'A'/(kind+'_stage/work/hypothesis_state.json'))
   ae=load(b/'work'/n/'E'/(kind+'_stage/work/hypothesis_state.json'))
   assert state['attempted_proposals']==ae['attempted_proposals'],'Feedback ablation proposal budget mismatch'
 reqs=list((b/'models_service/requests').glob('*/request.json'))
 for path in reqs:
  q=load(path);assert q['seed']==s and q['temperature']==0 and q['model']==f'evidforge-ablation-seed{s}'
  assert (path.parent/'response.json').exists()
 results=list((b/'work').glob('*/*/*_stage/native/result.json'));assert len(results)==36
 for p in results:
  q=load(p);assert q['closed'] and q['native_exit_code']==0 and q['synthetic_control_count']==0
  assert q['project_hook_registered']==(p.parts[-4]!='F')
 save(b/'audit/outputs_and_learning_pre_score.json',{'stages':stages,'A_saved_all_byteparity':True,'new_A_old_full_byteparity':parity,'requests':len(reqs),'native_closed':len(results),'seed_temp_model_verified':True,'formal_reference_rows_parsed':False,'time':time.time()})
 save(b/'status/all_outputs_closed.json',{'conditions':42,'formal_reference_read':False,'time':time.time()})
def main():
 with (ROOT/'status/controller.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not (ROOT/'status/owner.json').exists(),'Inspect existing owner before resume'
  save(ROOT/'status/owner.json',{'pid':os.getpid(),'started':time.time(),'seeds':SEEDS,'automatic_timeout_kill':False,'advisory_timeout_hours':12})
  try:
   for s in SEEDS:execute(s,'synthetic_preflight','synthetic_preflight.py')
   futures=[];mutex=threading.Lock()
   with concurrent.futures.ThreadPoolExecutor(max_workers=3) as cpu:
    for s in SEEDS:
     for n in NAMES:futures.append(cpu.submit(arm,s,n,'A_saved',load(old(s)/'outputs/v23'/n/'selection.json')['skill']))
    errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as gpu:
     work={gpu.submit(models,s,cpu,futures,mutex):s for s in SEEDS}
     for f in concurrent.futures.as_completed(work):
      try:f.result();save(ROOT/'status'/f'gpu_{work[f]}_complete.json',{'time':time.time()})
      except BaseException as e:errors.append({'seed':work[f],'error':repr(e),'traceback':traceback.format_exc()});save(ROOT/'status/branch_errors.json',errors)
    for f in futures:
     try:f.result()
     except BaseException as e:errors.append({'cpu_execution_error':repr(e)});save(ROOT/'status/branch_errors.json',errors)
   assert not errors,'Review preserved branch failures before proceeding'
   assert not list((ROOT/'status/failures').glob('*.json'))
   for s in SEEDS:verify(s)
   for f,h in load(ROOT/'audit/controller_freeze.json')['files'].items():assert sha(ROOT/f)==h
   assert sha(Path(P['original_ablation_scores']))==P['original_ablation_scores_sha256']
   save(ROOT/'status/all_outputs_closed.json',{'new_conditions':84,'time':time.time(),'formal_scoring_not_yet_started':True})
   for s in SEEDS:
    execute(s,'formal_scoring','score_ablation.py')
    assert load(new(s)/'status/scoring_complete.json')['rows']==36
   with (ROOT/'logs/aggregate.log').open('x') as log:
    subprocess.run([PY,'-B',str(ROOT/'aggregate_ablation.py')],cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT,check=True)
   save(ROOT/'status/complete.json',{'time':time.time(),'report':str(ROOT/'reports/第三个实验_三种子消融均值与标准差.md'),'owned_models_stopped':True})
  except BaseException as e:
   save(ROOT/'status/controller_error.json',{'time':time.time(),'error':repr(e),'traceback':traceback.format_exc(),'preserve_all_receipts_and_closed_requests':True,'do_not_rerun_entire_controller':True});raise
if __name__=='__main__':main()
