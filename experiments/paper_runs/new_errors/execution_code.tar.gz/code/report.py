"""Report only frozen original-system scores. Exploratory source pilots stay separate."""
from pathlib import Path
import statistics,collections,csv,time,sys,os
from common import ROOT as R,load,save,sha,read_csv
P=load(R/'configs/protocol.json');DS=P['datasets'];PROF=P['profiles'];SEEDS=P['seeds'];ARMS=P['arms']
def summary(values):
 v=[x for x in values if x is not None]
 return {'n':len(v),'expected_n':len(SEEDS),'mean':statistics.mean(v) if len(v)==len(SEEDS) else None,'sd':statistics.stdev(v) if len(v)==len(SEEDS) else None,'values':values}
def show(v):return f'{v["mean"]:.3f} ± {v["sd"]:.3f}' if v['mean'] is not None else f'N/A({v["n"]}/{len(SEEDS)})'
def plot(ag,dest=None):
 dest=dest or R;os.environ.setdefault('MPLCONFIGDIR',str(R/'tmp/matplotlib'))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 cn=FontProperties(fname=str(R/'resources/fonts/SongtiSC-Regular.ttf'));en=FontProperties(fname=str(R/'resources/fonts/TimesNewRoman.ttf'))
 plt.rcParams.update({'pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False})
 names={'spectf':'SPECTF（分类来源）','auto_mpg':'Auto MPG（回归来源）','airfoil':'Airfoil（回归来源）'}
 labels={'digit_transposition':'数字换位','cross_field_addition':'跨字段相加','scale_suffix_composition':'倍率＋后缀组合'}
 qa={}
 for key,title in [('F1','精确修复 F1 ↑'),('normal_damage_percent','正常误改率（%）↓')]:
  fig=plt.figure(figsize=(180/25.4,138/25.4),dpi=600);ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
  ax.text(.5,.96,'原系统在新错误条件上的LLM消融（三种子）',fontproperties=cn,fontsize=10,ha='center',va='center')
  ax.text(.5,.914,title,fontproperties=cn,fontsize=8,ha='center')
  xs=[.385,.625,.865]
  for pi,p in enumerate(PROF):
   top=.864-pi*.226
   ax.text(.03,top,labels[p],fontproperties=cn,fontsize=8,va='center')
   ax.plot([.025,.975],[top-.027,top-.027],color='black',lw=1.1)
   ax.text(.04,top-.062,'设置',fontproperties=cn,fontsize=7.5,va='center')
   for x,d in zip(xs,DS):ax.text(x,top-.062,names[d],fontproperties=cn,fontsize=7.6,ha='center',va='center')
   ax.plot([.025,.975],[top-.092,top-.092],color='black',lw=.6)
   for ai,a in enumerate(ARMS):
    y=top-.126-ai*.053;ax.text(.04,y,'有LLM' if a=='full' else '完全无LLM',fontproperties=cn,fontsize=8,va='center')
    for x,d in zip(xs,DS):
     v=next(z for z in ag if (z['dataset'],z['profile'],z['arm'])==(d,p,a))['metrics'][key]
     ax.text(x,y,show(v),fontproperties=en,fontsize=8,ha='center',va='center')
   ax.plot([.025,.975],[top-.205,top-.205],color='black',lw=1.1)
  notes=['原124核心、候选与保护门槛不变；仅开关原LLM排序／接受模块。','每区每字段30%可污染特征格；不等于全表30%，未使用旧脚本除4配额。','此前未测试的错误条件／组合，不代表每个正确值都不在旧候选池。','均值±样本SD，n=3；全部零／负／相同保留，外校资格另列。']
  for i,t in enumerate(notes):ax.text(.03,.15-i*.032,t,fontproperties=cn,fontsize=6.3,va='center')
  fig.canvas.draw();rr=fig.canvas.get_renderer()
  bad=[t.get_text() for t in ax.texts if (lambda b:b.x0<0 or b.y0<0 or b.x1>fig.bbox.width or b.y1>fig.bbox.height)(t.get_window_extent(rr))]
  assert not bad,bad
  stem='原系统新错误_LLM消融_'+key
  for ext in ['png','pdf','svg']:fig.savefig(dest/'reports'/f'{stem}.{ext}',dpi=600)
  plt.close(fig);sys.path.insert(0,str(R/'dependencies'));import fitz
  doc=fitz.open(dest/'reports'/f'{stem}.pdf');doc[0].get_pixmap(dpi=180).save(dest/'reports'/f'{stem}_PDF实际渲染.png')
  qa[key]={'text_bounds_pass':True,'saved_pdf_rendered':True,'actual_visual_review_pending':True}
 return qa
def main():
 assert (R/'status/scoring_complete.json').exists()
 scores=load(R/'reports/all_scores.json');ag=[];paired=[]
 for d in DS:
  for p in PROF:
   rs_by={}
   for arm in ARMS:
    rs=sorted([x for x in scores if (x['dataset'],x['profile'],x['arm'])==(d,p,arm)],key=lambda x:x['seed']);assert [x['seed'] for x in rs]==SEEDS;rs_by[arm]={x['seed']:x for x in rs}
    m={k:summary([x['repair'][k] for x in rs]) for k in ['P','R','F1','normal_damage_percent','edit01_AUC']}
    for label in ['reachable','in_pool_forward_blocked','pool_absent']:m[label+'_R']=summary([x['candidate_strata'][label]['R'] for x in rs])
    ag.append({'dataset':d,'profile':p,'arm':arm,'metrics':m,'qualified_seeds':sum(x['qualified'] for x in rs),'count_sums':{k:sum(x['repair'][k] for x in rs) for k in ['errors','normal','changes','exact','damaged']}})
   a=rs_by['full'];b=rs_by['no_llm']
   paired.append({'dataset':d,'profile':p,'F1_full_minus_noLLM':summary([a[s]['repair']['F1']-b[s]['repair']['F1'] for s in SEEDS]),'normal_damage_percent_delta':summary([a[s]['repair']['normal_damage_percent']-b[s]['repair']['normal_damage_percent'] for s in SEEDS]),'added_correct':sum(a[s]['pair']['added_correct'] for s in SEEDS),'lost_correct':sum(a[s]['pair']['lost_correct'] for s in SEEDS),'net_new_correct':sum(a[s]['pair']['net_new_correct'] for s in SEEDS),'per_seed':[{'seed':s,**a[s]['pair']} for s in SEEDS]})
 save(R/'reports/aggregate.json',ag);save(R/'reports/paired_differences.json',paired)
 costs=[];activation=[]
 for name in load(R/'configs/cases.json'):
  c=R/'cases'/name;tag=('Expansion'+name).replace('_','').replace('-','');reqs=[]
  for path in (R/'services').glob('gpu*/requests/*'):
   if tag not in path.name or not (path/'request.json').exists():continue
   q=load(path/'request.json');a=load(path/'response.json')
   reqs.append({'trace':str(path.relative_to(R)),'seed':q['seed'],'temperature':q['temperature'],'model':q['model'],'usage':a['usage'],'seconds':load(path/'timing.json')['seconds']})
  costs.append({'case':name,'actual_calls':len(reqs),'no_llm_calls':0,'source_fit_shared_once':True,'source_copy_not_independent_cold_training':True,'source_prepare_seconds':load(c/'work/full/onboarding/prior_prepared/prepare_receipt.json')['seconds'],'full_learning_including_copy_and_assessment_seconds':load(c/'work/full/selection.json')['seconds'],'requests':reqs,'tokens':sum(x['usage']['total_tokens'] for x in reqs)})
  activation.append({'case':name,**load(c/'status/activation_diagnostic.json'),'coverage':load(c/'teaching_coverage.json')})
 save(R/'reports/actual_model_costs.json',costs);save(R/'reports/teaching_activation.json',activation)
 save(R/'reports/qualification.json',[{'case':x['id'],'dataset':x['dataset'],'profile':x['profile'],'seed':x['seed'],'arm':x['arm'],'qualified':x['qualified'],'kind':x['selected_kind']} for x in scores])
 lines=['# 原系统新错误有／无LLM正式对照','','原124核心/候选/forward与置信门槛不变，没有新增候选生成器、组合解码器或原始值程序生成接口。','两组共享pre-native源拟合、学习样例与原候选池；无LLM保留全部原自动学习。完整组真实prior/context native各5调用；正式修复standalone0调用。','3已知数据来源×3新条件×3固定新seed7013/14/15，共27例，全部保留。旧seed1013实体角色和全行不变，非新盲数据。','每区每字段30%可污染格；数字换位有资格约束，跨字段anchor不污染，倍率后缀排除0。精确分母与实际格数见污染实际行格比例.json。','三类条件经过教学前测，并非证明原模板绝对不能覆盖；更难的旧ERR*x100+BAD失败仍保存，当前组合为*x10+u后缀。','','正式精确修复F1（均值±样本SD，n=3）：']
 for p in PROF:
  lines+=['','## '+p,'','| 设置 | SPECTF | Auto MPG | Airfoil |','|---|---|---|---|']
  for arm in ARMS:lines.append('| '+('有LLM' if arm=='full' else '完全无LLM')+' | '+' | '.join(show(next(x for x in ag if (x['dataset'],x['profile'],x['arm'])==(d,p,arm))['metrics']['F1']) for d in DS)+' |')
 lines+=['','源内前测/候选覆盖不是正式F1；正式参考只唯一scorer一次读取。','所有0、负收益、相同结果保留，不按正式结果筛数据/条件；3seed不能直接声称统计显著。','可达层由相同原候选池与forward保护统一定义，标签只评分可见，不按LLM修对格挑选。','外校不通过者为research checkpoint，不能声称自动部署合格。','旧表、旧分数、先前失败与超范围新增模块试验均未改，未与本批合并。']
 (R/'reports/原系统新错误_LLM消融结果.md').write_text('\n'.join(lines)+'\n')
 with (R/'reports/绘图数据.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['dataset','profile','arm','F1_mean','F1_sd','normal_damage_percent_mean','normal_damage_percent_sd','qualified_seeds'])
  for x in ag:w.writerow([x['dataset'],x['profile'],x['arm'],x['metrics']['F1']['mean'],x['metrics']['F1']['sd'],x['metrics']['normal_damage_percent']['mean'],x['metrics']['normal_damage_percent']['sd'],x['qualified_seeds']])
 save(R/'audit/figure_machine_qa.json',plot(ag))
 save(R/'status/reports_ready.json',{'at':time.time(),'all_scores_sha':sha(R/'reports/all_scores.json'),'visual_QA_pending':True})
if __name__=='__main__':main()
