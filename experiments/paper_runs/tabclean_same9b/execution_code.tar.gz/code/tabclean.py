"""Unmodified author graph on same authorized dev pool; fixed formal program, no formal debugging."""
from pathlib import Path
import os,sys,json,time,subprocess,uuid,random
from common import ROOT,PY,load,save,sha,freeze,read_csv,write_csv
AUTHOR=ROOT/'references/TabClean_author'
sys.path[:0]=[str(ROOT/'dependencies/tabclean'),str(AUTHOR)]
class ModelOutputTruncated(RuntimeError):pass
def main(case,gpu):
 from runtime import guard
 guard()
 import pandas as pd
 import pipeline as p
 meta=load(case/'case.json');seed=meta['seed'];random.seed(seed)
 out=case/'outputs/tabclean'
 if (out/'output_freeze.json').exists():
  for f,h in load(out/'output_freeze.json')['files'].items():assert sha(out/f)==h
  return
 if out.exists():raise RuntimeError('Partial TabClean run requires reviewed stage recovery, not replay')
 out.mkdir();work=out/'author_work';work.mkdir()
 b=load(case/'public/development_bundle.json');cols=load(case/'public/declaration.json')['targets'];fields=['entity_id',*cols]
 # Both algorithms are authorized the same complete development pool; native usage differs by algorithm.
 groups=b['learning']+b['validation']
 dirty=[{'entity_id':g['group'],**{c:r['dirty'][c] for c in cols}} for g in groups for r in g['records']]
 truth=[{'entity_id':g['group'],**{c:r['truth'][c] for c in cols}} for g in groups for r in g['records']]
 write_csv(work/'teaching_dirty.csv',fields,dirty);write_csv(work/'teaching_truth.csv',fields,truth)
 dev_n,gt_text=p.compute_dev_set(str(work/'teaching_dirty.csv'),str(work/'teaching_truth.csv'))
 save(out/'author_sampling.json',{'authorized_dev_rows':len(dirty),'author_selected_rows':dev_n,'all_supervision_authorized':True,'selection':'unchanged author compute_dev_set','learning_groups':len(b['learning']),'validation_groups':len(b['validation'])})
 p.OPENAI_API_KEY='local-only';count=0
 class Model:model_name='Qwen3.5-9B'
 p._make_llm=lambda *a,**k:Model()
 def call(llm,prompt,agent):
  nonlocal count
  count+=1;budget=load(ROOT/'configs/run_config.json')['output_token_ceiling']
  body={'_trace_tag':('Tab'+case.name+agent+str(count)).replace('_','').replace('-',''),'messages':[{'role':'user','content':prompt}],'max_tokens':budget}
  env={**os.environ,'EF_GPU':str(gpu),'EF_SEED':str(seed),'EF_METHOD':'tabclean','EF_CASE_ID':case.name,'EF_PHASE':meta['phase']}
  started=time.monotonic();r=subprocess.run([PY,'-B',str(ROOT/'code/model_service.py'),'call'],input=json.dumps(body),capture_output=True,text=True,env=env,timeout=1900)
  if r.returncode:raise RuntimeError('Model transport failure: '+r.stderr[-3000:])
  raw=json.loads(r.stdout);choice=raw['choices'][0]
  save(out/f'call_{count:03d}.json',{'agent':agent,'usage':raw.get('usage'),'seconds':time.monotonic()-started,'response_finish':choice['finish_reason']})
  if choice['finish_reason']!='stop':raise ModelOutputTruncated('Original model output truncated; response preserved; no pseudo-program fallback')
  text=choice['message'].get('content')
  if not isinstance(text,str) or not text.strip():raise RuntimeError('Empty actual model content')
  return text
 p._call_llm=call
 def safe_run(code,where,timeout=120):
  ident='exec_'+uuid.uuid4().hex;script=Path(where)/(ident+'.py');script.write_text(code)
  try:
   r=subprocess.run([PY,'-B',str(ROOT/'code/safe_exec.py'),str(script),str(case),str(work)],capture_output=True,text=True,timeout=timeout,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'})
   save(Path(where)/(ident+'.json'),{'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
   return {'ok':r.returncode==0,'stdout':r.stdout,'stderr':r.stderr}
  except subprocess.TimeoutExpired:return {'ok':False,'stdout':'','stderr':'Execution timeout'}
 p.run_code=safe_run
 state={k:'' for k in p.State.__annotations__};state.update(dirty_path=str((work/'teaching_dirty.csv').resolve()),work_dir=str(work.resolve()),dev_rows=dev_n,dev_gt_errors=gt_text,best_f1=-1.,best_iteration=0,iteration=0,no_improve_count=0,eval_history='{}')
 start=time.monotonic();result=p.build_pipeline().invoke(state,{'recursion_limit':120})
 code=result.get('best_cleaning_code') or result.get('cleaning_code','')
 if not code:raise RuntimeError('Author graph produced no executable program')
 if not result.get('cleaned_path'):raise RuntimeError('Author graph development execution never completed')
 (out/'frozen_program.py').write_text(code)
 save(out/'program_freeze.json',{'sha256':sha(out/'frozen_program.py'),'commit':load(ROOT/'audit/author_source.json')['commit'],'actual_calls':count,'max_iterations':p.MAX_ITERATIONS,'dev_rows':dev_n,'authorized_pool':len(dirty),'formal_reference_read':False,'adaptation':'same9B; same authorized development pool; bounded execution; formal fixed script no debugger'})
 ff,src=read_csv(case/'public/repair_dirty.csv');write_csv(work/'formal_dirty.csv',fields,[{c:r[c] for c in fields} for r in src])
 prefix=f"INPUT_PATH = {str(work/'formal_dirty.csv')!r}\nOUTPUT_PATH = {str(work/'formal_output.csv')!r}\n"
 er=safe_run(prefix+code,work,300)
 if not er['ok'] or not (work/'formal_output.csv').exists():raise RuntimeError('Fixed program formal execution failed: '+er['stderr'][-2000:])
 got,rows=read_csv(work/'formal_output.csv')
 if got!=fields or len(rows)!=len(src) or any(a['entity_id']!=b['entity_id'] for a,b in zip(src,rows)):raise RuntimeError('Formal shape, ordering or IDs changed')
 output=[{**r,**{c:x[c] for c in cols}} for r,x in zip(src,rows)]
 write_csv(out/'repair_output.csv',ff,output)
 save(out/'receipt.json',{'seconds':time.monotonic()-start,'calls':count,'seed':seed,'same_model_adaptation_not_original_paper_GPT':True,'formal_reference_read':False})
 save(out/'output_freeze.json',{'files':freeze(out)})
 save(case/'status/tabclean_closed.json',{'at':time.time(),'actual_calls':count})
if __name__=='__main__':
 import argparse,traceback
 ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--gpu',type=int,required=True);a=ap.parse_args();case=Path(a.case)
 try:main(case,a.gpu)
 except Exception as e:
  save(case/'status/tabclean_failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'known_truncation':isinstance(e,ModelOutputTruncated),'at':time.time()});raise
