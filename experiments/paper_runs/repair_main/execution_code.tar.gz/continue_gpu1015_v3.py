"""Format-contract continuation only, fixed seed/PURE prompt/summary/validator/outputs.
No test references. Keep accepted batches, every rejected response and call cost.
"""
from pathlib import Path
import json,sys,os,time,hashlib,subprocess,traceback,fcntl
PROJECT=Path(__file__).resolve().parent
ROOT=PROJECT.parent/"EvidForge_Benchmark_seed1015"
sys.path.insert(0,str(ROOT/"code"))
from common import load,save,read_csv,write_csv,freeze,digest,SEED
import seed_runtime
seed_runtime.install()
from run_primary_llm_v3 import PURE
from unseen_table.common import equal,number
from skill_runtime import client
def validate(answer,current,ids,rows,cols):
 patches=answer["repairs"]
 if set(answer)!={"repairs"} or set(patches)!=set(current):raise ValueError("Incomplete row keys")
 changes=[]
 for key,p in patches.items():
  if not isinstance(p,dict) or not set(p)<=set(cols):raise ValueError("Protected field change")
  index=ids[int(key.split("_")[1])]
  for c,v in p.items():
   if isinstance(v,str) and equal(v,rows[index][c]):continue
   if not isinstance(v,str) or len(v)>96 or v and number(v) is None:
    raise ValueError(f"Invalid output type at repairs.{key}.{c}: a changed value must be a finite numeric string or blank. Echoing the unchanged original value is allowed; a new ERR/BAD string is not a numeric replacement. Return complete row keys; use empty dict when abstaining.")
   changes.append((index,c,v))
 return changes
def resume(name):
 out=ROOT/"outputs"/name/"primary_llm"
 assert not (out/"output_freeze.json").exists(),"Already closed; do not repeat"
 pub=ROOT/"datasets"/name/"public"
 fields,rows=read_csv(pub/"repair_dirty.csv");cols=load(pub/"declaration.json")["targets"]
 layout=load(out/"batch_layout.json");history=load(out/"progress.json")
 summary=load(out/"shared_summary.json");_,output=read_csv(out/"pure_partial.csv")
 save(out/"progress_before_contract_recovery_v3.json",history)
 old_calls=sum(x["calls"] for x in history);new_calls=0;details=[]
 for batch,ids in enumerate(layout):
  if batch<len(history) and history[batch]["accepted"]:continue
  current={f"row_{i}":{c:rows[j][c] for c in cols} for i,j in enumerate(ids)}
  val={"type":"string","maxLength":96}
  rs={"type":"object","properties":{c:val for c in cols},"additionalProperties":False}
  schema={"type":"object","properties":{"repairs":{"type":"object","properties":{k:rs for k in current},"required":list(current),"additionalProperties":False}},"required":["repairs"],"additionalProperties":False}
  ok=False;reason=None;started=time.monotonic();calls=0;retained=history[batch]["calls"] if batch<len(history) else 0
  for attempt in range(3):
   p=out/"trace"/f"pure_{batch:04d}_{attempt}_response.json"
   if not p.exists():continue
   try:
    resp=load(p)
    if resp["choices"][0]["finish_reason"]!="stop":continue
    ans=client.strict_json(resp["choices"][0]["message"]["content"])
    changes=validate(ans,current,ids,rows,cols);ok=True
    details.append({"batch":batch,"first_legal_original_attempt":attempt,"extra_calls":0});break
   except (ValueError,KeyError,TypeError) as e:reason=str(e)
  if not ok:
   payload={"rows":current,"learned_summary":summary}
   if reason:payload["format_error"]=reason
   for attempt in range(3):
    calls+=1;new_calls+=1
    try:
     ans=client.call(PURE,payload,schema,out/"trace"/f"contract_v3_{batch:04d}_{attempt}",f"QsarPure1015ContractV3B{batch}R{attempt}",cols)
     changes=validate(ans,current,ids,rows,cols);ok=True;break
    except (ValueError,KeyError,RuntimeError,OSError,TypeError) as e:
     save(out/"trace"/f"contract_v3_rejected_{batch}_{attempt}.json",{"error":repr(e),"no_partial_batch_write":True})
     payload["format_error"]=str(e)
   if ok:details.append({"batch":batch,"first_legal_continuation_attempt":attempt,"extra_calls":calls,"retained_failed_calls":retained})
  if not ok:raise RuntimeError("Still invalid after bounded format continuation; retain all output, no grading")
  for i,c,v in changes:output[i][c]=v
  entry={"batch":batch,"accepted":True,"seconds":time.monotonic()-started,"calls":calls,"previous_calls_retained":retained,"format_contract_recovery":True}
  if batch<len(history):history[batch]=entry
  else:history.append(entry)
  save(out/"progress.json",history);write_csv(out/"pure_partial.csv",fields,output)
  print("CONTRACT_V3_BATCH_CLOSED",batch+1,"/",len(layout),"new_calls",calls,flush=True)
 write_csv(out/"pure_output.csv",fields,output)
 assert digest(out/"program_only.csv")==digest(out/"v23_output.csv")
 selected=load(ROOT/"outputs/v23"/name/"selection.json")
 save(out/"format_contract_recovery_v3_audit.json",{"old_calls":old_calls,"new_calls":new_calls,"details":details,
  "accepted_prior_batches_recalled":False,"test_gold_read":False,"original_PURE_prompt_unchanged":True,
  "allowed_answer_set_unchanged":True,"only_error_feedback_more_specific":True,"extra_failed_batch_format_attempt_budget":3,
  "not_strictly_equal_total_model_compute":True})
 save(out/"receipt.json",{"seed":SEED,"dataset":name,"calls":old_calls+new_calls+1,"program_seconds":None,
  "program_seconds_note":"initial unpersisted duration not fabricated","real_v23_dispatch_calls":1,"formal_reference_read":False,
  "shared_teaching_summary_identical":True,"system_output_equals_fresh_program":True,"automatic_deployment_qualified":selected["passed"],
  "system_native_learning_separately_recorded":True,"contract_recovery":True,"old_calls":old_calls,"new_calls":new_calls,
  "extra_format_retry_budget_disclosed":True})
 save(out/"output_freeze.json",{"files":freeze(out),"all_primary_outputs_closed":True,"test_gold_read":False})
def invoke(name,stage,script,args=None):
 log=ROOT/"logs"/f"{name}_{stage}_v3.log"
 assert not log.exists(),"Inspect existing v3 attempt rather than duplicate"
 command=["/root/fsas/home/anonymous/envs/dataforge-run/bin/python","-B",str(ROOT/"code"/script),*(["--dataset",name] if name else []),*(args or [])]
 with log.open("x") as f:
  p=subprocess.Popen(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","OMP_NUM_THREADS":"4","OPENBLAS_NUM_THREADS":"4","MKL_NUM_THREADS":"4"})
  save(PROJECT/"status/gpu1015_recovery_progress.json",{"stage":stage,"dataset":name,"pid":p.pid,"parent_pid":os.getpid(),"time":time.time()})
  rc=p.wait()
 if rc:raise RuntimeError(f"{name}/{stage} failed; inspect {log}")
def main():
 save(PROJECT/"status/gpu1015_recovery_owner.json",{"pid":os.getpid(),"started":time.time()})
 with (ROOT/"outputs/locks/gpu_recovery_v3.lock").open("a") as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  resume("qsar")
  invoke("qsar","tool","run_tool_llm_v5.py")
  names=["monks1","bc_original","cmc","mammographic","ilpd","climate","voting"]
  for name in names:
   if not (ROOT/"outputs/v23"/name/"selection.json").exists():invoke(name,"learning","run_v23_learning.py")
   if not (ROOT/"outputs"/name/"primary_llm/output_freeze.json").exists():invoke(name,"primary","run_primary_llm_v3.py")
   if not (ROOT/"outputs"/name/"tool_llm/output_freeze.json").exists():invoke(name,"tool","run_tool_llm_v5.py")
  # Import the original controller only after model work is finished; keep its seed checks.
  sys.path.insert(0,str(PROJECT))
  import run_multiseed
  run_multiseed.verify(1015)
  invoke("","service_stop","model_service.py",args=["stop"])
  save(PROJECT/"status/gpu1015_recovery_complete.json",{"time":time.time(),"all_model_outputs_closed":True,"seed":1015})
if __name__=="__main__":
 try:main()
 except Exception as e:
  save(PROJECT/"status/gpu1015_recovery_error.json",{"time":time.time(),"error":repr(e),"traceback":traceback.format_exc()})
  raise
