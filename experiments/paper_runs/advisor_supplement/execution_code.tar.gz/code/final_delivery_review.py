"""交付前独立只读复核：不读原始正式参考、不评分、不调用模型。"""
from pathlib import Path
import json,hashlib,statistics,math,collections,time
ROOT=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021")
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def same(a,b):
    if a is None or b is None:return a is None and b is None
    return math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-12)
def summary(v):
    x=[z for z in v if z is not None]
    return {"mean":statistics.mean(x) if len(x)==3 else None,"sd":statistics.stdev(x) if len(x)==3 else None,"n":len(x)}
def assert_summary(a,b,label):
    assert a["n"]==b["n"] and same(a["mean"],b["mean"]) and same(a["sd"],b["sd"]),label
def main():
    frozen_checks=0
    for n,base in [("code_freeze.json",ROOT),("core124.json",ROOT/"engine"),("recovery_queue_v3_freeze.json",ROOT/"code"),("recovery_queue_v4_freeze.json",ROOT/"code"),("metadata_interface_v4_freeze.json",ROOT/"code"),("source_unavailable_v5_freeze.json",ROOT/"code")]:
        a=load(ROOT/"audit"/n)
        for f,h in a["files"].items():
            assert sha(base/f)==h,f
            frozen_checks+=1
        if "review_sha" in a:assert sha(ROOT/"audit/source_guard_review_v5.json")==a["review_sha"]
    for f,h in load(ROOT/"audit/old_scores_frozen.json").items():
        assert sha(Path(f))==h;frozen_checks+=1
    raw=load(ROOT/"reports/all_scores.json");aggregate=load(ROOT/"reports/aggregate.json")
    keyfields=["suite","dataset","rate","error_type","learning_fraction","arm"]
    key=lambda x:tuple(x[k] for k in keyfields)
    groups=collections.defaultdict(list)
    metrics=["P","R","F1","normal_damage","detection_AUC","macro_F1","AUC","R2","MAE"]
    repair_count_rows=0
    for row in raw:
        groups[key(row)].append(row)
        repair=row.get("repair") or {}
        if repair.get("exact") is None:continue
        c,e,n,tp,h=[repair[k] for k in ["changes","errors","normal","exact","damaged"]]
        wanted={"P":tp/c if c else None,"R":tp/e if e else 0.0,"F1":2*tp/(c+e) if c+e else 0.0,"normal_damage":h/n if n else None,"detection_AUC":(1+(c-h)/e-h/n)/2 if e and n else None}
        for k,v in wanted.items():assert same(repair[k],v),(row["id"],row["arm"],k)
        repair_count_rows+=1
    assert len(groups)==len(aggregate)==98 and len(raw)==294
    for row in aggregate:
        values=sorted(groups[key(row)],key=lambda x:x["seed"])
        assert [x["seed"] for x in values]==[1013,1014,1015]
        for metric in metrics:
            part="repair" if metric in metrics[:5] else "downstream"
            v=[(x.get(part) or {}).get(metric) for x in values]
            assert_summary(summary(v),row[metric],(key(row),metric))
    bycase=collections.defaultdict(dict)
    for x in raw:bycase[x["id"]][x["arm"]]=x
    paired=load(ROOT/"reports/paired_mean_sd_review.json")
    for group in paired:
        rows=sorted(groups[key(group)],key=lambda x:x["seed"])
        fv=[];hv=[]
        for row in rows:
            full=bycase[row["id"]]["full"]
            a=(full.get("repair") or {}).get("F1");b=(row.get("repair") or {}).get("F1")
            fv.append(a-b if a is not None and b is not None else None)
            a=(full.get("repair") or {}).get("normal_damage");b=(row.get("repair") or {}).get("normal_damage")
            hv.append(b-a if a is not None and b is not None else None)
        assert_summary(summary(fv),group["F1_full_minus_arm"],"paired F1")
        assert_summary(summary(hv),group["harm_arm_minus_full"],"paired damage")
    names=load(ROOT/"configs/cases.json")
    hashes=0;source_na=0;native=0;native_calls=0;hook_registered=0;outputs=0
    for name in names:
        case=ROOT/"cases"/name
        assert (case/"audit_scoring_started.json").exists() and (case/"status/scored.json").exists()
        f=load(case/"input_freeze.json")
        assert sha(case/"case.json")==f["case_sha256"]
        for role in ["public","private"]:
            for p,h in f[role].items():
                assert sha(case/role/p)==h;hashes+=1
        if (case/"status/source_closed_unavailable.json").exists():
            source_na+=1
            marker=load(case/"audit_scoring_started.json")
            assert marker["formal_reference_read"] is False
            for row in bycase[name].values():assert all(v is None for v in row["repair"].values())
            continue
        assert (case/"status/closed.json").exists()
        assert sha(case/"outputs/full/repair_output.csv")==sha(case/"outputs/reuse/repair_output.csv")
        for p in (case/"outputs").glob("*/output_freeze.json"):
            for fn,h in load(p)["files"].items():assert sha(p.parent/fn)==h;hashes+=1
            outputs+=1
        for arm in ["full","no_llm"]+(["no_feedback","no_predictive_context"] if load(case/"case.json")["suite"] in ["main","natural"] else []):
            w=case/"work"/arm
            for p,h in load(w/"learning_freeze.json")["files"].items():assert sha(w/p)==h;hashes+=1
            if arm=="no_llm":
                s=load(w/"selection.json");assert s["actual9B_calls"]==0 and s["pre_native_checkpoint"]
                # A generated candidate may not enter this frozen pre-native checkpoint.
                for p in w.glob("onboarding/*/skill.json"):
                    sk=load(p);assert not sk.get("compiled_candidate")
            else:
                for stage in ["prior_stage","context_stage"]:
                    a=load(w/stage/"native_v3/result.json")
                    assert a["closed"] and a["native_exit_code"]==0 and a["synthetic_control_count"]==0 and a["real9B_calls"]==5
                    assert not a["raw_reference_cases_visible"] and not a["test_gold_read"]
                    native+=1;native_calls+=a["real9B_calls"];hook_registered+=bool(a["project_hook_registered"])
            if arm=="no_feedback":
                for stage in ["prior_stage","context_stage"]:
                    assert load(w/stage/"work/hypothesis_state.json")["attempted_proposals"]==load(case/"work/full"/stage/"work/hypothesis_state.json")["attempted_proposals"]
    assert source_na==9 and native==162 and native_calls==810 and hook_registered==162
    costs=load(ROOT/"reports/actual_model_costs.json");lookup={x["tag"]:x for x in costs}
    assert len(costs)==len(lookup)==983
    totals=collections.defaultdict(lambda:collections.Counter())
    mapping=[(n.replace("_","").replace("-",""),load(ROOT/"cases"/n/"case.json")["seed"],i%3) for i,n in enumerate(names)]
    for p in (ROOT/"services").glob("gpu*/requests/*/request.json"):
        req=load(p);resp=load(p.parent/"response.json");u=resp["usage"];cost=lookup.pop(p.parent.name)
        match=[(s,g) for n,s,g in mapping if p.parent.name.startswith("Advisor"+n) or p.parent.name.startswith("Tab"+n)]
        assert len(match)==1
        seed,g=match[0]
        assert req["seed"]==seed==cost["seed"] and req["temperature"]==0==cost["temperature"]
        assert req["model"]==cost["model"]=="evidforge-advisor-9b-gpu"+str(g)
        assert cost["input_tokens"]==u["prompt_tokens"] and cost["output_tokens"]==u["completion_tokens"]
        totals[str(g)]["calls"]+=1;totals[str(g)]["input_tokens"]+=u["prompt_tokens"];totals[str(g)]["output_tokens"]+=u["completion_tokens"]
    assert not lookup
    for host in ["a100","rtx4090"]:assert load(ROOT/"audit"/("resources_final_"+host+".json"))["passed"]
    out={"at":time.time(),"passed":True,"raw_scores_sha":sha(ROOT/"reports/all_scores.json"),"original_code_and_old_score_hashes":frozen_checks,"input_output_learning_hashes":hashes,"outputs":outputs,"raw_score_rows":len(raw),"count_based_rows_recomputed":repair_count_rows,"aggregate_groups_recomputed":len(groups),"paired_groups_recomputed":len(paired),"source_NA_cases":source_na,"once_markers":len(names),"native_sessions":native,"real_native_calls":native_calls,"native_hook_registered_sessions":hook_registered,"actual_costs_verified":len(costs),"costs_by_lane":dict(totals),"formal_reference_rows_read":0,"scoring_repeated":False,"resource_hosts_passed":["a100","rtx4090"]}
    (ROOT/"audit/final_independent_delivery_review.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(out,ensure_ascii=False))
if __name__=="__main__":main()
