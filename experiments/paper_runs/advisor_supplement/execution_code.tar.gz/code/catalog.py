CATALOG={
'real_estate':dict(id=477,slug='real+estate+valuation+data+set',task='regression',rows=414,columns=6,layout='estate'),
'auto_mpg':dict(id=9,slug='auto+mpg',task='regression',rows=398,columns=7,layout='auto'),
'concrete':dict(id=165,slug='concrete+compressive+strength',task='regression',rows=1030,columns=8,layout='concrete'),
'airfoil':dict(id=291,slug='airfoil+self+noise',task='regression',rows=1503,columns=5,layout='airfoil'),
'tic_tac_toe':dict(id=101,slug='tic+tac+toe+endgame',task='classification',rows=958,columns=9,layout='tic'),
'car_evaluation':dict(id=19,slug='car+evaluation',task='classification',rows=1728,columns=6,layout='car'),
'retinopathy':dict(id=329,slug='diabetic+retinopathy+debrecen',task='classification',rows=1151,columns=19,layout='retino'),
'spectf':dict(id=96,slug='spectf+heart',task='classification',rows=267,columns=44,layout='spectf')}
CATALOG={n:CATALOG[n] for n in ['tic_tac_toe', 'car_evaluation', 'retinopathy', 'real_estate', 'concrete', 'airfoil']}
NAMES=list(CATALOG)
METHODS=['dirty','pure_llm','tool_llm','raha_holoclean','garf','cdc','v23']
CLASSIFICATION=[n for n in NAMES if CATALOG[n]['task']=='classification']
XGB_PARAMETERS=dict(n_estimators=200,max_depth=4,learning_rate=.05,subsample=1.,colsample_bytree=1.,reg_lambda=1.,tree_method='hist',device='cpu',n_jobs=4,random_state=1014,verbosity=0)
# Public input-type encoding, no correction rules and no use of formal answers.
CAR_VOCAB=[['vhigh','high','med','low'],['vhigh','high','med','low'],['2','3','4','5more'],['2','4','more'],['small','med','big'],['low','med','high']]
TIC_VOCAB=[['x','o','b']]*9
