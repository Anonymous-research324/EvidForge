"""Independent post-score audit. Only saved counts/scores/public outputs; never reopens formal truth."""
from pathlib import Path
import os,json,time,statistics,collections,socket,subprocess,re,math
from common import ROOT,load,save,sha,read_csv
def close(a,b):
 if a is None or b is None:return a is b
 return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
def main():
 assert (ROOT/'status/scoring_complete.json').exists() and (ROOT/'status/reports_ready.json').exists(),'Only after once-only scoring/report completion'
 checks=0;old=ROOT.parent
 for root,manifest in [(ROOT,'execution_freeze_simple_v1.json'),(old,'execution_freeze.json'),(old/'sampler_v2','execution_freeze.json'),(old/'sampler_v2','bulk_execution_freeze_v3.json')]:
  for rel,h in load(root/'audit'/manifest)['files'].items():assert sha(root/rel)==h,rel;checks+=1
 core=load(ROOT/'audit/core124.json')['files']
 for rel,h in core.items():
  for base in [ROOT/'engine',old/'engine',old/'sampler_v2/engine']:assert sha(base/rel)==h;checks+=1
 for p,h in load(ROOT/'audit/old_scores_frozen.json').items():assert sha(p)==h;checks+=1
 for rel,h in load(ROOT/'audit/author_source.json')['files'].items():assert sha(ROOT/'references/TabClean_author'/rel)==h;checks+=1
 rows=load(ROOT/'reports/all_scores.json');names=load(ROOT/'configs/simple_cases.json');cfg=load(ROOT/'configs/simple_protocol_v1.json')
 assert len(names)==21 and len(rows)==42
 keyed={(x['id'],x['arm']):x for x in rows};assert len(keyed)==42
 valid=0;zeros=0
 for row in rows:
  assert row['seed'] in cfg['seeds'] and row['profile']=='mixed' and row['arm'] in ['full','tabclean']
  m=row['repair']
  if m is None:
   assert row['status']=='runtime_failure';continue
  valid+=1
  for k in ['errors','normal','changes','exact','damaged']:assert isinstance(m[k],int) and m[k]>=0
  assert m['exact']<=m['errors'] and m['exact']<=m['changes'] and m['damaged']<=m['normal']
  p=m['exact']/m['changes'] if m['changes'] else None;r=m['exact']/m['errors'] if m['errors'] else 0.
  f=2*p*r/(p+r) if p and r else 0.
  damage=m['damaged']/m['normal'] if m['normal'] else None
  assert close(m['P'],p) and close(m['R'],r) and close(m['F1'],f) and close(m['normal_damage'],damage)
  zeros+=m['F1']==0
 for name in names:
  c=ROOT/'cases'/name
  assert (c/'audit_scoring_started.json').exists() and (c/'status/scored.json').exists()
  for part in ['public','private']:
   for rel,h in load(c/'input_freeze.json')[part].items():assert sha(c/part/rel)==h;checks+=1
  for p in c.glob('outputs/*/output_freeze.json'):
   for rel,h in load(p)['files'].items():assert sha(p.parent/rel)==h;checks+=1
  assert load(c/'scores.json')==[keyed[(name,'full')],keyed[(name,'tabclean')]]
 agg=load(ROOT/'reports/aggregate.json');pairs=load(ROOT/'reports/paired_differences.json');eligibility=load(ROOT/'reports/completion_eligibility.json')
 for x in agg:
  selected=sorted([v for v in rows if v['dataset']==x['dataset'] and v['arm']==x['arm'] and v['repair'] is not None],key=lambda v:v['seed'])
  vals=[v['repair'][x['metric']] for v in selected]
  assert x['per_seed']==vals and x['n']==len(vals)
  complete=len(vals)==3 and all(v is not None for v in vals)
  assert close(x['mean'],statistics.mean(vals) if complete else None) and close(x['sample_sd'],statistics.stdev(vals) if complete else None)
 for x in pairs:
  metric=x['metric'].replace('full_minus_tabclean_','');selected={ (v['seed'],v['arm']):v['repair'][metric] for v in rows if v['dataset']==x['dataset'] and v['repair'] is not None}
  vals=[selected[(s,'full')]-selected[(s,'tabclean')] for s in cfg['seeds'] if (s,'full') in selected and (s,'tabclean') in selected and selected[(s,'full')] is not None and selected[(s,'tabclean')] is not None]
  assert vals==x['per_seed'] and x['n']==len(vals)
  assert close(x['mean'],statistics.mean(vals) if len(vals)==3 else None) and close(x['sample_sd'],statistics.stdev(vals) if len(vals)==3 else None)
 for x in eligibility:
  ds=x['dataset'];rr=[v for v in rows if v['dataset']==ds]
  complete=all(sum(v['arm']==a and v['repair'] is not None for v in rr)==3 for a in ['full','tabclean'])
  assert x['complete_both_three_seeds']==complete
  assert x['has_valid_zero']==any(v['repair'] is not None and v['repair']['F1']==0 for v in rr)
 table=load(ROOT/'reports/main_table_data.json');display={'banknote':'Banknote','retinopathy':'Retinopathy','wdbc':'WDBC','airfoil':'Airfoil','energy':'Energy','wine_red':'Wine Red','real_estate':'Real Estate'}
 expected={display[x['dataset']] for x in eligibility if x['complete_both_three_seeds']}
 assert {x[0].rstrip('†') for x in table['rows']}==expected,'Do not drop valid zeros or reverse outcomes'
 index={(x['dataset'],x['arm'],x['metric']):x for x in agg}
 def fmt(ds,arm,key):
  a=index[(ds,arm,key)];k=100 if key=='normal_damage' else 1
  return f"{a['mean']*k:.3f} ± {a['sample_sd']*k:.3f}"
 reverse={v:k for k,v in display.items()}
 for row in table['rows']:
  ds=reverse[row[0].rstrip('†')]
  assert row[1]==fmt(ds,'full','F1') and row[2]==fmt(ds,'tabclean','F1')
  assert row[3]==fmt(ds,'full','normal_damage')+' / '+fmt(ds,'tabclean','normal_damage')
 native=0;new_requests=collections.Counter()
 for p in ROOT.glob('services/gpu*/requests/*/request.json'):
  b=load(p.parent/'binding.json');q=load(p);resp=load(p.parent/'response.json')
  assert q['seed']==b['seed'] and q['temperature']==.7 and q['top_p']==.8 and q['top_k']==20 and q['max_tokens']<=8192 and q['presence_penalty']==1.5 and q['repetition_penalty']==1
  if b.get('case') is not None:
   assert q['seed']==load(ROOT/'cases'/b['case']/'case.json')['seed']
   new_requests[(b['case'],b['method'])]+=1
 for name in names:
  c=ROOT/'cases'/name
  for kind in ['prior','context']:
   p=c/'work/full'/(kind+'_stage/native_v3');d=load(p/'result.json')
   assert d['closed'] and d['native_exit_code']==0 and d['synthetic_control_count']==0 and d['real9B_calls']==5
   hooks=[json.loads(t) for t in (p/'native_hooks.jsonl').read_text().splitlines()]
   assert sum(t.get('event')=='PreToolUse' for t in hooks)==5 and sum(t.get('event')=='PostToolUse' for t in hooks)==5
   native+=1
  assert new_requests[(name,'full')]==10
  assert (c/'outputs/full/repair_output.csv').read_bytes()==(c/'outputs/reuse/repair_output.csv').read_bytes()
 assert native==42
 cost=load(ROOT/'reports/actual_model_costs.json');actual=collections.defaultdict(collections.Counter)
 for label,root in [('old_greedy16k',old),('old_greedy_presence32k',old/'sampler_v2'),('three_seed_simple',ROOT)]:
  for p in root.glob('services/gpu*/requests/*/request.json'):
   b=load(p.parent/'binding.json');key=label+'/'+str(b.get('phase'))+'/'+str(b.get('method'));actual[key]['requests']+=1
   if (p.parent/'response.json').exists():
    r=load(p.parent/'response.json');actual[key]['responses']+=1
    for k in ['prompt_tokens','completion_tokens','total_tokens']:actual[key][k]+=r['usage'].get(k,0)
    actual[key]['request_seconds_sum']+=load(p.parent/'timing.json')['seconds']
 assert {k:dict(v) for k,v in actual.items()}==cost['by_cohort_phase_method']
 resources=[]
 for p in ROOT.glob('services/gpu*/owner.json'):
  d=load(p);proc=Path('/proc')/str(d['pid'])/'cmdline';own=proc.exists() and d['name'].encode() in proc.read_bytes()
  with socket.socket() as sock:port_open=sock.connect_ex(('127.0.0.1',d['port']))==0
  stopped=load(p.parent/'stopped.json');assert stopped['port_closed'] and stopped['owner_exited'] and not own
  resources.append({'pid':d['pid'],'port':d['port'],'original_owned_process_absent':not own,'port_currently_open':port_open,'port_closed_at_release':stopped['port_closed']})
 apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True)
 memory=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],text=True)
 owned_groups={load(p)['pgid'] for p in ROOT.glob('services/gpu*/owner.json')}
 leftover=[]
 for line in apps.splitlines():
  parts=[x.strip() for x in line.split(',')]
  if len(parts)>=2 and parts[1].isdigit():
   try:
    if os.getpgid(int(parts[1])) in owned_groups:leftover.append(parts[1])
   except ProcessLookupError:pass
 assert not leftover,'Owned GPU worker remains'
 visual={}
 profile=load(ROOT/'reports/table_style_profile.json')
 if table['rows']:
  from PIL import Image
  png=ROOT/'reports/TabClean三种子_论文表.png';pdf=ROOT/'reports/TabClean三种子_论文表.pdf'
  im=Image.open(png);w,h=im.size
  assert abs(w-profile['width_cm']/2.54*profile['dpi'])<=2
  raw=pdf.read_bytes();box=re.search(rb'/MediaBox\s*\[\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)',raw);assert box
  vals=[float(v) for v in box.groups()];assert abs((vals[2]-vals[0])-profile['width_cm']/2.54*72)<.1
  assert b'/FontFile2' in raw,'Expected embedded TrueType'
  im.thumbnail((1500,1500));im.save(ROOT/'reports/table_visual_preview.png')
  visual={'pixel_size':[w,h],'pdf_mediabox':vals,'font_embedded':True,'preview_generated':True,'human_visual_inspection_still_required':True}
 save(ROOT/'audit/final_independent_review_simple_v1.json',{'passed':True,'at':time.time(),'hash_checks':checks,'case_rows':len(rows),'valid_metric_rows':valid,'valid_zero_f1_rows':zeros,'eligible_main_datasets':len(expected),'native_sessions':native,'native_calls':native*5,'counts_F1_meanSD_paired_display_checked':True,'all_old_new_costs_recomputed':True,'formal_reference_reopened':False,'resources':resources,'gpu_compute_snapshot':apps,'gpu_memory_snapshot':memory,'owned_gpu_workers_left':leftover,'visual_file_checks':visual,'final_visual_review_pending':True})
 print('FINAL_INDEPENDENT_REVIEW_PASS',len(expected),'complete datasets')
if __name__=='__main__':main()
