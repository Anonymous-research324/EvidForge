"""虚构数据前测：字段/分组隔离、种子、算子、编译器及原核哈希。"""
from pathlib import Path
import os,sys,time,subprocess,ast
from common import ROOT,ENGINE,PY,load,save,sha
def main():
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ENGINE/rel)==h
 for p in (ROOT/"code").glob("*.py"):ast.parse(p.read_text())
 folder=ROOT/"audit/synthetic";folder.mkdir(exist_ok=False)
 schema={"id":"synthetic-only","provenance":"invented preflight data","entity_fields":["entity_id"],"targets":["a","b"],"protected_fields":[],"visible_context_fields":[],"fields":{"entity_id":{"role":"identity","type":"string","identity":True},"a":{"role":"target","type":"number"},"b":{"role":"target","type":"number"}}}
 def groups(ids):
  return [{"group":f"g{i}","provenance":"synthetic","records":[{"row_key":str(i),"dirty":{"entity_id":str(i),"a":str(100+i*2),"b":str(200+i)},"truth":{"a":str(50+i),"b":str(200+i)}}]} for i in ids]
 for n,d in [("bundle.json",{"learning":groups(range(30)),"validation":groups(range(40,50))}),("schema.json",schema),("context.json",{"dataset":"synthetic"})]:save(folder/n,d)
 cmd=[str(ROOT/"code/ef-python"),str(ENGINE/"repair_platform.py"),"prepare-heldout","--labels",str(folder/"bundle.json"),"--declaration",str(folder/"schema.json"),"--context",str(folder/"context.json"),"--out",str(folder/"onboarding")]
 with (folder/"prepare.log").open("x") as f:r=subprocess.run(cmd,env={**os.environ,"EF_SEED":"1013","EF_ARM":"full"},stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError("Synthetic full preparation failed; inspect "+str(folder/"prepare.log"))
 wf=folder/"onboarding";assert load(wf/"partition_freeze.json")["validation_sent_to_learning"] is False
 assert load(wf/"prior_prepared/prepare_receipt.json")["actual9B_calls"]==0
 save(ROOT/"audit/preflight_pass.json",{"at":time.time(),"core124":True,"synthetic_source_prepare":True,"external_validation_isolated":True,"actual9B_calls":0,"formal_reference_read":False})
 print("SYNTHETIC_PREFLIGHT_PASS",flush=True)
if __name__=="__main__":main()
