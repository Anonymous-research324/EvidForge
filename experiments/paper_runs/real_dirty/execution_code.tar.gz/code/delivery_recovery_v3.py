from pathlib import Path
import os,json,time,subprocess,socket,traceback,fcntl
from common import ROOT as R,PY,load,save,sha

def live(pid,entry):
 p=Path('/proc')/str(pid)/'cmdline';return p.exists() and entry.encode() in p.read_bytes()
def run(n):
 log=R/'logs'/f'{n}_delivery.log'
 with log.open('x') as h:p=subprocess.run([PY,'-u','-B',str(R/'code'/(n+'.py'))],cwd=R,env={**os.environ,'PYTHONPATH':str(R/'code'),'PYTHONDONTWRITEBYTECODE':'1'},stdout=h,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(n+' exit'+str(p.returncode)+' log '+str(log))

def main():
 lock=(R/'status/delivery_recovery_v3.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (R/'status/delivery_recovery_v3_owner.json').exists()
 for p,h in load(R/'audit/delivery_recovery_v3_freeze.json')['files'].items():assert sha(R/p)==h
 cpu=load(R/'status/cpu_recovery_v3_owner.json');gpu=load(R/'status/gpu_recovery_v3_owner.json')
 save(R/'status/delivery_recovery_v3_owner.json',{'pid':os.getpid(),'pgid':os.getpgrp(),'at':time.time(),'host':socket.gethostname(),'waiting_for':[cpu['pid'],gpu['pid']]})
 while live(cpu['pid'],'cpu_recovery_v3.py') or live(gpu['pid'],'gpu_recovery_v3.py'):time.sleep(20)
 assert (R/'status/cpu_recovery_v3_complete.json').exists() and (R/'status/recovery_gpu_complete_v3.json').exists(),'Recovered controllers need actual completion receipts'
 for p in [R/'status/cpu_recovery_v3_error.json',R/'status/gpu_recovery_v3_error.json']:assert not p.exists(),str(p)
 cpu_done=load(R/'status/cpu_recovery_v3_complete.json');gpu_done=load(R/'status/recovery_gpu_complete_v3.json')
 assert not cpu_done['failed'] and not gpu_done['failed'],'Actual failure requires stage review, never zero fallback'
 new_failures=list(R.glob('cases/*/status/*cpu_recovery_v3_failure.json'))+list(R.glob('cases/*/status/*gpu_recovery_v3_failure.json'))+list(R.glob('cases/*/status/full_recovery_v3_failure.json'))
 assert not new_failures,[str(p) for p in new_failures]
 names=load(R/'configs/cases.json');pilot=load(R/'configs/cases_pilot.json');p=load(R/'configs/protocol_recovery_v3.json');imports={(x['case'],x['method']):Path(x['frozen_output']).parent for x in load(R/'audit/preserved_output_inventory.json')['validated_outputs']}
 failed=[]
 for n in names+pilot:
  for m in ['full'] if n in pilot else p['methods']:
   out=imports.get((n,m),R/'cases'/n/'outputs'/p['output_folder_by_method'].get(m,m));fr=out/'output_freeze.json'
   if not fr.exists():failed.append({'case':n,'method':m});continue
   assert all(sha(out/f)==h for f,h in load(fr)['files'].items())
 save(R/'status/all_attempts_complete_recovery_v3.json',{'at':time.time(),'failed':failed,'branch_errors':[],'expected_main':120,'expected_pilot':5,'imported':25,'formal_reference_read':False})
 assert not failed,'No table with failed/missing results may score'
 gaps=load(R/'audit/pilot_hook_gap_review_v3.json');assert gaps['passed'] and gaps['exploratory_only'] and gaps['not_protocol_complete']
 evidence={}
 for row in gaps['exceptions']:
  for f,h in row['evidence_files'].items():assert sha(R/f)==h
 for rel in ['status/controller_error.json','status/delivery_error.json','status/pilot_errors.json','audit/pilot_hook_gap_review_v3.json','audit/io_guard_strengthening_review_v3.json','audit/preflight_failures_reviewed.json','audit/native_v4_ready.json']:
  f=R/rel
  if f.exists():evidence[rel]=sha(f)
 for n in ['beers_s9013','jobposting_small_s9013']:
  for rel in ['status/full_expansion_failure.json','status/recovery_failure_v4.json','logs/full_expansion.log','logs/full/prior_native_v3.log']:
   f=R/'cases'/n/rel
   if f.exists():evidence[str(f.relative_to(R))]=sha(f)
 save(R/'audit/recovery_failures_reviewed_v3.json',{'passed':True,'at':time.time(),'no_unknown_failures':True,'evidence_files':evidence,'only_exploratory_hook_log_gaps_admitted':True,'new_formal_sessions_hook_complete_required':True,'old_errors_and_usage_preserved':True})
 assert not list(R.glob('cases/*/scoring_started_expansion.json')) and not list(R.glob('cases/*/scoring_started_recovery_v3.json')),'Never repeat or erase sole scoring'
 run('score_recovery_v3');run('review_recovery_v3');run('report_recovery_v3')
 save(R/'status/numerical_delivery_ready_recovery_v3.json',{'at':time.time(),'passed':True,'actual_visual_and_local_delivery_pending':True,'resources_released_and_fixed_count_review_passed':True})
if __name__=='__main__':
 try:main()
 except BaseException:save(R/'status/delivery_recovery_v3_error.json',{'at':time.time(),'traceback':traceback.format_exc(),'no_false_zero_or_rescoring':True});raise
