"""Curator-only new pollution. Original archives, public role membership, no old reference scores."""
from pathlib import Path
import sys,zipfile,random,collections,time,copy
from common import ROOT as R,load,save,sha,freeze,read_csv,write_csv
sys.path.insert(0,str(R/'dependencies'))
from original_curator_functions import parse,make_groups,damage,canonical,num
B=R.parent;P=load(R/'configs/protocol.json')
SPECS={'retinopathy':dict(rows=1151,columns=19,layout='retino',task='classification'),'airfoil':dict(rows=1503,columns=5,layout='airfoil',task='regression')}
def create(ds,seed):
 old=B/'EvidForge_Downstream_Study_seed1013/datasets'/ds;spec=SPECS[ds]
 with zipfile.ZipFile(old/'private/source.zip') as z:values,ys,ids,sources,vocab=parse(z,spec)
 del ys,sources,vocab
 groups=make_groups(values,ids);columns=[f'feature_{j+1:02d}' for j in range(spec['columns'])]
 decl=load(old/'public/declaration.json');assert decl['targets']==columns
 oldbundle=load(old/'public/development_bundle.json');fields,oldrepair=read_csv(old/'public/repair_dirty.csv')
 rolekeys={'learning':[g['group'] for g in oldbundle['learning']],'validation':[g['group'] for g in oldbundle['validation']],'repair':list(dict.fromkeys(x['entity_id'] for x in oldrepair))}
 assert all(not set(rolekeys[a])&set(rolekeys[b]) for a,b in [('learning','validation'),('learning','repair'),('validation','repair')])
 clean={g:[{'entity_id':g,**dict(zip(columns,values[i]))} for i in groups[g]] for gs in rolekeys.values() for g in gs}
 # Verify raw archive grouping against permitted teaching truth; never read old formal CSV.
 for zone in ['learning','validation']:
  for g in oldbundle[zone]:
   assert len(clean[g['group']])==len(g['records'])
   for row,rec in zip(clean[g['group']],g['records']):
    assert all(canonical(row[c])==canonical(rec['truth'][c]) for c in columns)
 zones={};keys={}
 for zn,gs in rolekeys.items():
  rows=[];rk=[]
  for g in gs:
   for i,row in zip(groups[g],clean[g]):rows.append(dict(row));rk.append(f'{ds}-{i:05d}')
  zones[zn]=rows;keys[zn]=rk
 assert [x['entity_id'] for x in zones['repair']]==[x['entity_id'] for x in oldrepair]
 truth=copy.deepcopy(zones);events=[];counts={}
 for zn,rows in zones.items():
  eligible=[(i,c) for c in columns for i,row in enumerate(rows) if row[c]!='']
  count=(7*len(eligible)+5)//10  # direct70%, integer nearest with half-up
  mask_rng=random.Random(f'Digit70:{ds}:{seed}:{zn}:mask')
  value_rng=random.Random(f'Digit70:{ds}:{seed}:{zn}:values')
  chosen=mask_rng.sample(eligible,count)
  assert len(set(chosen))==count
  for i,c in chosen:
   after,actual=damage(truth[zn][i][c],'digit',value_rng)
   assert actual=='digit' and canonical(after)!=canonical(truth[zn][i][c])
   rows[i][c]=after
   events.append({'zone':zn,'row_key':keys[zn][i],'group':rows[i]['entity_id'],'field':c,'mechanism':'single_digit_substitution'})
  perfield={}
  for c in columns:
   eligible_count=sum(row[c]!='' for row in truth[zn])
   actual_count=sum(canonical(a[c])!=canonical(b[c]) for a,b in zip(rows,truth[zn]))
   perfield[c]={'eligible_cells':eligible_count,'actual_digit_cells':actual_count,'actual_rate':actual_count/eligible_count if eligible_count else None}
  actual_count=sum(v['actual_digit_cells'] for v in perfield.values())
  assert actual_count==count
  assert all(a['entity_id']==b['entity_id'] for a,b in zip(rows,truth[zn]))
  counts[zn]={'rows':len(rows),'groups':len(set(x['entity_id'] for x in rows)),'eligible_cells':len(eligible),'requested_rate':.7,'selected_cells':count,'actual_changed_cells':actual_count,'actual_rate':actual_count/len(eligible),'target_cells':len(rows)*len(columns),'all_table_cells_including_ID':len(rows)*len(fields),'all_table_cell_rate':actual_count/(len(rows)*len(fields)),'per_field':perfield}
 name=f'digit70_{ds}_s{seed}';case=R/'cases'/name;case.mkdir()
 for d in ['public','private','status','outputs','work','logs']:(case/d).mkdir()
 newbundle={}
 for zn in ['learning','validation']:
  by=collections.defaultdict(list)
  for row,t,k in zip(zones[zn],truth[zn],keys[zn]):
   by[row['entity_id']].append({'row_key':k,'dirty':row,'truth':{c:t[c] for c in columns}})
  newbundle[zn]=[{'group':g,'provenance':'new fixed70% single-digit corruption; original public entity role unchanged','records':by[g]} for g in rolekeys[zn]]
 decl['id']=f'{ds}-candidate-ranking-{seed}'
 save(case/'public/development_bundle.json',newbundle);save(case/'public/declaration.json',decl)
 save(case/'public/context.json',{'dataset':ds,'source':'known_UCI_digit70','seed':seed})
 write_csv(case/'public/repair_dirty.csv',fields,zones['repair']);write_csv(case/'private/repair_reference.csv',fields,truth['repair'])
 save(case/'private/repair_rowkeys.json',{'row_keys':keys['repair']})
 save(case/'private/error_annotations.json',{'cells':events})
 meta={'id':name,'dataset':ds,'seed':seed,'profile':'digit_exact_r0p70','suite':'digit70_llm_ablation','original_task':spec['task'],'task':'repair_only','counts':counts,'old_entity_partitions_seed':1013,'new_partition':False,'known_source_not_new_blind':True,'old_holdout_excluded_groups':len(set(groups)-set(sum(rolekeys.values(),[]))),'native_budget':10,'raw_source_sha':sha(old/'private/source.zip'),'old_public_roles_sha':sha(old/'public/development_bundle.json')}
 save(case/'case.json',meta);save(case/'input_freeze.json',{'case_sha256':sha(case/'case.json'),'public':freeze(case/'public'),'private':freeze(case/'private')})
 return name
def main():
 if (R/'configs/cases.json').exists():raise RuntimeError('Inputs already frozen')
 cases=[create(ds,s) for s in P['seeds'] for ds in P['datasets']]
 save(R/'configs/cases.json',cases);save(R/'configs/lanes.json',{'0':[n for n in cases if 'retinopathy' in n],'1':[n for n in cases if 'airfoil' in n]})
 save(R/'audit/inputs_frozen.json',{'cases':{n:sha(R/'cases'/n/'input_freeze.json') for n in cases},'at':time.time(),'curator_only':True,'old_formal_reference_csv_read':False,'model_calls':0})
 save(R/'reports/污染实际行格比例.json',[load(R/'cases'/n/'case.json') for n in cases])
 print('FROZEN',len(cases),flush=True)
if __name__=='__main__':main()
