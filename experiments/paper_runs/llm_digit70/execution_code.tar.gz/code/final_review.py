"""Independent count arithmetic/public edit audit, no formal reference reparse."""
from pathlib import Path
import json,statistics,socket,time,os,subprocess,collections
from common import ROOT as R,load,save,sha,read_csv
def main():
 assert (R/'status/scoring_complete.json').exists() and (R/'status/reports_ready.json').exists()
 from audit_ready import verify_frozen
 verify_frozen()
 import sys;sys.path.insert(0,str(R/'engine/source_runtime'))
 from unseen_table.common import equal
 scores=load(R/'reports/all_scores.json');assert len(scores)==2*len(load(R/'configs/cases.json'))
 for x in scores:
  m=x['repair'];p=m['exact']/m['changes'] if m['changes'] else None;r=m['exact']/m['errors'] if m['errors'] else 0
  assert p==m['P'] and r==m['R'] and abs((2*p*r/(p+r) if p and r else 0)-m['F1'])<1e-12
  c=R/'cases'/x['id'];fields,dirty=read_csv(c/'public/repair_dirty.csv');_,out=read_csv(c/'outputs'/x['arm']/'repair_output.csv');cols=load(c/'public/declaration.json')['targets']
  assert sum(not equal(a[k],b[k]) for a,b in zip(dirty,out) for k in cols)==m['changes']
  for z in x['candidate_strata'].values():assert z['R']==(z['exact']/z['errors'] if z['errors'] else None)
 for a in load(R/'reports/aggregate.json'):
  zz=sorted([x for x in scores if x['dataset']==a['dataset'] and x['arm']==a['arm']],key=lambda x:x['seed'])
  for k in ['F1','R','normal_damage_percent','edit01_AUC']:
   vals=[x['repair'][k] for x in zz];assert abs(statistics.mean(vals)-a['metrics'][k]['mean'])<1e-12 and abs(statistics.stdev(vals)-a['metrics'][k]['sd'])<1e-12
 for d in load(R/'reports/paired_differences.json'):
  rows={arm:{x['seed']:x for x in scores if x['dataset']==d['dataset'] and x['arm']==arm} for arm in ['full','no_llm']}
  vals=[rows['full'][s]['repair']['F1']-rows['no_llm'][s]['repair']['F1'] for s in sorted(rows['full'])]
  assert abs(statistics.mean(vals)-d['F1_full_minus_noLLM']['mean'])<1e-12
  assert d['net_new_correct']==sum(x['repair']['exact'] for x in rows['full'].values())-sum(x['repair']['exact'] for x in rows['no_llm'].values())
 resources={}
 for g in [0,1]:
  o=load(R/'services'/f'gpu{g}'/'owner.json');assert socket.gethostname()==o['host'],'Wrong review host'
  assert not Path('/proc',str(o['pid'])).exists()
  members=[]
  for p in Path('/proc').iterdir():
   if p.name.isdigit():
    try:
     st=(p/'stat').read_text();f=st[st.rfind(')')+2:].split()
     if int(f[2])==o['pgid'] and f[0]!='Z':members.append(int(p.name))
    except (OSError,ValueError):pass
  assert not members
  with socket.socket() as s:assert s.connect_ex(('127.0.0.1',o['port']))!=0
  resources[str(g)]={'owned_pid_absent':True,'owned_pgid_live_members':members,'port_closed':True}
 resources['gpu_inventory']=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader'],text=True)
 hooks=collections.Counter()
 for n in load(R/'configs/cases.json'):
  for p in (R/'cases'/n/'work/full').glob('*_stage/native_v3/native_hooks.jsonl'):
   for line in p.read_text().splitlines():hooks[json.loads(line)['event']]+=1
 assert hooks=={'PreToolUse':100,'PostToolUse':100,'Stop':20},dict(hooks)
 save(R/'audit/final_independent_review.json',{'at':time.time(),'counts_F1_meanSD_paired_pass':True,'public_edit_counts_pass':True,'all_frozen_SHA_pass':True,'formal_reference_reparsed':False,'correctness_not_regraded':True,'actual_hooks':dict(hooks),'resources':resources,'visual_pending':True,'actual_calls':load(R/'configs/protocol.json')['max_real_calls']})
 save(R/'status/numerical_delivery_ready.json',{'at':time.time(),'visual_and_chat_delivery_pending':True})
 print('INDEPENDENT_REVIEW_PASS',flush=True)
if __name__=='__main__':main()
