"""One-sheet paper-style workbook, numeric mean/SD cells. Server-only fallback."""
from pathlib import Path
import sys,json,math,hashlib,shutil,datetime,copy
ROOT=Path(__file__).resolve().parents[1]
DEPS=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/dependencies")
sys.path.insert(0,str(DEPS))
import openpyxl
from openpyxl.styles import Font,Alignment,Border,Side
from openpyxl.worksheet.pagebreak import Break
from openpyxl.workbook.properties import CalcProperties
from PIL import Image,ImageDraw,ImageFont
OUT=ROOT/"outputs/efficiency_20261022";OUT.mkdir(exist_ok=True)
FONTDIR=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/reports/paper_ablation_tables_20261022/fonts")
LABELS={"pure_llm":"纯 LLM（9B）","raha_holoclean":"Raha＋HoloClean","evidforge_first":"EvidForge（首次）†","evidforge_sealed":"EvidForge（封存执行）†"}
SCOPE={"pure_llm":"给定教学摘要后的批量修复","raha_holoclean":"检测＋训练、校验及修复","evidforge_first":"学习＋修复核心阶段；不含外校、封装","evidforge_sealed":"直接执行封存程序，不调用LLM"}
def write_json(p,x):
 with Path(p).open("w") as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 source=ROOT/"data/efficiency_evidence.json";data=json.loads(source.read_text());ag=data["aggregate"]
 runtime={"server_node":shutil.which("node"),"server_bundled_node_exists":(Path.home()/".cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node").exists(),"artifact_tool_on_server":"unavailable: no Node/runtime","fallback":"openpyxl on server, preserving user server-only research-code constraint","openpyxl_version":openpyxl.__version__,"openpyxl_path":openpyxl.__file__,"source_sha":sha(source),"new_model_calls":0}
 write_json(ROOT/"audit/workbook_runtime.json",runtime)
 wb=openpyxl.Workbook();ws=wb.active;ws.title="效率对比"
 ws.sheet_view.showGridLines=False;ws.sheet_view.zoomScale=90
 ws.sheet_properties.pageSetUpPr.fitToPage=True
 ws.page_setup.orientation="landscape";ws.page_setup.paperSize=ws.PAPERSIZE_A4
 ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=1
 ws.print_options.horizontalCentered=True
 ws.page_margins.left=.25;ws.page_margins.right=.25;ws.page_margins.top=.35;ws.page_margins.bottom=.35
 widths={"A":29,"B":10,"C":9,"D":11,"E":10,"F":11,"G":10,"H":38}
 for col,w in widths.items():ws.column_dimensions[col].width=w
 for row in range(1,15):ws.row_dimensions[row].height=22
 ws.row_dimensions[1].height=9;ws.row_dimensions[2].height=28;ws.row_dimensions[3].height=24;ws.row_dimensions[4].height=7
 ws.row_dimensions[5].height=31;ws.row_dimensions[6].height=22
 for row in range(7,11):ws.row_dimensions[row].height=32
 ws.row_dimensions[11].height=9
 for row in range(12,15):ws.row_dimensions[row].height=24
 for row in ws.iter_rows(min_row=1,max_row=16,min_col=1,max_col=8):
  for cell in row:
   cell.font=Font(name="Songti SC",size=11,color="000000")
   cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
 ws.merge_cells("A2:H2");ws["A2"]="表：方法效率与LLM调用成本（精简对照）";ws["A2"].font=Font(name="Songti SC",size=15,bold=True);ws["A2"].alignment=Alignment(horizontal="left",vertical="center")
 ws.merge_cells("A3:H3");ws["A3"]="第二实验固定六表 × 三种子；每表成本的均值 ± 样本标准差";ws["A3"].font=Font(name="Songti SC",size=11);ws["A3"].alignment=Alignment(horizontal="left",vertical="center")
 for rg in ["A5:A6","B5:C5","D5:E5","F5:G5","H5:H6"]:ws.merge_cells(rg)
 for cell,text in {"A5":"方法","B5":"LLM调用\n（次/表）","D5":"模型请求耗时\n（秒/表）","F5":"记录流程用时\n（秒/表）","H5":"计时范围"}.items():ws[cell]=text
 for cell in ["B6","D6","F6"]:ws[cell]="均值"
 for cell in ["C6","E6","G6"]:ws[cell]="样本SD"
 for row in [5,6]:
  for c in ws[row]:c.font=Font(name="Songti SC",size=11,bold=True)
 for i,a in enumerate(ag,7):
  ws.cell(i,1,LABELS[a["method"]]);ws.cell(i,8,SCOPE[a["method"]])
  for j,key in [(2,"calls"),(4,"model_seconds"),(6,"core_seconds")]:
   assert a[key]["n"]==3 and a[key]["dataset_count_per_seed"]==6
   ws.cell(i,j,a[key]["mean"]);ws.cell(i,j+1,a[key]["sample_sd"])
   ws.cell(i,j).number_format="0.0";ws.cell(i,j+1).number_format='"± "0.0'
  ws.cell(i,1).alignment=Alignment(horizontal="left",vertical="center",wrap_text=True)
  ws.cell(i,8).alignment=Alignment(horizontal="left",vertical="center",wrap_text=True)
  if a["method"].startswith("evidforge"):
   for cell in ws[i]:cell.font=Font(name="Songti SC",size=11,bold=True)
 medium=Side(style="medium",color="000000");thin=Side(style="thin",color="000000")
 for col in range(1,9):
  ws.cell(5,col).border=Border(top=medium)
  ws.cell(6,col).border=Border(bottom=thin)
  ws.cell(10,col).border=Border(bottom=medium)
 notes=[
 "注：六表先取均值，再计算三种子均值±样本SD；首次EvidForge含10次学习＋1次原始调度，调用含真实重试。",
 "流程计时范围不同，不计算整体加速比；封存行为原程序执行实测，不是新批次复用实验；†含研究prior。",
 "来源：三seed下游实验原始日志（1013/1014/1015）；模型启动、排队及EvidForge外校、封装不计。"
 ]
 for i,text in enumerate(notes,12):
  ws.merge_cells(start_row=i,start_column=1,end_row=i,end_column=8);ws.cell(i,1,text)
  ws.cell(i,1).font=Font(name="Songti SC",size=10)
  ws.cell(i,1).alignment=Alignment(horizontal="left",vertical="center",wrap_text=True)
 ws.print_area="A2:H14"
 wb.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True,forceFullCalc=True)
 path=OUT/"效率对比_精简版.xlsx";wb.save(path)
 saved=openpyxl.load_workbook(path,data_only=False);s=saved["效率对比"]
 assert saved.sheetnames==["效率对比"] and len(saved.sheetnames)==1 and s.freeze_panes is None
 count=0
 for i,a in enumerate(ag,7):
  for j,key in [(2,"calls"),(4,"model_seconds"),(6,"core_seconds")]:
   vals=[]
   for seed in [1013,1014,1015]:
    q=[x[key] for x in data["records"] if x["method"]==a["method"] and x["seed"]==seed]
    assert len(q)==6;vals.append(sum(q)/6)
   mean=sum(vals)/3;sd=math.sqrt(sum((v-mean)**2 for v in vals)/2)
   assert isinstance(s.cell(i,j).value,(float,int)) and isinstance(s.cell(i,j+1).value,(float,int))
   assert abs(s.cell(i,j).value-mean)<1e-10 and abs(s.cell(i,j+1).value-sd)<1e-10
   count+=2
 for row in s:
  for cell in row:
   assert cell.data_type!="f" and str(cell.value) not in ["#REF!","#DIV/0!","#VALUE!","#NAME?"]
 render_saved(s,OUT/"效率对比_精简版.png")
 write_json(ROOT/"audit/workbook_qa.json",{"numeric_summary_cells_checked":count,"sheets":saved.sheetnames,"typed_numeric_values":True,"independent_mean_sd":True,"formula_errors":False,"print_area":str(s.print_area),"xlsx_sha":sha(path),"xlsx_bytes":path.stat().st_size,"preview_sha":sha(OUT/"效率对比_精简版.png"),"preview":"Content render from re-opened saved workbook, NOT an Excel application screenshot","source_sha":sha(source)})
 print(json.dumps({"xlsx":str(path),"numeric_cells_checked":count,"sha":sha(path)},ensure_ascii=False))
def render_saved(ws,path):
 # Render values/styles from the saved workbook; keep native XLSX numeric cells intact.
 scale=2
 cols=[round((ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width*7+5)*scale) for i in range(1,9)]
 rows=[round(ws.row_dimensions[i].height*96/72*scale) for i in range(1,15)]
 xs=[30];ys=[18]
 for w in cols:xs.append(xs[-1]+w)
 for h in rows:ys.append(ys[-1]+h)
 im=Image.new("RGB",(xs[-1]+30,ys[-1]+18),"white");draw=ImageDraw.Draw(im)
 merges={}
 for rg in ws.merged_cells.ranges:
  for rr in range(rg.min_row,rg.max_row+1):
   for cc in range(rg.min_col,rg.max_col+1):merges[(rr,cc)]=(rg.min_row,rg.min_col,rg.max_row,rg.max_col)
 seen=set();fontcache={}
 for rr in range(1,15):
  for cc in range(1,9):
   cell=ws.cell(rr,cc);box=merges.get((rr,cc),(rr,cc,rr,cc))
   if box in seen:continue
   seen.add(box);r1,c1,r2,c2=box;x1,x2=xs[c1-1],xs[c2];y1,y2=ys[r1-1],ys[r2]
   if cell.value is None:continue
   fp=FONTDIR/("SongtiSC-Bold.ttf" if cell.font.bold else "SongtiSC-Regular.ttf")
   size=round(float(cell.font.sz or 11)*96/72*scale);key=(str(fp),size)
   if key not in fontcache:fontcache[key]=ImageFont.truetype(str(fp),size)
   font=fontcache[key]
   if isinstance(cell.value,(int,float)):text=("± " if cc in [3,5,7] else "")+format(cell.value,".1f")
   else:text=str(cell.value)
   lines=[]
   for line in text.split("\n"):
    current=""
    for ch in line:
     candidate=current+ch
     if current and draw.textlength(candidate,font=font)>x2-x1-20*scale:lines.append(current);current=ch
     else:current=candidate
    lines.append(current)
   height=size*1.22
   assert len(lines)*height<=y2-y1+3*scale,"Clipped row "+str(rr)+":"+text
   yy=(y1+y2-len(lines)*height)/2
   for line in lines:
    length=draw.textlength(line,font=font)
    xx=x1+8*scale if cell.alignment.horizontal=="left" else (x1+x2-length)/2
    draw.text((xx,yy),line,font=font,fill="black",stroke_width=0);yy+=height
 for rr,width in [(5,2),(7,1),(11,2)]:
  draw.line((xs[0],ys[rr-1],xs[-1],ys[rr-1]),fill="black",width=width*scale)
 im.save(path,dpi=(192,192))
if __name__=="__main__":main()
