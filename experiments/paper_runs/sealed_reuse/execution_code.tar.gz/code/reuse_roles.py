"""Operational role isolation; no numerical algorithm changes."""
from pathlib import Path
import os,sys,json,time
_INSTALLED=False
def install():
 global _INSTALLED
 if _INSTALLED:return
 _INSTALLED=True
 role=os.environ.get("EF_ROLE","learning")
 def hook(event,args):
  if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
   p=Path(os.fsdecode(args[0])).resolve();mode=args[1] if len(args)>1 else ""
   flags=args[2] if len(args)>2 else 0
   writing=(isinstance(mode,str) and any(c in mode for c in "wax+")) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
   if role in ["learning","seal"] and not writing and ("batches" in p.parts or p.name in ["repair_dirty.csv","combined_dirty.csv"]):
    raise PermissionError("Reserved new-batch input cannot be read while learning/sealing: "+str(p))
   if role=="execution":
    case=Path(os.environ["EF_CASE"]).resolve()
    if writing and any(x==p or x in p.parents for x in [case/"work",case/"sealed"]):
     raise PermissionError("Frozen skill/capsule is read-only in execution: "+str(p))
 sys.addaudithook(hook)
