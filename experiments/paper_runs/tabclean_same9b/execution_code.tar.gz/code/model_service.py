"""Same-model transport with explicit inherited owned-service receipt; no implicit server start."""
from pathlib import Path
import os,sys,time,json,urllib.request
from common import ROOT,load,save
GPU=int(os.environ.get('EF_GPU','0'));SERVICE=ROOT/'services'/('gpu'+str(GPU))
def call():
 owner=load(SERVICE/'owner.json');name=owner['name'];port=owner['port']
 proc=Path('/proc')/str(owner['pid'])/'cmdline'
 if not proc.exists() or name.encode() not in proc.read_bytes():raise RuntimeError('Inherited owned service unavailable')
 body=json.load(sys.stdin);tag=body.pop('_trace_tag');cfg=load(ROOT/'configs/run_config.json')
 if not tag.isalnum():raise ValueError('Invalid trace tag')
 body['max_tokens']=min(int(body.get('max_tokens',cfg['output_token_ceiling'])),cfg['output_token_ceiling'])
 body.update(model=name,seed=int(os.environ['EF_SEED']),temperature=cfg['temperature'],top_p=cfg['top_p'],top_k=cfg['top_k'],min_p=cfg['min_p'],presence_penalty=cfg['presence_penalty'],repetition_penalty=cfg['repetition_penalty'],chat_template_kwargs={'enable_thinking':False})
 p=SERVICE/'requests'/tag;p.mkdir(parents=True,exist_ok=False);save(p/'request.json',body)
 save(p/'binding.json',{'case':os.environ.get('EF_CASE_ID'),'phase':os.environ.get('EF_PHASE'),'method':os.environ.get('EF_METHOD'),'seed':body['seed'],'gpu':GPU,'port':port,'token_ceiling':cfg['output_token_ceiling'],'sampler':'official_non_thinking_v1','owner_receipt':str(SERVICE/'owner.json')})
 start=time.monotonic()
 try:
  req=urllib.request.Request('http://127.0.0.1:'+str(port)+'/v1/chat/completions',json.dumps(body).encode(),{'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=1800) as f:response=json.load(f)
  save(p/'response.json',response);print(json.dumps(response,ensure_ascii=False),flush=True)
 except Exception as e:save(p/'failure.json',{'error':repr(e)});raise
 finally:save(p/'timing.json',{'seconds':time.monotonic()-start,'seed':body['seed']})
if __name__=='__main__':
 if sys.argv[1]!='call':raise RuntimeError('This version inherits owned services; never start/restart implicitly')
 call()
