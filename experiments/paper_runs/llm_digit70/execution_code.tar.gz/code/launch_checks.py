"""Meaningful synthetic contracts and resource ownership check before first fit/request."""
from pathlib import Path
import os,sys,ast,time,json,socket,subprocess,collections
from common import ROOT as R,load,save,sha
def main():
 for p in (R/'code').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
 core=load(R/'audit/core124.json')
 for f,h in core['files'].items():assert sha(R/'engine'/f)==h and sha(Path(core['original_engine'])/f)==h
 for p,h in load(R/'audit/old_scores_frozen.json').items():assert sha(p)==h
 inv={}
 inv['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],text=True)
 inv['compute']=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True)
 devices={int(x) for x in load(R/'configs/protocol.json')['lane_devices'].values()}
 gpu_rows=[line.split(',') for line in inv['gpu'].splitlines()]
 assert all(int(mem)<512 for index,mem in gpu_rows if int(index) in devices)
 uuid_text=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader'],text=True)
 selected_uuid={row.split(',')[1].strip() for row in uuid_text.splitlines() if int(row.split(',')[0]) in devices}
 assert not [line for line in inv['compute'].splitlines() if line.split(',')[0].strip() in selected_uuid]
 inv['selected_devices']=sorted(devices);inv['other_users_processes_untouched']=True
 for port in [8181,8182]:
  with socket.socket() as s:s.bind(('127.0.0.1',port))
 active=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit() and int(p.name)!=os.getpid():
   try:
    cmd=(p/'cmdline').read_bytes().decode(errors='replace')
    if '/projects/EvidForge' in cmd and any(k in cmd for k in ['/code/controller','/code/worker','vllm.entrypoints']):
     st=(p/'stat').read_text();state=st[st.rfind(')')+2:].split()[0]
     if state!='Z':active.append({'pid':int(p.name),'state':state,'entry':next((x for x in cmd.split('\0') if '/code/' in x),'')})
   except OSError:pass
 # The remote inspection command contains code in argv; only real file entry args count.
 active=[x for x in active if x['entry'].endswith('.py')]
 assert not active,active
 inv['other_active_study_workers']=active
 inv['codex_version']=subprocess.check_output(['/root/fsas/home/anonymous/bin/codex','--version'],text=True).strip();assert '0.153.1' in inv['codex_version']
 os.chdir(R);p=f'/proc/{os.getpid()}/cwd/tmp/contract.sock'
 with socket.socket(socket.AF_UNIX) as s:s.bind(p)
 Path(p).unlink();inv['unix_IPC_short_path_length']=len(p)
 # Tests use original rank and gate, no production session or fabricated calls.
 from runtime_v4 import install
 install()
 from learning.arithmetic import FIELDS
 from learning.candidate_verifier import rank,permitted
 def option(v,baseline,edit,forward):
  f={k:0. for k in FIELDS};f.update(is_baseline=float(baseline),is_keep=float(baseline),is_edit=float(edit),forward_explainable=float(forward),old_numeric=1.)
  return {'value':v,'features':f}
 frame={'row':0,'column':'feature_01','group':'synthetic_only','original':'18','baseline_after_local':'18','expected_local_only':'12','options':[option('18',True,False,True),option('12',False,True,True)]}
 q=rank([frame],{'score_expression':'is_edit','accept_expression':'True'})[0]
 assert q['value']=='12' and permitted(q,{'numeric/repair':{'score_threshold':0,'margin_threshold':0}})
 frame['options'][1]['features']['forward_explainable']=0.
 q=rank([frame],{'score_expression':'is_edit','accept_expression':'True'})[0];assert not q['accept']
 # Observation wrapper preserves identical original frame object.
 import worker
 tree=ast.parse((R/'code/worker.py').read_text());outer=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='execute_impl');fn=next(x for x in outer.body if isinstance(x,ast.FunctionDef) and x.name=='observed_build')
 fs=[frame];called=[]
 scope={'original_build':lambda *a,**k:(called.append(1) or fs),'captured':[]}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'observational_fixture','exec'),scope)
 assert scope['observed_build']() is fs and len(called)==1 and 'expected_local_only' not in scope['captured'][0]
 from score import metrics
 d=[{'x':'bad1'},{'x':'bad2'},{'x':'normal'}];t=[{'x':'1'},{'x':'2'},{'x':'normal'}];a=[{'x':'1'},{'x':'2'},{'x':'wrong'}]
 m=metrics(d,a,t,['x']);assert m['exact']==2 and abs(m['F1']-.8)<1e-12 and m['normal_damage_percent']==100
 n=metrics(d,d,t,['x']);assert n['P'] is None and n['F1']==0 and n['changes']==0
 # Check manifest-era seed replacement on actual original entry, without fitting.
 import runtime
 p0=R/'engine/learning/prepare.py';code=runtime.transform(p0.read_bytes(),str(p0));assert code is not None
 save(R/'audit/launch_checks.json',{'at':time.time(),'synthetic_rank_gate_pass':True,'observational_capture_identity_pass':True,'metric_hand_counts_pass':True,'private_guard_active':True,'source_seed_transform_pass':True,'synthetic_not_production_calls':True,'production_calls':0,'no_source_fit':True,'resource_inventory':inv})
 save(R/'status/launch_checks_pass.json',{'at':time.time(),'passed':True})
 print('LAUNCH_CONTRACTS_PASS',flush=True)
if __name__=='__main__':main()
