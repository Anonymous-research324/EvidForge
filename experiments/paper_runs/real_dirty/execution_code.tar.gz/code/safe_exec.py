"""生成代码执行边界：只可读自身工作/公开输入及Python依赖，不可访问答案或网络。"""
from pathlib import Path
import sys,os
script=Path(sys.argv[1]).resolve();case=Path(sys.argv[2]).resolve();work=Path(sys.argv[3]).resolve()
ROOT=Path(__file__).resolve().parents[1]
text=script.read_text()
allowed=[work,case/"public",ROOT/"code",Path(sys.prefix),Path("/usr"),Path("/etc"),Path("/root/.cache/matplotlib"),(ROOT/"dependencies/tabclean").resolve()]
def guard(event,args):
 if event.startswith("subprocess.") or event in ["os.system","os.exec","socket.connect","socket.bind"]:raise PermissionError("Generated code cannot launch processes or network")
 if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve()
  if p.name in ["development_bundle.json","heldout_validation_local.json","validation_truth.csv","validation_dirty.csv"] or "private" in p.parts or (ROOT/"references") in p.parents or (ROOT/"sources") in p.parents or (ROOT/"splits") in p.parents:raise PermissionError("No reference/source repository access")
  if not any(p==a or a in p.parents for a in allowed) and str(p) not in ["/dev/null","/dev/urandom","/proc/cpuinfo","/proc/meminfo"]:raise PermissionError("Generated file access outside work/dependencies: "+str(p))
  mode=args[1] if len(args)>1 else "r"
  if isinstance(mode,str) and any(c in mode for c in "wax+") and not (p==work or work in p.parents):raise PermissionError("Generated writes restricted to work")
sys.addaudithook(guard)
exec(compile(text,str(script),"exec"),{"__name__":"__main__","__file__":str(script)})
