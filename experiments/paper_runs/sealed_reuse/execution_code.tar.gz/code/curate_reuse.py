"""Curator-only: cached source, independent data namespace, prospectively reserved entity batches."""
from pathlib import Path
import os,sys,json,hashlib,random,shutil,collections,time
from common import ROOT,load,save,sha,freeze,read_csv,write_csv
import source_generator as gen
OLD=Path("/root/fsas/home/anonymous/projects/EvidForge_Downstream_Study_seed1014")
def make(name,seed):
 case=ROOT/"cases"/(name+"_s"+str(seed))
 if case.exists():raise FileExistsError("Inspect existing case, do not regenerate: "+str(case))
 case.mkdir()
 for d in ["source","private","batches","work","sealed","outputs","audit","status","logs"]:(case/d).mkdir()
 data_seed=int(hashlib.sha256(("skill-reuse-new-batches-v1|"+name+"|"+str(seed)).encode()).hexdigest()[:8],16)
 cache=case/"generator_inputs/private"/name;cache.mkdir(parents=True)
 for f in ["source.zip","provenance.json"]:shutil.copy2(OLD/"generator_inputs/private"/name/f,cache/f)
 gen.ROOT=case;gen.SEED=data_seed;gen.generate(name)
 raw=case/"datasets"/name
 shutil.copy2(raw/"input_freeze.json",case/"audit/original_generator_input_freeze.json")
 public=raw/"public"
 declaration=load(public/"declaration.json");declaration["id"]=name+"-reuse-v1-s"+str(seed)
 declaration["provenance"]="Existing UCI cached table; prospective dedicated same-table batch-reuse study; not new blind data"
 context={"dataset":name,"source":"skill_reuse_new_batches_v1_"+name+"_s"+str(seed),"model_seed":str(seed)}
 for f in ["development_bundle.json","learning_only.json","validation_only.json","learning_dirty.csv","validation_dirty.csv"]:shutil.copy2(public/f,case/"source"/f)
 save(case/"source/declaration.json",declaration);save(case/"source/context.json",context)
 metadata=load(public/"dataset_metadata.json");metadata.update(model_seed=seed,data_seed=data_seed,namespace="skill-reuse-new-batches-v1",not_new_blind_data=True)
 save(case/"source/dataset_metadata.json",metadata)
 fields,dirty=read_csv(public/"repair_dirty.csv");rf,reference=read_csv(raw/"private/repair_reference.csv")
 assert len(dirty)==len(reference) and all(a["entity_id"]==b["entity_id"] for a,b in zip(dirty,reference))
 assert "class" not in fields
 groups=collections.defaultdict(list)
 for i,row in enumerate(dirty):groups[row["entity_id"]].append(i)
 items=list(groups.items())
 random.Random(int(hashlib.sha256(("batch-order-v1|"+name+"|"+str(seed)).encode()).hexdigest()[:8],16)).shuffle(items)
 buckets=[[],[],[]];sizes=[0,0,0]
 for g,ids in items:
  k=min(range(3),key=lambda j:(sizes[j],j));buckets[k].append((g,ids));sizes[k]+=len(ids)
 split={}
 bundle=load(case/"source/development_bundle.json")
 zones={z:{g["group"] for g in bundle[z]} for z in ["learning","validation"]}
 for k,b in enumerate(buckets,1):
  label="B"+str(k);folder=case/"batches"/label;folder.mkdir()
  ix=[i for g,ids in b for i in ids]
  keys=[name+"-s"+str(seed)+"-q"+format(i,"06d") for i in ix]
  write_csv(folder/"dirty.csv",fields,[dirty[i] for i in ix])
  save(folder/"row_keys.json",keys)
  write_csv(case/"private"/(label+"_reference.csv"),fields,[{c:reference[i][c] for c in fields} for i in ix])
  save(case/"private"/(label+"_row_keys.json"),keys)
  zones[label]={g for g,ids in b}
  split[label]={"groups":len(b),"rows":len(ix),"entity_ids":[g for g,ids in b],"input_sha":sha(folder/"dirty.csv"),"row_keys_sha":sha(folder/"row_keys.json")}
 assert sum(sizes)==len(dirty)
 for a,ga in zones.items():
  for b,gb in zones.items():
   if a!=b:assert not ga&gb,"Entity leakage "+a+" "+b
 allkeys=[q for b in ["B1","B2","B3"] for q in load(case/"batches"/b/"row_keys.json")]
 assert len(allkeys)==len(set(allkeys))==len(dirty)
 # Prove original canonical clean duplicates cannot cross any source/query/holdout zone; curator role only.
 signatures={}
 for z in ["learning","validation","repair","holdout"]:
  _,rows=read_csv(raw/"private"/(z+"_reference.csv"))
  signatures[z]={tuple(gen.canonical(row[c]) for c in declaration["targets"]) for row in rows}
 for a in signatures:
  for b in signatures:
   if a!=b:assert not signatures[a]&signatures[b],"Clean duplicate leakage"
 hidden=case/"curator/private";hidden.mkdir(parents=True)
 shutil.move(str(case/"datasets"),str(hidden/"generated_datasets"))
 cfg={"id":case.name,"dataset":name,"seed":seed,"data_seed":data_seed,"gpu":0 if name=="retinopathy" else 1,"batches":split,
      "generation":"original generator functions unchanged; independent data seed/ROOT globals only",
      "new_to_this_skill":True,"known_raw_dataset":True,"source_roles":metadata["zones"],"holdout_used":False}
 save(case/"case.json",cfg)
 save(case/"audit/partition_assertions.json",{"entity_disjoint":True,"canonical_clean_duplicates_disjoint":True,"batch_keys_unique":True,"all_repair_rows_retained":True,"formal_scores_used":False,"holdout_rows":metadata["zones"]["holdout"]["rows"]})
 save(case/"input_freeze.json",{"source":freeze(case/"source"),"batches":freeze(case/"batches"),"private":freeze(case/"private"),"curator":freeze(case/"curator"),"generator_inputs":freeze(case/"generator_inputs"),"case_sha":sha(case/"case.json"),"partition_sha":sha(case/"audit/partition_assertions.json")})
 print("CURATED",case.name,"MODEL_SEED",seed,"DATA_SEED",data_seed,"BATCH_ROWS",sizes,flush=True)
 return case.name
def main():
 if (ROOT/"status/curator_started.json").exists():raise RuntimeError("No blind curator replay")
 save(ROOT/"status/curator_started.json",{"pid":os.getpid(),"at":time.time()})
 names=[make(n,s) for s in [1013,1014,1015] for n in ["retinopathy","airfoil"]]
 save(ROOT/"configs/cases.json",names)
 save(ROOT/"audit/inputs_frozen.json",{"at":time.time(),"case_input_sha":{n:sha(ROOT/"cases"/n/"input_freeze.json") for n in names},"before_any_learning":True})
if __name__=="__main__":main()
