from pathlib import Path
import os,json,time,socket,subprocess,concurrent.futures,queue,signal,traceback,fcntl
from common import ROOT as R,PY,load,save,sha
P=load(R/'configs/protocol_recovery_v3.json')
STOP=__import__('threading').Event()
def environment(name='',method='',gpu=0):
 e={k:v for k,v in os.environ.items() if not k.startswith(('EF_','EVIDFORGE_'))};seed=load(R/'cases'/name/'case.json')['seed'] if name else 1013
 e.update(EF_SEED=str(seed),EF_ARM='full',EF_CONF_OFFSET='0',EF_CASE_ID=name,EF_METHOD=method,EF_PHASE='real_dirty_recovery_v3',EF_GPU=str(gpu),EF_DEVICES=str(gpu),PYTHONPATH=str(R/'code'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',TMPDIR=f'/proc/{os.getpid()}/cwd/tmp');return e

def run(cmd,log,e,timeout):
 log.parent.mkdir(parents=True,exist_ok=True)
 with log.open('x') as h:
  p=subprocess.Popen(list(map(str,cmd)),cwd=R,env=e,stdout=h,stderr=subprocess.STDOUT,start_new_session=True);save(Path(str(log)+'.pid.json'),{'pid':p.pid,'pgid':p.pid,'at':time.time(),'command':list(map(str,cmd))})
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   assert os.getpgid(p.pid)==p.pid;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise TimeoutError('Frozen original job timeout')
 if rc:raise RuntimeError('Child exit'+str(rc)+': '+str(log))

def valid(c,m):
 f=c/'outputs'/m/'output_freeze.json'
 if not f.exists():return False
 return all(sha(f.parent/p)==h for p,h in load(f)['files'].items())
def attempt(name,m,gpu):
 c=R/'cases'/name
 if valid(c,m):return
 key=c/'status'/f'{m}_gpu_recovery_v3_dispatch.json';assert not key.exists(),'No attempt replay'
 save(key,{'at':time.time(),'gpu':gpu,'method':m,'case':name,'original_calls_not_reset':True})
 cmd=[PY,'-u','-B',R/'code/worker_recovery_v3.py','case','--case',c,'--gpu',gpu] if m=='full' else [PY,'-u','-B',R/'code/tabclean_recovery_v3.py','--case',c,'--gpu',gpu]
 try:
  fr=load(c/'input_freeze.json');assert sha(c/'case.json')==fr['case_sha'] and all(sha(c/'public'/p)==h for p,h in fr['public'].items())
  run(cmd,c/'logs'/f'{m}_gpu_recovery_v3.log',environment(name,m,gpu),21600)
  assert valid(c,m),'Output freeze absent/mismatch'
  save(c/'status'/f'{m}_gpu_recovery_v3_closed.json',{'at':time.time(),'gpu':gpu,'formal_reference_read':False})
 except BaseException:
  STOP.set();save(c/'status'/f'{m}_gpu_recovery_v3_failure.json',{'at':time.time(),'traceback':traceback.format_exc(),'preserve_partial_not_zero':True});raise

def wait_scoring():
 t=time.time()
 while not (R/'status/scoring_recovery_code_ready.json').exists():
  if time.time()-t>7200:raise TimeoutError('Scoring recovery readiness wait')
  time.sleep(3)
 # All production code is separately frozen before formal GPU fitting begins.
 if not (R/'audit/recovery_code_freeze.json').exists():
  files={str(p.relative_to(R)):sha(p) for d in ['code','configs','engine','references'] for p in (R/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
  save(R/'audit/recovery_code_freeze.json',{'at':time.time(),'files':files,'all_original_phase_files_retained':True,'before_new_formal_reference_read':True,'individual_CPU_and_pilot_dispatch_freezes_preserved':True})

def main():
 lock=(R/'status/gpu_recovery_v3.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);assert not (R/'status/gpu_recovery_v3_owner.json').exists()
 assert socket.gethostname()==P['hardware_host'];os.chdir(R);os.environ['TMPDIR']=f'/proc/{os.getpid()}/cwd/tmp'
 for f,h in load(R/'audit/core124.json')['files'].items():assert sha(R/'engine'/f)==h
 save(R/'status/gpu_recovery_v3_owner.json',{'pid':os.getpid(),'pgid':os.getpgrp(),'host':socket.gethostname(),'at':time.time(),'ipc_anchor':os.environ['TMPDIR']})
 save(R/'status/recovery_current.json',{'at':time.time(),'stage':'starting_services_v3','gpu_controller_pid':os.getpid(),'cpu_controller_pid':load(R/'status/cpu_recovery_v3_owner.json')['pid'],'entry':'code/gpu_recovery_v3.py','ports':list(range(8321,8329)),'old_generation_read_only':True})
 try:
  with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:
   fs=[p.submit(run,[PY,'-B',R/'code/service_recovery_v3.py','start'],R/'logs'/f'gpu{g}_recovery_v3_start.log',environment(method='lifecycle',gpu=g),1900) for g in range(8)]
   for f in concurrent.futures.as_completed(fs):f.result()
  save(R/'status/recovery_services_v3_ready.json',{'at':time.time(),'ports':list(range(8321,8329))})
  # Two prior sessions remain exactly as recorded; only their absent context/assessment/execute stages resume.
  errors=[]
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:
   fs={p.submit(attempt,n,'full',g):n for g,n in [(0,'beers_s9013'),(2,'jobposting_small_s9013')]}
   for f in concurrent.futures.as_completed(fs):
    try:f.result()
    except BaseException:errors.append({'case':fs[f],'traceback':traceback.format_exc()})
  if errors:save(R/'status/pilot_recovery_v3_errors.json',errors);raise RuntimeError('Reviewed stage-only pilot recovery failed; no replay')
  wait_scoring();names=load(R/'configs/cases_formal_new.json');q=queue.Queue()
  for n in names:q.put(n)
  def lane(g):
   while not STOP.is_set():
    try:n=q.get_nowait()
    except queue.Empty:break
    for m in ['full','tabclean']:
     save(R/'status'/f'lane{g}_recovery_v3.json',{'at':time.time(),'case':n,'method':m,'gpu':g});attempt(n,m,g)
    q.task_done()
  save(R/'status/recovery_current.json',{'at':time.time(),'stage':'formal_recovery_v3_running','gpu_controller_pid':os.getpid(),'cpu_controller_pid':load(R/'status/cpu_recovery_v3_owner.json')['pid'],'ports':list(range(8321,8329)),'candidate_zeros_retained':True})
  with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:
   fs=[p.submit(lane,g) for g in range(8)]
   for f in concurrent.futures.as_completed(fs):
    try:f.result()
    except BaseException:errors.append({'traceback':traceback.format_exc()})
  save(R/'status/recovery_gpu_complete_v3.json',{'at':time.time(),'failed':errors,'formal_new_full_closed':sum(valid(R/'cases'/n,'full') for n in names),'formal_new_tabclean_closed':sum(valid(R/'cases'/n,'tabclean') for n in names)})
 finally:
  for g in range(8):
   d=R/'services_v3'/f'gpu{g}'
   if (d/'owner.json').exists() and not (d/'stopped.json').exists():
    try:run([PY,'-B',R/'code/service_recovery_v3.py','stop'],R/'logs'/f'gpu{g}_recovery_v3_stop.log',environment(method='lifecycle',gpu=g),360)
    except BaseException:save(R/'status'/f'gpu{g}_recovery_v3_stop_failure.json',{'traceback':traceback.format_exc()})
  save(R/'status/gpu_recovery_v3_finished.json',{'at':time.time(),'stop_new_dispatch':STOP.is_set()})
if __name__=='__main__':
 try:main()
 except BaseException:save(R/'status/gpu_recovery_v3_error.json',{'at':time.time(),'traceback':traceback.format_exc()});raise
