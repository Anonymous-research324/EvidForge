"""Fixed exact-repair scoring, completion-only eligibility, compact three-seed report."""
from pathlib import Path
import json,time,statistics,collections,os
from common import ROOT,load,save,sha,read_csv,freeze
from scoring import metric
ARMS=['full','tabclean']
def verify_all(names,outcomes):
 checks=0
 for rel,h in load(ROOT/'audit/execution_freeze_simple_v1.json')['files'].items():assert sha(ROOT/rel)==h,rel;checks+=1
 for rel,h in load(ROOT/'audit/core124.json')['files'].items():assert sha(ROOT/'engine'/rel)==h;checks+=1
 for p,h in load(ROOT/'audit/old_scores_frozen.json').items():assert sha(p)==h;checks+=1
 request_index=collections.defaultdict(list)
 for p in ROOT.glob('services/gpu*/requests/*/request.json'):
  b=load(p.parent/'binding.json')
  if b.get('case') not in names:continue
  d=load(p);meta=load(ROOT/'cases'/b['case']/'case.json');owner=load(ROOT/'services'/('gpu'+str(b['gpu']))/'owner.json')
  assert d['seed']==b['seed']==meta['seed'] and d['model']==owner['name']
  assert d['temperature']==.7 and d['top_p']==.8 and d['top_k']==20 and d['presence_penalty']==1.5 and d['repetition_penalty']==1.
  assert d['max_tokens']<=8192 and d['chat_template_kwargs']['enable_thinking'] is False
  assert (p.parent/'response.json').exists(),'Actual model response absent '+str(p)
  request_index[(b['case'],b['method'])].append(p.parent)
 receipts=[]
 for name in names:
  c=ROOT/'cases'/name
  for part in ['public','private']:
   for rel,h in load(c/'input_freeze.json')[part].items():assert sha(c/part/rel)==h;checks+=1
  meta=load(c/'case.json');outcome=outcomes[name]
  if outcome['status']!='closed':
   failure=c/'status/tabclean_failure.json'
   if not (c/'status/closed.json').exists() or not failure.exists() or not load(failure).get('known_truncation'):raise RuntimeError('Unreviewed failure blocks scoring: '+name)
   bad=[p for p in request_index[(name,'tabclean')] if load(p/'response.json')['choices'][0]['finish_reason']=='length']
   if not bad:raise RuntimeError('Truncation not supported by actual response: '+name)
   save(c/'audit/runtime_failure_review.json',{'category':'actual_model_output_truncated','response_paths':[str(p) for p in bad],'preserved':True,'score_not_zero':True,'main_table_exclusion':'incomplete pipeline, independent of repair score'})
   outcome['reviewed_failure']='actual_model_output_truncated'
  fields,dirty=read_csv(c/'public/repair_dirty.csv')
  for arm in ARMS:
   out=c/'outputs'/arm
   if not (out/'output_freeze.json').exists():
    assert outcome.get('reviewed_failure') and arm=='tabclean';continue
   for rel,h in load(out/'output_freeze.json')['files'].items():assert sha(out/rel)==h;checks+=1
   of,rows=read_csv(out/'repair_output.csv');assert of==fields and len(rows)==len(dirty)
   assert all(a['entity_id']==b['entity_id'] for a,b in zip(dirty,rows))
  assert (c/'outputs/full/repair_output.csv').read_bytes()==(c/'outputs/reuse/repair_output.csv').read_bytes()
  sessions=[]
  for kind in ['prior','context']:
   p=c/'work/full'/(kind+'_stage/native_v3/result.json');d=load(p)
   assert d['closed'] and d['native_exit_code']==0 and d['synthetic_control_count']==0 and d['real9B_calls']==5
   events=[json.loads(s) for s in (p.parent/'native_hooks.jsonl').read_text().splitlines()]
   assert sum(x.get('event')=='PreToolUse' for x in events)==5 and sum(x.get('event')=='PostToolUse' for x in events)==5
   sessions.append(d['real9B_calls'])
  assert sum(sessions)==len(request_index[(name,'full')])
  if outcome['status']=='closed':assert load(c/'outputs/tabclean/program_freeze.json')['actual_calls']==len(request_index[(name,'tabclean')])
  receipts.append({'case':name,'outcome':outcome['status'],'reviewed_failure':outcome.get('reviewed_failure'),'native_calls':sum(sessions),'reuse_byte_parity':True,'gpu':outcome['gpu']})
 save(ROOT/'audit/all_outputs_ready_simple_v1.json',{'passed':True,'checks':checks,'cases':receipts,'formal_rows_parsed':False,'at':time.time()})
 return outcomes
def score_case(name,outcome):
 c=ROOT/'cases'/name
 if (c/'status/scored.json').exists():return load(c/'scores.json')
 if (c/'audit_scoring_started.json').exists():raise RuntimeError('Scoring marker exists; fixed-output recovery review required')
 meta=load(c/'case.json')
 save(c/'audit_scoring_started.json',{'at':time.time(),'role':'independent once-only scorer','formal_reference_read':True})
 _,dirty=read_csv(c/'public/repair_dirty.csv');_,truth=read_csv(c/'private/repair_reference.csv')
 assert len(dirty)==len(truth);rows=[];examples=[]
 from unseen_table.common import equal
 for arm in ARMS:
  p=c/'outputs'/arm/'repair_output.csv'
  valid=(p.parent/'output_freeze.json').exists()
  base={'id':name,'dataset':meta['dataset'],'seed':meta['seed'],'profile':'mixed','arm':arm,'task':meta['task']}
  if not valid:
   rows.append({**base,'repair':None,'status':'runtime_failure','reason':outcome['reviewed_failure'],'qualification':None});continue
  _,out=read_csv(p);assert len(out)==len(truth)
  assert all(a['entity_id']==b['entity_id']==d['entity_id'] for a,b,d in zip(dirty,out,truth))
  result=metric(dirty,out,truth,meta['targets'])
  rows.append({**base,'repair':result,'status':'scored','qualification':load(c/'work/full/selection.json')['passed'] if arm=='full' else None})
  counts=collections.Counter()
  for i,(before,after,ref) in enumerate(zip(dirty,out,truth)):
   for field in meta['targets']:
    if equal(before[field],after[field]):continue
    kind='correct' if equal(after[field],ref[field]) else 'normal_damage' if equal(before[field],ref[field]) else 'wrong_repair'
    if counts[kind]<3:
     examples.append({'arm':arm,'row':i,'field':field,'before':before[field],'after':after[field],'reference':ref[field],'kind':kind});counts[kind]+=1
 save(c/'scores.json',rows);save(c/'case_studies.json',examples);save(c/'status/scored.json',{'at':time.time(),'methods':2,'reference_read_once':True})
 return rows
def aggregate(rows):
 cfg=load(ROOT/'configs/simple_protocol_v1.json');agg=[];pairs=[];eligibility=[]
 for ds in cfg['datasets']:
  rr=[r for r in rows if r['dataset']==ds]
  complete=all(sum(x['arm']==arm and x['repair'] is not None for x in rr)==3 for arm in ARMS)
  eligibility.append({'dataset':ds,'complete_both_three_seeds':complete,'criterion':'pipeline completion only; no F1/winner filter','has_valid_zero':any(x['repair'] is not None and x['repair']['F1']==0 for x in rr)})
  for arm in ARMS:
   for key in ['F1','normal_damage']:
    selected=sorted([x for x in rr if x['arm']==arm and x['repair'] is not None],key=lambda x:x['seed']);vals=[x['repair'][key] for x in selected]
    valid=len(vals)==3 and all(v is not None for v in vals)
    agg.append({'dataset':ds,'arm':arm,'metric':key,'n':len(vals),'mean':statistics.mean(vals) if valid else None,'sample_sd':statistics.stdev(vals) if valid else None,'per_seed':vals,'seeds':[x['seed'] for x in selected]})
  for key in ['F1','normal_damage']:
   mapped={(x['seed'],x['arm']):x['repair'][key] for x in rr if x['repair'] is not None}
   vals=[mapped[(s,'full')]-mapped[(s,'tabclean')] for s in cfg['seeds'] if (s,'full') in mapped and (s,'tabclean') in mapped and mapped[(s,'full')] is not None and mapped[(s,'tabclean')] is not None]
   pairs.append({'dataset':ds,'metric':'full_minus_tabclean_'+key,'n':len(vals),'mean':statistics.mean(vals) if len(vals)==3 else None,'sample_sd':statistics.stdev(vals) if len(vals)==3 else None,'per_seed':vals})
 save(ROOT/'reports/all_scores.json',rows);save(ROOT/'reports/aggregate.json',agg);save(ROOT/'reports/paired_differences.json',pairs);save(ROOT/'reports/completion_eligibility.json',eligibility)
 return agg,eligibility
def cost_report():
 totals=collections.defaultdict(collections.Counter);records=[]
 for label,root in [('old_greedy16k',ROOT.parent),('old_greedy_presence32k',ROOT.parent/'sampler_v2'),('three_seed_simple',ROOT)]:
  for p in root.glob('services/gpu*/requests/*/request.json'):
   b=load(p.parent/'binding.json');key=label+'/'+str(b.get('phase'))+'/'+str(b.get('method'));totals[key]['requests']+=1
   if (p.parent/'response.json').exists():
    d=load(p.parent/'response.json');totals[key]['responses']+=1
    for k in ['prompt_tokens','completion_tokens','total_tokens']:totals[key][k]+=d.get('usage',{}).get(k,0)
    sec=load(p.parent/'timing.json')['seconds'];totals[key]['request_seconds_sum']+=sec
    records.append({'cohort':label,'path':str(p.parent),'binding':b,'usage':d.get('usage'),'seconds':sec,'finish':d['choices'][0]['finish_reason']})
 save(ROOT/'reports/actual_model_costs.json',{'by_cohort_phase_method':{k:dict(v) for k,v in totals.items()},'requests':records,'legacy_and_diagnostics_not_omitted':True,'cohorts_never_pooled_for_accuracy':True})
def render_report(agg,eligibility,rows):
 idx={(x['dataset'],x['arm'],x['metric']):x for x in agg};labels={'banknote':'Banknote','retinopathy':'Retinopathy','wdbc':'WDBC','airfoil':'Airfoil','energy':'Energy','wine_red':'Wine Red','real_estate':'Real Estate'}
 def fmt(ds,arm,key):
  x=idx[(ds,arm,key)];scale=100 if key=='normal_damage' else 1
  return f"{x['mean']*scale:.3f} ± {x['sample_sd']*scale:.3f}" if x['mean'] is not None else f"未完整完成（{x['n']}/3）"
 cells=[];text=['# 与TabClean的同模型对照（三种子）','同Qwen3.5-9B BF16；共同非思考采样设置与8192输出上限；原作者最多10轮、早停3、开发调试3。','真实表上30%受控混合错误；同case同A100 TP1。两方法获得同一开发监督池，内部使用方式不同。','均值±样本标准差（n=3，ddof=1）；正常误改率越低越好。正文按完整运行条件展示，有效零分保留。','','|数据集|EvidForge修复F1|TabClean修复F1|正常误改率% EF / TC|','|---|---:|---:|---:|']
 for e in eligibility:
  ds=e['dataset']
  if not e['complete_both_three_seeds']:continue
  dagger=any(x['dataset']==ds and x['arm']=='full' and x['qualification'] is False for x in rows)
  vals=[labels[ds]+('†' if dagger else ''),fmt(ds,'full','F1'),fmt(ds,'tabclean','F1'),fmt(ds,'full','normal_damage')+' / '+fmt(ds,'tabclean','normal_damage')]
  cells.append(vals);text.append('|'+ '|'.join(vals)+'|')
 text+=['','† 至少一个种子外校未达标，EvidForge使用原研究回退结果，不代表自动部署合格。','','## 完整附录','|数据集|方法|F1|正常误改率%|有效种子数|','|---|---|---:|---:|---:|']
 for ds in labels:
  for arm in ARMS:text.append('|'+ '|'.join([labels[ds],arm,fmt(ds,arm,'F1'),fmt(ds,arm,'normal_damage'),str(idx[(ds,arm,'F1')]['n'])+'/3'])+'|')
 text+=['','失败种子、真实调用、原始计数及所有有效零值见all_scores.json和actual_model_costs.json。新旧采样版本分开，不混合准确率。']
 (ROOT/'reports/TabClean三种子精简对照.md').write_text('\n'.join(text)+'\n')
 save(ROOT/'reports/main_table_data.json',{'columns':['数据集','EvidForge 修复F1','TabClean 修复F1','正常误改率(%)\nEvidForge / TabClean'],'rows':cells,'source':'frozen all_scores.json','eligibility':'completion only'})
 profile={'backend':'matplotlib','strategy':'native_final_size','width_cm':18,'height_cm':max(4.5,2.6+.62*len(cells)),'font_pt':9,'title_pt':12,'dpi':600,'formats':['png','pdf','svg'],'note':'project choice, no journal template claimed'}
 save(ROOT/'reports/table_style_profile.json',profile)
 if cells:
  os.environ['MPLCONFIGDIR']=str(ROOT/'reports/.matplotlib')
  import matplotlib
  matplotlib.use('Agg')
  import matplotlib.pyplot as plt
  from matplotlib.font_manager import FontProperties
  fp=FontProperties(fname=str(ROOT/'reports/fonts/SongtiSC-Regular.ttf'))
  with plt.rc_context({'pdf.fonttype':42,'svg.fonttype':'none'}):
   fig,ax=plt.subplots(figsize=(profile['width_cm']/2.54,profile['height_cm']/2.54));ax.axis('off')
   tab=ax.table(cellText=cells,colLabels=['数据集','EvidForge\n修复F1 ↑','TabClean\n修复F1 ↑','正常误改率(%) ↓\nEvidForge / TabClean'],cellLoc='center',colWidths=[.18,.21,.21,.40],bbox=[.0,.15,1.,.7])
   tab.auto_set_font_size(False);tab.set_fontsize(profile['font_pt'])
   for (i,j),cell in tab.get_celld().items():
    cell.get_text().set_fontproperties(fp);cell.get_text().set_fontsize(profile['font_pt']);cell.visible_edges='';cell.set_facecolor('white')
   for j in range(4):tab[(0,j)].visible_edges='TB';tab[(0,j)].set_linewidth(1.);tab[(len(cells),j)].visible_edges='B'
   ax.set_title('与TabClean的同模型对照（三种子）',fontproperties=fp,fontsize=profile['title_pt'],pad=4)
   fig.text(.03,.03,'均值±样本标准差；†含外校未达标的研究回退种子。完整结果与失败记录见附录。',fontproperties=fp,fontsize=7)
   fig.subplots_adjust(left=.025,right=.985,top=.86,bottom=.08)
   for suffix in profile['formats']:fig.savefig(ROOT/'reports'/('TabClean三种子_论文表.'+suffix),dpi=profile['dpi'])
   plt.close(fig)
 save(ROOT/'status/reports_ready.json',{'at':time.time(),'main_datasets':len(cells),'score_sha':sha(ROOT/'reports/all_scores.json'),'visual_and_independent_review_pending':True})
def finalize(names,outcomes):
 verify_all(names,outcomes)
 rows=[row for name in names for row in score_case(name,outcomes[name])]
 agg,eligibility=aggregate(rows)
 # Independent arithmetic check from immutable counts; never re-read formal reference.
 for row in rows:
  m=row['repair']
  if m is None:continue
  p=m['exact']/m['changes'] if m['changes'] else None;r=m['exact']/m['errors'] if m['errors'] else 0.
  f=2*p*r/(p+r) if p and r else 0.
  assert abs(f-m['F1'])<1e-12
  assert m['normal_damage']==(m['damaged']/m['normal'] if m['normal'] else None)
 save(ROOT/'audit/independent_arithmetic_v1.json',{'passed':True,'rows':len(rows),'formal_reference_reopened':False,'zero_f1_retained':True})
 cost_report();render_report(agg,eligibility,rows)
 save(ROOT/'status/scoring_complete.json',{'at':time.time(),'cases':len(names),'rows':len(rows),'no_re_evaluation':True})
