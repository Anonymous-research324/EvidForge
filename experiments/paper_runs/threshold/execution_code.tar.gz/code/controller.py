"""CPU-only, at most three workers, no automatic retries or model calls."""
import concurrent.futures,subprocess,os,time,socket,traceback
from common import ROOT,PY,read,save,sha,tag
def one(job):
 i,d=job;c=read(ROOT/"configs/cases.json")[i];name=c["dataset"]+"_s"+str(c["seed"])+"_"+tag(d)
 env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1","NUMEXPR_NUM_THREADS":"1"}
 with (ROOT/"logs"/(name+".log")).open("x") as f:
  p=subprocess.Popen([PY,"-B",str(ROOT/"code/worker.py"),"--case",str(i),"--offset",str(d)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
  save(ROOT/"status"/("active_"+name+".json"),{"pid":p.pid,"case":i,"offset":d,"started":time.time()},once=True)
  rc=p.wait()
 save(ROOT/"status"/("done_"+name+".json"),{"pid":p.pid,"returncode":rc,"finished":time.time()},once=True)
 return {"case":i,"dataset":c["dataset"],"seed":c["seed"],"offset":d,"returncode":rc}
def main():
 assert (ROOT/"audit/preflight_pass.json").exists()
 save(ROOT/"status/controller_owner.json",{"pid":os.getpid(),"host":socket.gethostname(),"started":time.time(),"max_workers":3},once=True)
 cases=read(ROOT/"configs/cases.json")
 # All zero offsets first; their bytes must match each original A.
 jobs=[(i,d) for d in [0.,-.1,-.05,.05,.1] for i in range(len(cases))]
 results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futures=[pool.submit(one,j) for j in jobs]
  for f in concurrent.futures.as_completed(futures):
   result=f.result();results.append(result);save(ROOT/"status/progress.json",{"completed":len(results),"total":len(jobs),"failures":sum(x["returncode"]!=0 for x in results),"latest":result,"at":time.time()})
 if any(x["returncode"] for x in results):
  save(ROOT/"status/needs_review.json",{"outcomes":results,"scoring_blocked":True},once=True);return
 for c in cases:
  receipt=read(ROOT/"outputs"/(c["dataset"]+"_s"+str(c["seed"]))/"zero/receipt.json")
  assert receipt["zero_offset_original_A_byte_parity"] is True
 save(ROOT/"status/all_outputs_closed.json",{"outputs":len(results),"zero_parity":18,"new_model_calls":0},once=True)
 with (ROOT/"logs/score_once.log").open("x") as f:
  subprocess.run([PY,"-B",str(ROOT/"code/score_once.py")],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
 save(ROOT/"status/awaiting_presentation.json",{"scoring_complete":True,"at":time.time()},once=True)
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/controller_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()},once=True);raise
