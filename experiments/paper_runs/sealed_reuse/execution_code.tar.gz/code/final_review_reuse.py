
"""Independently recompute score-count statistics; never re-read formal reference."""
from pathlib import Path
import math,statistics,time
from common import ROOT,load,save,sha
def main():
 assert (ROOT/"status/scoring_complete.json").exists() and (ROOT/"status/reports_ready.json").exists()
 from audit_reuse import audit_ready
 audit_ready()
 rows=load(ROOT/"reports/all_scores.json");agg=load(ROOT/"reports/aggregate.json");checks=0
 for x in rows:
  m=x["repair"];p=m["exact"]/m["changes"] if m["changes"] else None;r=m["exact"]/m["errors"] if m["errors"] else 0.
  f=2*m["exact"]/(m["changes"]+m["errors"]) if m["changes"]+m["errors"] else 0.
  assert p==m["P"] and r==m["R"] and math.isclose(f,m["F1"],rel_tol=1e-12,abs_tol=1e-12)
  assert m["normal_damage"]==(m["damaged"]/m["normal"] if m["normal"] else None)
  c=ROOT/"cases"/x["case"]
  assert load(c/"status/execution_started.json")["at"]>load(ROOT/"status/inference_disabled.json")["at"]
  checks+=1
 for name in ["retinopathy","airfoil"]:
  for b in ["B1","B2","B3"]:
   for metric in ["P","R","F1","normal_damage"]:
    vals=[x["repair"][metric] for x in sorted(rows,key=lambda q:q["seed"]) if x["dataset"]==name and x["batch"]==b]
    a=agg[name][b][metric]
    assert a["per_seed"]==vals and a["n"]==sum(v is not None for v in vals)
    if all(v is not None for v in vals):
     mean=sum(vals)/3;sd=math.sqrt(sum((v-mean)**2 for v in vals)/2)
     assert math.isclose(mean,a["mean"],rel_tol=1e-12,abs_tol=1e-12)
     assert math.isclose(sd,a["sample_sd"],rel_tol=1e-12,abs_tol=1e-12)
    else:assert a["mean"] is None and a["sample_sd"] is None
 save(ROOT/"audit/final_independent_review.json",{"passed":True,"at":time.time(),"score_count_rows":checks,"aggregate_mean_sample_SD":"PASS","core_and_old_files":"PASS","source_cache_no_refit_and_zero_calls":"PASS","capsule_and_output_hashes":"PASS","combined_vs_split":"PASS","real_native_12sessions_60calls":"PASS","all_scores_sha":sha(ROOT/"reports/all_scores.json"),"formal_reference_reread":False,"still_needs_visual_QA":True})
 print("FINAL_INDEPENDENT_REVIEW_PASS",checks)
if __name__=="__main__":main()
