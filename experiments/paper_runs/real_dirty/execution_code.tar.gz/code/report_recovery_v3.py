"""Fixed-score presentation only. Never reads private/reference or changes numerical files."""
from pathlib import Path
import csv,json
from common import ROOT as R,load,save,sha
NAMES={'address_museum':'Museum','movies':'Movies','address_shoppingcenter':'ShoppingCenter','beers':'Beers','library_official':'Library（作者子集）','school_small':'School（固定子集）','government_small':'Government（固定子集）','jobposting_small':'JobPosting（固定子集）'}
SHORT={'address_museum':'Museum','movies':'Movies','address_shoppingcenter':'ShoppingCenter','beers':'Beers','library_official':'Library*','school_small':'School*','government_small':'Government*','jobposting_small':'JobPosting*'}
LABELS={'full':'EvidForge','raha_holoclean':'Raha＋HoloClean','garf':'GARF（兼容修复）','cdc':'CDC（CPU／类型适配）','tabclean':'TabClean（原生调试）'}
ORDER=['raha_holoclean','garf','cdc','tabclean','full']
NUMERICAL=['all_scores.json','pilot_scores.json','aggregate.json','paired_differences.json','qualification.json','actual_split_budgets.json','actual_model_costs.json']
def main():
 assert (R/'status/scoring_complete.json').exists() and load(R/'audit/final_independent_fixedscore_review.json')['passed']
 before={n:sha(R/'reports'/n) for n in NUMERICAL}
 p=load(R/'configs/protocol_recovery_v3.json');datasets=p['datasets'];assert len(datasets)==8
 ag=load(R/'reports/aggregate.json');records=load(R/'reports/all_scores.json');pilots=load(R/'reports/pilot_scores.json');assert len(records)==120 and len(pilots)==5
 assert all(x['complete'] and x['n']==3 for x in ag) and all(x['status']=='scored' for x in records)
 cells={(x['dataset'],x['method']):f"{x['mean']:.3f} ± {x['sample_sd']:.3f}" for x in ag}
 title='真实错误数据：五方法三种子准确修复结果'
 lines=['# '+title,'','种子1013/1014/1015；约10%实体组学习＋10%独立验证，剩余正式修复。沿用原EvidForge数值核心与质量门槛；不注入错误，不报告分类/回归下游分数。','','| 方法 | '+' | '.join(NAMES[x] for x in datasets)+' |','|---|'+'---:|'*len(datasets)]
 table=[]
 for method in ORDER:
  row=[LABELS[method],*[cells[ds,method] for ds in datasets]];table.append(row);lines.append('| '+' | '.join(row)+' |')
 lines+=['','三种子等权均值±样本标准差（ddof1），不声称统计显著。显示到三位小数的0.000可能为四舍五入，逐种子完整值见下表及JSON。','原Museum、Movies、ShoppingCenter的18份EvidForge/Raha＋HoloClean成绩及7份TabClean成功成绩由原冻结结果导入，未重新评分；其余95份主表成绩来自本次新冻结输出。','GARF为SQL值绑定、完整单元格传输、行读取与缓存兼容修复版本；CDC为CPU/source-schema适配版本；TabClean保持8192输出上限及作者原重试/调试次数，截断程序不执行。版本差异与旧失败及成本全部保留。','CDC的全singleton类别训练折会把同一TRAIN折同时供内部模型选择（tuning_data）使用，内部验证偏乐观；该例外未使用外部验证或独立conformal校准折训练，不能冒称作者默认独立内部验证配置。','两项9013探索prior（Beers、JobPosting）保留原Hook日志缺失：真实5次MCP/9B已闭合，未伪造Hook记录；仅作描述性探索，protocol_log_complete=false，绝不混入1013/1014/1015正式均值。正式30个native阶段均执行含SessionStart的完整严格Hook契约。','Government源内OOF F1=0仍按预先固定名单保留，不按正式得分删除数据、隐藏0或放松质量门槛。','Library为作者发布的1656行官方小子集；School3026行、Government3121行、JobPosting3125行为先按脏表实体组冻结的固定小子集，不冒称完整原表。','这些地址表属于同一个数据来源家族，OSM匹配参考不是逐格人工裁定；候选经过前期探索筛选，不能称独立新盲测。全部探索及旧SkiResort/Landmarks结果另留档。','外校未通过的EvidForge检查点仅作为研究结果，不称自动部署合格；资格与实际分区见对应JSON。','','## 各表实际分区与资格','','| 数据集 | 种子 | 学习组 | 验证组 | 修复组 | 学习行 | 验证行 | 修复行 | EvidForge原外校通过 |','|---|---:|---:|---:|---:|---:|---:|---:|---|']
 for b in load(R/'reports/actual_split_budgets.json'):
  if b['partition']!='formal':continue
  x=next(x for x in records if x['dataset']==b['dataset'] and x['seed']==b['seed'] and x['method']=='full');g=b['groups'];r=b['rows']
  lines.append(f"|{NAMES[b['dataset']]}|{b['seed']}|{g['learning']}|{g['validation']}|{g['repair']}|{r['learning']}|{r['validation']}|{r['repair']}|{x.get('original_evidforge_qualification')}|")
 lines+=['','## 正式逐种子原始结果','','| 数据集 | 种子 | 方法 | F1 | P | R | 正常误改率 | 结果来源 |','|---|---:|---|---:|---:|---:|---:|---|']
 for x in records:
  m=x['repair'];damage='None' if m['normal_damage_rate'] is None else f"{100*m['normal_damage_rate']:.6f}%"
  lines.append(f"|{NAMES[x['dataset']]}|{x['seed']}|{LABELS[x['method']]}|{m['F1']:.9f}|{m['P']:.9f}|{m['R']:.9f}|{damage}|{x['result_origin']}|")
 lines+=['','## 9013单种子探索（不混入三种子均值）','','| 数据集 | 方法 | 修复F1 | 协议记录 |','|---|---|---:|---|']
 for x in pilots:lines.append(f"|{NAMES[x['dataset']]}|EvidForge|{x['repair']['F1']:.9f}|{'完整' if x['protocol_log_complete'] else '原prior缺Hook日志，仅描述性探索'}|")
 md=R/'reports/真实错误扩展_五方法三种子_结果.md';md.write_text('\n'.join(lines)+'\n')
 with (R/'reports/绘图数据.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['method',*[NAMES[x] for x in datasets]]);w.writerows(table)
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 fonts=list((R/'resources/fonts').glob('*'));font=next((x for x in fonts if any(y in x.name.lower() for y in ['song','noto','simsun','pingfang'])),None)
 if font is None:raise RuntimeError('Chinese font absent; numerical report retained; repair presentation only')
 fp=FontProperties(fname=str(font))
 def panel(ax,ds,title,fontsize):
  ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off');width=.27;cw=(1-width)/len(ds);centers=[width/2,*[width+cw*(j+.5) for j in range(len(ds))]]
  ax.text(.5,1.035,title,fontproperties=fp,fontsize=fontsize+1,ha='center',va='bottom')
  for j,text in enumerate(['方法',*[SHORT[x] for x in ds]]):ax.text(centers[j],.91,text,fontproperties=fp,fontsize=fontsize,ha='center',va='center')
  ax.plot([0,1],[1,1],color='black',lw=1.2);ax.plot([0,1],[.82,.82],color='black',lw=.7)
  for j,method in enumerate(ORDER):
   y=.72-j*.145
   for k,text in enumerate([LABELS[method],*[cells[x,method] for x in ds]]):ax.text(centers[k],y,text,fontproperties=fp,fontsize=fontsize-.3,weight='bold' if method=='full' else 'normal',ha='center',va='center')
  ax.plot([0,1],[.035,.035],color='black',lw=1.2)
 def finish(fig,stem):
  for ext in ['png','pdf','svg']:fig.savefig(R/'reports'/(stem+'.'+ext),dpi=600,facecolor='white')
  plt.close(fig)
  try:
   import fitz
   doc=fitz.open(R/'reports'/(stem+'.pdf'));doc[0].get_pixmap(matrix=fitz.Matrix(2,2)).save(R/'reports'/(stem+'_PDF实际渲染.png'))
  except ImportError:save(R/'status/pdf_render_pending.json',{'reason':'PyMuPDF unavailable; actual PDF rendering required before delivery'})
 fig=plt.figure(figsize=(240/25.4,105/25.4));ax=fig.add_axes([.025,.23,.95,.65]);panel(ax,datasets,'真实错误数据上的准确修复表现（F1）',8.1)
 fig.text(.03,.15,'注：均值±样本标准差，n=3；*为明确标注的作者／固定小子集；实际规模和分区见附表。',fontproperties=fp,fontsize=7)
 fig.text(.03,.10,'原成绩保留；CDC有TRAIN折内部验证复用，选择偏乐观；地址子集同源；外校资格另列。',fontproperties=fp,fontsize=7)
 fig.text(.03,.05,'0.000为三位小数显示；9013探索不混入正式均值，不作三种子统计显著性断言。',fontproperties=fp,fontsize=7)
 finish(fig,'真实错误扩展_五方法三种子_F1')
 fig=plt.figure(figsize=(180/25.4,145/25.4));top=fig.add_axes([.025,.55,.95,.37]);bottom=fig.add_axes([.025,.14,.95,.37]);panel(top,datasets[:4],'真实错误修复F1（上）',8.6);panel(bottom,datasets[4:],'真实错误修复F1（下）',8.6)
 fig.text(.03,.09,'均值±样本标准差，n=3；*为作者／固定小子集，详见实际行数与版本附表。',fontproperties=fp,fontsize=7)
 fig.text(.03,.055,'保留旧成绩；CDC内部TRAIN验证复用；地址子集同源；9013含2项Hook缺日志探索。',fontproperties=fp,fontsize=7)
 finish(fig,'真实错误扩展_五方法三种子_F1_Word')
 assert {n:sha(R/'reports'/n) for n in NUMERICAL}==before,'Presentation must not mutate numerical results'
 save(R/'reports/presentation_manifest.json',{'files':{x.name:sha(x) for x in (R/'reports').glob('*') if x.is_file() and x.name!='presentation_manifest.json'},'actual_visual_inspection_pending':True,'numerical_files_preserved':before})
 save(R/'status/reports_ready.json',{'main':str(md.relative_to(R)),'visual_QA_pending':True,'main_records':120,'pilot_records':5})
 print('RECOVERY_V3_REPORTS_READY;actual_PNG_PDF_viewing_still_required')
if __name__=='__main__':main()
