"""Fresh process: install original runtime before untouched original teaching audit."""
from pathlib import Path
import argparse
from runtime_v4 import install
install()
from coverage_two import audit_prior
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--case",type=Path,required=True);p.add_argument("--prior",type=Path,required=True);a=p.parse_args()
    audit_prior(a.case,a.prior)
