"""Read fixed scores only; paper-style tables, mean/sample SD and paired deltas."""
from pathlib import Path
import os,sys,statistics,collections,math,json,hashlib,time
from common import ROOT,load,save,sha
ARMS=["full","no_llm","no_transforms","no_generated_execution","no_final_gate","no_feedback","no_predictive_context","reuse"]
LABEL={"full":"完整 EvidForge","no_llm":"完全不使用 LLM","no_transforms":"关闭学得纠错变换","no_generated_execution":"关闭新增规则执行","no_final_gate":"关闭最终置信门槛","no_feedback":"关闭源内反馈改写","no_predictive_context":"关闭预测上下文","reuse":"封存技能复用"}
def stats(v):
 values=[x for x in v if x is not None]
 return {"n":len(values),"total_seeds":3,"mean":statistics.mean(values) if len(values)==3 else None,"sample_sd":statistics.stdev(values) if len(values)==3 else None,"per_seed":v}
def fmt(a,percent=False):
 if a["mean"] is None:return "N/A ("+str(a["n"])+"/3)"
 scale=100 if percent else 1
 return format(a["mean"]*scale,".3f")+" ± "+format(a["sample_sd"]*scale,".3f")
def build(scores):
 if len(scores)!=48:raise ValueError("Expected 6 cases x8 fixed outputs")
 index={(x["dataset"],x["seed"],x["arm"]):x for x in scores}
 if len(index)!=48:raise ValueError("Repeated/missing score identity")
 ag=[];paired=[]
 for ds in ["hospital","flights"]:
  for arm in ARMS:
   for metric in ["P","R","F1","normal_damage","detection_AUC"]:
    vals=[index[(ds,s,arm)]["repair"][metric] for s in [1013,1014,1015]]
    ag.append({"dataset":ds,"arm":arm,"metric":metric,**stats(vals)})
   if arm!="full":
    for metric in ["F1","normal_damage"]:
     vals=[index[(ds,s,"full")]["repair"][metric]-index[(ds,s,arm)]["repair"][metric] if index[(ds,s,"full")]["repair"][metric] is not None and index[(ds,s,arm)]["repair"][metric] is not None else None for s in [1013,1014,1015]]
     paired.append({"dataset":ds,"arm":arm,"metric":"full_minus_arm_"+metric,**stats(vals)})
 strata=[]
 for ds in ["hospital","flights"]:
  kinds=sorted({k for x in scores if x["dataset"]==ds for k in x["by_constructed_mechanism"]})
  for arm in ARMS:
   for k in kinds:
    vals=[index[(ds,s,arm)]["by_constructed_mechanism"].get(k,{}).get("exact_repair_recall") for s in [1013,1014,1015]]
    strata.append({"dataset":ds,"arm":arm,"mechanism":k,**stats(vals)})
 report={"scope":"Known real-source tables with newly controlled domain-valid conflicts; frozen original method, not new blind/natural-only data","score_sha256":sha(ROOT/"reports/all_scores.json"),"aggregate":ag,"paired":paired,"mechanisms":strata}
 save(ROOT/"reports/aggregate.json",report);save(ROOT/"reports/paired_differences.json",paired)
 lookup={(a["dataset"],a["arm"],a["metric"]):a for a in ag}
 lines=["# 语义与跨字段专项：三种子受控压力测试",
 "Hospital、Flights来自以前使用过的真实表；本轮先还原参考，再按预定30%比例在指定字段制造合法值冲突。因此是受控实验，不能称原始自然错误或新盲测。",
 "124核心算法与原数值参数不改。此结果独立于正文Retinopathy/Airfoil主消融，不与原实验均值合并。","",
 "|条件|Hospital 修复F1|正常误改%|Flights 修复F1|正常误改%|","|---|---:|---:|---:|---:|"]
 for arm in ARMS:
  lines.append("|"+LABEL[arm]+"|"+"|".join(fmt(lookup[(d,arm,m)],m=="normal_damage") for d in ["hospital","flights"] for m in ["F1","normal_damage"])+"|")
 lines+=["","各格为三seed等权均值±样本标准差（ddof=1）。置信门槛同时看修复和正常误改；三seed不代表统计显著。","源内学习/独立外校/正式修复按医院20/10/15实体、航班20/10/70实体隔离；不是统一10%/10%。30%仅为预定受扰字段中的已知格，不能写成全表30%。","无修改时P为N/A，F1=0属于有效no-op；失败不能记0。reuse零新调用且字节一致。","保留全部条件和反向/持平结果；不得以本文发现选择更好seed或调整候选。自然源旧实验结果不改。","",
 "## 错误机制分层（准确修复召回率）",
 "|数据|错误类型|完整|无LLM|无新增规则执行|无反馈|无预测上下文|","|---|---|---:|---:|---:|---:|---:|"]
 for d in ["hospital","flights"]:
  for k in sorted({x["mechanism"] for x in strata if x["dataset"]==d}):
   choices=[next(x for x in strata if x["dataset"]==d and x["mechanism"]==k and x["arm"]==a) for a in ["full","no_llm","no_generated_execution","no_feedback","no_predictive_context"]]
   lines.append("|"+d+"|"+k+"|"+"|".join(fmt(x) for x in choices)+"|")
 qualifications=[]
 for ds in ["hospital","flights"]:
  for arm in ["full","no_llm","no_feedback","no_predictive_context"]:
   vals=[load(ROOT/"cases"/("semantic_"+ds+"_s"+str(s))/"work"/arm/"selection.json")["passed"] for s in [1013,1014,1015]]
   qualifications.append({"dataset":ds,"arm":arm,"passed_seeds":sum(vals),"per_seed":vals})
 lines+=["","## 外校资格","未通过外校的技能仅按既定研究prior报告，不能称合格自动部署。",json.dumps(qualifications,ensure_ascii=False)]
 (ROOT/"reports/语义与跨字段消融结果.md").write_text("\n".join(lines)+"\n")
 calls=[];totals=collections.Counter()
 for p in sorted((ROOT/"services").glob("gpu*/requests/*")):
  a=load(p/"request.json");b=load(p/"response.json");t=load(p/"timing.json");usage=b["usage"]
  calls.append({"path":str(p),"request_sha":sha(p/"request.json"),"response_sha":sha(p/"response.json"),"seed":a["seed"],"model":a["model"],"temperature":a["temperature"],"usage":usage,"seconds":t["seconds"],"finish_reason":b["choices"][0]["finish_reason"]})
  totals["requests"]+=1
  for k in ["prompt_tokens","completion_tokens","total_tokens"]:totals[k]+=usage.get(k,0)
 save(ROOT/"reports/actual_model_costs.json",{"totals":dict(totals),"calls":calls,"hardware":"A10040GB TP1 both lanes; each case all arms same device","wall_clock_scope":"Per request timings are API elapsed, not CPU fit wall time; no speedup claim from absent source timing"})
 save(ROOT/"reports/qualification.json",qualifications)
 render(lookup)
 save(ROOT/"status/reports_ready.json",{"at":time.time(),"all_scores_sha":report["score_sha256"],"still_requires_final_review":True})
def render(lookup):
 os.environ["MPLCONFIGDIR"]=str(ROOT/"reports/.matplotlib")
 import matplotlib
 matplotlib.use("Agg")
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 fonts=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/reports/paper_ablation_tables_20261022/fonts")
 reg=FontProperties(fname=str(fonts/"SongtiSC-Regular.ttf"),size=10)
 bold=FontProperties(fname=str(fonts/"SongtiSC-Bold.ttf"),size=10)
 plt.rcParams.update({"pdf.fonttype":42,"ps.fonttype":42,"svg.fonttype":"none"})
 fig=plt.figure(figsize=(10.4,4.35),facecolor="white");ax=fig.add_axes([.02,.02,.96,.96]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
 def txt(x,y,s,strong=False,ha="center",size=None):
  p=bold if strong else reg
  if size is not None:p=p.copy();p.set_size(size)
  ax.text(x,y,s,fontproperties=p,ha=ha,va="center",color="black")
 txt(.5,.96,"语义与跨字段专项：三种子消融（均值 ± 样本标准差）",True,size=13)
 txt(.5,.90,"真实表派生的受控合法值冲突；保留原算法，非原始自然脏表",size=9)
 xs=[.02,.44,.59,.78,.94];ys=.78;dh=.070
 ax.hlines(.85,.01,.995,color="black",lw=1.3)
 for x,s in zip(xs,["设置","Hospital F1","误改 / %","Flights F1","误改 / %"]):txt(x,ys,s,True,ha="left" if x==.02 else "center")
 ax.hlines(.735,.01,.995,color="black",lw=.65)
 for i,arm in enumerate(ARMS):
  y=.69-i*dh;txt(.02,y,LABEL[arm],arm=="full","left")
  for x,(d,m) in zip(xs[1:],[(d,m) for d in ["hospital","flights"] for m in ["F1","normal_damage"]]):txt(x,y,fmt(lookup[(d,arm,m)],m=="normal_damage"),arm=="full")
 ax.hlines(.69-7*dh-.045,.01,.995,color="black",lw=1.3)
 txt(.015,.09,"F1越高越好，正常误改率越低越好；全部条件保留，三种子不称统计显著。",ha="left",size=9)
 txt(.015,.035,"外校资格另表报告；未通过者为研究prior。本表不替代分类/回归主消融。",ha="left",size=9)
 for suffix in ["png","pdf","svg"]:fig.savefig(ROOT/"reports"/("语义跨字段消融表."+suffix),dpi=600,bbox_inches="tight",pad_inches=.08)
 plt.close(fig)
if __name__=="__main__":build(load(ROOT/"reports/all_scores.json"))
