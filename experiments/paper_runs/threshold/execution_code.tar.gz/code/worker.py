import os,sys,time,argparse,traceback
from pathlib import Path
from common import ROOT,read,save,sha,csvread,csvwrite,freeze,tag
sys.dont_write_bytecode=True
def run(index,delta):
 c=read(ROOT/"configs/cases.json")[index]
 out=ROOT/"outputs"/(c["dataset"]+"_s"+str(c["seed"]))/tag(delta)
 if out.exists():raise FileExistsError("Do not replay or reset an existing output")
 out.mkdir(parents=True)
 save(out/"started.json",{"pid":os.getpid(),"seed":c["seed"],"offset":delta,"time":time.time()},once=True)
 from runtime import install
 counts=install(c["seed"],delta)
 from workflow.packages import execute
 fields,dirty=csvread(c["input"]);targets=set(read(c["declaration"])["targets"])
 t=time.monotonic();rows,decisions=execute(dirty,Path(c["skill"]));seconds=time.monotonic()-t
 assert len(rows)==len(dirty) and all(set(r)==set(fields) for r in rows)
 assert all(a[k]==b[k] for a,b in zip(dirty,rows) for k in fields if k not in targets)
 csvwrite(out/"repair_output.csv",fields,rows)
 parity=None
 if delta==0:
  parity=(out/"repair_output.csv").read_bytes()==Path(c["original_output"]).read_bytes()
  if not parity:raise ValueError("Zero-offset must reproduce frozen A bytes; block scoring")
 save(out/"decisions.json",decisions,once=True)
 save(out/"receipt.json",{"dataset":c["dataset"],"seed":c["seed"],"offset":delta,"seconds":seconds,"qualified_original":c["qualified"],"rows":len(rows),"target_cells":len(rows)*len(targets),"changed_literal_cells":sum(a[k]!=b[k] for a,b in zip(dirty,rows) for k in targets),"permission_counters":dict(counts),"zero_offset_original_A_byte_parity":parity,"new_model_calls":0,"formal_reference_read":False},once=True)
 save(out/"output_freeze.json",{"files":freeze(out)},once=True)
 print("OUTPUT_CLOSED",c["dataset"],c["seed"],delta,round(seconds,2),flush=True)
if __name__=="__main__":
 p=argparse.ArgumentParser();p.add_argument("--case",type=int,required=True);p.add_argument("--offset",type=float,required=True);a=p.parse_args()
 try:run(a.case,a.offset)
 except Exception as exc:
  save(ROOT/"status"/("failure_case"+str(a.case)+"_"+tag(a.offset)+".json"),{"error":repr(exc),"traceback":traceback.format_exc(),"time":time.time()},once=True);raise
