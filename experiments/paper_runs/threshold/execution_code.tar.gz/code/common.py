from pathlib import Path
import json,hashlib,os,uuid,csv
ROOT=Path(__file__).resolve().parents[1]
PY="/root/fsas/home/anonymous/envs/dataforge-run/bin/python"
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def save(p,x,once=False):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 if once:
  with p.open("x") as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
 else:
  t=p.with_name(p.name+"."+uuid.uuid4().hex+".tmp");t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+"\n");os.replace(t,p)
def csvread(p):
 with Path(p).open(newline="") as f:r=csv.DictReader(f);return r.fieldnames,list(r)
def csvwrite(p,fields,rows):
 with Path(p).open("x",newline="") as f:w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n");w.writeheader();w.writerows(rows)
def freeze(p):return {str(x.relative_to(p)):sha(x) for x in sorted(Path(p).rglob("*")) if x.is_file() and x.suffix!=".pyc"}
def tag(d):return "zero" if not d else ("m" if d<0 else "p")+str(abs(d)).replace(".","p")
