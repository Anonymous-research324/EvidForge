
"""Synthetic full-fit and offline equivalence tests, never reads reserved formal rows."""
from pathlib import Path
import os,sys,time,subprocess,ast,statistics
from common import ROOT,ENGINE,PY,load,save,sha,freeze
def run():
 for p in (ROOT/"code").glob("*.py"):ast.parse(p.read_text())
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ENGINE/rel)==h
 for p,h in load(ROOT/"audit/protected_old_files.json").items():assert sha(p)==h
 folder=ROOT/"audit/synthetic";folder.mkdir(exist_ok=False)
 schema={"id":"invented-reuse-preflight","provenance":"fictional isolation and cache test, not performance","entity_fields":["entity_id"],"targets":["a","b"],"protected_fields":[],"visible_context_fields":[],"fields":{"entity_id":{"role":"identity","type":"string","identity":True},"a":{"role":"target","type":"number"},"b":{"role":"target","type":"number"}}}
 def groups(ids):
  return [{"group":f"g{i}","provenance":"synthetic","records":[{"row_key":str(i),"dirty":{"entity_id":str(i),"a":str(100+i*2),"b":str(200+i)},"truth":{"a":str(50+i),"b":str(200+i)}}]} for i in ids]
 for n,d in [("bundle.json",{"learning":groups(range(30)),"validation":groups(range(40,50))}),("schema.json",schema),("context.json",{"dataset":"synthetic"})]:save(folder/n,d)
 env={**os.environ,"EF_SEED":"1013","EF_ARM":"full","EF_ROLE":"learning","OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2"}
 cmd=[str(ROOT/"code/ef-python-v4"),str(ENGINE/"repair_platform.py"),"prepare-heldout","--labels",str(folder/"bundle.json"),"--declaration",str(folder/"schema.json"),"--context",str(folder/"context.json"),"--out",str(folder/"onboarding")]
 with (folder/"prepare.log").open("x") as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError("Synthetic fit failed: "+str(folder/"prepare.log"))
 os.environ.update(env)
 from runtime_v4 import install
 install()
 from learn_reuse import seal_off
 from source_cache import materialize,install as install_cache
 from workflow.packages import execute
 from cache_codec import encode,decode
 from offline_guard import install as offline,stop_profile
 import numpy as np
 from decimal import Decimal
 sample={("key",1):np.asarray([[1.,float("nan")],[2.,float("inf")]]),"decimal":Decimal("1.200"),"tuple":("x",3),"set":{1,2}}
 assert encode(decode(encode(sample)))==encode(sample)
 skill=folder/"onboarding/prior_prepared";seal_off(skill)
 rows=[dict(x["records"][0]["dirty"]) for x in groups([70,71,72])]
 cache=materialize(skill);before=execute(rows,skill);events=[];install_cache(cache,events)
 from skill_runtime.codec import fit
 # Original reference is obtained from its source in a separate synthetic process below.
 bad=folder/"negative_fit.py"
 bad.write_text("import os,sys\nsys.path.insert(0,"+repr(str(ROOT/"code"))+")\nfrom runtime_v4 import install\ninstall()\nfrom skill_runtime.codec import fit\nfrom offline_guard import install as guard\nfrom pathlib import Path\nc=guard(Path("+repr(str(folder/"fit_negative.jsonl"))+"),Path("+repr(str(ENGINE))+"))\ntry:fit([],{'targets':[]})\nexcept PermissionError:pass\nelse:raise AssertionError('fit allowed')\nassert c['fit_attempts']==1\n")
 with (folder/"negative_fit.log").open("x") as f:p=subprocess.run([PY,"-B",str(bad)],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0
 counts=offline(folder/"offline_positive.jsonl",ENGINE)
 try:after=execute(rows,skill)
 finally:stop_profile()
 assert encode(before)==encode(after) and len(events)>=3 and not any(counts.values())
 # Negative tests prove the guards fire, not just a stored zero.
 import socket
 negative=offline(folder/"offline_negative.jsonl",ENGINE)
 try:socket.create_connection(("127.0.0.1",9),timeout=.1)
 except PermissionError:pass
 else:raise AssertionError("Network guard failed")
 stop_profile()
 assert negative["network_attempts"]==1
 from metrics_reuse import repair_metrics,summary
 from unseen_table.common import equal
 d=[{"a":"bad","b":"2"}];t=[{"a":"1","b":"2"}]
 assert repair_metrics(d,d,t,["a","b"],equal)["P"] is None
 assert repair_metrics(d,t,t,["a","b"],equal)["F1"]==1.
 assert summary([1.,2.,3.])["sample_sd"]==1. and summary([1.,2.,None])["mean"] is None
 # Batch/private guards must reject actual open attempts, before reading.
 probe=folder/"batches/B1/dirty.csv";probe.parent.mkdir(parents=True);probe.write_text("a\n1\n")
 try:probe.read_text()
 except PermissionError:pass
 else:raise AssertionError("Learning read future batch")
 try:(folder/"private/reference.csv").read_text()
 except PermissionError:pass
 else:raise AssertionError("Learning read private")
 save(ROOT/"audit/preflight_pass.json",{"at":time.time(),"core124":"PASS","protected_old_files":"PASS","synthetic_full_fit":"PASS","type_preserving_cache_roundtrip":"PASS","cached_uncached_output_decision_parity":"PASS","offline_no_fit_positive":"PASS","network_and_fit_negative_tests":"PASS","learning_batch_private_isolation":"PASS","metric_None_and_sample_sd":"PASS","actual_model_calls":0,"formal_rows_read":0})
 print("PREFLIGHT_PASS",flush=True)
if __name__=="__main__":run()
