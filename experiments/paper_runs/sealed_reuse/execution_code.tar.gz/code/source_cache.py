"""Materialize unchanged source-only fit functions before seeing any new batch."""
from pathlib import Path
import json
from common import load,save
from cache_codec import encode,decode,key
def materialize(skill):
 from skill_runtime.package import open_skill
 from skill_runtime.codec import fit as codec_fit
 from learning.observation_model import fit as observation_fit
 configs=[];current=Path(skill)
 while True:
  cfg=load(current/"configuration.json")
  if "base_skill_path" in cfg:
   configs.append(current);break
  if "prior_skill_path" in cfg:current=Path(cfg["prior_skill_path"])
  else:raise ValueError("Unknown sealed skill format")
 cache={}
 for root in configs:
  cfg=load(root/"configuration.json");records=load(root/"source_records_backend.json")["records"]
  _,base,*_=open_skill(cfg["base_skill_path"])
  cache[key("codec",records,base["declaration"])]=encode(codec_fit(records,base["declaration"]))
  for mode in ["raw","signed_log"]:cache[key("observation",records,base,mode)]=encode(observation_fit(records,base,mode))
 return cache
def install(cache,events):
 import learning.evidence as evidence
 import learning.observation_model as observation
 import skill_runtime.codec as codec
 old_codec=codec.fit;old_observation=observation.fit
 def get(kind,args):
  k=key(kind,*args)
  if k not in cache:raise RuntimeError("Cache miss is forbidden, never fit at inference: "+kind+" "+k)
  events.append({"kind":"source_cache_hit","function":kind,"key":k})
  return decode(cache[k])
 def cached_codec(records,declaration):return get("codec",[records,declaration])
 def cached_observation(records,base,mode="raw"):return get("observation",[records,base,mode])
 # Replace exact original imported aliases, preserving all numerical consumers.
 import sys
 for module in list(sys.modules.values()):
  if module:
   for name,value in list(vars(module).items()):
    if value is old_codec:setattr(module,name,cached_codec)
    elif value is old_observation:setattr(module,name,cached_observation)
 return {"codec":cached_codec,"observation":cached_observation}
