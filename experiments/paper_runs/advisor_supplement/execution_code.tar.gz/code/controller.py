"""唯一双GPU调度；不重复执行，不自动重试，失败证据保留，全部封存后评分。"""
from pathlib import Path
import os,sys,time,json,subprocess,threading,queue,traceback,fcntl
from common import ROOT,PY,load,save,status,sha
def run(entry,args,log,env):
 with Path(log).open("x") as f:r=subprocess.run([PY,"-B",str(ROOT/"code"/entry),*map(str,args)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 return r.returncode
def main():
 lock=(ROOT/"status/controller.lock").open("a");fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (ROOT/"status/owner.json").exists():raise RuntimeError("Prior controller exists; inspect before recovery")
 save(ROOT/"status/owner.json",{"pid":os.getpid(),"started":time.time(),"command":[PY,str(Path(__file__))],"scope":"fixed protocol; no result-driven tuning"})
 # Freeze check before any case begins.
 frozen=load(ROOT/"audit/code_freeze.json")
 for rel,h in frozen["files"].items():
  if sha(ROOT/rel)!=h:raise ValueError("Frozen driver changed: "+rel)
 names=load(ROOT/"configs/cases.json");q=queue.Queue()
 # Already fixed order: main/natural first, sample size and robustness afterward.
 for i,n in enumerate(names):
  if i%3!=2:q.put(n)
 outcomes={};mu=threading.Lock()
 def lane(gpu):
  env={**os.environ,"EF_GPU":str(gpu),"EF_SEED":"1013","OMP_NUM_THREADS":"2","PYTHONDONTWRITEBYTECODE":"1"}
  ready=ROOT/"services"/f"gpu{gpu}"/"ready.json"
  for _ in range(600):
   if ready.exists():break
   time.sleep(2)
  else:raise RuntimeError("Service not ready; inspect owner without duplicating")
  while True:
   try:n=q.get_nowait()
   except queue.Empty:return
   case=ROOT/"cases"/n
   status(f"gpu{gpu}",case=n,pid=os.getpid(),phase="EvidForge")
   rc=run("worker.py",["case","--case",case,"--gpu",gpu],ROOT/"logs"/(n+"_worker.log"),env)
   tabrc=None
   if load(case/"case.json")["suite"] in ["main","natural"]:
    status(f"gpu{gpu}",case=n,pid=os.getpid(),phase="TabClean")
    tabrc=run("tabclean.py",["--case",case,"--gpu",gpu],ROOT/"logs"/(n+"_tabclean.log"),env)
    if tabrc==0:save(case/"status/tabclean_closed.json",{"at":time.time()})
   with mu:
    outcomes[n]={"worker_returncode":rc,"tabclean_returncode":tabrc,"at":time.time()}
    save(ROOT/"status/outcomes.json",outcomes)
    status("overview",completed=len(outcomes),planned=len(names),failed=sum(v["worker_returncode"]!=0 or v["tabclean_returncode"] not in [None,0] for v in outcomes.values()))
   q.task_done()
 from concurrent.futures import ThreadPoolExecutor
 with ThreadPoolExecutor(2) as pool:
  fs=[pool.submit(lane,g) for g in [0,1]]
  for f in fs:f.result()
 while not (ROOT/"status/satellite_complete.json").exists():
  if (ROOT/"status/satellite_error.json").exists():raise RuntimeError("Satellite execution failed; preserve evidence")
  time.sleep(15)
 outcomes.update(load(ROOT/"status/outcomes_gpu2.json"))
 save(ROOT/"status/outcomes.json",outcomes)
 bad={k:v for k,v in outcomes.items() if v["worker_returncode"]!=0 or v["tabclean_returncode"] not in [None,0]}
 if bad:
  save(ROOT/"status/needs_interface_review.json",{"failures":bad,"at":time.time(),"scoring_blocked":True,"no_automatic_retry":True});return
 save(ROOT/"status/all_model_outputs_closed.json",{"at":time.time(),"cases":len(names)})
 for gpu in [0,1]:
  rc=run("model_service.py",["stop"],ROOT/"logs"/f"service_stop_gpu{gpu}.log",{**os.environ,"EF_GPU":str(gpu)})
  if rc:raise RuntimeError("Owned resource cleanup failed")
 rc=run("score.py",[],ROOT/"logs/independent_scoring.log",dict(os.environ))
 if rc:raise RuntimeError("Scoring failed; preserve once markers")
 save(ROOT/"status/complete.json",{"at":time.time(),"cases":len(names)})
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/controller_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
