"""Scorer only: once per closed case, original exact-repair formulas. No downstream labels exposed."""
from pathlib import Path
import sys,time,collections,statistics
from common import ROOT,load,save,sha,read_csv
sys.path.insert(0,str(ROOT/'engine/source_runtime'))
from unseen_table.common import equal
ARMS=['full','no_llm','reuse','tabclean']
def metric(d,o,t,cols):
 e=n=c=tp=harm=0
 for a,b,z in zip(d,o,t):
  for k in cols:
   if z[k]=='':continue
   bad=not equal(a[k],z[k]);changed=not equal(a[k],b[k])
   e+=bad;n+=not bad;c+=changed;tp+=bad and changed and equal(b[k],z[k]);harm+=not bad and changed
 p=tp/c if c else None;r=tp/e if e else 0.
 return {'P':p,'R':r,'F1':2*p*r/(p+r) if p and r else 0.,'normal_damage':harm/n if n else None,'errors':e,'normal':n,'changes':c,'exact':tp,'damaged':harm}
def score(case):
 if (case/'status/scored.json').exists():return load(case/'scores.json')
 if (case/'audit_scoring_started.json').exists():raise RuntimeError('Once-only marker exists; fixed-output recovery review required')
 if not (case/'status/paired_closed.json').exists():raise RuntimeError('Paired outputs not closed')
 fz=load(case/'input_freeze.json')
 for part in ['public','private']:
  for rel,h in fz[part].items():assert sha(case/part/rel)==h
 for a in ARMS:
  out=case/'outputs'/a
  for rel,h in load(out/'output_freeze.json')['files'].items():assert sha(out/rel)==h
 save(case/'audit_scoring_started.json',{'at':time.time(),'role':'independent scorer','once_only':True})
 cfg=load(case/'case.json');_,d=read_csv(case/'public/repair_dirty.csv');_,t=read_csv(case/'private/repair_reference.csv');cols=cfg['targets'];assert len(d)==len(t)
 results=[];examples=[]
 for a in ARMS:
  _,o=read_csv(case/'outputs'/a/'repair_output.csv');assert len(d)==len(o)
  assert all(x['entity_id']==y['entity_id']==z['entity_id'] for x,y,z in zip(d,o,t))
  results.append({'id':case.name,'dataset':cfg['dataset'],'phase':cfg['phase'],'seed':cfg['seed'],'profile':cfg['profile'],'task':cfg['task'],'arm':a,'repair':metric(d,o,t,cols),'qualification':load(case/'work/full/selection.json')['passed'] if a in ['full','reuse'] else load(case/'work/no_llm/selection.json')['passed'] if a=='no_llm' else None})
  ct=collections.Counter()
  for i,(x,y,z) in enumerate(zip(d,o,t)):
   for k in cols:
    if equal(x[k],y[k]):continue
    kind='correct' if equal(y[k],z[k]) else 'normal_damage' if equal(x[k],z[k]) else 'wrong_repair'
    if ct[kind]<3:examples.append({'arm':a,'row':i,'field':k,'before':x[k],'after':y[k],'reference':z[k],'kind':kind});ct[kind]+=1
 save(case/'scores.json',results);save(case/'case_studies.json',examples);save(case/'status/scored.json',{'at':time.time(),'rows':len(results)})
 return results
def aggregate(phase,names):
 rows=[x for n in names for x in load(ROOT/'cases'/n/'scores.json')]
 save(ROOT/'reports'/(phase+'_all_scores.json'),rows)
 out=[]
 for ds in sorted({x['dataset'] for x in rows}):
  for prof in ['structured_repeat','mixed']:
   for arm in ARMS:
    for key in ['F1','normal_damage']:
     r=sorted([x for x in rows if x['dataset']==ds and x['profile']==prof and x['arm']==arm],key=lambda x:x['seed']);v=[x['repair'][key] for x in r]
     expected=2 if phase=='pilot' else 5
     if len(v)!=expected or any(x is None for x in v):raise RuntimeError('Incomplete aggregate')
     out.append({'dataset':ds,'profile':prof,'arm':arm,'metric':key,'n':len(v),'mean':statistics.mean(v),'sample_sd':statistics.stdev(v),'per_seed':v})
 save(ROOT/'reports'/(phase+'_aggregate.json'),out)
 pairs=[]
 for ds in sorted({x['dataset'] for x in rows}):
  for prof in ['structured_repeat','mixed']:
   for key in ['F1','normal_damage']:
    rr={ (x['seed'],x['arm']):x['repair'][key] for x in rows if x['dataset']==ds and x['profile']==prof}
    seeds=sorted({k[0] for k in rr});v=[rr[(s,'full')]-rr[(s,'tabclean')] for s in seeds]
    pairs.append({'dataset':ds,'profile':prof,'metric':'full_minus_tabclean_'+key,'n':len(v),'mean':statistics.mean(v),'sample_sd':statistics.stdev(v),'per_seed':v})
 save(ROOT/'reports'/(phase+'_paired.json'),pairs)
 return rows
if __name__=='__main__':score(Path(sys.argv[1]))
