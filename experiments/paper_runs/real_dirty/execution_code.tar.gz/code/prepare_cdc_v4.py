from pathlib import Path
import ast,json,time,hashlib
R=Path('/root/fsas/home/anonymous/projects/EvidForge_RealDirty_Expansion_CompatV2_20261027')
s=(R/'code/cdc_schema_v2.py').read_text();s=s.replace('if native_is_categorical(frame[c]) or not numeric:cats.append(c)',"# Author explicit empty strings denote known absence, a valid category.\n        # Do not send them as NaN numeric target labels to AutoGluon.\n        explicit_empty=bool(frame[c].map(lambda v:isinstance(v,str) and v=='').any())\n        if native_is_categorical(frame[c]) or not numeric or explicit_empty:cats.append(c)")
p=R/'code/cdc_schema_v4.py';assert not p.exists();p.write_text(s);ast.parse(s)
files=[]
for seed in [1013,1014,1015]:
 old=R/f'code/run_cdc_seed{seed}_v3.py';s=old.read_text().replace('from cdc_schema_v2 import infer_schema,install_schema','from cdc_schema_v4 import infer_schema,install_schema')
 s=s.replace(' io_audit=[]'," io_audit=load(out/'native_trainfold_io_audit.json') if (out/'native_trainfold_io_audit.json').exists() else []")
 s=s.replace("'type_bridge_version':'source_schema_v2 + all-singleton trainfold IO v3; no formal tuning'","'type_bridge_version':'source_schema_v4 explicit known empty categorical + all-singleton trainfold IO v3; no formal tuning'")
 # Final canonical method output path stays cdc_v3 to preserve closed V3 firstcase.
 s=s.replace('status/cdc_v3_failure.json','status/cdc_v4_failure.json')
 q=R/f'code/run_cdc_seed{seed}_v4.py';assert not q.exists();q.write_text(s);ast.parse(s)
 files.append({'entry':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'prior_entry_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'seed':seed})
(R/'audit/cdc_schema_v4_preparation.json').write_text(json.dumps({'at':time.time(),'files':files,'helper_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'old_v2_v3_files_unchanged':True,'numeric_hyperparameters_changed':False,'source_type_change':'Any explicit known empty-string source target remains categorical absence rather than NaN numeric target','no_unknown_reference_reinterpreted':True,'output_directory':'cdc_v3','closed_v3_case_reuse_requires_source_category_equality_audit':True,'IO_audit_append_recovery_fixed':True,'formal_reference_read':False},indent=2))
print('V4_PREPARED')
