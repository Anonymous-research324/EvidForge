"""Fixed score reporting only. No private files, fits, inference or score edits."""
from pathlib import Path
import time,sys,statistics,collections,csv,os
from common import ROOT as R,load,save,sha
P=load(R/'configs/protocol.json');SEEDS=P['seeds']
def summary(vals):
 vv=[v for v in vals if v is not None]
 return {'n':len(vv),'expected_n':len(SEEDS),'mean':statistics.mean(vv) if len(vv)==len(SEEDS) else None,'sd':statistics.stdev(vv) if len(vv)==len(SEEDS) else None,'values':vals}
def show(s):
 return f"{s['mean']:.3f} ± {s['sd']:.3f}" if s['mean'] is not None else f"N/A ({s['n']}/{len(SEEDS)})"
def make():
 scores=load(R/'reports/all_scores.json');ag=[];paired=[]
 for ds in P['datasets']:
  for arm in P['arms']:
   rs=sorted([x for x in scores if x['dataset']==ds and x['arm']==arm],key=lambda x:x['seed'])
   assert [x['seed'] for x in rs]==SEEDS
   m={k:summary([x['repair'][k] for x in rs]) for k in ['P','R','F1','normal_damage_percent','edit01_AUC']}
   for label in ['reachable','in_pool_forward_blocked','pool_absent']:m[label+'_R']=summary([x['candidate_strata'][label]['R'] for x in rs])
   ag.append({'dataset':ds,'arm':arm,'metrics':m,'qualified_seeds':sum(x['qualified'] for x in rs),'count_sums':{k:sum(x['repair'][k] for x in rs) for k in ['errors','normal','changes','exact','damaged']}})
  a={x['seed']:x for x in scores if x['dataset']==ds and x['arm']=='full'};b={x['seed']:x for x in scores if x['dataset']==ds and x['arm']=='no_llm'}
  paired.append({'dataset':ds,'F1_full_minus_noLLM':summary([a[s]['repair']['F1']-b[s]['repair']['F1'] for s in SEEDS]),'normal_damage_percent_delta':summary([a[s]['repair']['normal_damage_percent']-b[s]['repair']['normal_damage_percent'] for s in SEEDS]),'added_correct':sum(a[s]['pair']['added_correct'] for s in SEEDS),'lost_correct':sum(a[s]['pair']['lost_correct'] for s in SEEDS),'net_new_correct':sum(a[s]['pair']['net_new_correct'] for s in SEEDS),'per_seed':[{'seed':s,**a[s]['pair']} for s in SEEDS]})
 save(R/'reports/aggregate.json',ag);save(R/'reports/paired_differences.json',paired)
 costs=[]
 for name in load(R/'configs/cases.json'):
  c=R/'cases'/name;meta=load(c/'case.json');tag=('Digit70'+name).replace('_','').replace('-','');reqs=[]
  for p in (R/'services').glob('gpu*/requests/*'):
   if tag in p.name and (p/'request.json').exists():
    w=load(p/'request.json');resp=load(p/'response.json')
    reqs.append({'trace':str(p.relative_to(R)),'seed':w['seed'],'temperature':w['temperature'],'model':w['model'],'usage':resp['usage'],'seconds':load(p/'timing.json')['seconds']})
  costs.append({'case':name,'actual_calls':len(reqs),'no_llm_calls':0,'source_fit_shared_once':True,'source_prepare_seconds':load(c/'work/full/onboarding/prior_prepared/prepare_receipt.json')['seconds'],'source_copy_not_independent_fit':True,'requests':reqs,'tokens':sum(x['usage']['total_tokens'] for x in reqs)})
 save(R/'reports/actual_model_costs.json',costs)
 save(R/'reports/qualification.json',[{'case':x['id'],'arm':x['arm'],'qualified':x['qualified'],'kind':x['selected_kind']} for x in scores])
 save(R/'reports/teaching_activation.json',[{'case':n,**load(R/'cases'/n/'status/activation_diagnostic.json'),'coverage':load(R/'cases'/n/'teaching_coverage.json')} for n in load(R/'configs/cases.json')])
 lookup={(x['dataset'],x['arm']):x for x in ag}
 lines=['#70%单数字替换下的LLM消融','原124核心和原数字替换操作；full/noLLM共享同一源拟合与候选池；五个预定新种子2013–2017，全保留。','已使用过的数据来源、相同旧实体角色，新随机污染重复，不是新盲数据。','直接抽取70%已知可污染特征格执行单数字替换，不除4；ID/任务标签/原缺失不动。逐区整数取整与实际计数见污染实际行格比例.json。','','|方法|Retinopathy F1↑|可达候选层召回↑|正常误改%↓|Airfoil F1↑|可达候选层召回↑|正常误改%↓|','|---|---:|---:|---:|---:|---:|---:|']
 for arm in P['arms']:
  cells=[]
  for ds in P['datasets']:
   cells += [show(lookup[(ds,arm)]['metrics'][k]) for k in ['F1','reachable_R','normal_damage_percent']]
  lines.append('|'+('有LLM' if arm=='full' else '无LLM')+'|'+'|'.join(cells)+'|')
 lines+=['','所有值为五seed等权均值±样本SD（ddof1）；缺失不填0，不只挑正向seed。可达层定义为正确值在同一pre-native候选池且forward保护允许的全部错误格，评分时一次分层；方法不能读这些分层标签。','无LLM保留全部原自动规则与同样例，0LLM、无compiled_candidate。LLM只学习排序/接受规则，正式repair无需模型请求。','未通过外校者明确为research prior，不能声称自动部署合格。本文不以五seed直接宣称统计显著。','保留既定Retinopathy与Airfoil，单数字替换实际70%。本轮同RTX4090公平配对；与旧约7.5%A100结果之间还存在硬件差异，不将跨轮变化全归因于污染率。全部种子/零/负收益保留。','']
 for x in paired:lines.append(f"{x['dataset']}：净新增准确格{x['net_new_correct']}（新增{x['added_correct']}，丢失{x['lost_correct']}）；F1配对差值{show(x['F1_full_minus_noLLM'])}。")
 (R/'reports/70%单数字替换_LLM消融结果.md').write_text('\n'.join(lines)+'\n')
 with (R/'reports/绘图数据.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['dataset','arm','F1_mean','F1_sd','reachable_R_mean','reachable_R_sd','normal_damage_percent_mean','normal_damage_percent_sd','qualified_seeds'])
  for x in ag:w.writerow([x['dataset'],x['arm'],*[x['metrics'][k][v] for k in ['F1','reachable_R','normal_damage_percent'] for v in ['mean','sd']],x['qualified_seeds']])
 plot(lookup)
 save(R/'status/reports_ready.json',{'at':time.time(),'all_scores_sha':sha(R/'reports/all_scores.json'),'visual_QA_pending':True})
def plot(lookup):
 os.environ.setdefault('MPLCONFIGDIR',str(R/'tmp/matplotlib'))
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 cn=FontProperties(fname=str(R/'resources/fonts/SongtiSC-Regular.ttf'));en=FontProperties(fname=str(R/'resources/fonts/TimesNewRoman.ttf'))
 with matplotlib.rc_context({'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False}):
  fig=plt.figure(figsize=(180/25.4,75/25.4));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');texts=[]
  def tx(x,y,t,size=10,font=None):texts.append(ax.text(x,y,t,fontproperties=font or cn,fontsize=size,ha='center',va='center'))
  tx(.5,.94,'70% 单数字替换下的 LLM 模块消融（五种子）',11)
  for y,w in [(.83,1.1),(.61,.6),(.28,1.1)]:ax.plot([.025,.975],[y,y],color='black',lw=w)
  tx(.21,.725,'设置 / 数据集')
  tx(.56,.775,'Retinopathy†',11,en);tx(.84,.775,'Airfoil†',11,en)
  tx(.56,.67,'分类来源；修复 F1 ↑',9);tx(.84,.67,'回归来源；修复 F1 ↑',9)
  for y,arm,label in [(.495,'full','完整 EvidForge（有 LLM）'),(.36,'no_llm','完全不使用 LLM')]:
   tx(.21,y,label)
   for x,ds in [(.56,'retinopathy'),(.84,'airfoil')]:tx(x,y,show(lookup[(ds,arm)]['metrics']['F1']),11,en)
  qual='；'.join(ds+':'+str(lookup[(ds,'full')]['qualified_seeds'])+'/5、'+str(lookup[(ds,'no_llm')]['qualified_seeds'])+'/5' for ds in P['datasets'])
  notes=['70%按已知可污染特征格计算，ID、任务标签、原缺失不动；整数抽样取整。',
         '均值 ± 样本标准差（n=5）；两组共享源拟合、学习样例与候选池。',
         '† 外校通过数（有/无LLM）：'+qual+'；其余为研究检查点。',
         '本轮两组均在RTX4090运行；全部种子及零、负收益均保留。']
  for y,t in zip([.21,.15,.09,.035],notes):texts.append(ax.text(.03,y,t,fontproperties=cn,fontsize=6.8,ha='left',va='center'))
  fig.canvas.draw();ren=fig.canvas.get_renderer()
  for t in texts:
   b=t.get_window_extent(ren);assert 0<=b.x0 and b.x1<=fig.bbox.width and 0<=b.y0 and b.y1<=fig.bbox.height,t.get_text()
  files={}
  for ext in ['png','pdf','svg']:
   p=R/'reports'/('70%单数字替换_LLM消融_F1.'+ext);fig.savefig(p,dpi=600,facecolor='white');files[str(p.relative_to(R))]=sha(p)
  plt.close(fig)
 sys.path.insert(0,str(R/'dependencies'));import fitz
 doc=fitz.open(R/'reports/70%单数字替换_LLM消融_F1.pdf');p=R/'reports/70%单数字替换_LLM消融_F1_PDF实际渲染.png';doc[0].get_pixmap(dpi=200).save(p);files[str(p.relative_to(R))]=sha(p)
 save(R/'audit/figure_machine_qa.json',{'files':files,'text_clipping':[],'dimensions_mm':[180,75],'dpi':600,'actual_visual_review_pending':True,'no_hypothesis_significance_claim':True})
if __name__=='__main__':make()
