"""One controller, two owned A100 queues; never silently retries a case or score."""
from pathlib import Path
import os,sys,time,socket,subprocess,traceback,concurrent.futures
from common import ROOT,PY,load,save
def run(cmd,log,env):
 with Path(log).open("x") as f:
  p=subprocess.Popen(list(map(str,cmd)),cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
  save(Path(str(log)+".pid.json"),{"pid":p.pid,"command":list(map(str,cmd)),"at":time.time()})
  rc=p.wait()
 if rc:raise RuntimeError("exit "+str(rc)+": "+str(log))
def lane(gpu,names):
 env={**os.environ,"EF_GPU":str(gpu),"OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","MKL_NUM_THREADS":"2","PYTHONDONTWRITEBYTECODE":"1"}
 results=[]
 try:
  run([PY,ROOT/"code/model_service.py","start"],ROOT/"logs"/("gpu"+str(gpu)+"_start.log"),env)
  for i,name in enumerate(names):
   save(ROOT/"status"/("lane"+str(gpu)+".json"),{"gpu":gpu,"index":i,"total":len(names),"case":name,"at":time.time()})
   try:
    run([PY,ROOT/"code/worker_budget.py","case","--case",ROOT/"cases"/name,"--gpu",gpu],ROOT/"logs"/(name+"_worker.log"),{**env,"EF_CASE":name,"PYTHONPATH":str(ROOT/"code")})
    results.append({"case":name,"status":"closed"})
   except Exception as e:
    results.append({"case":name,"status":"failed","error":repr(e)})
    save(ROOT/"cases"/name/"status/controller_case_failure.json",{"error":repr(e),"at":time.time(),"automatic_retry":False})
  save(ROOT/"status"/("lane"+str(gpu)+".json"),{"gpu":gpu,"index":len(names),"total":len(names),"done":True,"records":results,"at":time.time()})
 except Exception as e:
  save(ROOT/"status"/("lane"+str(gpu)+"_error.json"),{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
 finally:
  if (ROOT/"services"/("gpu"+str(gpu))/"owner.json").exists():
   try:run([PY,ROOT/"code/model_service.py","stop"],ROOT/"logs"/("gpu"+str(gpu)+"_stop.log"),env)
   except Exception as e:save(ROOT/"status"/("resource_stop_error_gpu"+str(gpu)+".json"),{"error":repr(e)})
 return results
def main():
 if (ROOT/"status/controller_owner.json").exists():raise RuntimeError("Owner exists; inspect instead of duplicate")
 assert (ROOT/"audit/small_sample_preflight_pass.json").exists() and (ROOT/"audit/input_preflight_pass.json").exists()
 save(ROOT/"status/controller_owner.json",{"pid":os.getpid(),"host":socket.gethostname(),"started":time.time(),"scope":"54 nested example budgets; no old model reuse"})
 names=load(ROOT/"configs/cases.json")
 lanes=[[name for i,name in enumerate(names) if (i//3)%2==g] for g in [0,1]]
 assert len(lanes[0])==len(lanes[1])==27
 save(ROOT/"status/lane_assignment.json",{"gpu0":lanes[0],"gpu1":lanes[1],"same_cohort_all_tiers_same_GPU":True})
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(lane,g,lanes[g]) for g in [0,1]]
  results=[]
  for f in fs:results+=f.result()
 save(ROOT/"status/outcomes.json",results)
 if any(x["status"]!="closed" for x in results):raise RuntimeError("Unknown case failure preserved; scoring blocked")
 run([PY,ROOT/"code/audit_ready.py"],ROOT/"logs/audit_ready.log",os.environ.copy())
 save(ROOT/"status/all_outputs_closed.json",{"cases":54,"at":time.time()})
 run([PY,ROOT/"code/score_once.py"],ROOT/"logs/score_once.log",os.environ.copy())
 save(ROOT/"status/run_complete.json",{"at":time.time(),"independent_review_and_visual_QA_pending":True})
if __name__=="__main__":
 try:main()
 except Exception as e:save(ROOT/"status/controller_error.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
