from pathlib import Path
from decimal import Decimal
import csv,io,collections,shlex
CAR_VOCAB=[]
TIC_VOCAB=[]
def num(x):
 try:
  d=Decimal(str(x));return d if d.is_finite() else None
 except Exception:return None

def canonical(x):return format(num(x).normalize(),'f') if num(x) is not None else x

def member(z,basename):
 names=[n for n in z.namelist() if Path(n).name.casefold()==basename.casefold()]
 if len(names)!=1:raise ValueError('Missing/ambiguous official archive member '+basename)
 return z.read(names[0])

def parse(z,spec):
 mode=spec['layout'];values=[];ys=[];ids=[];sources=[]
 if mode in ['estate','concrete']:
  import pandas as pd
  if mode=='estate':
   candidates=[n for n in z.namelist() if n.lower().endswith('.xlsx') and not Path(n).name.startswith('~')]
   if len(candidates)!=1:raise ValueError('Expected unique estate workbook')
   df=pd.read_excel(io.BytesIO(z.read(candidates[0])),engine='openpyxl');a=df.iloc[:,1:7];y=df.iloc[:,7];ident=df.iloc[:,0]
  else:
   df=pd.read_excel(io.BytesIO(member(z,'Concrete_Data.xls')),engine='xlrd');a=df.iloc[:,:8];y=df.iloc[:,8];ident=[None]*len(df)
  for row,truth,identity in zip(a.itertuples(index=False,name=None),y,ident):
   values.append(['' if pd.isna(v) else str(v) for v in row]);ys.append(str(truth));ids.append(None if identity is None else str(identity));sources.append('official_workbook')
 else:
  if mode=='spectf':
   texts=[('original_train',member(z,'SPECTF.train').decode('utf-8-sig')),('original_test',member(z,'SPECTF.test').decode('utf-8-sig'))]
  elif mode=='retino':texts=[('official_arff',member(z,'messidor_features.arff').decode('utf-8-sig'))]
  else:
   name={'car':'car.data','tic':'tic-tac-toe.data','auto':'auto-mpg.data','airfoil':'airfoil_self_noise.dat'}[mode]
   texts=[('official_data',member(z,name).decode('utf-8-sig'))]
  for source,text in texts:
   in_data=mode!='retino'
   for line in text.splitlines():
    line=line.strip()
    if not line or line.startswith('%'):continue
    if not in_data:
     if line.casefold().startswith('@data'):in_data=True
     continue
    identity=None
    if mode=='auto':
     a=shlex.split(line);truth=a[0];row=a[1:8];identity=' '.join(a[8:])
    elif mode=='airfoil':
     a=line.split();row=a[:-1];truth=a[-1]
    else:
     a=[v.strip() for v in next(csv.reader([line]))]
     if mode=='spectf':truth=a[0];row=a[1:]
     else:row=a[:-1];truth=a[-1]
    values.append(['' if v in ['?','NA','NaN','nan',''] else v for v in row]);ys.append(truth);ids.append(identity);sources.append(source)
 if len(values)!=spec['rows'] or any(len(r)!=spec['columns'] for r in values):raise ValueError('Official source shape mismatch')
 vocab=CAR_VOCAB if mode=='car' else TIC_VOCAB if mode=='tic' else None
 if vocab:
  values=[[str(vocab[j].index(v)) for j,v in enumerate(r)] for r in values]
 if any(v and num(v) is None for row in values for v in row):raise ValueError('Unexpected nonnumeric value after registered reversible type encoding')
 if spec['task']=='regression' and any(num(v) is None for v in ys):raise ValueError('Unknown regression target')
 return values,ys,ids,sources,vocab

def make_groups(values,ids):
 parent=list(range(len(values)))
 def find(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 def union(i,j):parent[find(i)]=find(j)
 seen={};identities={}
 for i,row in enumerate(values):
  key=tuple(map(canonical,row))
  if key in seen:union(i,seen[key])
  else:seen[key]=i
  if ids[i] is not None:
   if ids[i] in identities:union(i,identities[ids[i]])
   else:identities[ids[i]]=i
 grouped=collections.defaultdict(list)
 for i in range(len(values)):grouped[find(i)].append(i)
 return {f'g{k:05d}':ix for k,ix in enumerate(sorted(grouped.values(),key=lambda x:x[0]))}

def damage(value,kind,rng,domain=None):
 if kind=='blank':return '',kind
 if kind=='affix':return 'ERR'+value+'BAD',kind
 if domain is not None:
  if kind=='digit':return rng.choice([x for x in domain if num(x)!=num(value)]),'category_substitution'
  return format(num(value)+100,'f'),'category_invalid_code'
 if kind=='scale' and num(value)!=0:return format(num(value)*100,'f'),kind
 indices=[i for i,c in enumerate(value) if c.isdigit()]
 if not indices:raise ValueError('No digit for registered numeric corruption')
 i=rng.choice(indices);d=rng.choice([v for v in '0123456789' if v!=value[i]])
 return value[:i]+d+value[i+1:],'digit'
