"""Post-score audit and transparent delivery notes. No per-cell references or regrading."""
from pathlib import Path
import json,hashlib,math,time,csv,subprocess
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/"DataForge_V23_Benchmark_seed1013"
def load(p):return json.loads(Path(p).read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 assert (ROOT/"status/complete.json").exists()
 protocol=load(ROOT/"protocol.json")
 agg_path=ROOT/"reports/three_seed_aggregate.json";agg=load(agg_path)
 seeds=[1013,1014,1015];names=protocol["datasets"];methods=protocol["methods"]
 raw={}
 for seed in seeds:
  r=BASE if seed==1013 else ROOT.parent/f"EvidForge_Benchmark_seed{seed}"
  p=r/f"reports/final_seed{seed}/scores.json"
  assert digest(p)==agg["source_scores"][str(seed)]["sha256"]
  assert (p.parent/"scoring_complete.json").exists()
  raw[seed]=load(p)
 assert digest(BASE/"reports/final_seed1013/scores.json")==protocol["original_1013_scores_sha256"]
 verified_metrics=0;unavailable=[];fallbacks=[];qualification_failures=[];guard_failures=[]
 for name in names:
  for method in methods:
   item=agg["scores"][name][method]
   for metric in ["P","R","F1","normal_damage","detection_AUC"]:
    values=[raw[s][name]["methods"][method].get("repair",{}).get(metric) for s in seeds]
    q=item["repair"][metric]
    assert q["values"]==values and q["n"]==sum(v is not None for v in values)
    if q["n"]==3:
     mean=sum(values)/3;sd=math.sqrt(sum((v-mean)**2 for v in values)/2)
     assert abs(mean-q["mean"])<1e-12 and abs(sd-q["sample_sd"])<1e-12,(name,method,metric)
     verified_metrics+=1
    else:assert q["mean"] is None and q["sample_sd"] is None
   if item["repair"]["F1"]["n"]<3:unavailable.append({"dataset":name,"method":method,"available_seeds":[s for s in seeds if raw[s][name]["methods"][method]["status"]=="complete"]})
   expected=[s for s in seeds if raw[s][name]["methods"][method].get("method_receipt",{}).get("fallback")]
   assert item["fallback_seeds"]==expected
   if expected:fallbacks.append({"dataset":name,"method":method,"seeds":expected})
  for seed in seeds:
   x=raw[seed][name]["methods"]["v23"]
   if not x["method_receipt"].get("automatic_deployment_qualified"):qualification_failures.append({"dataset":name,"seed":seed})
   if not x.get("safety_guardrail_pass"):guard_failures.append({"dataset":name,"seed":seed})
 # Verify every immutable code manifest and new output receipt once again, without parsing private data.
 code_files=0;output_files=0;output_tables=0
 manifests=[ROOT/"audit/controller_freeze.json",ROOT/"audit/cdc_recovery_v2_freeze.json",ROOT/"audit/format_contract_continuation_v3_freeze.json"]
 for manifest in manifests:
  j=load(manifest)
  for rel,h in j["files"].items():assert digest(ROOT/rel)==h;code_files+=1
 for seed in [1014,1015]:
  r=ROOT.parent/f"EvidForge_Benchmark_seed{seed}"
  for manifest in [r/"audit/frozen_v23_files.json",r/"audit/run_code_freeze.json"]:
   for rel,h in load(manifest)["files"].items():assert digest(r/rel)==h;code_files+=1
  for name in names:
   with (r/"datasets"/name/"public/repair_dirty.csv").open() as f:
    rd=csv.DictReader(f);fields=rd.fieldnames;ids=[x["entity_id"] for x in rd]
   for method in ["primary_llm","tool_llm","raha_holoclean","garf","cdc"]:
    folder=r/"outputs"/name/method;freeze=folder/"output_freeze.json"
    if not freeze.exists():
     assert seed==1015 and name=="qsar" and method=="cdc"
     assert (r/"status/closed_unavailable/qsar_cdc.json").exists()
     continue
    for rel,h in load(freeze)["files"].items():assert digest(folder/rel)==h;output_files+=1
    for file in (["pure_output.csv","v23_output.csv"] if method=="primary_llm" else ["repair_output.csv"]):
     with (folder/file).open() as f:
      rd=csv.DictReader(f);assert rd.fieldnames==fields;assert [x["entity_id"] for x in rd]==ids
     output_tables+=1
  assert (r/"models_service/stopped.json").exists() and (r/"status/postgres_stopped.json").exists()
  pg=load(r/"status/postgres.json");pidfile=Path(pg["cluster"])/"postmaster.pid"
  assert not pidfile.exists(),"Owned PostgreSQL still live"
  owner=load(r/"models_service/owner.json")
  proc=Path("/proc")/str(owner["pid"])/"cmdline"
  assert not proc.exists() or owner["name"] not in proc.read_bytes().decode(errors="replace")
 scores=agg["scores"]
 def cmp(a,b):return "win" if a>b+1e-12 else "loss" if a<b-1e-12 else "tie"
 vs_pure={}
 for metric in ["F1","detection_AUC"]:
  result={"win":[],"tie":[],"loss":[]}
  for name in names:
   a=scores[name]["v23"]["repair"][metric]["mean"];b=scores[name]["pure_llm"]["repair"][metric]["mean"]
   result[cmp(a,b)].append(name)
  vs_pure[metric]=result
 mean_best={"best_or_tied":[],"not_best":[]}
 for name in names:
  own=scores[name]["v23"]["repair"]["F1"]["mean"]
  candidates={m:scores[name][m]["repair"]["F1"]["mean"] for m in methods if scores[name][m]["repair"]["F1"]["mean"] is not None}
  if own>=max(candidates.values())-1e-12:mean_best["best_or_tied"].append(name)
  else:mean_best["not_best"].append({"dataset":name,"evidforge":own,"highest_method":max(candidates,key=candidates.get),"highest_mean":max(candidates.values())})
 per_seed={}
 for metric in ["F1","detection_AUC"]:
  result={"win":0,"tie":0,"loss":0}
  for seed in seeds:
   for name in names:
    a=raw[seed][name]["methods"]["v23"]["repair"][metric];b=raw[seed][name]["methods"]["pure_llm"]["repair"][metric]
    result[cmp(a,b)]+=1
  per_seed[metric]=result
 audit={"time":time.time(),"old1013_scores_unchanged":True,"independently_verified_mean_sd_metrics":verified_metrics,
 "sample_sd_formula":"sqrt(sum((x-mean)^2)/(n-1)); n=3; not SEM/CI",
 "new_output_tables_verified":output_tables,"new_output_files_sha_verified":output_files,"code_files_sha_verified":code_files,
 "unavailable":unavailable,"fallbacks":fallbacks,"external_qualification_failed_research_prior":qualification_failures,
 "formal_safety_guardrail_failed_P98_or_normal_damage_0p5percent":guard_failures,
 "mean_comparison_vs_pure":vs_pure,"paired_seed_dataset_comparison_vs_pure":per_seed,"mean_F1_best_among_displayed_methods":mean_best,
 "model_audit":str(ROOT/"audit/all_model_work_complete_integrity.json"),"private_cell_truth_read":False,"regrading":False,
 "owned_models_and_postgres_stopped":True,
 "GPU_snapshot":subprocess.run(["nvidia-smi","--query-compute-apps=pid,used_memory","--format=csv"],capture_output=True,text=True).stdout}
 (ROOT/"audit/final_three_seed_delivery_audit.json").write_text(json.dumps(audit,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
 report=ROOT/"reports/第一个实验_三种子均值与标准差.md"
 marker="## 完整性核验与结论范围"
 assert marker not in report.read_text(),"Delivery notes already appended; inspect, do not duplicate"
 notes=["",marker,"",
 "三种子逐表修复F1均值：EvidForge高于纯9B **8/8**；逐种子、逐表的24组配对也均高于纯9B。AUC均值为7胜0平1负，Climate低于纯9B；ILPD均值差小于0.001，不夸大。这里的三种子比较不是统计显著性检验。",
 "在表中选定六方法范围，EvidForge平均修复F1有7/8列最高，Voting低于Raha＋HoloClean；不能说超过所有方法。这个范围不包含此前原1013完整记录中的Raha＋Baran，旧完整记录保留。",
 "",
 "### 回退的具体种子","",
 "| 数据集 | 代码工具回退纯9B的种子 |","|---|---|"]
 for x in fallbacks:notes.append("| "+x["dataset"]+" | "+", ".join(map(str,x["seeds"]))+" |")
 notes+=["","Voting的代码工具没有fallback标记，部分种子确实可执行但无有效修复；有效零效果不等于运行失败。",
 "",
 "### 已保留的限制","",
 "- CDC的QSAR在1015原生单类别训练失败，整项该seed不可用；保留1013与1014实际值于JSON，主表N/A（n=2/3），不把失败当0，也不写两次样本的均值SD冒充三次。",
 "- "+str(len(qualification_failures))+"/24个EvidForge种子×数据集未通过独立教学校验，按事先约定保留prior研究输出，不能视为可自动部署的合格技能。具体记录见审计JSON的external_qualification_failed_research_prior。",
 "- "+str(len(guard_failures))+"/24个EvidForge种子×数据集正式修复P或正常误改未达到P≥98%、正常误改≤0.5%的护栏；不以总体均值掩盖单次失败，详见审计JSON。",
 "- 原1013存在任务说明修订及旧工具开发/格式重试历史，新增1014/1015只运行最终v5工具协议；1015纯9B另有三次原拒绝答及一次成功格式接续。预算原始账全部保留，不能声称三个种子累计开发调用严格相等。",
 "- 这组标准差覆盖划分、污染、教学样本和方法随机种子的整体波动；不单独衡量9B解码随机性，也不是新增数据来源的迁移验证。",
 "- GARF显示接近零的有效结果来自真实完整训练与输出，不是将运行失败填0；仅代表本SQLite移植及当前高污染设置，不代表论文方法普遍无效。",
 "- 全部新输出封存后各新seed独立评分一次；本后处理只读聚合分数、公开脏表及指纹，不重新评分、不解析个别测试答案。",
 "",
 "### 审计与复现","",
 "旧1013分数SHA保持不变；原124与适配器指纹通过，95张新可用方法输出表字段/ID/冻结文件通过，235项均值及样本SD独立公式复算通过；两模型及两专属PostgreSQL已停止。",
 "详细证据：audit/final_three_seed_delivery_audit.json；原始逐种子分数路径与SHA：reports/three_seed_aggregate.json 的 source_scores。",
 ""]
 with report.open("a") as f:f.write("\n".join(notes))
 manifest={"time":time.time(),"files":{str(p.relative_to(ROOT)):digest(p) for p in [report,agg_path,ROOT/"audit/final_three_seed_delivery_audit.json"]},
 "all_original_scores_unmodified":True,"new_reference_scoring_runs":2,"aggregation_only_after_scoring":True}
 (ROOT/"reports/交付文件指纹.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
 print(json.dumps({k:audit[k] for k in ["old1013_scores_unchanged","independently_verified_mean_sd_metrics","new_output_tables_verified","code_files_sha_verified","mean_comparison_vs_pure","paired_seed_dataset_comparison_vs_pure","mean_F1_best_among_displayed_methods","unavailable"]},ensure_ascii=False))
 print("qualification_failed",len(qualification_failures),"guard_failed",len(guard_failures))
if __name__=="__main__":main()
