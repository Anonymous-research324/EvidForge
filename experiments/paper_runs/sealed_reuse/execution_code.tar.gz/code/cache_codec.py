"""Type-preserving JSON for deterministic source-derived cached state; never pickle/eval."""
import json,hashlib,math
from decimal import Decimal
import numpy as np
def encode(x,canonical=False):
 if isinstance(x,np.ndarray):return {"t":"ndarray","dtype":str(x.dtype),"v":encode(x.tolist(),canonical)}
 if isinstance(x,np.generic):return encode(x.item(),canonical)
 if isinstance(x,Decimal):return {"t":"decimal","v":str(x)}
 if isinstance(x,float) and not math.isfinite(x):return {"t":"float","v":"nan" if math.isnan(x) else "inf" if x>0 else "-inf"}
 if isinstance(x,dict):
  items=[[encode(k,canonical),encode(v,canonical)] for k,v in x.items()]
  if canonical:items.sort(key=lambda q:json.dumps(q[0],sort_keys=True,allow_nan=False,separators=(",",":")))
  return {"t":"dict","v":items}
 if isinstance(x,list):return {"t":"list","v":[encode(v,canonical) for v in x]}
 if isinstance(x,tuple):return {"t":"tuple","v":[encode(v,canonical) for v in x]}
 if isinstance(x,set):
  values=[encode(v,canonical) for v in x];values.sort(key=lambda q:json.dumps(q,sort_keys=True,allow_nan=False))
  return {"t":"set","v":values}
 if x is None or type(x) in [str,int,float,bool]:return x
 raise TypeError("Unsupported cache value "+str(type(x)))
def decode(x):
 if not isinstance(x,dict) or "t" not in x:return x
 t=x["t"]
 if t=="dict":return {decode(k):decode(v) for k,v in x["v"]}
 if t=="list":return [decode(v) for v in x["v"]]
 if t=="tuple":return tuple(decode(v) for v in x["v"])
 if t=="set":return {decode(v) for v in x["v"]}
 if t=="decimal":return Decimal(x["v"])
 if t=="float":return float(x["v"])
 if t=="ndarray":return np.asarray(decode(x["v"]),dtype=np.dtype(x["dtype"]))
 raise ValueError("Unknown cache type")
def key(kind,*args):
 raw=json.dumps(encode([kind,*args],True),sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
 return hashlib.sha256(raw).hexdigest()
