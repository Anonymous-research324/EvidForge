
"""Compact paper table and numeric evidence, reads only completed scores and usage."""
from pathlib import Path
import sys,time,statistics,html,json
from common import ROOT,load,save,sha
from metrics_reuse import summary
def fmt(x):
 return "N/A (n="+str(x["n"])+"/3)" if x["mean"] is None else f'{x["mean"]:.3f} ± {x["sample_sd"]:.3f}'
def build():
 assert (ROOT/"status/scoring_complete.json").exists()
 scores=load(ROOT/"reports/all_scores.json");usage=load(ROOT/"audit/outputs_ready.json")["requests"]
 aggregate={};qual={};cost={}
 for name in ["retinopathy","airfoil"]:
  aggregate[name]={};qual[name]=[]
  for b in ["B1","B2","B3"]:
   rows=sorted([x for x in scores if x["dataset"]==name and x["batch"]==b],key=lambda x:x["seed"])
   assert len(rows)==3
   aggregate[name][b]={m:summary([x["repair"][m] for x in rows]) for m in ["P","R","F1","normal_damage"]}
   aggregate[name][b].update(rows=[x["rows"] for x in rows],seeds=[x["seed"] for x in rows],new_calls=[x["receipt"]["new_model_calls"] for x in rows],seconds=summary([x["receipt"]["seconds"] for x in rows]))
  for seed in [1013,1014,1015]:
   c=ROOT/"cases"/(name+"_s"+str(seed));sel=load(c/"work/full/selection.json")
   calls=[x for x in usage if x["case"]==c.name]
   cost[c.name]={"learning_calls":len(calls),"input_tokens":sum(x["usage"].get("prompt_tokens",0) for x in calls),"output_tokens":sum(x["usage"].get("completion_tokens",0) for x in calls),"model_http_seconds":sum(x["seconds"] for x in calls),"learning_source_native_and_validation_seconds":sel["seconds"],"batch_calls":{b:0 for b in ["B1","B2","B3"]},"batch_seconds":{b:load(c/"outputs"/b/"receipt.json")["seconds"] for b in ["B1","B2","B3"]}}
   qual[name].append({"seed":seed,"passed":sel["passed"],"selected":sel["kind"],"research_prior_fallback":not sel["passed"]})
 save(ROOT/"reports/aggregate.json",aggregate);save(ROOT/"reports/model_usage.json",{"cost_per_skill":cost,"requests":usage,"total_learning_calls":len(usage),"new_batch_calls":0,"new_batch_tokens":0,"unselected_context_included":True})
 save(ROOT/"reports/qualification.json",qual)
 headers=["数据集","首次学习调用","B1 修复F1","B2 修复F1","B3 修复F1","每批新增调用","三批累计新增"]
 table=[]
 for name,label in [("retinopathy","Retinopathy"),("airfoil","Airfoil")]:
  passed=sum(x["passed"] for x in qual[name])
  table.append([label+("†" if passed<3 else ""),str(cost[name+"_s1013"]["learning_calls"]),*[fmt(aggregate[name][b]["F1"]) for b in ["B1","B2","B3"]],"0 / 0 / 0","0"])
 notes=["三种子1013/1014/1015等权均值 ± 样本标准差（ddof=1，n=3）；F1为准确单元格修复F1。",
 "每个种子独立学习一次；B1/B2/B3实体隔离，均未参与该技能学习或外校。学习调用含未选中的context会话。",
 "模型服务在所有批次执行前关闭；批次执行不重新拟合，封存技能与缓存SHA不变，分批与合并输出一致。",
 "†：至少一个种子未通过独立外校，保留预定研究prior；不得据此称合格自动部署。",
 "本实验使用已知UCI来源的新预留分区，检验同来源、同字段和同错误分布的复用，不代表任意新表或分布漂移。"]
 notes+=["外校合格种子：Retinopathy "+str(sum(x["passed"] for x in qual["retinopathy"]))+"/3；Airfoil "+str(sum(x["passed"] for x in qual["airfoil"]))+"/3。"]
 md="# 封存技能处理同表三批新数据\n\n"+"| "+" | ".join(headers)+" |\n"+"| "+" | ".join(["---"]*len(headers))+" |\n"
 for row in table:md+="| "+" | ".join(row)+" |\n"
 md+="\n"+"\n".join(notes)+"\n"
 (ROOT/"reports/同表新批次技能复用结果.md").write_text(md)
 # Server-only fallback: this host has no Node/artifact-tool; preserve typed data with openpyxl.
 sys.path.insert(0,str(ROOT/"dependencies"))
 from openpyxl import Workbook,load_workbook
 from openpyxl.styles import Font,Alignment,Border,Side
 from openpyxl.utils import get_column_letter
 wb=Workbook();ws=wb.active;ws.title="技能复用";raw=wb.create_sheet("每种子原始结果")
 ws.sheet_view.showGridLines=False;ws.merge_cells("A1:G1");ws["A1"]="封存技能处理同表三批新数据";ws["A1"].font=Font(name="宋体",size=15,bold=True)
 for j,h in enumerate(headers,1):ws.cell(3,j,h)
 for i,(name,row) in enumerate(zip(["retinopathy","airfoil"],table),4):
  ws.cell(i,1,row[0]);ws.cell(i,2,10)
  for j,b in enumerate(["B1","B2","B3"],3):
   x=aggregate[name][b]["F1"];cell=ws.cell(i,j,x["mean"] if x["mean"] is not None else "N/A")
   if x["mean"] is not None:cell.number_format='0.000" ± '+format(x["sample_sd"],".3f")+'"'
  ws.cell(i,6,"0 / 0 / 0");ws.cell(i,7,0)
 thin=Side(style="thin",color="000000");medium=Side(style="medium",color="000000")
 for row in ws.iter_rows(min_row=3,max_row=5,max_col=7):
  for cell in row:
   cell.font=Font(name="Times New Roman" if cell.row>3 else "宋体",size=12,bold=cell.row==3)
   cell.alignment=Alignment(horizontal="left" if cell.column==1 else "center",vertical="center",wrap_text=True)
   if cell.row==3:cell.border=Border(top=medium,bottom=thin)
   if cell.row==5:cell.border=Border(bottom=medium)
 for i,n in enumerate(notes,7):
  ws.merge_cells(start_row=i,start_column=1,end_row=i,end_column=7);c=ws.cell(i,1,n);c.font=Font(name="宋体",size=10);c.alignment=Alignment(wrap_text=True,vertical="center");ws.row_dimensions[i].height=30
 widths=[21,17,24,24,24,20,20]
 for j,w in enumerate(widths,1):ws.column_dimensions[get_column_letter(j)].width=w
 for i in [3,4,5]:ws.row_dimensions[i].height=34
 ws.freeze_panes="C4";ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation="landscape";ws.page_setup.paperSize=ws.PAPERSIZE_A3;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=1;ws.print_area="A1:G12"
 raw.append(["数据集","种子","批次","行数","P","R","准确修复F1","正常误改率","新增调用","CPU修复秒","输入SHA","输出SHA"])
 for x in sorted(scores,key=lambda x:(x["dataset"],x["seed"],x["batch"])):
  c=ROOT/"cases"/x["case"];raw.append([x["dataset"],x["seed"],x["batch"],x["rows"],x["repair"]["P"],x["repair"]["R"],x["repair"]["F1"],x["repair"]["normal_damage"],x["receipt"]["new_model_calls"],x["receipt"]["seconds"],sha(c/"batches"/x["batch"]/"dirty.csv"),sha(c/"outputs"/x["batch"]/"repair_output.csv")])
 raw.append([]);raw.append(["数据集","批次","F1均值","F1样本SD","n"])
 for name in aggregate:
  for b in ["B1","B2","B3"]:
   x=aggregate[name][b]["F1"];raw.append([name,b,x["mean"],x["sample_sd"],x["n"]])
 raw.sheet_view.showGridLines=False;raw.freeze_panes="E2"
 for col in range(1,13):raw.column_dimensions[get_column_letter(col)].width=22 if col<11 else 68
 for row in raw.iter_rows():
  for cell in row:
   cell.font=Font(name="Times New Roman",size=11);cell.alignment=Alignment(vertical="center")
   if isinstance(cell.value,float):cell.number_format="0.000000"
 path=ROOT/"reports/封存技能复用_精简表.xlsx";wb.save(path)
 saved=load_workbook(path,data_only=True)
 for j in range(3,6):
  for i,name in [(4,"retinopathy"),(5,"airfoil")]:assert saved["技能复用"].cell(i,j).value==aggregate[name]["B"+str(j-2)]["F1"]["mean"]
 # Paper image, same table values as the saved workbook; SD read from numeric aggregate.
 from PIL import Image,ImageDraw,ImageFont
 fonts=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/reports/paper_ablation_tables_20261022/fonts")
 im=Image.new("RGB",(2200,620),"white");d=ImageDraw.Draw(im)
 song=ImageFont.truetype(str(fonts/"SongtiSC-Regular.ttf"),30);title=ImageFont.truetype(str(fonts/"SongtiSC-Bold.ttf"),38)
 text=ImageFont.truetype(str(fonts/"TimesNewRoman.ttf"),33);small=ImageFont.truetype(str(fonts/"SongtiSC-Regular.ttf"),25)
 d.text((55,22),"封存技能处理同表三批新数据",font=title,fill="black")
 xs=[55,410,670,1030,1390,1740,2000];centers=[200,515,810,1170,1530,1840,2070]
 def draw_center(x,y,s,font):
  box=d.textbbox((0,0),s,font=font);d.text((x-(box[2]-box[0])/2,y),s,font=font,fill="black")
 d.line((45,100,2155,100),fill="black",width=3)
 for j,h in enumerate(headers):draw_center(centers[j],121,h,song)
 d.line((45,175,2155,175),fill="black",width=2)
 for i,row in enumerate(table):
  for j,s in enumerate(row):draw_center(centers[j],200+i*65,s,text)
 d.line((45,330,2155,330),fill="black",width=3)
 foot=["准确修复F1：三种子均值 ± 样本标准差（n=3）。每个种子学习一次，同一技能顺序处理B1、B2、B3。","三批数据与学习/外校实体隔离；新增调用为真实账本核验值。模型先关闭，修复期间零拟合、零网络请求。","† 外校未全通过的种子按预定研究prior保留；不得称合格自动部署。已知来源的新预留分区，仅检验同表复用。",notes[-1]]
 for i,s in enumerate(foot):d.text((55,355+i*52),s,font=small,fill="black")
 im.save(ROOT/"reports/封存技能复用_精简表.png",dpi=(300,300))
 save(ROOT/"audit/report_export.json",{"at":time.time(),"xlsx_sha":sha(path),"png_sha":sha(ROOT/"reports/封存技能复用_精简表.png"),"all_scores_sha":sha(ROOT/"reports/all_scores.json"),"authoring":"server openpyxl fallback because Node/artifact-tool unavailable","visual_QA_pending":True})
 save(ROOT/"status/reports_ready.json",{"at":time.time(),"visual_QA_pending":True})
if __name__=="__main__":build()
