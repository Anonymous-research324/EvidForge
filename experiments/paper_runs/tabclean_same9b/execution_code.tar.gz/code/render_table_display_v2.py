"""Display-only table layout. Reads immutable aggregated table cells; never trains, scores or filters."""
from pathlib import Path
import os,time,hashlib,shutil,json
from common import ROOT,load,save,sha
def main():
 source=ROOT/'reports/main_table_data.json';before=sha(ROOT/'reports/all_scores.json')
 table=load(source);rows=table['rows'];assert len(rows)==7
 os.environ['MPLCONFIGDIR']=str(ROOT/'reports/.matplotlib_display_v2')
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 fp=FontProperties(fname=str(ROOT/'reports/fonts/SongtiSC-Regular.ttf'),size=9)
 archived=ROOT/'reports/layout_original_v1';archived.mkdir(exist_ok=False)
 originals={}
 for ext in ['png','pdf','svg']:
  p=ROOT/'reports'/('TabClean三种子_论文表.'+ext);shutil.copyfile(p,archived/p.name);originals[p.name]=sha(p)
 profile={'strategy':'native_final_size','width_cm':18.,'height_cm':8.,'body_pt':9.,'title_pt':12.,'footnote_pt':7.,'dpi':600,'header_top':.79,'header_bottom':.68,'row_step':.075,'formats':['png','pdf','svg'],'project_style_not_journal_requirement':True}
 with plt.rc_context({'pdf.fonttype':42,'svg.fonttype':'none'}):
  fig,ax=plt.subplots(figsize=(18/2.54,8/2.54));ax.set_position([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
  ax.text(.5,.92,'与TabClean的同模型对照（三种子）',ha='center',va='center',fontproperties=fp,fontsize=12)
  xs=[.11,.30,.51,.79];headers=['数据集','EvidForge\n修复F1 ↑','TabClean\n修复F1 ↑','正常误改率(%) ↓\nEvidForge / TabClean']
  for x,h in zip(xs,headers):ax.text(x,.735,h,ha='center',va='center',fontproperties=fp,fontsize=9,linespacing=1.25)
  for y,lw in [(.79,1.1),(.68,.7),(.14,1.1)]:ax.plot([.02,.98],[y,y],color='black',lw=lw,solid_capstyle='butt')
  for i,row in enumerate(rows):
   for x,txt in zip(xs,row):ax.text(x,.635-i*.075,txt,ha='center',va='center',fontproperties=fp,fontsize=9)
  ax.text(.025,.065,'均值±样本标准差（n=3）。†含外部验证未达标的研究回退种子，不代表部署合格。',ha='left',va='center',fontproperties=fp,fontsize=7)
  for ext in profile['formats']:fig.savefig(ROOT/'reports'/('TabClean三种子_论文表_v2.'+ext),dpi=600)
  plt.close(fig)
 assert before==sha(ROOT/'reports/all_scores.json')
 outputs={ext:sha(ROOT/'reports'/('TabClean三种子_论文表_v2.'+ext)) for ext in profile['formats']}
 save(ROOT/'reports/table_style_profile_v2.json',profile)
 save(ROOT/'audit/display_amendment_v2.json',{'at':time.time(),'original_layout_preserved':originals,'source_table_sha':sha(source),'scores_sha_unchanged':before,'all_7_rows_values_unchanged':True,'no_statistical_or_eligibility_change':True,'outputs':outputs,'reason':'Increase two-line header height and clear horizontal rules; display only','actual_visual_review_pending':True})
 print('DISPLAY_ONLY_RENDER_COMPLETE')
if __name__=='__main__':main()
