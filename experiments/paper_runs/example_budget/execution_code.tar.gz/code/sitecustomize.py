"""Cross-budget case isolation for all Python descendants with EF_CASE binding."""
import sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CASE=os.environ.get("EF_CASE")
if CASE:
 def guard(event,args):
  if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
   p=Path(os.fsdecode(args[0])).resolve()
   if ROOT/"cases" in p.parents:
    rel=p.relative_to(ROOT/"cases")
    if rel.parts and rel.parts[0]!=CASE:raise PermissionError("A case cannot read another budget/seed/dataset: "+str(p))
 sys.addaudithook(guard)
