"""Curator only: known raw features, preserved roles, new controlled corruption."""
from pathlib import Path
import sys,json,zipfile,collections,copy,time
from common import ROOT as R,load,save,sha,freeze,read_csv,write_csv
from original_curator_functions import parse,make_groups
sys.path.insert(0,str(R/'engine/source_runtime'))
from corruption_functions import corrupt
from unseen_table.common import canonical,number,equal
P=load(R/'configs/protocol.json')
SPECS={'spectf':dict(rows=267,columns=44,layout='spectf',task='classification'),'auto_mpg':dict(rows=398,columns=7,layout='auto',task='regression'),'airfoil':dict(rows=1503,columns=5,layout='airfoil',task='regression')}
def create(ds,seed,profile):
 old=R.parent/'EvidForge_Downstream_Study_seed1013/datasets'/ds;spec=SPECS[ds]
 with zipfile.ZipFile(old/'private/source.zip') as z:values,ys,ids,sources,vocab=parse(z,spec)
 del ys,sources,vocab
 groups=make_groups(values,ids);columns=[f'feature_{i+1:02d}' for i in range(spec['columns'])]
 decl=load(old/'public/declaration.json');assert decl['targets']==columns
 bundle=load(old/'public/development_bundle.json');fields,oldrepair=read_csv(old/'public/repair_dirty.csv')
 roles={'learning':[g['group'] for g in bundle['learning']],'validation':[g['group'] for g in bundle['validation']],'repair':list(dict.fromkeys(x['entity_id'] for x in oldrepair))}
 assert all(not set(roles[a])&set(roles[b]) for a,b in [('learning','validation'),('learning','repair'),('validation','repair')])
 clean={g:[{'entity_id':g,**{f:canonical(v) if number(v) is not None else v for f,v in zip(columns,values[i])}} for i in groups[g]] for gs in roles.values() for g in gs}
 for zone in ['learning','validation']:
  for g in bundle[zone]:
   assert len(clean[g['group']])==len(g['records'])
   assert all(all(equal(row[f],rec['truth'][f]) for f in columns) for row,rec in zip(clean[g['group']],g['records']))
 zones={};keys={};truth={};counts={};events=[]
 for zone,gs in roles.items():
  records=[];rk=[]
  for g in gs:
   for i,row in zip(groups[g],clean[g]):
    k=f'{ds}-{i:05d}';records.append({'row_key':k,'group':g,'dirty':dict(row),'truth':{f:row[f] for f in columns}});rk.append(k)
  changed,perfield=corrupt(records,ds,profile,P['pollution']['anchors'][ds],str(seed)+':'+zone)
  rows=[x['dirty'] for x in changed];refs=[{**x['dirty'],**x['truth']} for x in changed]
  actual=0
  for x in changed:
   for f in columns:
    if not equal(x['dirty'][f],x['truth'][f]):
     actual+=1;events.append({'zone':zone,'row_key':x['row_key'],'group':x['group'],'field':f,'mechanism':profile})
  assert actual==sum(v['changed'] for v in perfield.values())
  assert all(x['dirty']['entity_id']==x['group'] for x in changed)
  zones[zone]=rows;truth[zone]=refs;keys[zone]=rk
  eligible=sum(v['eligible'] for v in perfield.values())
  counts[zone]={'rows':len(rows),'groups':len(gs),'eligible_cells':eligible,'actual_changed_cells':actual,'target_cells':len(rows)*len(columns),'eligible_cell_rate':actual/eligible if eligible else None,'all_target_cell_rate':actual/(len(rows)*len(columns)),'per_field':perfield}
 assert [x['entity_id'] for x in zones['repair']]==[x['entity_id'] for x in oldrepair]
 name=f'original_{profile}_{ds}_s{seed}';c=R/'cases'/name;c.mkdir()
 for d in ['public','private','status','outputs','work','logs']:(c/d).mkdir()
 newbundle={}
 for zone in ['learning','validation']:
  by=collections.defaultdict(list)
  for row,t,k in zip(zones[zone],truth[zone],keys[zone]):by[row['entity_id']].append({'row_key':k,'dirty':row,'truth':{f:t[f] for f in columns}})
  newbundle[zone]=[{'group':g,'provenance':'known source, original public role; new controlled errors, semantic numeric spelling normalization','records':by[g]} for g in roles[zone]]
 save(c/'public/development_bundle.json',newbundle);save(c/'public/declaration.json',decl)
 save(c/'public/context.json',{'dataset':ds,'source':'known_UCI_original_system_source_only','seed':seed})
 write_csv(c/'public/repair_dirty.csv',fields,zones['repair']);write_csv(c/'private/repair_reference.csv',fields,truth['repair'])
 save(c/'private/repair_rowkeys.json',{'row_keys':keys['repair']});save(c/'private/error_annotations.json',{'cells':events})
 meta={'id':name,'dataset':ds,'seed':seed,'profile':profile,'suite':'original_system_new_error_conditions','original_task':spec['task'],'task':'repair_only','counts':counts,'old_entity_partitions_seed':1013,'new_partition':False,'known_source_not_new_blind':True,'old_holdout_excluded_groups':len(set(groups)-set(sum(roles.values(),[]))),'native_budget':10,'raw_source_sha':sha(old/'private/source.zip'),'old_public_roles_sha':sha(old/'public/development_bundle.json'),'original_core_unmodified':True,'new_candidate_modules':False}
 save(c/'case.json',meta);save(c/'input_freeze.json',{'case_sha256':sha(c/'case.json'),'public':freeze(c/'public'),'private':freeze(c/'private')})
 return name
def main():
 if (R/'configs/cases.json').exists():raise RuntimeError('Inputs already frozen, do not rebuild')
 cases=[create(ds,seed,profile) for seed in P['seeds'] for profile in P['profiles'] for ds in P['datasets']]
 save(R/'configs/cases.json',cases);save(R/'configs/lanes.json',{str(g):[n for i,n in enumerate(cases) if i%2==g] for g in [0,1]})
 save(R/'audit/inputs_frozen.json',{'at':time.time(),'cases':{n:sha(R/'cases'/n/'input_freeze.json') for n in cases},'curator_only':True,'old_formal_reference_csv_read':False,'model_calls':0})
 save(R/'reports/污染实际行格比例.json',[load(R/'cases'/n/'case.json') for n in cases])
 print('ORIGINAL_SYSTEM_INPUTS_FROZEN',len(cases),flush=True)
if __name__=='__main__':main()
