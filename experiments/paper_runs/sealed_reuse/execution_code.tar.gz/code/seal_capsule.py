
"""Seal only original source fits; teaching-only byte/decision parity is required."""
from pathlib import Path
import argparse,os,time,json
from common import ROOT,ENGINE,load,save,sha,freeze

def build(case):
 from runtime_v4 import install
 install()
 from source_cache import materialize,install as install_cache
 from workflow.packages import execute
 from cache_codec import encode,key
 base=case/"work/full";selection=load(base/"selection.json");skill=Path(selection["skill"])
 cache=materialize(skill)
 teaching=load(case/"source/development_bundle.json")["learning"]
 probes=[dict(z["records"][0]["dirty"]) for z in teaching[:3]]
 # Probe only authorized teaching observations; no reserved batch access.
 before=execute(probes,skill);events=[];install_cache(cache,events);after=execute(probes,skill)
 if encode(before)!=encode(after):raise ValueError("Source cache changes original execution")
 if len(events)<3:raise ValueError("Expected materialized evidence cache was not used")
 frozen=load(base/"learning_freeze.json")["files"]
 for rel,h in frozen.items():
  if sha(base/rel)!=h:raise ValueError("Learning artifact mutated during seal: "+rel)
 save(case/"sealed/source_cache.json",cache)
 save(case/"sealed/teaching_parity.json",{"rows":len(probes),"both_output_and_decisions_exact":True,"uncached_sha":key("probe",before),"cached_sha":key("probe",after),"cache_hits":events,"reserved_batch_read":False,"at":time.time()})
 files={str(p.resolve()):sha(p) for p in sorted(base.rglob("*")) if p.is_file() and p.suffix!=".pyc"}
 for name in ["source_cache.json","teaching_parity.json"]:files[str((case/"sealed"/name).resolve())]=sha(case/"sealed"/name)
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():files[str((ENGINE/rel).resolve())]=h
 for rel,h in load(ROOT/"audit/execution_freeze.json")["files"].items():files[str((ROOT/rel).resolve())]=h
 save(case/"sealed/capsule.json",{"files":files,"selected_skill":str(skill),"qualification_passed":selection["passed"],"cache":"source_cache.json","source_only_materialization":True,"original_numeric_functions_unchanged":True,"new_batch_access_before_seal":False,"at":time.time()})

def main():
 p=argparse.ArgumentParser();p.add_argument("--case",required=True);a=p.parse_args();build(Path(a.case))
if __name__=="__main__":main()
