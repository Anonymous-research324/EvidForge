"""Fixed10cases, first pair is a source-only activation check, no outcome filtering."""
from pathlib import Path
import os,sys,time,threading,subprocess,traceback,socket
from concurrent.futures import ThreadPoolExecutor
from common import ROOT as R,PY,load,save
def run(cmd,log,env):
 with Path(log).open('x') as f:p=subprocess.Popen(list(map(str,cmd)),env=env,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 save(Path(str(log)+'.pid.json'),{'pid':p.pid,'at':time.time(),'command':list(map(str,cmd))})
 if p.wait():raise RuntimeError('Stage failed; preserve '+str(log))
def main():
 assert socket.gethostname()==load(R/'configs/protocol.json')['execution_host'],'Wrong execution host'
 if (R/'status/controller_owner.json').exists():raise RuntimeError('Existing dispatch; do not restart')
 os.chdir(R);os.environ.update(TMPDIR=f'/proc/{os.getpid()}/cwd/tmp',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2')
 assert Path(os.environ['TMPDIR']).resolve()==R/'tmp'
 save(R/'status/controller_owner.json',{'pid':os.getpid(),'at':time.time(),'host':socket.gethostname(),'ipc_anchor':os.environ['TMPDIR']})
 from audit_ready import verify_frozen
 verify_frozen();assert (R/'status/preflight_pass.json').exists() and (R/'status/launch_checks_pass.json').exists()
 lanes=load(R/'configs/lanes.json');stop=threading.Event()
 def lane(g):
  env={**os.environ,'EF_GPU':str(g),'EF_DEVICES':load(R/'configs/protocol.json')['lane_devices'][str(g)]};service=R/'services'/f'gpu{g}'
  try:
   run([PY,'-B',R/'code/model_service.py','start'],R/'logs'/f'service_start_gpu{g}.log',env)
   for i,n in enumerate(lanes[str(g)]):
    if stop.is_set():break
    save(R/'status'/f'lane{g}.json',{'gpu':g,'index':i,'total':len(lanes[str(g)]),'case':n,'at':time.time(),'state':'running'})
    run([PY,'-u','-B',R/'code/worker.py','case','--case',R/'cases'/n,'--gpu',g],R/'logs'/f'{n}_worker.log',env)
    c=R/'cases'/n;sel=load(c/'work/full/selection.json')
    programs=[]
    for k in ['prior','context']:
     st=load(c/'work/full'/f'{k}_stage/native_v3/result.json')
     programs.append({'stage':k,'candidate':st['candidate'],'calls':st['real9B_calls']})
    save(c/'status/activation_diagnostic.json',{'at':time.time(),'programs':programs,'selected':sel['kind'],'outer_qualified':sel['passed'],'outputs_differ':load(c/'outputs/full/output_freeze.json')['files']['repair_output.csv']!=load(c/'outputs/no_llm/output_freeze.json')['files']['repair_output.csv'],'no_formal_score':True,'all_preplanned_cases_retained':True})
    save(R/'status'/f'lane{g}.json',{'gpu':g,'index':i+1,'total':len(lanes[str(g)]),'case':n,'at':time.time(),'state':'case_closed'})
  except BaseException:
   stop.set();save(R/'status'/f'lane{g}_error.json',{'at':time.time(),'traceback':traceback.format_exc()});raise
  finally:
   if (service/'owner.json').exists():run([PY,'-B',R/'code/model_service.py','stop'],R/'logs'/f'service_stop_gpu{g}.log',env)
 with ThreadPoolExecutor(2) as ex:
  fs=[ex.submit(lane,g) for g in [0,1]];errors=[]
  for f in fs:
   try:f.result()
   except BaseException as e:errors.append(repr(e))
 if errors:raise RuntimeError(str(errors))
 assert all((R/'cases'/n/'status/closed.json').exists() for n in load(R/'configs/cases.json'))
 for entry in ['audit_ready.py','score.py','report.py']:
  run([PY,'-u','-B',R/'code'/entry],R/'logs'/entry.replace('.py','.log'),os.environ.copy())
 save(R/'status/run_complete.json',{'at':time.time(),'all10cases_complete':True,'reports_ready':True,'final_review_required':True})
if __name__=='__main__':
 try:main()
 except BaseException:
  save(R/'status/controller_error.json',{'at':time.time(),'traceback':traceback.format_exc()});raise
