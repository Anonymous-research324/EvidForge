"""接续唯一缺少prepared_manifest、但base拟合已完成的源阶段；不重复拟合和模型调用。"""
from pathlib import Path
import argparse,time
from common import load,save,sha,freeze
from runtime_v4 import install
def main():
    p=argparse.ArgumentParser();p.add_argument("--case",required=True);p.add_argument("--arm",required=True);a=p.parse_args()
    case=Path(a.case);wf=case/"work"/a.arm/"onboarding";prior=wf/"prior_prepared";base=prior/"base_skill"
    assert not (prior/"prepared_manifest.json").exists()
    assert (base/"manifest.json").exists() and not (case/"work"/a.arm/"prior_stage/native_v3/result.json").exists()
    original=freeze(wf)
    install()
    from unseen_table.common import normalize_bundle,fingerprint,validate_declaration
    from workflow.onboarding import split_learning
    import learning.prepare as m
    bundle=load(case/"public/development_bundle.json");schema=load(case/"public/declaration.json");context=load(case/"public/context.json")
    internal,_=split_learning(bundle,schema)
    assert fingerprint(internal)==load(wf/"partition_freeze.json")["learning_only_bundle_sha256"]
    assert load(wf/"learning_only_bundle.json")==internal
    assert load(wf/"declaration.json")==schema and load(wf/"context.json")==context
    assert load(base/"preregistration.json")["source_bundle_sha256"]==fingerprint(internal)
    assert all(sha(base/n)==h for n,h in load(base/"manifest.json")["files"].items())
    oldfresh=m.fresh
    def fresh(path):
        if Path(path).resolve()==prior.resolve():return prior
        return oldfresh(path)
    def learn(bundle_,schema_,context_,out):
        assert Path(out).resolve()==base.resolve()
        assert fingerprint(bundle_)==fingerprint(internal) and schema_==schema and context_==context
        assert all(sha(base/n)==h for n,h in load(base/"manifest.json")["files"].items())
        return {"reused_original_source_fit":True}
    m.fresh=fresh;m.learn=learn
    started=time.monotonic();m.prepare(internal,schema,context,prior)
    records=load(prior/"source_records_backend.json")["records"]
    assert {r["group"] for r in records}=={g["group"] for g in bundle["learning"]}
    save(wf/"prepare_boundary_receipt.json",{"only_external_learning_used":True,"external_learning_groups":len(bundle["learning"]),"external_validation_groups":len(bundle["validation"]),"actual9B_calls":0})
    assert all(sha(wf/n)==h for n,h in original.items())
    save(case/"status"/(a.arm+"_source_continuation_v4.json"),{"old_partial_files":original,"all_prior_bytes_preserved":True,"same_source_fit":True,"new_model_calls":0,"seconds":time.monotonic()-started,"metadata_only":True})
if __name__=="__main__":main()
