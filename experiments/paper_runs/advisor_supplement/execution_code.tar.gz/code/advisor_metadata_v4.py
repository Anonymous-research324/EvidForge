"""无数值邻域时，从已拟合模型自身的内层交叉分组读取同一来源边界。"""
def fit_groups(model):
    context=model.get("numeric_context",{})
    if context:
        return context["training_groups"]
    folds=model.get("training_summary",{}).get("inner_folds")
    if not folds:
        raise ValueError("No independent training-group provenance in nonnumeric model")
    universes=[]
    for fold in folds:
        a,b=set(fold["training_groups"]),set(fold["check_groups"])
        if a & b or not a or not b:
            raise ValueError("Malformed or overlapping fitted source folds")
        universes.append(a|b)
    if any(s!=universes[0] for s in universes):
        raise ValueError("Fitted inner folds disagree on source universe")
    return sorted(universes[0])
