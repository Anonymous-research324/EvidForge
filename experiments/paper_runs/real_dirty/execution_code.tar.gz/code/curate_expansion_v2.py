"""Curator-only public paired input construction. No fitting, model calls or scoring."""
from pathlib import Path
import sys,json,hashlib,time,csv,re,collections,importlib.util,ast
R=Path(__file__).resolve().parents[1]
O=Path('/root/fsas/home/anonymous/projects/EvidForge_RealDirty_Formal5_ThreeSeeds_20261027')
sys.path.insert(0,str(R/'code'))
from common import read_csv,write_csv,save,load,sha,freeze
engine=R/'engine'
if not engine.exists():engine=O/'engine'
sys.path[:0]=[str(engine),str(engine/'source_runtime')]
from workflow.onboarding import split_learning
DATASETS=['beers','library_official','school_small','government_small','jobposting_small']
SEEDS=[9013,1013,1014,1015]
AUDITS=[]
def norm(v):return re.sub(r'[^\w]+','',v.casefold())
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def dataset(ds):
 folder=R/'candidate_sources'/ds;fields,dirty=read_csv(folder/'dirty.csv');rf,reference=read_csv(folder/'reference.csv')
 assert len(dirty)==len(reference) and all(None not in x for x in dirty+reference)
 if ds=='beers':
  assert len(fields)==len(rf)
  mapping=dict(zip(fields,rf));assert mapping['index']=='index' and mapping['id']=='id' and mapping['brewery_id']=='brewery_id'
  by={x['index']:x for x in reference};assert len(by)==len(reference)==len({x['index'] for x in dirty}) and set(by)=={x['index'] for x in dirty}
  aligned=[{f:by[x['index']][mapping[f]] for f in fields} for x in dirty]
  protected=['index','id','brewery_id'];keys=[['brewery_id'],['brewery_name','city','state']]
  alignment='unique protected index; id and brewery_id independently identical; reviewed header name mapping'
 elif ds=='library_official':
  assert fields==rf
  # Independently tie every positional pair to the author's full, ID-bearing pair.
  full=R/'sources/address_library'
  if not full.exists():full=R.parent/'EvidForge_SmallRealDirty_ExpansionB_Seed9013_20261027/sources/address_library_named'
  bf,bd=read_csv(full/'dirty.csv');cf,bc=read_csv(full/'reference.csv');by={x['id']:x for x in bc};assert len(by)==len(bc)==len({x['id'] for x in bd})
  pair_index=collections.defaultdict(list)
  for x in bd:pair_index[(tuple(x[f] for f in fields),tuple(by[x['id']][f] for f in fields))].append(x['id'])
  orig_ids=[]
  for x,y in zip(dirty,reference):
   pair=(tuple(x[f] for f in fields),tuple(y[f] for f in fields));assert pair_index[pair], 'Library official pair not verified against source IDs';orig_ids.append(pair_index[pair].pop())
  aligned=reference;protected=[];keys=[['name','road','postcode','locality']]
  mapping={f:f for f in fields};alignment='all1656 exact dirty/clean tuple pairs verified against pinned5370-row named parent joined by unique id, with duplicate multiplicity respected'
  save(R/'audit/library_official_identity_alignment.json',{'passed':True,'rows':len(dirty),'source_full_rows':len(bd),'author_pair_ids':orig_ids,'all_rows_matched':True,'no_method_scores_or_formal_outputs_read':True,'parent_files':{str(p):sha(p) for p in [full/'dirty.csv',full/'reference.csv']}})
 else:
  assert fields==rf
  by={x['id']:x for x in reference};assert len(by)==len(reference)==len({x['id'] for x in dirty}) and set(by)=={x['id'] for x in dirty}
  aligned=[by[x['id']] for x in dirty];protected=['id','provenance_graph_iri'];keys=[['id'],['name','road','postcode','locality']];mapping={f:f for f in fields};alignment='unique exact author id; selected by frozen dirty-only whole-group subset'
  sf=folder/'selection_freeze.json';sel=load(sf);assert sel['selected_only_from_dirty'] and sel['no_error_values_scores_or_reference_used_for_selection'] and len(dirty)==sel['actual_rows']
 assert all(a[c]==b[c] for a,b in zip(dirty,aligned) for c in protected)
 targets=[f for f in fields if f not in protected];truth=[{f:r[f] for f in targets} for r in aligned]
 n=len(dirty);parent=list(range(n));edges=collections.Counter()
 def find(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 def union(a,b,label):
  a,b=find(a),find(b)
  if a!=b:parent[b]=a;edges[label]+=1
 for label,rows in [('dirty_entity',dirty),('reference_entity_metadata',aligned)]:
  for cols in keys:
   seen={}
   for i,row in enumerate(rows):
    key=tuple(norm(row[c]) for c in cols)
    if not all(key):continue
    if key in seen:union(i,seen[key],label+':'+','.join(cols))
    else:seen[key]=i
 for label,rows in [('exact_dirty_targets',dirty),('exact_reference_targets',aligned)]:
  seen={}
  for i,row in enumerate(rows):
   key=tuple(row[f] for f in targets)
   if key in seen:union(i,seen[key],label)
   else:seen[key]=i
 groups=collections.defaultdict(list)
 for i in range(n):groups[find(i)].append(i)
 groups={f'g{min(ids):06d}':ids for ids in groups.values()};blocks=[[g] for g in groups]
 AUDITS.append({'dataset':ds,'rows':n,'fields':fields,'targets':targets,'protected':protected,'groups':len(groups),'alignment':alignment,'field_mapping':mapping,'edges':dict(edges),'source_files_sha':{str(p):sha(p) for p in folder.glob('*.csv')},'known_reference_semantics':'every paired author value is confirmed, including explicit blank; no missing key inferred clean','no_injected_error':True,'all_candidate_rows_preserved':True,'no_method_performance_read':True,'curator_only':True})
 return fields,dirty,truth,targets,groups,blocks,protected,dict(edges)

def main():
 cases=[];inventory=[];fail=[]
 for ds in DATASETS:
  fields,dirty,truth,targets,groups,blocks,protected_raw,edges=dataset(ds)
  for seed in SEEDS:
   name=f'{ds}_s{seed}';c=R/'cases'/name
   if (c/'input_freeze.json').exists():
    fr=load(c/'input_freeze.json')
    for part in ['public','private']:
     for f,h in fr[part].items():assert sha(c/part/f)==h
    assert sha(c/'case.json')==fr['case_sha'];cases.append(name);inventory.append(load(c/'case.json'));continue
   assert not c.exists(),('Partial curation requires reviewed recovery',name)
   for part in ['public','private','work','outputs','logs','status','audit']:(c/part).mkdir(parents=True,exist_ok=True)
   ordered=sorted(blocks,key=lambda b:digest([seed,ds,sorted(b)]));count=sum(map(len,ordered));k,v=max(20,int(count*.1+.5)),max(10,int(count*.1+.5))
   chosen=None
   for rotation in range(len(ordered)):
    seq=ordered[rotation:]+ordered[:rotation];zones={'learning':[],'validation':[],'repair':[]}
    for b in seq:
     z='learning' if len(zones['learning'])<k else 'validation' if len(zones['validation'])<v else 'repair';zones[z]+=b
    if len(zones['learning'])>=20 and len(zones['validation'])>=10 and len(zones['repair'])>=1:chosen=zones;break
   if chosen is None:
    save(c/'status/input_incompatible.json',{'reason':'Original source minimum groups impossible','entity_groups':len(groups),'no_algorithm_change':True});fail.append(name);continue
   zones=chosen;gid={i:g for g,ids in groups.items() for i in ids}
   def row(i):return {'entity_id':gid[i],'__rowkey__':f'r{i:06d}',**dirty[i]}
   allfields=['entity_id','__rowkey__',*fields]
   bundle={z:[{'group':g,'provenance':'Pinned author paired reference; exact source alignment independently audited; whole entities','records':[{'row_key':f'r{i:06d}','dirty':row(i),'truth':truth[i]} for i in groups[g]]} for g in zones[z]] for z in ['learning','validation']}
   protected=['entity_id','__rowkey__',*protected_raw]
   declaration={'id':name,'provenance':'Published real error pair; fixed small source if indicated; protected identities and original source guard','fields':{f:{'role':'target' if f in targets else 'identity' if f=='entity_id' else 'protected','identity':f in protected,'type':'string'} for f in allfields},'targets':targets,'entity_fields':['entity_id'],'protected_fields':protected,'visible_context_fields':[]}
   try:split_learning(bundle,declaration)
   except Exception as e:save(c/'status/input_incompatible.json',{'reason':repr(e),'no_algorithm_change':True});fail.append(name);continue
   for p,x in [('development_bundle.json',bundle),('learning_only.json',{'learning':bundle['learning']}),('declaration.json',declaration),('context.json',{'dataset':ds,'source_version':'author_pair_small_expansion_20261027','schema':'original_dirty_headers','seed':seed})]:save(c/'public'/p,x)
   ids={z:sorted(i for g in gs for i in groups[g]) for z,gs in zones.items()}
   for z in ids:write_csv(c/'public'/(z+'_dirty.csv'),allfields,[row(i) for i in ids[z]])
   for z in ['validation','repair']:save(c/'private'/(z+'_truth.json'),{'row_keys':[f'r{i:06d}' for i in ids[z]],'truth':[truth[i] for i in ids[z]],'known_mask':[[f for f in targets if f in truth[i]] for i in ids[z]]})
   meta={'dataset':ds,'seed':seed,'phase':'real_dirty_expansion_pilot' if seed==9013 else 'real_dirty_expansion_formal_three_seeds','suite':'real_dirty','targets':targets,'protected':protected,'rows':{z:len(ids[z]) for z in ids},'groups':{z:len(zones[z]) for z in zones},'learning_label_cells':sum(len(truth[i]) for i in ids['learning']),'validation_label_cells':sum(len(truth[i]) for i in ids['validation']),'test_unknown_cells':sum(len(targets)-len(truth[i]) for i in ids['repair']),'no_repollution':True,'strict_literal_main_metric':True}
   save(c/'case.json',meta)
   save(c/'audit/curation.json',{'at':time.time(),'edges':edges,'all_rows_preserved':sum(meta['rows'].values())==len(dirty),'original_source_guard_passed':True,'truth_signature_blocks':len(blocks),'entity_groups':len(groups),'zone_groups':zones,'source_files_sha':{str(p):sha(p) for p in (R/'candidate_sources'/ds).glob('*.csv')},'source_metadata_reference_read':True,'formal_method_scores_read':False,'literal_values_unchanged':True,'selection_manifest_sha':sha(R/'candidate_sources'/ds/'selection_freeze.json') if (R/'candidate_sources'/ds/'selection_freeze.json').exists() else None})
   save(c/'input_freeze.json',{'public':freeze(c/'public'),'private':freeze(c/'private'),'case_sha':sha(c/'case.json')});cases.append(name);inventory.append(meta)
 save(R/'configs/new_candidate_cases.json',cases);save(R/'configs/cases_pilot.json',[x for x in cases if x.endswith('_s9013')]);save(R/'configs/cases_formal_new.json',[x for x in cases if not x.endswith('_s9013')]);save(R/'audit/curation_expansion_summary.json',{'at':time.time(),'cases':inventory,'incompatible':fail,'original_source_guard_unchanged':True,'model_calls':0,'formal_scores':0});save(R/'audit/pair_alignment_expansion_v2.json',{'passed':not fail,'datasets':AUDITS,'reference_seen_only_by_curator':True,'formal_method_scores_read':False,'no_new_pollution':True})
 save(R/'audit/new_candidate_input_snapshot_freeze.json',{'case_freeze_sha':{n:sha(R/'cases'/n/'input_freeze.json') for n in cases}})
 print(json.dumps({'prepared':len(cases),'incompatible':fail,'pilot_budgets':[x for x in inventory if x['seed']==9013]},ensure_ascii=False))
if __name__=='__main__':main()
