"""Report frozen scores only; retain all selected data, zero values and qualifications."""
from pathlib import Path
import os,statistics,time,collections,json
from common import ROOT,load,save,sha
def build(phase):
 ag=load(ROOT/'reports'/(phase+'_aggregate.json'));rows=load(ROOT/'reports'/(phase+'_all_scores.json'))
 index={(x['dataset'],x['profile'],x['arm'],x['metric']):x for x in ag}
 names=sorted({x['dataset'] for x in rows})
 def fmt(d,p,a,m):
  x=index[(d,p,a,m)];k=100 if m=='normal_damage' else 1
  return f"{x['mean']*k:.3f} ± {x['sample_sd']*k:.3f}"
 title='独立预实验' if phase=='pilot' else '正式确认实验'
 text=['# EvidForge 与 TabClean：'+title,'同Qwen3.5-9B BF16/temp0。真实表派生受控污染；不是原论文GPT结果，不是新自然脏表。','正常误改越低越好；0误改是有效好结果。F1为原准确修复口径，零修改F1=0而P未定义。','所有入选数据/种子均保留；外校不通过的EvidForge结果明确为研究回退，不称合格自动部署。','','|数据集|场景|EvidForge F1|TabClean F1|正常误改% EF / TC|','|---|---|---:|---:|---:|']
 cells=[]
 for d in names:
  for p in ['structured_repeat','mixed']:
   vals=[d,p,fmt(d,p,'full','F1'),fmt(d,p,'tabclean','F1'),fmt(d,p,'full','normal_damage')+' / '+fmt(d,p,'tabclean','normal_damage')]
   text.append('|'+ '|'.join(vals)+'|');cells.append(vals)
 text+=['','全部指标为逐seed等权mean±sampleSD(ddof1)。同一case两方法同卡；两张A100TP1同权重。','监督预算对齐、内部使用方式不同：EvidForge学习/外校；TabClean原生采样自相同授权开发池。']
 (ROOT/'reports'/(phase+'_完整对照.md')).write_text('\n'.join(text)+'\n')
 costs=collections.Counter();requests=[]
 for p in (ROOT/'services').glob('gpu*/requests/*'):
  if not (p/'response.json').exists():continue
  b=load(p/'binding.json')
  if b['phase']!=phase:continue
  r=load(p/'response.json');u=r.get('usage',{});costs['calls']+=1
  for k in ['prompt_tokens','completion_tokens','total_tokens']:costs[k]+=u.get(k,0)
  requests.append({'path':str(p),'binding':b,'usage':u,'seconds':load(p/'timing.json')['seconds']})
 save(ROOT/'reports'/(phase+'_actual_costs.json'),{'totals':dict(costs),'requests':requests})
 if phase=='pilot':return
 os.environ['MPLCONFIGDIR']=str(ROOT/'reports/.matplotlib')
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 fontdir=ROOT.parent/'EvidForge_Advisor_Study_20261021/reports/paper_ablation_tables_20261022/fonts'
 fp=FontProperties(fname=str(fontdir/'SongtiSC-Regular.ttf'))
 fig,ax=plt.subplots(figsize=(12,1.8+.36*len(cells)));ax.axis('off')
 table=ax.table(cellText=cells,colLabels=['数据集','场景','EvidForge F1','TabClean F1','正常误改% EF / TC'],loc='center',cellLoc='center',colWidths=[.15,.16,.19,.19,.31])
 table.auto_set_font_size(False);table.set_fontsize(9);table.scale(1,1.6)
 for (i,j),c in table.get_celld().items():c.get_text().set_fontproperties(fp);c.visible_edges='B' if i==0 else '';c.set_facecolor('white')
 for j in range(5):table[(0,j)].visible_edges='TB';table[(len(cells),j)].visible_edges='B'
 ax.set_title('与TabClean的同模型对照（五种子）',fontproperties=fp,fontsize=15,pad=15)
 fig.text(.03,.025,'准确修复F1越高越好；正常误改越低越好。全部预定条件保留，未按胜负筛除正式结果。',fontproperties=fp,fontsize=9)
 for suffix in ['pdf','png','svg']:fig.savefig(ROOT/'reports'/('TabClean正式对照_论文表.'+suffix),dpi=600,bbox_inches='tight')
 plt.close(fig)
 save(ROOT/'status/reports_ready.json',{'at':time.time(),'phase':phase,'score_sha':sha(ROOT/'reports/confirmation_all_scores.json'),'independent_review_still_required':True})
