"""Aggregate existing frozen seed scores; never open formal cell answers."""
from pathlib import Path
import json,hashlib,statistics,time
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/"DataForge_V23_Benchmark_seed1013"
SEEDS=[1013,1014,1015]
METHODS=["pure_llm","tool_llm","raha_holoclean","garf","cdc","v23"]
LABELS={"pure_llm":"纯LLM（9B）","tool_llm":"LLM＋代码工具","raha_holoclean":"Raha＋HoloClean","garf":"GARF（SQLite移植）","cdc":"CDC（限时CPU适配）","v23":"EvidForge"}
NAMES=["monks1","cmc","bc_original","mammographic","ilpd","climate","voting","qsar"]
TITLES=["MONKS1","CMC","BC Original","Mammographic","ILPD","Climate","Voting","QSAR"]
def main():
 protocol=json.loads((ROOT/"protocol.json").read_text())
 old=BASE/"reports/final_seed1013/scores.json"
 assert hashlib.sha256(old.read_bytes()).hexdigest()==protocol["original_1013_scores_sha256"]
 all_scores={};paths={}
 for seed in SEEDS:
  folder=BASE if seed==1013 else ROOT.parent/f"EvidForge_Benchmark_seed{seed}"
  p=folder/f"reports/final_seed{seed}/scores.json"
  assert (p.parent/"scoring_complete.json").exists()
  paths[str(seed)]={"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
  all_scores[seed]=json.loads(p.read_text())
 aggregate={}
 for name in NAMES:
  aggregate[name]={}
  for method in METHODS:
   metrics={}
   for key in ["P","R","F1","normal_damage","detection_AUC"]:
    values=[all_scores[s][name]["methods"][method].get("repair",{}).get(key) for s in SEEDS]
    ok=all(v is not None for v in values)
    metrics[key]={"values":values,"n":sum(v is not None for v in values),"mean":statistics.mean(values) if ok else None,"sample_sd":statistics.stdev(values) if ok else None}
   aggregate[name][method]={"repair":metrics,"fallback_seeds":[s for s in SEEDS if all_scores[s][name]["methods"][method].get("method_receipt",{}).get("fallback")]}
 out=ROOT/"reports";out.mkdir(exist_ok=True)
 data={"seeds":SEEDS,"scope":"three full end-to-end seeds including splits, pollution, teaching and model seeds; no individual test truth read by aggregation","standard_deviation":"sample ddof=1; not SEM/CI","scores":aggregate,"source_scores":paths}
 (out/"three_seed_aggregate.json").write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
 lines=["# EvidForge 第一个问题：三种子修复能力对照","",
 "三个随机种子1013、1014、1015。每格为 **修复F1均值 ± 样本标准差 / 二值检测AUC均值 ± 样本标准差**；各指标分别统计，三个种子等权。",
 "模型和方法保持固定；每个种子重新生成分组划分、70%污染和教学样本，同一种子内全部方法使用完全相同的输入。原1013成绩不修改，不挑种子。","",
 "| 方法 / 数据集 | "+" | ".join(TITLES)+" |","|---|"+"---:|"*8]
 first=all_scores[1013]
 lines+=["| 样本数 | "+" | ".join(str(first[n]["metadata"]["rows"]) for n in NAMES)+" |",
         "| 特征数 | "+" | ".join(str(len(first[n]["metadata"]["targets"])) for n in NAMES)+" |"]
 def cell(name,method,key,percent=False):
  q=aggregate[name][method]["repair"][key]
  if q["mean"] is None:return f"N/A（n={q['n']}/3）"
  factor=100 if percent else 1
  return f"{q['mean']*factor:.3f} ± {q['sample_sd']*factor:.3f}"
 for method in METHODS:
  vals=[cell(n,method,"F1")+" / "+cell(n,method,"detection_AUC")+("†" if aggregate[n][method]["fallback_seeds"] else "") for n in NAMES]
  lines.append("| "+LABELS[method]+" | "+" | ".join(vals)+" |")
 lines+=["","检测AUC保持原1013口径：统一按实际是否修改的0/1决策计算，属于单工作点，不能解释成完整置信排序能力。",
 "† 至少一个种子的代码工具回退同次纯9B；具体种子列在原始汇总JSON，不能称该种子独立代码程序成功。",
 "标准差不是统计显著性证明，也不是95%置信区间。单个种子失败或指标不可定义不按0处理，也不悄悄减少n。",""]
 for key,title,percentage in [("P","修复准确率P（%）",True),("R","准确修复召回率（%）",True),("normal_damage","正常格误改率（%）",True)]:
  lines+=["## "+title,"","| 方法 | "+" | ".join(TITLES)+" |","|---|"+"---:|"*8]
  for m in METHODS:lines.append("| "+LABELS[m]+" | "+" | ".join(cell(n,m,key,percentage) for n in NAMES)+" |")
  lines+=[""]
 (out/"第一个实验_三种子均值与标准差.md").write_text("\n".join(lines)+"\n")
 print(str(out/"第一个实验_三种子均值与标准差.md"),flush=True)
if __name__=="__main__":main()
