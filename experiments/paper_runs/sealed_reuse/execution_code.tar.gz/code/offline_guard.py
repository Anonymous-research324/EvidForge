"""Execution-phase proof: no network/subprocess or engine/sklearn fitting is permitted."""
from pathlib import Path
import sys,os,json,time
def install(log,engine):
 log=Path(log);engine=str(Path(engine).resolve());counts={"network_attempts":0,"subprocess_attempts":0,"fit_attempts":0}
 def emit(kind,detail):
  with log.open("a") as f:f.write(json.dumps({"at":time.time(),"kind":kind,"detail":detail},ensure_ascii=False)+"\n")
 def audit(event,args):
  if event in ["socket.connect","socket.connect_ex","socket.sendto","socket.sendmsg"]:
   counts["network_attempts"]+=1;emit("network_blocked",event);raise PermissionError("Offline frozen execution forbids network")
  if event in ["subprocess.Popen","os.system","os.exec","os.posix_spawn"]:
   counts["subprocess_attempts"]+=1;emit("subprocess_blocked",event);raise PermissionError("Offline execution forbids subprocess")
 sys.addaudithook(audit)
 def profile(frame,event,arg):
  if event!="call":return
  code=frame.f_code;file=code.co_filename
  if code.co_name in ["fit","fit_transform","partial_fit","learn","prepare","train","crossfit"] and (file.startswith(engine+"/") or "/sklearn/" in file):
   counts["fit_attempts"]+=1;emit("fit_blocked",file+":"+code.co_name);raise PermissionError("Frozen execution forbids fitting/training")
 sys.setprofile(profile)
 return counts
def stop_profile():sys.setprofile(None)
