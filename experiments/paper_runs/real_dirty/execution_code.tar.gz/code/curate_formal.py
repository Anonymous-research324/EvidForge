"""Curator only: literal author pairs, identity alignment, group-safe fixed budgets."""
from pathlib import Path
import sys,re,collections,hashlib,json,importlib.util,shutil
from common import ROOT as R,load,save,sha,read_csv
OLD=R.parent/'EvidForge_RealDirty_MainStudy_20261026/code/curate.py'
COPY=R/'code/curate_legacy.py'
if not COPY.exists():shutil.copyfile(OLD,COPY)
sys.path[:0]=[str(R/'engine'),str(R/'engine/source_runtime')]
spec=importlib.util.spec_from_file_location('legacy_curator',COPY);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def norm(v):return re.sub(r'[^\w]+','',v.casefold())
PROTECTED={};AUDITS=[]
def dataset(ds):
 folder=R/'sources'/ds;f,d=read_csv(folder/'dirty.csv');rf,t=read_csv(folder/'reference.csv')
 assert all(None not in x for x in d+t) and len(d)==len(t)
 if ds=='university':
  def k(x):
   y={c.strip():v for c,v in x.items()}
   return (norm(y['university name']),*[y[c] for c in sorted(y) if c not in ['university name','state','location']])
  truthby={k(x):x for x in t};assert len(truthby)==len(t)
  assert len({k(x) for x in d})==len(d) and set(truthby)=={k(x) for x in d}
  t=[truthby[k(x)] for x in d]
  mapping={x:re.sub(r'[^a-zA-Z0-9]+','_',x.strip()).strip('_').lower() for x in f}
  refmap={x.strip():x for x in rf};assert {x.strip() for x in f}==set(refmap)
  aligned=[{x:y[refmap[x.strip()]] for x in f} for y in t]
  protected=[mapping['university name'],mapping['expenses thous$']]
  keycols=[[mapping['university name']]]
  assert all(norm(a['university name'])==norm(b['university name']) for a,b in zip(d,aligned))
 else:
  assert f==rf and {x['id'] for x in d}=={x['id'] for x in t}
  by={x['id']:x for x in t};assert len(by)==len(t)==len({x['id'] for x in d})
  aligned=[by[x['id']] for x in d];mapping={x:x for x in f};protected=['id','provenance_graph_iri']
  assert all(a[c]==b[c] for a,b in zip(d,aligned) for c in protected)
  keycols=[['id'],['name','road','postcode','locality']]
 assert len(mapping)==len(set(mapping.values()))
 d=[{mapping[x]:v for x,v in a.items()} for a in d];truthall=[{mapping[x]:v for x,v in a.items()} for a in aligned]
 fields=list(mapping.values());targets=[x for x in fields if x not in protected];PROTECTED[ds]=protected
 truth=[{c:x[c] for c in targets} for x in truthall]
 parent=list(range(len(d)));edges=collections.Counter()
 def find(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 def union(a,b,reason):
  a,b=find(a),find(b)
  if a!=b:parent[b]=a;edges[reason]+=1
 for role,rows in [('dirty',d),('reference_entity_metadata',truthall)]:
  for cols in keycols:
   seen={}
   for i,row in enumerate(rows):
    key=tuple(norm(row[c]) for c in cols)
    if not all(key):continue
    if key in seen:union(i,seen[key],role+':'+','.join(cols))
    else:seen[key]=i
 for role,rows in [('exact_dirty_targets',d),('exact_reference_targets',truthall)]:
  seen={}
  for i,row in enumerate(rows):
   key=tuple(row[c] for c in targets)
   if key in seen:union(i,seen[key],role)
   else:seen[key]=i
 g=collections.defaultdict(list)
 for i in range(len(d)):g[find(i)].append(i)
 groups={f'g{min(ids):06d}':ids for ids in g.values()};blocks=[[x] for x in groups]
 AUDITS.append({'dataset':ds,'rows':len(d),'columns':len(fields),'protected':protected,'targets':targets,'field_mapping':mapping,'aligned_by':'unique normalized university name plus15 unchanged attributes; exact key multiset verified' if ds=='university' else 'unique exact published id','group_blocks':len(blocks),'author_reference_not_independent_manual_truth':True,'row_sampling':False,'no_injected_errors':True,'source_files':{str(x.relative_to(R)):sha(x) for x in folder.glob('*.csv')},'curator_only_no_method_score':True})
 return fields,d,truth,targets,groups,blocks,[],dict(edges)

original_dataset=m.dataset
small_dataset=dataset
def dispatch_dataset(ds):
 if ds in ['address_skiresort','address_museum','address_landmarks']:
  result=small_dataset(ds);m.PROTECTED.update(PROTECTED);return result
 return original_dataset(ds)
m.dataset=dispatch_dataset;m.PLAN=R
m.main()
save(R/'audit/pair_alignment_formal.json',{'passed':True,'new_address_datasets':AUDITS,'movies_and_shoppingcenter':'same pinned pairs and curator entity alignment as published pilot; old references never reused as model inputs','no_method_performance_read':True,'no_new_pollution':True})
