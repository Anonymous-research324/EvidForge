"""All outputs first, hashes/private only, once-only scoring follows."""
from pathlib import Path
import os,socket,time,collections,json
from common import ROOT as R,load,save,sha,read_csv
def verify_frozen():
 for rel,h in load(R/'audit/execution_freeze.json')['files'].items():assert sha(R/rel)==h,rel
 core=load(R/'audit/core124.json')
 for rel,h in core['files'].items():
  assert sha(R/'engine'/rel)==h
  assert sha(Path(core['original_engine'])/rel)==h
 for p,h in load(R/'audit/old_scores_frozen.json').items():assert sha(p)==h,p
def main():
 verify_frozen();plan=load(R/'configs/cases.json');lanes=load(R/'configs/lanes.json');lane={n:int(g) for g,ns in lanes.items() for n in ns}
 counts=collections.Counter()
 for name in plan:
  c=R/'cases'/name;f=load(c/'input_freeze.json')
  for z in ['public','private']:
   for p,h in f[z].items():assert sha(c/z/p)==h
  assert sha(c/'case.json')==f['case_sha256']
  assert not list((c/'status').glob('*failure*.json'))
  assert load(c/'status/closed.json')['arms']==['full','no_llm']
  fields,dirty=read_csv(c/'public/repair_dirty.csv');targets=set(load(c/'public/declaration.json')['targets'])
  for arm in ['full','no_llm']:
   out=c/'outputs'/arm
   for p,h in load(out/'output_freeze.json')['files'].items():assert sha(out/p)==h
   for p,h in load(c/'work'/arm/'learning_freeze.json')['files'].items():assert sha(c/'work'/arm/p)==h
   ff,rows=read_csv(out/'repair_output.csv');assert ff==fields and len(rows)==len(dirty)
   assert all(a[k]==b[k] for a,b in zip(dirty,rows) for k in fields if k not in targets)
   assert load(out/'receipt.json')['new9B_calls']==0
   counts['outputs']+=1
  assert load(c/'outputs/full/candidate_evidence.json')==load(c/'outputs/no_llm/candidate_evidence.json'),'Candidate pool differs'
  shared=load(c/'work/pre_native_shared_fit.json');assert shared['base_files']==shared['no_llm_base_files']
  for rel,h in shared['base_files'].items():
   assert sha(c/'work/full/onboarding/prior_prepared/base_skill'/rel)==h
   assert sha(c/'work/no_llm/onboarding/prior_prepared/base_skill'/rel)==h
  for rel,h in shared['prepared_files'].items():
   assert sha(c/'work/full/onboarding/prior_prepared'/rel)==h
   assert sha(c/'work/no_llm/onboarding/prior_prepared'/rel)==h
  no=load(c/'work/no_llm/selection.json');assert no['actual9B_calls']==0 and no['pre_native_checkpoint']
  assert not list((c/'work/no_llm').rglob('compiled_candidate.json'))
  actual_learning={g['group'] for g in load(c/'public/development_bundle.json')['learning']}
  assert set(load(c/'work/full/onboarding/prior_prepared/source_freeze.json')['source_groups'])==actual_learning
  for kind in ['prior','context']:
   p=c/'work/full'/f'{kind}_stage/native_v3';rec=load(p/'result.json');budget=load(p/'budget.json')
   assert rec['closed'] and rec['native_exit_code']==0 and rec['real9B_calls']==5 and rec['synthetic_control_count']==0 and not rec['gateway_failure']
   assert budget['calls']==5 and budget['pending_call'] is None and len(budget['actual_usage'])==5
   events=[json.loads(x) for x in (p/'native_events.jsonl').read_text().splitlines() if x.strip()]
   hooks=[json.loads(x) for x in (p/'native_hooks.jsonl').read_text().splitlines() if x.strip()]
   assert hooks and events and rec['project_hook_registered']
   hc=collections.Counter(x['event'] for x in hooks);assert hc['PreToolUse']==hc['PostToolUse']==5 and hc['Stop']>=1
   for n in range(1,6):
    raw=load(p/f'actual9b-response-{n}.json');assert 'usage' in raw and raw['usage']==budget['actual_usage'][n-1]
    tag=load(p/'session.json')['tag'];original=R/'services'/f'gpu{lane[name]}'/'requests'/f'{tag}call{n}'/'response.json'
    assert raw==load(original),'Native raw differs from service raw'
   counts['native_sessions']+=1;counts['actual_calls']+=5
  assert load(c/'teaching_coverage.json')['formal_reference_rows_read']==0
  counts['cases_closed']+=1
 for req in (R/'services').glob('gpu*/requests/*'):
  if not (req/'request.json').exists():continue
  w=load(req/'request.json');resp=load(req/'response.json')
  matched=[n for n in plan if ('Expansion'+n).replace('_','').replace('-','') in req.name]
  assert len(matched)==1;name=matched[0];gpu=lane[name]
  assert req.parents[1].name==f'gpu{gpu}'
  assert w['seed']==load(R/'cases'/name/'case.json')['seed'] and w['temperature']==0
  assert w['model']==f'evidforge-original-newerrors-gpu{gpu}-9b' and 'usage' in resp
  counts['actual_requests']+=1
 assert counts['actual_calls']==counts['actual_requests']==load(R/'configs/protocol.json')['max_real_calls']
 for g in [0,1]:
  owner=load(R/'services'/f'gpu{g}'/'owner.json')
  assert owner['host']==socket.gethostname() and not Path('/proc',str(owner['pid'])).exists()
  with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',8211+g))!=0
  assert (R/'services'/f'gpu{g}'/'stopped.json').exists()
 save(R/'audit/all_outputs_ready_integrity.json',{'at':time.time(),'counts':dict(counts),'passed':True,'formal_reference_rows_parsed':0,'same_candidate_pool':True})
 save(R/'status/all_model_outputs_closed.json',{'at':time.time(),'cases':len(plan)})
 print(dict(counts),flush=True)
if __name__=='__main__':main()
