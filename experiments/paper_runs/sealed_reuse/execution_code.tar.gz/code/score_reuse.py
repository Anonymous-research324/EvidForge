
"""Unique independent once-only scorer after all three-batch outputs are frozen."""
from pathlib import Path
import sys,time
from common import ROOT,ENGINE,load,save,sha,read_csv
sys.path.insert(0,str(ENGINE/"source_runtime"))
from unseen_table.common import equal
from metrics_reuse import repair_metrics
def case_score(case):
 if (case/"audit/scoring_started.json").exists():raise RuntimeError("Once-only marker exists: do not re-score")
 assert (case/"status/outputs_closed.json").exists()
 cfg=load(case/"case.json");cols=load(case/"source/declaration.json")["targets"]
 save(case/"audit/scoring_started.json",{"at":time.time(),"role":"independent scorer","read_formal_reference":True,"fixed_capsule_sha":sha(case/"sealed/capsule.json")})
 result=[]
 for b in ["B1","B2","B3"]:
  fields,dirty=read_csv(case/"batches"/b/"dirty.csv");_,rows=read_csv(case/"outputs"/b/"repair_output.csv")
  _,truth=read_csv(case/"private"/(b+"_reference.csv"))
  keys=load(case/"batches"/b/"row_keys.json")
  assert keys==load(case/"private"/(b+"_row_keys.json"))==load(case/"outputs"/b/"row_keys.json")
  assert len(dirty)==len(rows)==len(truth)==len(keys)
  assert all(a["entity_id"]==b["entity_id"]==t["entity_id"] for a,b,t in zip(dirty,rows,truth))
  result.append({"case":case.name,"dataset":cfg["dataset"],"seed":cfg["seed"],"data_seed":cfg["data_seed"],"batch":b,"rows":len(rows),"repair":repair_metrics(dirty,rows,truth,cols,equal),"receipt":load(case/"outputs"/b/"receipt.json"),"capsule_sha":sha(case/"sealed/capsule.json")})
 save(case/"scores.json",result);save(case/"status/scored.json",{"at":time.time(),"rows":len(result),"scores_sha":sha(case/"scores.json")})
 return result
def main():
 assert load(ROOT/"audit/outputs_ready.json")["passed"]
 scores=[]
 for name in load(ROOT/"configs/cases.json"):
  c=ROOT/"cases"/name
  if (c/"status/scored.json").exists():
   assert sha(c/"scores.json")==load(c/"status/scored.json")["scores_sha"];scores+=load(c/"scores.json")
  else:scores+=case_score(c)
 assert len(scores)==18
 save(ROOT/"reports/all_scores.json",scores);save(ROOT/"status/scoring_complete.json",{"at":time.time(),"score_sha":sha(ROOT/"reports/all_scores.json"),"rows":len(scores)})
if __name__=="__main__":main()
