"""Process-local seed and base-permission offset; no original file mutation."""
from pathlib import Path
import os,sys,ast,copy,importlib.machinery,collections
from common import ROOT,read,sha
sys.dont_write_bytecode=True
KNOWN=set(read(ROOT/"audit/core124.json")["files"].values())
SOURCE=importlib.machinery.SourceFileLoader.source_to_code
COUNTS=collections.Counter()
def install(seed,delta):
 def hook(event,args):
  if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)):
   p=Path(os.fsdecode(args[0])).resolve()
   if {"private","local_private","downstream_training"}.intersection(p.parts) or p.name in {"repair_reference.csv","holdout_reference.csv","holdout_dirty.csv","clean.csv"}:
    raise PermissionError("Repair role cannot read formal or original reference: "+str(p))
   mode=args[1] if len(args)>1 else None;flags=args[2] if len(args)>2 else 0
   write=(isinstance(mode,str) and any(k in mode for k in "wax+")) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
   if write and ROOT!=p and ROOT not in p.parents:raise PermissionError("All new writes confined to threshold ROOT")
  if event in {"socket.connect","socket.bind","subprocess.Popen"}:raise PermissionError("No network/model/subprocess in repair")
 sys.addaudithook(hook)
 def loader(self,data,path,*,_optimize=-1):
  b=data.encode() if isinstance(data,str) else data
  p=Path(path).resolve()
  if ROOT/"engine" in p.parents and __import__("hashlib").sha256(b).hexdigest() in KNOWN:
   t=ast.parse(b,filename=str(path))
   class Seed(ast.NodeTransformer):
    def visit_Constant(self,n):
     return ast.copy_location(ast.Constant(seed),n) if type(n.value)is int and n.value==20260927 else n
   t=Seed().visit(t);ast.fix_missing_locations(t)
   return compile(t,str(path),"exec",dont_inherit=True)
  return SOURCE(self,data,path,_optimize=_optimize)
 importlib.machinery.SourceFileLoader.source_to_code=loader
 sys.path[:0]=[str(ROOT/"dependencies"),str(ROOT/"engine"),str(ROOT/"engine/source_runtime"),str(ROOT/"engine/application")]
 import random,numpy as np
 random.seed(seed);np.random.seed(seed)
 import unseen_table.validate_skill as m
 original=m.permitted
 def shifted(cell,policy):
  COUNTS["checks"]+=1
  if delta==0:return original(cell,policy)
  p=copy.deepcopy(policy)
  def adjust(x):
   if isinstance(x,dict):
    for k,v in x.items():
     if k in ["confidence_threshold","score_threshold"] and isinstance(v,(int,float)):x[k]=max(0.,min(1.,v+delta))
     elif isinstance(v,dict):adjust(v)
  adjust(p)
  a=original(cell,policy);b=original(cell,p)
  COUNTS["newly_admitted"]+=bool(b and not a);COUNTS["newly_blocked"]+=bool(a and not b)
  return b
 for module in list(sys.modules.values()):
  if module:
   for k,v in list(vars(module).items()):
    if v is original:setattr(module,k,shifted)
 return COUNTS
