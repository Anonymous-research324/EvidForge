"""公共I/O；所有新材料保存在独立A100研究目录。"""
from pathlib import Path
import json,hashlib,os,uuid,csv,time
ROOT=Path(__file__).resolve().parents[1]
PY="/root/fsas/home/anonymous/envs/dataforge-run/bin/python"
ENGINE=ROOT/"engine"
SEED=int(os.environ.get("EF_SEED","1013"))
def load(p):return json.loads(Path(p).read_text())
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+"."+uuid.uuid4().hex+".tmp")
 t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+"\n");os.replace(t,p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read_csv(p):
 with Path(p).open(newline="",encoding="utf-8-sig") as f:r=csv.DictReader(f);return r.fieldnames,list(r)
def write_csv(p,fields,rows):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("w",newline="") as f:w=csv.DictWriter(f,fieldnames=fields,lineterminator="\n");w.writeheader();w.writerows(rows)
def freeze(p):return {str(x.relative_to(p)):sha(x) for x in sorted(Path(p).rglob("*")) if x.is_file() and x.suffix!=".pyc"}
def status(key,**x):save(ROOT/"status"/(key+".json"),{"at":time.time(),**x})
