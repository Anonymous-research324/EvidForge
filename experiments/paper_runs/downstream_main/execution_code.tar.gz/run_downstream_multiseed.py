"""Two-seed downstream replication; isolated GPU and unchanged numerical methods."""
from pathlib import Path
import os,sys,json,time,subprocess,concurrent.futures,hashlib,fcntl,traceback,csv,math
ROOT=Path(__file__).resolve().parent
PY='/root/fsas/home/anonymous/envs/dataforge-run/bin/python'
P=json.loads((ROOT/'protocol.json').read_text())
NAMES=P['datasets'];SEEDS=[1014,1015]
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','MKL_NUM_THREADS':'4','NUMEXPR_NUM_THREADS':'4','EVIDFORGE_MODEL_REPLICA':'primary'}
ENV.pop('EVIDFORGE_SUPERVISED_COMPONENT',None)
def load(p):return json.loads(Path(p).read_text())
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 t=p.with_name(p.name+'.'+str(os.getpid())+'.'+str(time.time_ns())+'.tmp')
 t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n');os.replace(t,p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def r(s):return Path(P['new_roots'][str(s)])
def invoke(s,stage,script,name=None,exe=PY):
 base=r(s);args=[exe,'-B',str(base/'code'/script)]
 if name:args+=['--dataset',name]
 label=(name+'_' if name else '')+stage
 log=base/'logs'/(label+'.log')
 assert not log.exists(),'Existing execution needs reviewed recovery '+str(log)
 st=base/'status'/('active_'+stage+'.json')
 with log.open('x') as f:
  child=subprocess.Popen(args,cwd=base,env=ENV,stdout=f,stderr=subprocess.STDOUT)
  save(st,{'seed':s,'dataset':name,'stage':stage,'pid':child.pid,'phase':'running','time':time.time(),'log':str(log)})
  code=child.wait()
 save(st,{'seed':s,'dataset':name,'stage':stage,'phase':'complete' if not code else 'failed','returncode':code,'time':time.time(),'log':str(log)})
 if code:
  evidence={'seed':s,'dataset':name,'stage':stage,'returncode':code,'log':str(log),'time':time.time(),'review_required':True,'not_zero_score':True}
  save(base/'status/failures'/(label+'.json'),evidence)
  save(ROOT/'status/failures'/(str(s)+'_'+label+'.json'),evidence)
  return False
 return True
def complete(s,n,stage):
 base=r(s)
 if stage=='learning':return (base/'outputs/v23'/n/'selection.json').is_file()
 return (base/'outputs'/n/('primary_llm' if stage=='primary' else stage)/'output_freeze.json').is_file()
def gpu(s):
 base=r(s)
 assert invoke(s,'service_start','model_service_start.py')
 for n in NAMES:
  if not invoke(s,'learning','run_v23_learning.py',n):raise RuntimeError(f'{s} {n} learning needs review')
  assert complete(s,n,'learning')
  if not invoke(s,'primary','run_primary_llm_v3.py',n):raise RuntimeError(f'{s} {n} primary needs review')
  assert complete(s,n,'primary')
 for n in NAMES:
  if not invoke(s,'tool_llm','run_tool_llm_v5.py',n):raise RuntimeError(f'{s} {n} Tool needs review')
  if n in P['classification']:
   if not invoke(s,'caafe','run_caafe.py',n):raise RuntimeError(f'{s} {n} CAAFE needs review')
  save(base/'status'/('model_done_'+n+'.json'),{'closed':True,'time':time.time(),'seed':s})
 save(base/'status/model_queue_complete.json',{'time':time.time(),'seed':s})
 assert invoke(s,'service_stop','model_service_stop.py')
 return {'seed':s,'phase':'models_complete'}
def garf(s):
 for n in ['retinopathy']+[n for n in NAMES if n!='retinopathy']:
  invoke(s,'garf','run_garf.py',n,str(r(s)/'environments/garf/bin/python'))
 save(r(s)/'status/cpu_garf_complete.json',{'time':time.time()})
 return {'seed':s,'phase':'garf_complete'}
def cpu_combined(method):
 for n in ['retinopathy']+[n for n in NAMES if n!='retinopathy']:
  for s in SEEDS:
   if method=='raha_holoclean':
    ok=invoke(s,'raha_detection','run_raha_detection.py',n,str(r(s)/'environments/raha/bin/python'))
    if ok:invoke(s,method,'run_holoclean.py',n,str(r(s)/'environments/holoclean/bin/python'))
   else:invoke(s,method,'run_cdc.py',n,str(r(s)/'environments/cdc/bin/python'))
 for s in SEEDS:save(r(s)/'status'/('cpu_'+method+'_complete.json'),{'time':time.time()})
 return {'phase':method+'_complete'}
def verify(s):
 base=r(s);checks={}
 for f,h in load(base/'audit/run_code_freeze.json')['files'].items():assert sha(base/f)==h,'Code changed '+f
 for f,h in load(base/'audit/frozen_v23_files.json')['files'].items():assert sha(base/f)==h,'Core changed '+f
 for n in NAMES:
  inp=load(base/'datasets'/n/'input_freeze.json')
  for group,folder in [('public','public'),('private','private'),('supervised_labels','downstream_training')]:
   for f,h in inp[group].items():assert sha(base/'datasets'/n/folder/f)==h,'Input changed'
  _,initial=read(base/'datasets'/n/'public/repair_dirty.csv')
  for stage in ['primary','tool_llm','raha_holoclean','garf','cdc']+(['caafe'] if n in P['classification'] else []):
   folder=base/'outputs'/n/('primary_llm' if stage=='primary' else stage)
   manifest=load(folder/'output_freeze.json')['files']
   for f,h in manifest.items():assert sha(folder/f)==h,'Output changed '+str(folder/f)
   paths=['v23_output.csv','pure_output.csv'] if stage=='primary' else [] if stage=='caafe' else ['repair_output.csv']
   for f in paths:
    fields,rows=read(folder/f)
    assert list(initial[0])==fields and len(rows)==len(initial)
    assert [x['entity_id'] for x in rows]==[x['entity_id'] for x in initial]
   checks[n+'/'+stage]=len(manifest)
  assert (base/'status'/('model_done_'+n+'.json')).exists()
 reqs=list((base/'models_service/requests').glob('*/request.json'))
 for p in reqs:
  b=load(p);assert b['seed']==s and b['temperature']==0 and b['model']=='evidforge-downstream-seed'+str(s),str(p)
  assert (p.parent/'response.json').is_file(),'Unclosed real model request '+str(p)
 save(base/'audit/pre_score_output_verification.json',{'time':time.time(),'code_core_input_and_output_hashes':True,'request_count':len(reqs),'seed_model_temp_verified':True,'stages':checks,'formal_reference_parsed':False})
 return checks
def read(p):
 with Path(p).open(newline='') as f:a=csv.DictReader(f);return a.fieldnames,list(a)
def cleanup_pg(s):
 base=r(s);owner=load(base/'status/postgres.json');cluster=base/'outputs/postgres/cluster'
 assert owner['owned'] and owner['cluster']==str(cluster) and owner['port']==P['postgres_ports'][str(s)]
 if (cluster/'postmaster.pid').exists():
  lines=(cluster/'postmaster.pid').read_text().splitlines()
  pid=int(lines[0]);cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes().replace(b'\0',b' ').decode()
  assert str(cluster) in cmd,'Database ownership mismatch'
  subprocess.run([str(base/'environments/postgres/bin/pg_ctl'),'-D',str(cluster),'-m','fast','stop'],check=True,cwd=base,env=ENV,capture_output=True)
 save(base/'status/postgres_stopped.json',{'time':time.time(),'owned_cluster':str(cluster),'port':owner['port']})
def main():
 (ROOT/'status').mkdir(exist_ok=True)
 with (ROOT/'status/controller.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not (ROOT/'status/owner.json').exists(),'Existing controller: inspect without rerun'
  save(ROOT/'status/owner.json',{'pid':os.getpid(),'started':time.time(),'seeds':SEEDS,'datasets':NAMES,'advisory_timeout_hours':24,'automatic_timeout_kill':False})
  try:
   for s in SEEDS:
    assert invoke(s,'synthetic_precheck','self_check.py')
    assert invoke(s,'generate_inputs','generate_benchmarks.py')
    assert invoke(s,'postgres_setup','setup_postgres_v2.py')
   save(ROOT/'status/inputs_ready.json',{'time':time.time(),'inputs':12})
   with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    tasks={pool.submit(gpu,s):'gpu'+str(s) for s in SEEDS}
    tasks.update({pool.submit(garf,s):'garf'+str(s) for s in SEEDS})
    tasks.update({pool.submit(cpu_combined,m):m for m in ['raha_holoclean','cdc']})
    errors=[]
    for f in concurrent.futures.as_completed(tasks):
     label=tasks[f]
     try:result=f.result();save(ROOT/'status'/(label+'_complete.json'),result)
     except BaseException as e:
      errors.append({'branch':label,'error':repr(e),'traceback':traceback.format_exc()})
      save(ROOT/'status/branch_errors.json',errors)
   assert not errors,'Failed branch needs review; preserve partial outputs'
   assert not list((ROOT/'status/failures').glob('*.json')),'Method failures require independent applicability/interface review before scoring'
   assert sha(Path(P['original_scores']))==P['original_scores_sha256']
   for s in SEEDS:verify(s)
   freeze=load(ROOT/'audit/controller_freeze.json')
   for f,h in freeze['files'].items():assert sha(ROOT/f)==h,'Controller changed '+f
   save(ROOT/'status/all_outputs_closed.json',{'time':time.time(),'all_outputs_frozen':True,'formal_scoring_not_yet_started':True})
   for s in SEEDS:
    assert invoke(s,'formal_scoring','score_downstream.py'),'Independent scoring failed: retain started receipt'
    assert (r(s)/'status/scoring_complete.json').exists()
   with (ROOT/'logs/aggregate.log').open('x') as f:
    subprocess.run([PY,'-B',str(ROOT/'aggregate_downstream.py')],cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=True)
   for s in SEEDS:cleanup_pg(s)
   save(ROOT/'status/complete.json',{'time':time.time(),'report':str(ROOT/'reports/第二个实验_三种子下游均值与标准差.md'),'gpu_services_stopped':True,'owned_postgres_stopped':True})
  except BaseException as e:
   save(ROOT/'status/controller_error.json',{'time':time.time(),'error':repr(e),'traceback':traceback.format_exc(),'do_not_restart_entire_controller':True,'do_not_delete_closed_outputs_or_scoring_receipts':True})
   raise
if __name__=='__main__':main()
