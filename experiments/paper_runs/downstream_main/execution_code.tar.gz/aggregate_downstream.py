"""Aggregate fixed independent downstream scores. No row-level references read."""
from pathlib import Path
import json,statistics,hashlib,time,math
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
 assert sha(Path(P['original_scores']))==P['original_scores_sha256']
 paths={1013:Path(P['original_scores']),**{s:Path(P['new_roots'][str(s)])/f'reports/final_seed{s}/scores.json' for s in [1014,1015]}}
 allrows={s:load(p) for s,p in paths.items()}
 names=P['datasets'];methods=P['methods']+['caafe'];records=[];paired={}
 for n in names:
  task=P['catalog'][n]['task'];metric_names=['macro_F1','AUC'] if task=='classification' else ['R2','MAE']
  for m in methods:
   if m=='caafe' and task!='classification':continue
   byseed={s:[x for x in rows if x['dataset']==n and x['method']==m] for s,rows in allrows.items()}
   assert all(len(v)==1 for v in byseed.values()),(n,m)
   byseed={s:v[0] for s,v in byseed.items()};stats={}
   for k in metric_names:
    v={s:x.get('metrics',{}).get(k) for s,x in byseed.items() if x['status']=='complete'}
    v={s:x for s,x in v.items() if isinstance(x,(int,float)) and math.isfinite(x)}
    stats[k]={'n':len(v),'seeds':list(v),'per_seed':v,'mean':statistics.mean(v.values()) if len(v)==3 else None,'sample_sd':statistics.stdev(v.values()) if len(v)==3 else None,'ddof':1,'status':'complete_n3' if len(v)==3 else 'N/A_incomplete_n3'}
   fallback=[s for s,x in byseed.items() if x.get('method_receipt',{}).get('fallback')]
   records.append({'dataset':n,'method':m,'task':task,'metrics':stats,'fallback_seeds':fallback,'per_seed_records':byseed})
 lookup={(x['dataset'],x['method']):x for x in records}
 title={'dirty':'未修复＋基础预处理','pure_llm':'纯LLM（9B）','tool_llm':'LLM＋代码工具','raha_holoclean':'Raha＋HoloClean','garf':'GARF（作者SQLite移植）','cdc':'CDC（限时CPU适配）','caafe':'CAAFE（同9B适配）','v23':'**EvidForge**'}
 display=['dirty','pure_llm','tool_llm','raha_holoclean','garf','cdc','caafe','v23']
 text=['# 第二个实验：修复后的数据是否更有用？（三个种子）','',
 '范围：此前选定展示的六张数据集，保留原1013，补充1014、1015。原八表完整结果不删除。这不是新盲测；选定范围不能代表所有原始数据集。','',
 '每个数为三种子的等权均值 ± 样本标准差（ddof=1，n=3）。分类为宏F1 / 概率ROC-AUC，回归为R² / MAE；前三项越高越好，MAE越低越好。全部方法使用相同固定XGBoost、同种子的训练/未污染留出。','',
 '| 方法 / 数据集 | '+' | '.join(P['display_names'][n] for n in names)+' |',
 '|---|'+'---:|'*len(names),
 '| 任务 | '+' | '.join('分类' if n in P['classification'] else '回归' for n in names)+' |',
 '| 样本数 | '+' | '.join(str(P['catalog'][n]['rows']) for n in names)+' |',
 '| 特征数 | '+' | '.join(str(P['catalog'][n]['columns']) for n in names)+' |',
 '| 指标 | '+' | '.join('F1 / AUC' if n in P['classification'] else 'R² / MAE' for n in names)+' |']
 for m in display:
  cells=[]
  for n in names:
   if m=='caafe' and n not in P['classification']:cells.append('—');continue
   item=lookup[n,m];vals=[]
   for k,v in item['metrics'].items():vals.append(f"{v['mean']:.3f} ± {v['sample_sd']:.3f}" if v['mean'] is not None else f"N/A（{v['n']}/3）")
   value=' / '.join(vals)+('†' if item['fallback_seeds'] else '')
   cells.append('**'+value+'**' if m=='v23' else value)
  text.append('| '+title[m]+' | '+' | '.join(cells)+' |')
 text+=['','† 代码工具存在纯LLM安全回退时，具体种子列于JSON和下列说明；不当作独立强代码法成功。失败不填零；不足三次的单元格不冒充三种子均值±SD。','',
 '洁净训练参考仅保留在独立评分原始记录中，不放主表。单独三次重复不构成统计显著性证明；不将分类F1混同单元格修复F1，不将回归指标称作AUC。','',
 '## 与对照的逐表比较','']
 for m in ['pure_llm','tool_llm','raha_holoclean','garf','cdc','caafe']:
  lines=[]
  for n in names:
   if (n,m) not in lookup:continue
   sysrow=lookup[n,'v23'];control=lookup[n,m]
   desc=[]
   for k in sysrow['metrics']:
    a=sysrow['metrics'][k]['mean'];b=control['metrics'][k]['mean']
    if a is None or b is None:desc.append(k+'：N/A');continue
    delta=a-b;good=delta<0 if k=='MAE' else delta>0
    desc.append(k+'：'+('相同' if abs(delta)<1e-12 else '高于对照' if good else '不如对照')+f'（系统−对照={delta:+.6f}）')
   lines.append(P['display_names'][n]+'，'+'；'.join(desc))
  text.append('- '+title[m]+'：'+'。'.join(lines)+'。')
 for x in records:
  if x['fallback_seeds']:text.append('- '+P['display_names'][x['dataset']]+'，代码工具纯LLM回退种子：'+','.join(map(str,x['fallback_seeds']))+'。')
 report=ROOT/'reports/第二个实验_三种子下游均值与标准差.md'
 report.write_text('\n'.join(text)+'\n')
 save(ROOT/'reports/three_seed_downstream_aggregate.json',{'seeds':[1013,1014,1015],'sample_sd_ddof':1,'selected_six_not_new_blind':True,'original_eight_retained':True,'scores_sha256':{s:sha(p) for s,p in paths.items()},'records':records,'created_at':time.time()})
 print('AGGREGATED',len(records),str(report),flush=True)
if __name__=='__main__':main()
