
"""Original exact repair metrics; no model or study-data access."""
def repair_metrics(dirty,rows,truth,cols,equal):
 e=n=c=tp=harm=0
 assert len(dirty)==len(rows)==len(truth)
 for a,b,t in zip(dirty,rows,truth):
  for col in cols:
   if t.get(col,"")=="":continue
   wrong=not equal(a[col],t[col]);changed=not equal(a[col],b[col])
   e+=wrong;n+=not wrong;c+=changed;tp+=wrong and changed and equal(b[col],t[col]);harm+=not wrong and changed
 p=tp/c if c else None;r=tp/e if e else 0.
 return {"P":p,"R":r,"F1":2*p*r/(p+r) if p and r else 0.,"normal_damage":harm/n if n else None,"errors":e,"normal":n,"changes":c,"exact":tp,"damaged":harm,"detection_AUC":(1+(c-harm)/e-harm/n)/2 if e and n else None}
def summary(values):
 import statistics
 xs=[x for x in values if x is not None]
 return {"n":len(xs),"mean":statistics.mean(xs) if len(xs)==3 else None,"sample_sd":statistics.stdev(xs) if len(xs)==3 else None,"per_seed":values}
