"""仅对冻结文件做SHA及公开输入输出结构审计；不解析正式参考。"""
from pathlib import Path
from common import ROOT,load,save,sha,read_csv
import time
def check(path,expected):
 if sha(path)!=expected:raise ValueError("Frozen SHA differs: "+str(path))
def verify():
 count={"cases":0,"outputs":0,"learning_packages":0,"native_sessions":0,"real_native_calls":0,"requests":0}
 for n in ["audit/code_freeze.json","audit/core124.json","audit/recovery_queue_v3_freeze.json","audit/metadata_interface_v4_freeze.json","audit/recovery_queue_v4_freeze.json","audit/source_unavailable_v5_freeze.json"]:
  content=load(ROOT/n)
  for f,h in content["files"].items():
   base=ROOT/"engine" if n.endswith("core124.json") else ROOT if n.endswith("code_freeze.json") else ROOT/"code"
   check(base/f,h)
 for f,h in load(ROOT/"audit/old_scores_frozen.json").items():check(Path(f),h)
 for name in load(ROOT/"configs/cases.json"):
  case=ROOT/"cases"/name;cfg=load(case/"case.json")
  count["cases"]+=1
  frozen=load(case/"input_freeze.json")
  for role in ["public","private"]:
   for f,h in frozen[role].items():check(case/role/f,h)
  check(case/"case.json",frozen["case_sha256"])
  unavailable=case/"status/source_closed_unavailable.json"
  if unavailable.exists():
   from review_source_unavailable_v5 import review
   if not review(case):raise ValueError("Source N/A review no longer matches")
   receipt=load(unavailable)
   assert receipt["actual_model_calls"]==0 and receipt["guard_unchanged"]
   count["reviewed_unavailable_cases"]=count.get("reviewed_unavailable_cases",0)+1
   continue
  fields,dirty=read_csv(case/"public/repair_dirty.csv")
  targets=set(load(case/"public/declaration.json")["targets"])
  arms=load(case/"status/closed.json")["arms"]
  if (case/"status/tabclean_closed.json").exists():arms=arms+["tabclean"]
  elif cfg["suite"] in ["main","natural"] and not (case/"status/tabclean_closed_unavailable.json").exists():raise ValueError("TabClean has no reviewed closure")
  for arm in arms:
   out=case/"outputs"/arm
   for f,h in load(out/"output_freeze.json")["files"].items():check(out/f,h)
   columns,rows=read_csv(out/"repair_output.csv")
   if columns!=fields or len(rows)!=len(dirty):raise ValueError("Output dimensions differ")
   if any(a[k]!=b[k] for a,b in zip(dirty,rows) for k in fields if k not in targets):raise ValueError("Protected field/ID changed")
   count["outputs"]+=1
  check(case/"outputs/reuse/repair_output.csv",sha(case/"outputs/full/repair_output.csv"))
  for arm in ["full","no_llm"]+(["no_feedback","no_predictive_context"] if cfg["suite"] in ["main","natural"] else []):
   w=case/"work"/arm
   for f,h in load(w/"learning_freeze.json")["files"].items():check(w/f,h)
   count["learning_packages"]+=1
   if arm=="no_llm":
    selection=load(w/"selection.json")
    assert selection["actual9B_calls"]==0 and selection["pre_native_checkpoint"]
   else:
    for stage in ["prior_stage","context_stage"]:
     receipt=load(w/stage/"native_v3/result.json")
     if not receipt["closed"] or receipt["native_exit_code"] or receipt["synthetic_control_count"]:raise ValueError("Native not real/closed")
     count["native_sessions"]+=1;count["real_native_calls"]+=receipt["real9B_calls"]
   if arm=="no_feedback":
    for stage in ["prior_stage","context_stage"]:
     a=load(case/"work/full"/stage/"work/hypothesis_state.json")
     b=load(w/stage/"work/hypothesis_state.json")
     if a["attempted_proposals"]!=b["attempted_proposals"]:raise ValueError("Unpaired no_feedback proposal count")
 mapping=[(n.replace("_","").replace("-",""),load(ROOT/"cases"/n/"case.json")["seed"],i%3) for i,n in enumerate(load(ROOT/"configs/cases.json"))]
 for req in (ROOT/"services").glob("gpu*/requests/*"):
  if not (req/"request.json").exists():continue
  a=load(req/"request.json")
  matches=[(n,s,g) for n,s,g in mapping if req.name.startswith("Advisor"+n) or req.name.startswith("Tab"+n)]
  if len(matches)!=1:raise ValueError("Request does not bind exactly one case")
  n,s,g=matches[0]
  if a["seed"]!=s or a["model"]!="evidforge-advisor-9b-gpu"+str(g):raise ValueError("Wrong case seed or hardware lane")
  if a["seed"] not in [1013,1014,1015] or a["temperature"]!=0 or not a["model"].startswith("evidforge-advisor-9b-gpu"):raise ValueError("Request model/seed/temp mismatch")
  if not (req/"response.json").exists():raise ValueError("Unreviewed request without response")
  count["requests"]+=1
 save(ROOT/"audit/all_outputs_ready_integrity_v5.json",{"at":time.time(),"counts":count,"formal_reference_rows_parsed":0,"passed":True})
 return count
if __name__=="__main__":print(verify())
