import sys,os,time,ast
from pathlib import Path
from common import ROOT,read,save,sha
sys.dont_write_bytecode=True
def main():
 for p in (ROOT/"code").glob("*.py"):ast.parse(p.read_text())
 for rel,h in read(ROOT/"audit/core124.json")["files"].items():assert sha(ROOT/"engine"/rel)==h
 cases=read(ROOT/"configs/cases.json");snapshot={}
 def add(p):
  p=Path(p).resolve();snapshot[str(p)]=sha(p)
 for c in cases:
  for k in ["input","declaration","reference","original_output","original_score"]:add(c[k])
  visited=set()
  def visit(p):
   p=Path(p).resolve()
   if p in visited:return
   visited.add(p)
   manifest=read(p/"manifest.json");add(p/"manifest.json")
   for rel,h in manifest["files"].items():assert sha(p/rel)==h;add(p/rel)
   cfg=read(p/"configuration.json")
   for key in ["base_skill_path","prior_skill_path"]:
    if key in cfg:visit(cfg[key])
  visit(c["skill"])
 from runtime import install
 install(1013,0)
 from unseen_table.validate_skill import permitted
 cell={"top":{"kind":"scale","score":.8},"margin":.1,"repair_confidence":.8}
 assert permitted(cell,{"confidence_threshold":.8,"margin_threshold":.1})
 assert not permitted(cell,{"confidence_threshold":.85,"margin_threshold":.1})
 try:open(ROOT/"private/repair_reference.csv")
 except PermissionError:pass
 else:raise AssertionError("Reference guard failed")
 try:open("/root/fsas/home/anonymous/projects/threshold-forbidden-write","w")
 except PermissionError:pass
 else:raise AssertionError("Old write guard failed")
 save(ROOT/"audit/input_skill_snapshot.json",{"files":snapshot,"private_reference_hash_only":True,"formal_rows_parsed":0},once=True)
 save(ROOT/"audit/preflight_pass.json",{"cases":len(cases),"core124":True,"all_skills_verified":True,"syntax":True,"guards":True,"timestamp":time.time(),"new_model_calls":0},once=True)
 print("PREFLIGHT_PASS",len(cases),len(snapshot),flush=True)
if __name__=="__main__":main()
