"""Independent count/stat/cost review and static paper table. No raw formal reference parsing."""
import os,sys,time,statistics,json,csv
from pathlib import Path
from common import ROOT,load,save,sha,freeze
sys.dont_write_bytecode=True;os.environ["MPLCONFIGDIR"]=str(ROOT/"audit/mpl-cache")
LABELS={"tic_tac_toe":"Tic-Tac-Toe","car_evaluation":"Car","retinopathy":"Retinopathy","real_estate":"Real Estate","concrete":"Concrete","airfoil":"Airfoil"}
def agg(v):
 n=sum(x is not None for x in v)
 return {"mean":statistics.mean(v) if n==3 else None,"sd":statistics.stdev(v) if n==3 else None,"n":n,"values":v}
def main():
 assert (ROOT/"status/scoring_complete.json").exists()
 scorehash=sha(ROOT/"reports/all_scores.json");scores=load(ROOT/"reports/all_scores.json")
 assert len(scores)==54
 stored=load(ROOT/"reports/aggregate.json");pairs=load(ROOT/"reports/paired_differences.json")
 assert len(stored)==18 and len(pairs)==18
 real=load(ROOT/"reports/actual_model_costs.json");rt={x["tag"]:x for x in real};assert len(rt)==len(real)
 reviewed=[];token_details=[]
 for x in scores:
  m=x["repair"];p=m["exact"]/m["changes"] if m["changes"] else None;r=m["exact"]/m["errors"] if m["errors"] else 0
  assert p==m["P"] and abs(r-m["R"])<1e-12 and abs((2*p*r/(p+r) if p and r else 0)-m["F1"])<1e-12
  assert abs(m["damaged"]/m["normal"]-m["normal_damage"])<1e-12
  case=ROOT/"cases"/x["id"];tags=[]
  for kind in ["prior","context"]:
   tags+=[load(p)["_trace_tag"] for p in (case/"work/full"/(kind+"_stage/native_v3")).glob("actual9b-request-*.json")]
  assert len(tags)==x["cost"]["actual_calls"]
  usage={k:sum(rt[tag]["usage"].get(k,0) for tag in tags) for k in ["prompt_tokens","completion_tokens","total_tokens"]}
  assert usage["prompt_tokens"]==x["cost"]["prompt_tokens"] and usage["completion_tokens"]==x["cost"]["completion_tokens"]
  token_details.append({"case":x["id"],"actual_requests":len(tags),"usage":usage,"request_seconds":sum(rt[tag]["seconds"] for tag in tags),"native_seconds":x["cost"]["native_seconds"],"learning_and_validation_total_seconds":x["learning_seconds"],"repair_seconds":x["repair_seconds"],"reuse_seconds":x["reuse_seconds"]})
 for d in LABELS:
  for n in [5,10,20]:
   xs=sorted([x for x in scores if x["dataset"]==d and x["learning_groups"]==n],key=lambda x:x["seed"]);assert [x["seed"] for x in xs]==[1013,1014,1015]
   a=next(g for g in stored if g["dataset"]==d and g["learning_groups"]==n)
   g={"dataset":d,"learning_groups":n,"validation_groups":n,"qualified_seeds":sum(x["qualified"] for x in xs)}
   for k in ["P","R","F1","normal_damage"]:
    g[k]=agg([x["repair"][k] for x in xs]);assert g[k]["n"]==a[k]["n"]
    if g[k]["n"]==3:assert abs(g[k]["mean"]-a[k]["mean"])<1e-12 and abs(g[k]["sd"]-a[k]["sd"])<1e-12
    else:assert a[k]["mean"] is None and a[k]["sd"] is None
   g["actual_calls"]=agg([x["cost"]["actual_calls"] for x in xs]);g["learning_seconds"]=agg([x["learning_seconds"] for x in xs])
   reviewed.append(g)
 for d in LABELS:
  for seed in [1013,1014,1015]:
   xs=[x for x in scores if x["dataset"]==d and x["seed"]==seed]
   assert len({(x["repair"]["errors"],x["repair"]["normal"],x["formal_rows"]) for x in xs})==1
 for z in pairs:
  for k in ["F1","normal_damage"]:
   before={x["seed"]:x for x in scores if x["dataset"]==z["dataset"] and x["learning_groups"]==z["from"]}
   after={x["seed"]:x for x in scores if x["dataset"]==z["dataset"] and x["learning_groups"]==z["to"]}
   a=agg([after[s]["repair"][k]-before[s]["repair"][k] for s in [1013,1014,1015]])
   assert abs(a["mean"]-z[k]["mean"])<1e-12 and abs(a["sd"]-z[k]["sd"])<1e-12
 hooks={"PreToolUse":0,"PostToolUse":0,"Stop":0};session_count=0
 for case in (ROOT/"cases").iterdir():
  for kind in ["prior","context"]:
   folder=case/"work/full"/(kind+"_stage/native_v3")
   for line in (folder/"native_hooks.jsonl").read_text().splitlines():
    event=json.loads(line)["event"]
    if event in hooks:hooks[event]+=1
   session_count+=1
 assert session_count==108 and hooks["PreToolUse"]==hooks["PostToolUse"]==len(real) and hooks["Stop"]>=108
 checks=0
 for rel,h in load(ROOT/"audit/execution_freeze.json")["files"].items():assert sha(ROOT/rel)==h;checks+=1
 for rel,h in load(ROOT/"audit/core124.json")["files"].items():assert sha(ROOT/"engine"/rel)==h;checks+=1
 for p,h in load(ROOT/"audit/old_scores_frozen.json").items():assert sha(p)==h;checks+=1
 for case in (ROOT/"cases").iterdir():
  for zone in ["public","private"]:
   for rel,h in load(case/"input_freeze.json")[zone].items():assert sha(case/zone/rel)==h;checks+=1 # hash only
  for rel,h in load(case/"work/full/learning_freeze.json")["files"].items():assert sha(case/"work/full"/rel)==h;checks+=1
  for arm in ["full","reuse"]:
   for rel,h in load(case/"outputs"/arm/"output_freeze.json")["files"].items():assert sha(case/"outputs"/arm/rel)==h;checks+=1
 save(ROOT/"audit/independent_review.json",{"status":"PASS","metric_rows":54,"mean_sd_groups":18,"paired_groups":18,"sessions":session_count,"actual_calls":len(real),"hook_events":hooks,"hashed_files":checks,"formal_rows_read":0,"score_sha256":scorehash})
 save(ROOT/"reports/independent_aggregate.json",reviewed);save(ROOT/"reports/verified_case_costs.json",token_details)
 lookup={(g["dataset"],g["learning_groups"]):g for g in reviewed}
 def fmt(g,k):
  x=g[k]
  if x["n"]!=3:return "N/A("+str(x["n"])+"/3)"
  scale=100 if k=="normal_damage" else 1
  return format(x["mean"]*scale,".3f")+" ± "+format(x["sd"]*scale,".3f")
 with (ROOT/"reports/table_values.csv").open("w",newline="") as f:
  fields=["dataset","learning_groups","validation_groups","F1_mean","F1_sd","damage_pct_mean","damage_pct_sd","qualified_seeds"]
  w=csv.DictWriter(f,fields);w.writeheader()
  for g in reviewed:w.writerow({"dataset":g["dataset"],"learning_groups":g["learning_groups"],"validation_groups":g["validation_groups"],"F1_mean":g["F1"]["mean"],"F1_sd":g["F1"]["sd"],"damage_pct_mean":g["normal_damage"]["mean"]*100 if g["normal_damage"]["mean"] is not None else None,"damage_pct_sd":g["normal_damage"]["sd"]*100 if g["normal_damage"]["sd"] is not None else None,"qualified_seeds":g["qualified_seeds"]})
 import matplotlib
 matplotlib.use("Agg")
 import matplotlib.pyplot as plt
 from matplotlib.font_manager import FontProperties
 font=Path("/root/fsas/home/anonymous/projects/EvidForge_Advisor_Study_20261021/reports/paper_ablation_tables_20261022/fonts")
 cn=FontProperties(fname=str(font/"SongtiSC-Regular.ttf"));bold=FontProperties(fname=str(font/"SongtiSC-Bold.ttf"));en=FontProperties(fname=str(font/"TimesNewRoman.ttf"))
 fig=plt.figure(figsize=(180/25.4,115/25.4),dpi=150,facecolor="white");ax=fig.add_axes([.035,.19,.93,.62]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
 fig.text(.035,.955,"教学与校验联合预算敏感性（三种子）",fontproperties=bold,fontsize=11)
 fig.text(.035,.90,"每格上行：修复 F1 ↑；下行：正常误改率（%）↓。均值 ± 样本标准差。",fontproperties=cn,fontsize=8)
 ax.plot([0,1],[.98,.98],color="black",lw=1);ax.plot([0,1],[.865,.865],color="black",lw=.65)
 ax.text(.005,.92,"数据集",fontproperties=cn,fontsize=9,va="center")
 xs=[.35,.61,.87]
 for n,x in zip([5,10,20],xs):ax.text(x,.92,str(n)+" + "+str(n)+" 组",fontproperties=cn,fontsize=8.5,ha="center",va="center")
 numeric=[]
 for i,d in enumerate(LABELS):
  y=.79-i*.13;gs=[lookup[d,n] for n in [5,10,20]];mark="†" if any(g["qualified_seeds"]<3 for g in gs) else ""
  ax.text(.005,y,LABELS[d]+mark,fontproperties=en,fontsize=9,va="center")
  for g,x in zip(gs,xs):
   t=ax.text(x,y,fmt(g,"F1")+"\n"+fmt(g,"normal_damage"),fontproperties=en,fontsize=9,ha="center",va="center",linespacing=1.4);numeric.append((t,x))
 ax.plot([0,1],[.055,.055],color="black",lw=1)
 fig.text(.035,.13,"每档为学习组 + 独立校验组；同一 seed 三档共用固定60组正式测试。",fontproperties=cn,fontsize=7.5)
 fig.text(.035,.085,"† 含预定研究 prior；各档实际行数、标注格数和外校资格见完整结果。",fontproperties=cn,fontsize=7.5)
 fig.text(.035,.04,"组数指独立实体组。原候选与安全要求保持；三种子差异不解释为统计显著。",fontproperties=cn,fontsize=7.5)
 fig.canvas.draw();rr=fig.canvas.get_renderer()
 for t,x in numeric:
  b=t.get_window_extent(rr);bb=ax.transData.inverted().transform([[b.x0,b.y0],[b.x1,b.y1]])
  assert bb[0,0]>=x-.13 and bb[1,0]<=x+.13
 paths=[]
 with plt.rc_context({"pdf.fonttype":42,"ps.fonttype":42,"svg.fonttype":"none"}):
  for ext in ["png","pdf","svg"]:
   p=ROOT/"reports"/("example_budget_table."+ext);fig.savefig(p,dpi=600,facecolor="white");paths.append(p)
 plt.close(fig)
 assert sha(ROOT/"reports/all_scores.json")==scorehash
 save(ROOT/"audit/figure_files_qa.json",{"files":{str(p.relative_to(ROOT)):sha(p) for p in paths},"size_mm":[180,115],"dpi_png":600,"numeric_column_overflow":False,"actual_visual_check":"PENDING","manuscript_integration":"not performed"})
 save(ROOT/"status/delivery_files_ready.json",{"at":time.time(),"independent_stats":"PASS","visual_QA_pending":True,"no_rescoring":True})
 print("INDEPENDENT_REVIEW_AND_TABLE_READY",flush=True)
if __name__=="__main__":main()
