import sys,runpy
from pathlib import Path
from runtime import install
install()
from common import ENGINE
runpy.run_path(str(ENGINE/'application/native_tools.py'),run_name='__main__')
