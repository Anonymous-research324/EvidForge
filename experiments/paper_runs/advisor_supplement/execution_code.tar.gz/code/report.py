"""汇总均值±样本SD、配对差值、实际成本和Excel；不改指标或筛掉反例。"""
from pathlib import Path
import statistics,collections,time,json
from common import ROOT,load,save
def stat(vals):
 good=[v for v in vals if v is not None]
 return {"mean":statistics.mean(good) if len(good)==3 else None,"sd":statistics.stdev(good) if len(good)==3 else None,"n":len(good),"seed_values":vals}
def flat(row,prefix=""):
 out={}
 for k,v in row.items():
  key=prefix+str(k)
  if isinstance(v,dict):out.update(flat(v,key+"_"))
  elif isinstance(v,list):out[key]=json.dumps(v,ensure_ascii=False)
  else:out[key]=v
 return out
def build(results):
 groups=collections.defaultdict(list)
 for r in results:groups[(r["suite"],r["dataset"],r["rate"],r["error_type"],r["learning_fraction"],r["arm"])].append(r)
 ag=[]
 for k,rs in groups.items():
  item=dict(zip(["suite","dataset","rate","error_type","learning_fraction","arm"],k));by={r["seed"]:r for r in rs}
  for m in ["P","R","F1","normal_damage","detection_AUC"]:item[m]=stat([by.get(s,{}).get("repair",{}).get(m) for s in [1013,1014,1015]])
  for m in ["macro_F1","AUC","R2","MAE"]:item[m]=stat([(by.get(s,{}).get("downstream") or {}).get(m) for s in [1013,1014,1015]])
  ag.append(item)
 save(ROOT/"reports/aggregate.json",ag)
 paired=[]
 for r in results:
  if r["arm"] in ["full","reuse"]:continue
  full=next((q for q in results if q["id"]==r["id"] and q["arm"]=="full"),None)
  if full:
   paired.append({"case":r["id"],"seed":r["seed"],"suite":r["suite"],"dataset":r["dataset"],"arm":r["arm"],"F1_full_minus_arm":full["repair"]["F1"]-r["repair"]["F1"],"damage_full_minus_arm":full["repair"]["normal_damage"]-r["repair"]["normal_damage"] if full["repair"]["normal_damage"] is not None and r["repair"]["normal_damage"] is not None else None})
 save(ROOT/"reports/paired_differences.json",paired)
 def f(x):return "N/A(n="+str(x["n"])+"/3)" if x["mean"] is None else f'{x["mean"]:.3f} ± {x["sd"]:.3f}'
 lines=["# EvidForge 导师补充实验：真实结果","", "三个种子等权均值±样本SD；N/A不填0。旧表1表2保持原值，代表表不是新盲测。",""]
 for suite in ["main","natural","sample_size","robustness"]:
  lines+=["## "+suite,"","|数据集|条件|污染率/类型|教学比例|修复F1|正常误改率|分类宏F1或回归R²|","|---|---|---|---|---|---|---|"]
  for r in ag:
   if r["suite"]==suite:lines.append("|"+"|".join([r["dataset"],r["arm"],str(r["rate"])+"/"+r["error_type"],str(r["learning_fraction"]),f(r["F1"]),f(r["normal_damage"]),f(r["macro_F1"] if r["dataset"]=="car_evaluation" else r["R2"])])+"|")
 (ROOT/"reports/补充实验完整结果.md").write_text("\n".join(lines)+"\n")
 # Real model usage; local weights do not have an invented dollar API price.
 cost=[]
 for req in sorted((ROOT/"services").glob("gpu*/requests/*")):
  if not (req/"response.json").exists():continue
  a=load(req/"request.json");b=load(req/"response.json");cost.append({"tag":req.name,"seed":a["seed"],"model":a["model"],"temperature":a["temperature"],"input_tokens":b.get("usage",{}).get("prompt_tokens"),"output_tokens":b.get("usage",{}).get("completion_tokens"),"seconds":load(req/"timing.json")["seconds"]})
 save(ROOT/"reports/actual_model_costs.json",cost)
 import openpyxl
 from openpyxl.styles import Font,PatternFill,Alignment
 wb=openpyxl.Workbook();wb.remove(wb.active)
 for title,data in [("逐种子原始指标",results),("三种子汇总",ag),("配对差值",paired),("模型调用成本",cost)]:
  data=[flat(row) for row in data]
  ws=wb.create_sheet(title);keys=list(dict.fromkeys(k for row in data for k in row))
  ws.append(keys)
  for row in data:ws.append([json.dumps(row.get(k),ensure_ascii=False) if isinstance(row.get(k),(dict,list)) else row.get(k) for k in keys])
  ws.freeze_panes="A2";ws.auto_filter.ref=ws.dimensions
  for c in ws[1]:c.font=Font(bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="245D87")
  for column in ws.columns:ws.column_dimensions[column[0].column_letter].width=min(55,max(12,max(len(str(c.value or "")) for c in list(column)[:80])+2))
 ws=wb.create_sheet("原表1表2保留")
 ws.append(["说明","来源"])
 ws.append(["原表1表2不重算覆盖；以下为原三种子正式记录","EvidForge_Paper_Release_20261020/repository/results/recorded"])
 for kind in ["repair","downstream"]:
  for seed in [1013,1014,1015]:
   for row in load(ROOT.parent/f"EvidForge_Paper_Release_20261020/repository/results/recorded/{kind}_seed{seed}.json"):ws.append([kind+"/"+str(seed),json.dumps(row,ensure_ascii=False)])
 ws=wb.create_sheet("案例与失败")
 ws.append(["case","记录"])
 for p in sorted((ROOT/"cases").glob("*/case_studies.json")):
  for r in load(p):ws.append([p.parent.name,json.dumps(r,ensure_ascii=False)])
 for p in sorted((ROOT/"cases").glob("*/status/*failure*.json")):ws.append([p.parent.parent.name,p.read_text()])
 wb.save(ROOT/"reports/EvidForge_导师补充实验汇总.xlsx")
 save(ROOT/"reports/delivery_manifest.json",{"at":time.time(),"aggregates":len(ag),"raw_rows":len(results),"actual_calls":len(cost)})
if __name__=="__main__":build(load(ROOT/"reports/all_scores.json"))
