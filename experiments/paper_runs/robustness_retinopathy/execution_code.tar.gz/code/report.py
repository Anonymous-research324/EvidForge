"""Read fixed per-seed scores, retain all conditions and compare with frozen Concrete."""
from pathlib import Path
import statistics,collections,time
from common import ROOT,load,save,sha
CONCRETE=ROOT.parent/"EvidForge_Advisor_Study_20261021"
def stat(v):
 n=sum(x is not None for x in v)
 return {"mean":statistics.mean(v) if n==3 else None,"sd":statistics.stdev(v) if n==3 else None,"n":n,"seed_values":v}
def build(results):
 assert len(results)==72
 groups=collections.defaultdict(list)
 for r in results:groups[(r["rate"],r["error_type"],r["arm"])].append(r)
 aggregate=[]
 for (rate,kind,arm),rs in groups.items():
  rs=sorted(rs,key=lambda x:x["seed"]);assert [r["seed"] for r in rs]==[1013,1014,1015]
  item={"dataset":"retinopathy","rate":rate,"error_type":kind,"arm":arm}
  for k in ["P","R","F1","normal_damage","detection_AUC"]:item[k]=stat([r["repair"][k] for r in rs])
  for k in ["macro_F1","AUC"]:item[k]=stat([(r.get("downstream") or {}).get(k) for r in rs])
  item["qualified_seeds"]=sum(load(ROOT/"cases"/r["id"]/"work/full/selection.json")["passed"] for r in rs) if arm=="full" else None
  aggregate.append(item)
 save(ROOT/"reports/aggregate.json",aggregate)
 old=load(CONCRETE/"reports/all_scores.json")
 table=[]
 for spec in load(ROOT/"configs/protocol.json")["conditions"]:
  rate,kind=spec["rate"],spec["type"]
  a=next(x for x in aggregate if x["rate"]==rate and x["error_type"]==kind and x["arm"]=="full")
  raw=sorted([x for x in old if x["dataset"]=="concrete" and x["arm"]=="full" and x["rate"]==rate and x["error_type"]==kind and x["suite"]==("main" if rate==.7 else "robustness")],key=lambda x:x["seed"])
  assert [x["seed"] for x in raw]==[1013,1014,1015]
  b={k:stat([x["repair"][k] for x in raw]) for k in ["F1","normal_damage"]}
  table.append({"rate":rate,"type":kind,"Retinopathy":a,"Concrete":b})
 save(ROOT/"reports/comparison_all_conditions.json",table)
 def fmt(x,scale=1):
  return "N/A("+str(x["n"])+"/3)" if x["mean"] is None else format(x["mean"]*scale,".3f")+" ± "+format(x["sd"]*scale,".3f")
 lines=["# 鲁棒性：Retinopathy替换Car的完整对照","","三种子均值±样本标准差。Retinopathy为新增实验，Concrete为已封存旧实验；所有条件保留。此为每污染条件重新学习后的适应性，不是固定技能零样本鲁棒性。","",
 "|污染条件|Retinopathy 修复F1 ↑|Concrete 修复F1 ↑|Retinopathy 正常误改% ↓|Concrete 正常误改% ↓|",
 "|---|---:|---:|---:|---:|"]
 labels={"blank":"空值","digit":"数字错误","scale":"倍率错误","affix":"前后缀错误","mixed":"混合错误"}
 for r in table:
  label=str(round(r["rate"]*100))+"% "+labels[r["type"]];a,b=r["Retinopathy"],r["Concrete"]
  lines.append("|"+label+"|"+"|".join([fmt(a["F1"]),fmt(b["F1"]),fmt(a["normal_damage"],100),fmt(b["normal_damage"],100)])+"|")
 lines+=["","Retinopathy1151行19特征，选用原因是观测取值丰富且24份输入均通过原教学/外校与内部隔离检查；不是按正式成绩挑选。Car原数据与9项保护失败记录保留，不修改其N/A。",
 "","Retinopathy本轮两台独立RTX4090 48GB TP1同9B；Concrete原实验三seed包含A100TP1/RTXTP2。按条件内公平配对，不用跨硬件耗时声称算法加速。",
 "","原独立外校未过的技能按既定研究prior回退，完整资格见aggregate.json；不是部署认证。零修改P未定义时保持None，F1=0是有效零修复结果；未知失败不得记0。"]
 (ROOT/"reports/鲁棒性_精简对照表.md").write_text("\n".join(lines)+"\n")
 costs=[]
 for req in sorted((ROOT/"services").glob("gpu*/requests/*")):
  a=load(req/"request.json");b=load(req/"response.json");t=load(req/"timing.json")
  costs.append({"tag":req.name,"seed":a["seed"],"model":a["model"],"temperature":a["temperature"],"usage":b.get("usage"),"seconds":t["seconds"]})
 save(ROOT/"reports/actual_model_costs.json",costs)
 save(ROOT/"status/reports_ready.json",{"rows":len(results),"aggregates":len(aggregate),"cost_requests":len(costs),"at":time.time(),"independent_review_and_visual_qa_pending":True})
