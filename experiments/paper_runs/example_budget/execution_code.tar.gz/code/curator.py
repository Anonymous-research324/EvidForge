"""Curator-only old reference access to build new nested group budgets; no performance selection."""
from pathlib import Path
import sys,json,random,copy,collections,time
from common import ROOT,load,save,sha,freeze,read_csv,write_csv
sys.dont_write_bytecode=True
P=ROOT.parent
NAMES=["tic_tac_toe","car_evaluation","retinopathy","real_estate","concrete","airfoil"]
def main():
 if (ROOT/"status/curator_started.json").exists():raise RuntimeError("Do not rerun curator")
 save(ROOT/"status/curator_started.json",{"pid":__import__("os").getpid(),"at":time.time()})
 cases=[];sourcehashes={};summary=[]
 for seed in [1013,1014,1015]:
  for name in NAMES:
   old=P/f"EvidForge_Downstream_Study_seed{seed}"/"datasets"/name
   paths=[old/"public/development_bundle.json",old/"public/declaration.json",old/"public/repair_dirty.csv",old/"private/repair_reference.csv"]
   sourcehashes.update({str(p):sha(p) for p in paths})
   bundle=load(paths[0]);schema=load(paths[1]);cols=schema["targets"]
   fields,dirty=read_csv(paths[2]);_,truth=read_csv(paths[3]);assert len(dirty)==len(truth)
   assert [r["entity_id"] for r in dirty]==[r["entity_id"] for r in truth]
   groups=collections.defaultdict(list);seen=set()
   for zone in ["learning","validation"]:
    for g in bundle[zone]:
     for r in g["records"]:
      key=r["row_key"];assert key not in seen;seen.add(key)
      assert set(r["dirty"])==set(fields)
      groups[r["dirty"]["entity_id"]].append(copy.deepcopy(r))
   for i,(d,t) in enumerate(zip(dirty,truth)):
    groups[d["entity_id"]].append({"row_key":name+"-oldrepair-"+str(i),"dirty":d,"truth":{c:t[c] for c in cols}})
   eligible={g:rs for g,rs in groups.items() if all(all(c in r["truth"] and r["truth"][c].strip() for c in cols) for r in rs)}
   assert len(eligible)>=100, (name,len(eligible))
   order=random.Random(seed).sample(sorted(eligible),100)
   master=[{"group":g,"provenance":"authorized paired existing source; newly sampled entity cohort; not blind source","records":eligible[g]} for g in order]
   cohort=ROOT/"cohorts"/(name+"_s"+str(seed));(cohort/"private").mkdir(parents=True)
   save(cohort/"private/master_groups.json",{"groups":master,"seed":seed,"original_holdout_excluded":True})
   targets={"learning":[g["group"] for g in master[:20]],"validation":[g["group"] for g in master[20:40]],"repair":[g["group"] for g in master[40:]]}
   assert len(set(sum(targets.values(),[])))==100
   save(cohort/"group_assignment.json",targets)
   formal=[r for g in master[40:] for r in g["records"]]
   for n in [5,10,20]:
    ident=f"budget_{name}_s{seed}_n{n}";c=ROOT/"cases"/ident;c.mkdir()
    for folder in ["public","private","work","outputs","status","logs"]:(c/folder).mkdir()
    b={"learning":copy.deepcopy(master[:n]),"validation":copy.deepcopy(master[20:20+n])}
    new_schema=copy.deepcopy(schema);new_schema["id"]=ident
    save(c/"public/development_bundle.json",b);save(c/"public/declaration.json",new_schema)
    save(c/"public/context.json",{"dataset":name,"source":"known-UCI-100-group-budget","seed":str(seed)})
    write_csv(c/"public/repair_dirty.csv",fields,[r["dirty"] for r in formal])
    write_csv(c/"private/repair_reference.csv",fields,[{**r["dirty"],**r["truth"]} for r in formal])
    meta={"id":ident,"dataset":name,"seed":seed,"suite":"example_budget","learning_groups":n,"validation_groups":n,"development_groups":2*n,"formal_groups":60,"cohort_groups":100,"eligible_original_groups":len(eligible),"old_holdout_not_used":True,"task":"repair_only","original_task":load(old/"public/dataset_metadata.json")["task"],
    "zones":{z:{"groups":len(gs),"rows":sum(len(g["records"]) for g in gs),"confirmed_target_cells":sum(len(r["truth"]) for g in gs for r in g["records"])} for z,gs in b.items()},
    "formal_rows":len(formal),"formal_target_cells":len(formal)*len(cols),"unused_development_groups":40-2*n,"previously_seen_source":True,"pollution":"unchanged old dirty literals; nominal original70%; actual subset rate scored only after output freeze","categorical_columns":load(old/"public/dataset_metadata.json")["categorical_columns"]}
    save(c/"case.json",meta);save(c/"public/dataset_metadata.json",meta)
    save(c/"input_freeze.json",{"public":freeze(c/"public"),"private":freeze(c/"private"),"case_sha256":sha(c/"case.json")})
    cases.append(ident);summary.append(meta)
   base=ROOT/"cases"/f"budget_{name}_s{seed}_n5"
   for n in [10,20]:
    c=ROOT/"cases"/f"budget_{name}_s{seed}_n{n}"
    assert sha(base/"public/repair_dirty.csv")==sha(c/"public/repair_dirty.csv")
    assert sha(base/"private/repair_reference.csv")==sha(c/"private/repair_reference.csv")
 for p,h in sourcehashes.items():assert sha(p)==h
 save(ROOT/"configs/cases.json",cases)
 save(ROOT/"audit/curation_summary.json",{"cases":summary,"source_files_sha256":sourcehashes,"model_calls":0,"original_source_data_unchanged":True,"labels_used_by_curator_to_construct_new_inputs":True,"formal_performance_used":False})
 save(ROOT/"audit/all_inputs_frozen.json",{"cases":{n:sha(ROOT/"cases"/n/"input_freeze.json") for n in cases},"at":time.time()})
 save(ROOT/"status/curator_closed.json",{"cases":len(cases),"cohorts":18,"same_test_in_each_tier":True,"model_calls":0})
 print("CURATOR_CLOSED",len(cases),flush=True)
if __name__=="__main__":main()
