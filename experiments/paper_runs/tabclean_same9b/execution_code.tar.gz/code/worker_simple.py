"""每case完整配对学习与执行；不读取正式参考，失败保留并阻止评分。"""
from pathlib import Path
import argparse,os,sys,subprocess,shutil,time,json,copy
from common import ROOT,ENGINE,PY,load,save,freeze,read_csv,write_csv,status,sha
WRAP=ROOT/"code/ef-python-serialization-v3"
def run(cmd,log,env):
 cmd=[str(ROOT/"code/native_v3.py") if str(x)==str(ROOT/"code/native.py") else x for x in cmd]
 log=Path(log);log.parent.mkdir(parents=True,exist_ok=True)
 with log.open("x") as f:r=subprocess.run(list(map(str,cmd)),cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError("Stage failed: "+str(log))
def seal_off(skill):
 cfg=load(skill/"configuration.json");cfg["base_skill_path"]=str((skill/"base_skill").resolve());save(skill/"configuration.json",cfg)
 save(skill/"no_llm_receipt.json",{"actual_calls":0,"generated_program":False,"source_only_fit":True})
 save(skill/"manifest.json",{"files":freeze(skill),"format_version":cfg["format_version"],"status":"pending_independent_validation"})
def native(case,skill,arm,kind,env):
 stage=case/"work"/arm/(kind+"_stage");logs=case/"logs"/arm
 if not stage.exists():run([WRAP,ENGINE/"tools/stage_native.py","--prepared",skill,"--out",stage],logs/(kind+"_stage.log"),env)
 ne={**env,"EVIDFORGE_NATIVE_STAGE":str(stage),"EVIDFORGE_NATIVE_VARIANT":"no_feedback" if arm=="no_feedback" else "full"}
 if arm=="no_feedback":
  st=load(case/"work/full"/(kind+"_stage/work/hypothesis_state.json"));ne["EVIDFORGE_PROPOSAL_TARGET"]=str(st["attempted_proposals"])
 tag=("Semantic"+case.name+arm+kind).replace("_","").replace("-","")
 if not (stage/"native_v3/result.json").exists():
  if (stage/"native_v3").exists():raise RuntimeError("Partial native directory requires per-call review; do not replay")
  run([PY,ROOT/"code/native_v3.py","--work",stage/"work","--out",stage/"native_v3","--codex","/root/fsas/home/anonymous/bin/codex","--remote-helper",ROOT/"code/model_service.py","--tag",tag],logs/(kind+"_native_v3.log"),ne)
 r=load(stage/"native_v3/result.json")
 if not r["closed"] or r["native_exit_code"] or r["synthetic_control_count"]:raise ValueError("Incomplete/nonreal native session")
 if not (skill/"manifest.json").exists():run([WRAP,ENGINE/"tools/seal_skill.py","--skill",skill,"--native",stage/"native_v3"],logs/(kind+"_seal.log"),env)
 return r
def assess(case,skill,kind,arm,env):
 folder=case/"work"/arm/(kind+"_external")
 existing=case/"work"/arm/(kind+"_assessment/assessment.json")
 if existing.exists():return load(existing)
 if (folder/"assessment_started.json").exists():raise RuntimeError("Validation interrupted; fixed-output recovery required")
 folder.mkdir(exist_ok=True)
 onboarding=case/"work"/arm/"onboarding"
 for n in ["heldout_validation_local.json","learning_only_bundle.json","partition_freeze.json","declaration.json","context.json"]:shutil.copyfile(onboarding/n,folder/n)
 log=case/"logs"/arm
 if not (folder/"assessment_freeze.json").exists():run([WRAP,ENGINE/"repair_platform.py","freeze-validation","--workflow",folder,"--skill",skill],log/(kind+"_freeze.log"),env)
 out=case/"work"/arm/(kind+"_assessment")
 run([WRAP,ENGINE/"repair_platform.py","validate","--workflow",folder,"--out",out],log/(kind+"_assessment.log"),env)
 return load(out/"assessment.json")
def learn(case,arm,env):
 t=time.monotonic();base=case/"work"/arm
 if (base/"selection.json").exists() and (base/"learning_freeze.json").exists():return
 base.mkdir(parents=True,exist_ok=True)
 pub=case/"public";wf=base/"onboarding";logs=case/"logs"/arm
 en={**env,"EF_ARM":arm}
 if not (wf/"prior_prepared/prepared_manifest.json").exists():
  if wf.exists():
   if not (wf/"prior_prepared/base_skill/manifest.json").exists():raise RuntimeError("Unknown partial source fit; independent review required")
   run([PY,ROOT/"code/resume_source_v5.py","--case",case,"--arm",arm],logs/"prepare_continuation_v4.log",en)
  else:
   run([WRAP,ENGINE/"repair_platform.py","prepare-heldout","--labels",pub/"development_bundle.json","--declaration",pub/"declaration.json","--context",pub/"context.json","--out",wf],logs/"prepare.log",en)
 prior=wf/"prior_prepared"
 # Exact pre-native checkpoint, with no historical/generated model input.
 if arm=="full" and not (case/"work/no_llm/selection.json").exists():
  checkpoint=case/"work/no_llm";checkpoint.mkdir()
  shutil.copytree(wf,checkpoint/"onboarding")
  seal_off(checkpoint/"onboarding/prior_prepared")
  noenv={**env,"EF_ARM":"full"}
  ar=assess(case,checkpoint/"onboarding/prior_prepared","prior","no_llm",noenv)
  save(checkpoint/"selection.json",{"kind":"prior","skill":str(checkpoint/"onboarding/prior_prepared"),"passed":ar["passed"],"candidate_assessments":{"prior":ar},"actual9B_calls":0,"pre_native_checkpoint":True})
  save(checkpoint/"learning_freeze.json",{"files":freeze(checkpoint),"actual9B_calls":0})
 receipts={"prior":native(case,prior,arm,"prior",en)}
 context=base/"context"
 if not (context/"prepared_manifest.json").exists():run([WRAP,ENGINE/"repair_platform.py","prepare-context","--prior",prior,"--out",context],logs/"context_prepare.log",en)
 receipts["context"]=native(case,context,arm,"context",en)
 results={k:assess(case,s,k,arm,en) for k,s in [("prior",prior),("context",context)]}
 passed=[k for k in results if results[k]["passed"]]
 chosen=max(passed,key=lambda k:(results[k]["metrics"]["F1"],k=="prior")) if passed else "prior"
 save(base/"selection.json",{"kind":chosen,"skill":str(prior if chosen=="prior" else context),"passed":bool(passed),"candidate_assessments":results,"native":receipts,"seconds":time.monotonic()-t})
 save(base/"learning_freeze.json",{"files":freeze(base)})
def execute(case,arm,env,skill=None,offset=0.):
 out=case/"outputs"/arm
 if (out/"output_freeze.json").exists():
  for rel,h in load(out/"output_freeze.json")["files"].items():assert sha(out/rel)==h
  return
 if out.exists():raise FileExistsError("Partial output requires review")
 e={**env,"EF_ARM":arm if arm in ["no_transforms","no_generated_execution","no_final_gate","no_predictive_context"] else "full","EF_CONF_OFFSET":str(offset)}
 sel=load(case/"work"/("full" if skill is None else arm)/"selection.json") if skill is None else None
 if skill is None:skill=sel["skill"]
 run([PY,ROOT/"code/worker_simple.py","execute","--case",case,"--arm",arm,"--skill",skill],case/"logs"/(arm+"_execute.log"),e)
def execute_impl(case,arm,skill):
 from runtime_serialization_v3 import install
 install()
 from workflow.packages import execute as repair
 fields,rows=read_csv(case/"public/repair_dirty.csv");out=case/"outputs"/arm;out.mkdir(parents=True,exist_ok=False)
 t=time.monotonic();output,ds=repair(rows,skill);elapsed=time.monotonic()-t
 if len(rows)!=len(output) or any(set(r)!=set(fields) for r in output):raise ValueError("Output shape/fields changed")
 targets=set(load(case/"public/declaration.json")["targets"])
 if any(a[c]!=b[c] for a,b in zip(rows,output) for c in fields if c not in targets):raise ValueError("Protected value changed")
 write_csv(out/"repair_output.csv",fields,output);save(out/"decisions.json",ds)
 selected=Path(skill);source=load(selected/"source_freeze.json")
 # Learning-only coverage and admitted new-action diagnostics; no formal truth.
 summary={"arm":arm,"seconds":elapsed,"rows":len(rows),"changed_cells":sum(a[c]!=b[c] for a,b in zip(rows,output) for c in targets),"new9B_calls":0,"skill":str(skill),"seed":int(os.environ["EF_SEED"]),"formal_reference_read":False}
 save(out/"receipt.json",summary);save(out/"output_freeze.json",{"files":freeze(out)})
 if arm=="full":
  reuse=case/"outputs/reuse";reuse.mkdir()
  t=time.monotonic();again,_=repair(rows,skill);secs=time.monotonic()-t
  write_csv(reuse/"repair_output.csv",fields,again)
  if (reuse/"repair_output.csv").read_bytes()!=(out/"repair_output.csv").read_bytes():raise ValueError("Reuse byte parity failed")
  save(reuse/"receipt.json",{"seconds":secs,"new9B_calls":0,"byte_parity":True,"same_input":True});save(reuse/"output_freeze.json",{"files":freeze(reuse)})
def case_run(case,gpu):
 from runtime import guard
 guard()
 meta=load(case/"case.json");env={**os.environ,"EF_SEED":str(meta["seed"]),"EF_GPU":str(gpu),"OMP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","MKL_NUM_THREADS":"2","PYTHONDONTWRITEBYTECODE":"1"}
 if (case/"status/closed.json").exists():return
 if (case/"status/owner.json").exists():
  pid=load(case/"status/owner.json")["pid"];f=Path("/proc")/str(pid)/"cmdline"
  if f.exists() and b"worker" in f.read_bytes():raise RuntimeError("Original case still active")
 save(case/"status/recovery_owner_v4.json",{"pid":os.getpid(),"gpu":gpu,"started":time.time()})
 learn(case,"full",env);selected=load(case/"work/full/selection.json")
 execute(case,"full",env)
 arms=["full","reuse"]
 if meta["suite"] in ["main","natural","semantic_controlled"]:
  for arm in ["no_transforms","no_generated_execution","no_final_gate"]:execute(case,arm,env)
  arms+=["no_transforms","no_generated_execution","no_final_gate"]
  for arm in ["no_feedback","no_predictive_context"]:
   learn(case,arm,env);execute(case,arm,env,load(case/"work"/arm/"selection.json")["skill"]);arms.append(arm)
 if meta["suite"]=="main":
  for delta in [-.10,-.05,.05,.10]:
   arm="threshold_"+str(delta).replace("-","m").replace(".","p");execute(case,arm,env,selected["skill"],delta);arms.append(arm)
 save(case/"status/closed.json",{"arms":arms,"at":time.time(),"formal_reference_read":False})
def main():
 p=argparse.ArgumentParser();p.add_argument("action",choices=["case","execute"]);p.add_argument("--case",required=True);p.add_argument("--gpu",type=int,default=0);p.add_argument("--arm");p.add_argument("--skill");a=p.parse_args();case=Path(a.case)
 if a.action=="execute":execute_impl(case,a.arm,Path(a.skill))
 else:
  try:case_run(case,a.gpu)
  except Exception as e:
   import traceback
   save(case/"status/recovery_failure_v4.json",{"error":repr(e),"traceback":traceback.format_exc(),"at":time.time()});raise
if __name__=="__main__":main()
